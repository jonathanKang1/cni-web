Ext.define('cni.view.main.Main', {
    extend: 'Ext.panel.Panel',
    xtype: 'app-main',

    /*requires: [
        'Ext.plugin.Viewport',
        'Ext.window.MessageBox',

        'cni.controller.main.MainController',
        //'cni.model.main.MenuModel',
        //'cni.view.main.List'
    ],*/

    controller: 'main.mainController',
    viewModel: 'main.menuModel',

    layout: 'border',
    bodyBorder: false,
    
    header: {
    	iconCls : 'x-fa fa-desktop',
    	title: '<font size="3">&nbsp;&nbsp;서해안기후환경연구소-마을대기측정망 관제시스템</font>',
    	items: [{
    		xtype: 'segmentedbutton',allowToggle: false,width: 170,height: 40,defaults: {},
            items: [{
            	iconCls: 'x-fa fa-home',cls: 'clsB',text: '',width: 40,tooltip: '클린에어충남',handler : function () {window.location.assign('/');}
            }/*,{
                iconCls: 'x-fa fa-desktop',text: '&nbsp;&nbsp;대시보드',name: 'dashboardCAIPanel',handler: 'fnMenuChange' 
            },{
            	iconCls : 'x-fa fa-search',text: '&nbsp;&nbsp;자료조회',
                menu: [
                    { iconCls : 'x-fa fa-list-ul', text: '&nbsp;&nbsp;측정자료조회', width : 158, name: 'dataPanel', handler: 'fnMenuChange'},
                    { iconCls : 'x-fa fa-list-ol', text: '&nbsp;&nbsp;측정자료조회2', width : 158, name: 'data2Panel', handler: 'fnMenuChange'},
                    { iconCls : 'x-fa fa-list-ol', text: '&nbsp;&nbsp;통합대기환경지수', width : 158, name: 'caiDataPanel', handler: 'fnMenuChange'},
                    { iconCls : 'x-fa fa-bell', text: '&nbsp;&nbsp;경보이력조회', width : 158, name: 'alertPanel', handler: 'fnMenuChange'},
                    { iconCls : 'x-fa fa-share-alt', text: '&nbsp;&nbsp;그래프조회', width : 158, name: 'graphPanel', handler: 'fnMenuChange'},
                    { iconCls : 'x-fa fa-share-square', text: '&nbsp;&nbsp;미수신조회', width : 158, name: 'receivePanel', handler: 'fnMenuChange'},
                    { iconCls : 'x-fa fa-compress', text: '&nbsp;&nbsp;자료비교', width : 158, name: 'comparePanel', handler: 'fnMenuChange'}
                ]
            },{
            	iconCls : 'x-fa fa-folder',text: '&nbsp;&nbsp;자료관리',
                menu: [
                    { iconCls: 'x-fa fa-tag', text: '&nbsp;&nbsp;이상자료관리', width : 158, name: 'managementPanel', handler: 'fnMenuChange'},
                    { iconCls: 'x-fa fa-download', text: '&nbsp;&nbsp;측정자료마감', width : 158, name: 'confirmPanel', handler: 'fnMenuChange'},
                    { iconCls: 'x-fa fa-clipboard', text: '&nbsp;&nbsp;마감자료조회', width : 158, name: 'confirmDataPanel', handler: 'fnMenuChange'},
                    { iconCls: 'x-fa fa-book', text: '&nbsp;&nbsp;보고서업로드', width : 158, name: 'reportPanel', handler: 'fnMenuChange'}
                ]
            },{
            	iconCls: 'x-fa fa-sliders',text: '&nbsp;&nbsp;분석통계',
                menu: [
                    { iconCls : 'x-fa fa-hourglass', text: '&nbsp;&nbsp;시간평균', width : 158, name: 'timePanel', handler: 'fnMenuChange'},
                    { iconCls : 'x-fa fa-list-ol', text: '&nbsp;&nbsp;일평균', width : 158, name: 'dayPanel', handler: 'fnMenuChange'},
                    { iconCls : 'x-fa fa-stack-overflow', text: '&nbsp;&nbsp;요일평균', width : 158, name: 'weekPanel', handler: 'fnMenuChange'},
                    { iconCls : 'x-fa fa-calendar', text: '&nbsp;&nbsp;월평균', width : 158, name: 'monthPanel', handler: 'fnMenuChange'}
                ]
            },{
                //xtype: 'splitbutton',
                iconCls: 'x-fa fa-cog',text: '&nbsp;&nbsp;시스템관리',
                menu: [
                    { iconCls: 'x-fa fa-home', text: '&nbsp;&nbsp;측정소관리', width : 158, name: 'tmsPanel', handler: 'fnMenuChange'},
                    { iconCls: 'x-fa fa-user', text: '&nbsp;&nbsp;사용자관리', width : 158, name: 'userPanel', handler: 'fnMenuChange'},
                    { iconCls : 'x-fa fa-flag', text: '&nbsp;&nbsp;기준값관리', width : 158, name: 'levelPanel', handler: 'fnMenuChange'},
                    { iconCls: 'x-fa fa-comment', text: '&nbsp;&nbsp;SMS관리', width : 158, name: 'smsPanel', handler: 'fnMenuChange'},
                    { iconCls : 'x-fa fa-share-square', text: '&nbsp;&nbsp;API관리', width : 158, name: 'apiPanel', handler: 'fnMenuChange'},
                    { iconCls : 'x-fa fa-inbox', text: '&nbsp;&nbsp;게시판관리', width : 158, name: 'noticeList', handler: 'fnMenuChange'},
                    { iconCls : 'x-fa fa-inbox', text: '&nbsp;&nbsp;보고서관리', width : 158, name: 'reportList', handler: 'fnMenuChange'},
                    { iconCls : 'x-fa fa-map', text: '&nbsp;&nbsp;방문기록', width : 158, name: 'visitList', handler: 'fnMenuChange'}
                ]
            }*/,{
            	iconCls: 'x-fa fa-key',cls: 'clsZ',text: '',width : 40,tooltip: 'Change Password',handler : 'fnChangePasswordWindow'
            },{
            	iconCls: 'x-fa fa-power-off',text: '',cls: 'clsZ',width : 40,tooltip: 'Logout',handler : 'fnLogout'
            },{
            	iconCls: 'x-fa fa-info-circle',text: '',cls: 'clsZ',width : 40,tooltip: '정보',handler: function() {Ext.widget('copyrightWindow');}
            }]
    	}],
    },
    /*tools:[{
    	xtype: 'button',iconCls: 'x-fa fa-home',cls: 'clsB',text: '',width : 50,scale: 'medium',tooltip: '클린에어충남',handler : function () {window.location.assign('/');}
    },{
    	xtype: 'button',iconCls: 'x-fa fa-desktop',text: '&nbsp;&nbsp;대시보드',scale: 'medium',width: 158,name: 'dashboardCAIPanel',handler: 'fnMenuChange' 
    },{
    	xtype: 'button',iconCls: 'x-fa fa-search',text: '&nbsp;&nbsp;자료조회',scale: 'medium',width: 158,
        menu: [
        	{ iconCls : 'x-fa fa-list-ul', text: '&nbsp;&nbsp;측정자료조회',width: 158, name: 'dataPanel', handler: 'fnMenuChange'}, 
        	{ iconCls : 'x-fa fa-list-ol', text: '&nbsp;&nbsp;측정자료조회2',width: 158, name: 'data2Panel', handler: 'fnMenuChange'}, 
        	{ iconCls : 'x-fa fa-list-ol', text: '&nbsp;&nbsp;통합대기환경지수',width: 158, name: 'caiDataPanel', handler: 'fnMenuChange'},
        	{ iconCls : 'x-fa fa-bell', text: '&nbsp;&nbsp;경보이력조회', width : 158, name: 'alertPanel', handler: 'fnMenuChange'},
            { iconCls : 'x-fa fa-share-alt', text: '&nbsp;&nbsp;그래프조회', width : 158, name: 'graphPanel', handler: 'fnMenuChange'},
            { iconCls : 'x-fa fa-share-square', text: '&nbsp;&nbsp;미수신조회', width : 158, name: 'receivePanel', handler: 'fnMenuChange'},
            { iconCls : 'x-fa fa-compress', text: '&nbsp;&nbsp;자료비교', width : 158, name: 'comparePanel', handler: 'fnMenuChange'}
        ]
    },{
    	xtype: 'button',iconCls: 'x-fa fa-folder',text: '&nbsp;&nbsp;자료관리',scale: 'medium', width: 158,
        menu: [
            { iconCls: 'x-fa fa-tag', text: '&nbsp;&nbsp;이상자료관리',width: 158, name: 'managementPanel', handler: 'fnMenuChange'},
            { iconCls: 'x-fa fa-download', text: '&nbsp;&nbsp;측정자료마감', name: 'confirmPanel', handler: 'fnMenuChange'},
            { iconCls: 'x-fa fa-clipboard', text: '&nbsp;&nbsp;마감자료조회', name: 'confirmDataPanel', handler: 'fnMenuChange'},
            { iconCls: 'x-fa fa-book', text: '&nbsp;&nbsp;보고서업로드', name: 'reportPanel', handler: 'fnMenuChange'}
        ]
    },{
    	xtype: 'button',iconCls: 'x-fa fa-sliders',text: '&nbsp;&nbsp;분석통계',scale: 'medium', width: 158,
        menu: [
            { iconCls : 'x-fa fa-hourglass', text: '&nbsp;&nbsp;시간평균', width : 158, name: 'timePanel', handler: 'fnMenuChange'},
            { iconCls : 'x-fa fa-list-ol', text: '&nbsp;&nbsp;일평균', width : 158, name: 'dayPanel', handler: 'fnMenuChange'},
            { iconCls : 'x-fa fa-stack-overflow', text: '&nbsp;&nbsp;요일평균', width : 158, name: 'weekPanel', handler: 'fnMenuChange'},
            { iconCls : 'x-fa fa-calendar', text: '&nbsp;&nbsp;월평균', width : 158, name: 'monthPanel', handler: 'fnMenuChange'}
        ]
    },{
    	xtype: 'button',iconCls: 'x-fa fa-cog',text: '&nbsp;&nbsp;시스템관리',scale: 'medium', width: 158,
        menu: [
            { iconCls: 'x-fa fa-home', text: '&nbsp;&nbsp;측정소관리', width : 158, name: 'tmsPanel', handler: 'fnMenuChange'},
            { iconCls: 'x-fa fa-user', text: '&nbsp;&nbsp;사용자관리', width : 158, name: 'userPanel', handler: 'fnMenuChange'},
            { iconCls : 'x-fa fa-flag', text: '&nbsp;&nbsp;기준값관리', width : 158, name: 'levelPanel', handler: 'fnMenuChange'},
            { iconCls: 'x-fa fa-comment', text: '&nbsp;&nbsp;SMS관리', width : 158, name: 'smsPanel', handler: 'fnMenuChange'},
            { iconCls : 'x-fa fa-share-square', text: '&nbsp;&nbsp;API관리', width : 158, name: 'apiPanel', handler: 'fnMenuChange'},
            { iconCls : 'x-fa fa-inbox', text: '&nbsp;&nbsp;게시판관리', width : 158, name: 'noticeList', handler: 'fnMenuChange'},
            { iconCls : 'x-fa fa-inbox', text: '&nbsp;&nbsp;보고서관리', width : 158, name: 'reportList', handler: 'fnMenuChange'},
            { iconCls : 'x-fa fa-map', text: '&nbsp;&nbsp;방문기록', width : 158, name: 'visitList', handler: 'fnMenuChange'}
        ]
    }, {
    	xtype: 'button',iconCls: 'x-fa fa-key',cls: 'clsZ',text: '',width : 40,scale: 'medium',tooltip: 'Change Password',handler : 'fnChangePasswordWindow'
    }, {
    	xtype: 'button',iconCls: 'x-fa fa-power-off',text: '',cls: 'clsZ',width : 40,scale: 'medium',tooltip: 'Logout',handler : 'fnLogout'
    }, {
    	xtype: 'button',iconCls: 'x-fa fa-info-circle',text: '',cls: 'clsZ',width : 40,scale: 'medium',tooltip: '정보',handler: function() {Ext.widget('copyrightWindow');}
    }],*/
    
    /*tools:[{
        //xtype: 'button',
        tooltip: 'Change Password',
        iconCls: 'x-fa fa-key',
        handler : 'fnChangePasswordWindow'
    },{
        tooltip: 'Logout',
        iconCls: 'x-fa fa-power-off',
        handler : 'fnLogout'
    }],*/

    items: [{
        region: 'west',
        iconCls : 'x-fa fa-list-ul',
        title: '메뉴',
        itemId: 'menu_panel',
        margin: '2 2 0 0',
        width: 220, minWidth: 200, maxWidth: 250,
        floatable: false,
        collapsed: true,
        collapsible: true,
        //split: true,
        reference: 'treelistContainer',
        layout: 'fit',
        border: true,
        //bodyPadding: 10,
        bodyPadding: 0,
        scrollable: true,
        items: [{
            xtype: 'treelist',
            reference: 'treelist',
            expanderOnly: false,
            listeners : {
				selectionchange : 'onSelectionchange'
			},
            bind: '{navItems}'
        }],
        bbar:[{
        	xtype: 'button',
        	text: 'System Info',
        	iconCls : 'x-fa fa-info-circle',
        	flex: 1,
        	//handler : 'fnViewCopyright'
        	handler: function() {Ext.widget('copyrightWindow');}
        }]
    },{
    	region: 'center',
        xtype: 'panel',
        collapsible: false,
        margin: '2 0 0 0',
        //bodyPadding: 10,
        flex: 1,
		layout : 'fit',
		//bodyStyle: 'background:#eee;',
		items : {
        	xtype: 'mainImagePanel'
    	}
        
    }],
    
    listeners: {
    	beforerender: function (obj, eOpts) {
    		var agent = navigator.userAgent.toLowerCase();
        	if ((navigator.appName == 'Netscape' && navigator.userAgent.search('Trident') != -1) || (agent.indexOf("msie") != -1) ) {
        		Ext.toast('인터넷 익스플로러 브라우저의 경우  화면 및 기능이 정상동작 하지 않을 수 있습니다.<br/> 엣지 또는 크롬 등 다른 브라우져를 사용하시기 바랍니다.');
            }
        	
    		/*var treelist = this.lookupReference('treelist'),
            ct = this.lookupReference('treelistContainer');

	        //treelist.setExpanderFirst(!pressed);
    		treelist.setExpanderFirst(false);
	        //treelist.setUi(pressed ? 'nav' : null);
    		treelist.setUi('nav');
	        treelist.setHighlightPath(true);
	        //ct[pressed ? 'addCls' : 'removeCls']('treelist-with-nav');
    		ct['addCls']('treelist-with-nav');
	
	        if (Ext.isIE8) {
	            this.repaintList(treelist);
	        }*/
	        
	        Ext.Ajax.request({
        		url : '/system/getLoginInfo.ax',
        		method : 'POST',
        		success : function(res){
        			var result = Ext.decode(res.responseText);           
        			if (result['code'] == 404) {
        				Ext.toast(result['msg']);
        				Ext.widget('loginWindow',{
        					center: obj.down('component[region=center]')
        				});
        			} else {
        				cni.app.soundYN = result['SOUND_YN'];
        				cni.app.alertYN = result['ALERT_YN'];
        				cni.app.sTM = result['S_TM'];
        				cni.app.eTM = result['E_TM'];
        				cni.app.dashboardItem = result['DASHBOARD_ITEM'];
        				cni.app.dashboardItemNM = result['DASHBOARD_ITEM_NM'];

        				/*let center_page = Ext.util.History.getToken();
        				if (!center_page) center_page = 'dashboardCAIPanel';
        				cni.app.center = obj.down('component[region=center]');
        				obj.getController().onAfterRender(center_page);*/
        				var center = obj.down('component[region=center]');
        				center.removeAll(true);
        				center.add({
        					xtype : 'dashboardCAIPanel'
        				});
        			}
        		}
        	});
    	},
    	render: function(obj) {
    	},
    	boxready: function(obj) {
		},
        afterrender: function(obj, eOpts) {
        	//cni.app.mainPanel = this; 
        }
    }
});