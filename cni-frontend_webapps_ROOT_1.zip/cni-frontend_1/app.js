Ext.application({
    name: 'cni',

    extend: 'cni.Application',

    requires: [
    	'cni.view.main.Main',
        /*'Ext.chart.CartesianChart',
        'Ext.chart.axis.Numeric',
        'Ext.chart.axis.Category',
        'Ext.chart.series.Bar',
        'Ext.chart.interactions.ItemHighlight',
        'Ext.chart.interactions.PanZoom'*/
    ],

    /*전역변수 설정 cni.app.adminYN*/
    //그리드 오토스크롤 타임(초)
    scrollInterval: 3,
    //그리드 판엘 높이
    contentPanelHeigt: '',
    //망구분
    netCD: 'ALL',
    //지역코드
    regionCD: '',
    //측정소코드
    tmsCD: '',
    itemCd:'',
    //그리드 클릭시 해당 레코드 보관소
    clickRecord: '',
    
    /*알람설정*/
    //경보음
    soundYN: 'N',
    //경보창
    alertYN: 'N',
    //경보시간(동일경보 방지)
    alertTM: '',
    //경보음 허용시간
    sTM: '09',
    eTM: '20',
    
    dashboardItem: 'CAI',
    dashboardItemNM: '통합대기환경지수',
    
    mLoginYN: 'N',
    
    objTemp: null,
    taskTemp: null,
    
    dataType: 'H',
    storeTemp: null,
    
    center: null,
    
    // The name of the initial view to create. With the classic toolkit this class
    // will gain a "viewport" plugin if it does not extend Ext.Viewport. With the
    // modern toolkit, the main view will be added to the Viewport.
    //
    mainView: 'cni.view.main.Main'

    //-------------------------------------------------------------------------
    // Most customizations should be made to cni.Application. If you need to
    // customize this file, doing so below this section reduces the likelihood
    // of merge conflicts when upgrading to new versions of Sencha Cmd.
    //-------------------------------------------------------------------------
});
