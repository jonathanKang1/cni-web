Ext.define('cni.view.dashboard.RadarChart', {
	extend: 'Ext.panel.Panel',
    xtype: 'radarChart',
    controller: 'dashboard.radarChartController',
    border: true,
    layout: 'fit',  
    
    items: [{
        xtype: 'polar',
        reference: 'polar',
        id: 'id_polarChart',
        itemId: 'polarChart',
        width: '100%',
        height: 500,
        legend: {
            docked: 'right'
        },
        insetPadding: '40 40 60 40',
        interactions: ['rotate'],
        
        sprites: [{
            type: 'text',
            text: '시군별 대기질 현황 (24시간)',
            fontSize: 22,
            width: 100,
            height: 30,
            x: 40,
            y: 25
        }],
        
        axes: [{
            type: 'numeric',
            position: 'radial',
            fields: 'MSR_VL',
            grid: true,
            minimum: 0,
            maximum: 50,
            majorTickSteps: 50,
            //renderer: 'onAxisLabelRender'
        }, {
            type: 'category',
            position: 'angular',
            grid: true
        }],
        
        series: [{
            type: 'radar',
            title: 'Safari',
            angleField: 'month',
            radiusField: 'data4',
            style: {
                opacity: 0.40
            }
        }],
        
        /*store: {
	        type: 'comm.dataStore',
	        autoLoad: true,
			listeners : {
				beforeload: function(obj, records, successful, operation, eOpts) {
					obj.getProxy().setUrl('/dashboard/getDashboardRadarChartSeries.ax');
					obj.proxy.extraParams = {
					};
		    	},
				load: function(obj, records, successful, operation, eOpts) {
					var chart = Ext.getCmp('radarChart').down('#polarChart');
					var series = new Array();
	             	for (i = 0, len = records.length; i < len; ++i) {
	                 	series.push({
	                 		type: 'radar',
	                        title: records[i].get('DSP_DT'),
	                        angleField: 'DSP_DT',
	                        radiusField: 'REGION'+(i+1),
	                        style: {
	                            opacity: 0.40
	                        },
	                 		tooltip: {
	                 			trackMouse: true,
	                 			showDelay: 0,
	                 			dismissDelay: 0,
	                 			hideDelay: 0,
	                 			renderer: function (tooltip, record, item) {
	                 				//tooltip.setHtml('측정소: '+item.series.getTitle()+'<br/>측정값: '+record.get(item.series.getYField())+'<br/>시간: ' + Ext.Date.format(record.get(item.series.getXField()),'m-d H:i'));
	                 			}
	                 		}
	                 	});
	             	}
	             	chart.setSeries(series);
	             	chart.redraw();
				}
			}
	    },*/
	        
        listeners: {
        	afterrender: function() {
        		console.log(this.getId());
        		cni.app.objTemp = this;
        	}
        	//destroy: 'onChartDestroy'
        }
    }],
    
    listeners : {
    	beforerender: function (obj, eOpts) {
    	},
    	//afterrender: 'onChartRendered',
    	boxready : function(obj) {
		},
		resize: function (obj, width, height, oldWidth, oldHeight, eOpts) {
        },
		destroy: function(obj, eOpts) {
    	} 
    }
});