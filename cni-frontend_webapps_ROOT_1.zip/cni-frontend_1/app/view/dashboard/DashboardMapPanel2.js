Ext.define('cni.view.dashboard.DashboardMapPanel2', {
	extend: 'Ext.panel.Panel',
    xtype: 'dashboardMapPanel2',
    
    /*id: 'dashboardMapPanel',
    reference: 'dashboardMapPanel',
    alias: 'widget.dashboardMapPanel',*/
    
    title: '측정소현황',
    
    border: true,
    layout: 'fit',
    
    tools:[{
        //type:'gear',
    	iconCls : 'x-fa fa-wrench',
        itemId: 'tms_item_setting',
        tooltip: '설정',
        handler : function () {
        	//Ext.widget("dashboardMapDataConfigWindow");	
        }
    }],
    
    items: [{
    	html: '<iframe src="gmap.html?grp_cd=44180&item_cd=PMb&center_tms_cd=4418032025" width="100%" height="100%"></iframe>'
    }],
    
    listeners : {
    	afterrender : function (obj, eOpts) {
    		//Ext.getCmp('dashboardTMSPanel').setTitle('측정소현황 ('+WMS.app.dashBoardTMSItemNM+' 시간자료)');
    		//obj.setTitle('측정소현황 ('+cni.app.dashBoardTMSItemNM+(cni.app.tmsType=='S'?' 30분자료)':' 시간자료)'));
    		obj.setTitle('보령화력 (PM2.5 시간자료)');
    	}
    }
});

