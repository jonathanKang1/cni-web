Ext.define('cni.view.dashboard.DashboardCAIListWindow', {
	extend: 'Ext.window.Window',
    xtype: 'dashboardCAIListWindow', 
    
    //controller: 'system.userController',
    
    title: '통합대기환경지수 48h',
    
    width : 600,
    height: 800,
    closable : true,
    autoShow : true,
    modal : true,
    layout : 'fit',
    /*onEsc : function(){
    	return true;
    },*/
    
    items : [{
    	xtype: 'grid',
    	itemId: 'window_grid',
    	columns : [{
        	header : '측정시간',
        	flex : 1,
        	dataIndex : 'DSP_FM',
        	align: 'center'
        },{
        	header : '통합환경지수',
        	flex : 0.8,
        	dataIndex : 'CI_VL',
        	align: 'center',
        },{
        	header : '등급',
        	flex : 0.8,
        	dataIndex : 'CI_LV_NM',
        	align: 'center',
        	renderer: function(value, meta, record) {
                if (record.get('CI_LV') == 'A') {
                	value = "<span style='color:#0000ff;font-weight:bold;' >"+value+"</span>";
                } else if (record.get('CI_LV') == 'B') {
                	value = "<span style='color:#008080;font-weight:bold;' >"+value+"</span>";
                } else if (record.get('CI_LV') == 'C') {
                	value = "<span style='color:#ffa500;font-weight:bold;' >"+value+"</span>";
                } else if (record.get('CI_LV') == 'D') {
                	value = "<span style='color:#ff0000;font-weight:bold;' >"+value+"</span>";
                	//meta.css = 'level-D';
                } else {
                	//meta.css = 'monitor-list-column-value';
                }
                return value;
            }
        },{
        	header : '주오염물질',
        	flex : 1,
        	dataIndex : 'CI_ITEM_NM',
        	align: 'center',
        	//style: 'font-weight:bold;font-size:16px;',
        	renderer: function(value, meta, record) {
                if (record.get('CI_LV') > 'B') {
                	value = "<span style='color:#9400D3;font-weight:bold;' >"+value+"</span>";
                	//meta.css = 'msr-status-1';
                } else {
                	//meta.css = 'monitor-list-column-value';
                }
                return value;
            }
        }],
        store: {
        	type: 'comm.dataStore'
        },
    }],
    listeners : {
    	beforerender : function(obj, eOpts) {
    		Ext.StoreManager.lookup('comm.dataStore').load();
    	},
    	render: function(obj, eOpts) {
    	},
        afterrender: function(obj, eOpts) {
        	if (obj.config.tms_nm)
        		obj.setTitle('통합대기환경지수 48h ('+obj.config.tms_nm+')');
        	var store = Ext.StoreManager.lookup('comm.dataStore');
        	store.getProxy().setUrl('/dashboard/getDashboardRegionTMS24List.ax');
        	store.proxy.extraParams = {
        			msr_dt: obj.config.msr_dt,
        			tms_cd: obj.config.tms_cd,
        			item_cd: obj.config.item_cd
        	};
        	store.load();
        	
        	if (obj.config.item_cd != 'CAI') {
	        	var grid = obj.down('#window_grid');
	            grid.headerCt.getHeaderAtIndex(1).setText('환경지수');
	            grid.headerCt.getHeaderAtIndex(3).setText('지수항목');
        	}
        },
    	boxready : function(obj) {
		},
		destroy: function(obj, eOpts) {
    	}
    }

});

