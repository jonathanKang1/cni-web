Ext.define('cni.view.dashboard.DashboardCAIPanel', {
	extend: 'Ext.panel.Panel',
    xtype: 'dashboardCAIPanel',
    
    /*id: 'dashboardCAIPanel',
    reference: 'dashboardCAIPanel',
    alias: 'widget.dashboardCAIPanel',*/
    
    controller: 'dashboard.dashboardController',
    
    border: true,
    bodyBorder: false,
    layout: {
        type: 'hbox',
        pack: 'start',
        align: 'stretch'
    },
    
    //bodyPadding: 10,

    defaults: {
        //frame: true,
        //bodyPadding: 10
    },

    items: [{
    	xtype: 'panel',
    	flex: 1,
    	layout: {
            type: 'vbox',
            pack: 'start',
            align: 'stretch'
        },
        items: [{
        	xtype: 'panel',
        	itemId: 'row1',
        	title: '통합대기환경현항',
        	iconCls : 'x-fa fa-flag',
            flex: 4,
            //margin: '0 10 0 0',
            tools:[{
            	iconCls: 'x-fa fa-tag',
                //itemId:'bell',
                tooltip: '대기환경지수',
                handler : function (me) {
                	Ext.widget('dashboardCAIGuideWindow');
                }
            }],
        },{
        	xtype: 'panel',
        	itemId:'alert_panel',
        	flex: 1,
        	layout: {
                type: 'hbox',
                pack: 'start',
                align: 'stretch'
            },
        	items:[{
        		xtype: 'panel',
        		//title: '<font color="red">'+'가동율 : 98%'+'</font>',
        		title: '측정평균',
        		flex: 1,
        		border: true,
    	    	margin: '2 1 1 0',
    	    	header: {
    	    	    style: {
    	    	        backgroundColor: '#008080'
    	    	    }
    	    	},
        		items:[{
            		xtype: 'button',
            		itemId: 'btn1',
            		width: '100%', height: '100%', margin: '1 0 0 0',
            		text: '<p style="font-weight:bold; font-size:medium;">'+'통합대기환경지수'+'</P>'
            			+'<p style="font-weight:bold; font-size:medium;">'+'-'+'</P>',
            		cls: 'clsZ'
            	}]
        	},{
        		xtype: 'panel',
        		title: '측정상태',
        		flex: 2,
        		border: true,
    	    	margin: '2 1 1 0',
    	    	header: {
    	    	    style: {
    	    	        backgroundColor: '#008000'
    	    	    }
    	    	},
    	    	layout: {
                    type: 'hbox',
                    pack: 'start',
                    align: 'stretch'
                },
        		items:[{
            		xtype: 'button',
            		itemId: 'btn2',
            		width: '50%', height: '100%', margin: '1 0 0 0',
            		text: '<p style="font-weight:bold; font-size:medium;">'+'교정중 : -건'+'</P>'
            			+'<p style="font-weight:bold; font-size:medium;">'+'동작불량 : -건'+'</P>',
            		cls: 'clsZ'
            	},{
            		xtype: 'button',
            		itemId: 'btn3',
            		width: '50%', height: '100%', margin: '1 0 0 0',
            		text: '<p style="font-weight:bold; font-size:medium;">'+'전원단절 : -건'+'</P>'
            			+'<p style="font-weight:bold; font-size:medium;">'+'보수중 : -건'+'</P>',
            		cls: 'clsZ'
            	}]
        	},{
        		xtype: 'panel',
        		title: '기준초과',
        		flex: 1,
        		border: true,
    	    	margin: '2 1 1 0',
    	    	header: {
    	    	    style: {
    	    	        backgroundColor: 'orange'
    	    	    }
    	    	},
    	    	items:[{
            		xtype: 'button',
            		itemId: 'btn4',
            		width: '100%', height: '100%', margin: '1 0 0 0',
            		text: '<p style="font-weight:bold; font-size:medium;">'+'기준초과 : -건'+'</P>'
            			+'<p style="font-weight:bold; font-size:medium;">'+'나쁨 : -건'+'</P>'
            			+'<p style="font-weight:bold; font-size:medium;">'+'매우나쁨 : -건'+'</P>',
            		cls: 'clsZ'
            	}]
        	},{
        		xtype: 'panel',
        		title: '주의보/경보',
        		flex: 1,
        		border: true,
    	    	margin: '2 1 1 0',
    	    	header: {
    	    	    style: {
    	    	        backgroundColor: 'red'
    	    	    }
    	    	},
    	    	//bodyStyle:{'background-color':'#808080'},
    	    	items:[{
            		xtype: 'button',
            		itemId: 'btn5',
            		width: '100%', height: '100%', margin: '1 0 0 0',
            		text: '<p style="font-weight:bold; font-size:medium;">'+'주의보 : -건'+'</P>'
            			+'<p style="font-weight:bold; font-size:medium;">'+'경  보 : -건 '+'</P>',
            		cls: 'clsZ',
            		handler : function(btn, e, eOpts) {
            			var center = btn.up('app-main').down('component[region=center]');
        				center.removeAll(true);
        				center.add({
        					xtype : 'alertPanel'
        				});
            		}
            	}]
        	}],
        	listeners : {
        		afterrender : function (obj, eOpts) {
        			
        			obj.up('dashboardCAIPanel').getController('dashboardController').fnAjaxCall(obj);
        			
        			cni.app.objTemp = setInterval(function() {
        				
        				if (new Date().getMinutes() % 10 > 3) return true;
        				
        				obj.up('dashboardCAIPanel').getController('dashboardController').fnAjaxCall(obj);
        				
        			},60000);
        		},
        		destroy: function(obj, eOpts) {
        			if (cni.app.objTemp) {
        				clearInterval(cni.app.objTemp);
        				cni.app.objTemp = null;
        			}
        		}
        	}
        }]
    },{
    	xtype: 'dashboardCAIListPanel',
    	itemId: 'row2',
    	flex: 1
    }],
    
    listeners : {
    	beforerender: function (obj, eOpts) {
    		obj.down('#row1').setTitle('대기환경현항 ('+cni.app.dashboardItemNM+')');
    		obj.down('#row1').setHtml('<iframe src="now_map.html?v=6&item_cd='+cni.app.dashboardItem+'" width="100%" height="100%"></iframe>');
    		obj.down('#alert_panel')
    	},
    	afterrender : function (obj, eOpts) {
    	},
    	destroy: function(obj, eOpts) {
			if (cni.app.taskTemp) {
				clearInterval(cni.app.taskTemp);
				cni.app.taskTemp = null;
			}
		}
    }
});

