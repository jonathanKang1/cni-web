var viewSize = Ext.getBody().getViewSize();
Ext.define('cni.view.dashboard.DashboardCAIGraphWindow', {
	//extend: 'Ext.panel.Panel',
	extend: 'Ext.window.Window',
    xtype: 'dashboardCAIGraphWindow',
   
    controller: 'dashboard.dashboardCAIGraphController',
    
    title: '대기환경지수 24h 그래프',
    
    border: true,
    layout: 'fit',
 
    closable : true,
    maximizable: true,
    autoShow : false,
    modal : true,
    iconCls : 'x-fa fa-share-alt',
    renderTo: Ext.getBody(),
    onEsc : function(){
    	return false;
    },
    tools:[{
        //type:'gear',
    	iconCls : 'x-fa fa-save',
        tooltip: '그래프다운로드',
        handler : 'onDownload'
    },{
    	iconCls : 'x-fa fa-laptop',
        tooltip: '그래프보기',
        handler : 'onPreview'
    }],
    items: {
    	xtype: 'cartesian',
    	id: 'real_time_graph',
    	itemId: 'real_time_graph',
        reference: 'real_time_graph',
        insetPadding: '60 10 10 10',
        innerPadding: '10 10 10 10',
        legend: {
            docked: 'right'
        },
        // 그래프 확대축소 
        /*interactions: {
            type: 'panzoom',
            zoomOnPanGesture: true
        },*/
        animation: {
            duration: 200
        },
        axes: [{
        	
            type: 'numeric',
            minimum: 0,
            maximum: 50,
            grid: true,
            position: 'left',
            title: '측정값',
           	label: {fontSize: 10}
           	//renderer: 'onAxisLabelRender'
        },{
            type: 'time',
            //dateFormat: 'G:i:s',
            dateFormat: 'H:i',
            segmenter: {
                type: 'time',
                step: {
                    unit: Ext.Date.HOUR,
                    step: 1
                }
            },
            label: {fontSize: 10},
            grid: true,
            position: 'bottom',
            title: '측정시간',
            fields: ['DSP_DT'],
            majorTickSteps: 23        
        }],

        listeners: {
            //afterrender: 'onTimeChartRendered',
        	destroy: 'onTimeChartDestroy'
        }
    },
    
    listeners : {
    	beforerender: function (obj, eOpts) {
    		obj.setWidth(Ext.getBody().getViewSize().width-200);
    		obj.setHeight(Ext.getBody().getViewSize().height-100);
    		obj.setTitle((cni.app.dashboardItem=='CAI'?'통합대기환경지수':cni.app.dashboardItemNM+' 대기환경지수')+' 24h 그래프 ('+ obj.config.region_nm+')');
    		
    		var chart = this.lookupReference('real_time_graph').setSprites({
                type: 'text',
                text: obj.getTitle(),
                font: '20px Arial',
                x: 100, 
                y: 30  
        	});
    	},
    	afterrender: 'onTimeChartRendered',
    	boxready : function(obj) {
		},
		resize: function (obj, width, height, oldWidth, oldHeight, eOpts) {
        }, 
    }
});    