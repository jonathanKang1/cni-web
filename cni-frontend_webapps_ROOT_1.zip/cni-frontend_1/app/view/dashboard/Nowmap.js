Ext.define('cni.view.dashboard.Nowmap', {
	extend: 'Ext.panel.Panel',
    xtype: 'nowmap',
    
    border: true,
    layout: 'fit',
    
    //title: '',
    //iconCls : 'x-fa fa-flag',
    
    listeners : {
    	beforerender: function (obj, eOpts) {
    		//obj.setTitle(obj.config.grp_nm+' ( PM2.5 시간자료 )');
    		obj.setHtml('<iframe src="now_map.html?v=1&item_cd='+obj.config.item_cd+'" width="100%" height="100%"></iframe>');
    	},
    	afterrender : function (obj, eOpts) {
    	},
    	boxready : function(obj) {
		},
		resize: function (obj, width, height, oldWidth, oldHeight, eOpts) {
        },
		destroy: function(obj, eOpts) {
    	} 
    }
});

