var viewSize = Ext.getBody().getViewSize();
Ext.define('cni.view.dashboard.DashboardRegonPanel', {
	extend: 'Ext.window.Window',
    xtype: 'dashboardRegionPanel',
    
    title: '측정소현황',
    
    width: '100%',
    height: '100%',
    closable : true,
    maximizable: true,
    autoShow : false,
    modal : true,
    title : 'Log-in',
    //iconCls : 'x-fa fa-key',
    iconCls : 'x-fa fa-share-alt',
    renderTo: Ext.getBody(),
    onEsc : function(){
    	return false;
    },
    
    border: true,
    layout: {
        type: 'vbox',
        pack: 'start',
        align: 'stretch'
    },
    
    items: [{
    	xtype: 'dashboardGraphPanel',
    	itemId: 'row1',
        flex: 1,
        //margin: '0 10 0 0',
        grp_cd: '',
    	grp_nm: '',
    	item_cd: '',
    	center_tms_cd: ''
    }, {
    	xtype: 'panel',
    	itemId: 'row2',
    	flex: 1,
    	//margin: '0 10 0 0',
    	layout: {
        	type: 'hbox',
        	pack: 'start',
        	align: 'stretch'
        },
        items: [{
        	xtype: 'panel',
        	itemId: 'panel3',
        	title: '측정소현황',
        	iconCls : 'x-fa fa-flag',	
        	flex: 1
        },{
        	//xtype: 'panel',
        	xtype: 'dashboardListPanel',
        	itemId: 'panel4',
        	flex: 1,
        	grp_cd: '',
        	grp_nm: '',
        	item_cd: ''
        }]	
    }],
    
    listeners : {
    	beforerender: function (obj, eOpts) {
    		obj.setWidth(Ext.getBody().getViewSize().width);
    		obj.setHeight(Ext.getBody().getViewSize().height);
    		      
    		obj.setTitle(obj.config.grp_nm+' ('+obj.config.item_cd+')');
    		obj.down('#row1').config.grp_cd = obj.config.grp_cd; 
    		obj.down('#row1').config.grp_nm = obj.config.grp_nm;
    		obj.down('#row1').config.region_cd = obj.config.region_cd;
    		obj.down('#row1').config.item_cd = obj.config.item_cd;
    		
    		obj.down('#row2').down('#panel4').config.grp_cd = obj.config.grp_cd; 
    		obj.down('#row2').down('#panel4').config.grp_nm = obj.config.grp_nm;
    		obj.down('#row2').down('#panel4').config.item_cd = obj.config.item_cd;
    		
    		obj.down('#row2').down('#panel3').setHtml('<iframe src="gmap.html?grp_cd='+obj.config.grp_cd+'&region_cd='+obj.config.region_cd+'&item_cd='+obj.config.item_cd+'&center_tms_cd='+obj.config.center_tms_cd+'" width="100%" height="100%"></iframe>');
    	},
    	afterrender : function (obj, eOpts) {
    	},
    	boxready : function(obj) {
		},
		resize: function (obj, width, height, oldWidth, oldHeight, eOpts) {
        }, 
    }
});
