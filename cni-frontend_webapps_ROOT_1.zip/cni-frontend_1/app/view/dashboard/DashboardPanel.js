Ext.define('cni.view.dashboard.DashboardPanel', {
	extend: 'Ext.panel.Panel',
    xtype: 'dashboardPanel',
    
    border: true,
    bodyBorder: false,
    layout: {
        type: 'vbox',
        pack: 'start',
        align: 'stretch'
    },

    items: [{
    	xtype: 'panel',
    	itemId: 'row1',
        flex: 1,
        //margin: '0 10 0 0',
        layout: {
        	type: 'hbox',
        	pack: 'start',
        	align: 'stretch'
        },
        items: [{
        	xtype: 'dashboardMap',
        	itemId: 'map1',
        	flex: 1,
        	grp_cd: '',
        	grp_nm: '',
        	item_cd: '',
        	center_tms_cd: ''
        },{
        	xtype: 'dashboardMap',
        	itemId: 'map2',
        	flex: 1,
        	grp_cd: '',
        	grp_nm: '',
        	item_cd: '',
        	center_tms_cd: ''
        }]	
    }, {
    	xtype: 'panel',
    	itemId: 'row2',
    	flex: 1,
    	//margin: '0 10 0 0',
    	layout: {
        	type: 'hbox',
        	pack: 'start',
        	align: 'stretch'
        },
        items: [{
        	xtype: 'dashboardMap',
        	itemId: 'map3',
        	flex: 1,
        	grp_cd: '',
        	grp_nm: '',
        	item_cd: '',
        	center_tms_cd: ''
        },{
        	xtype: 'dashboardMap',  
        	itemId: 'map4',
        	flex: 1,
        	grp_cd: '',
        	grp_nm: '',
        	item_cd: '',
        	center_tms_cd: ''
        }]	
    }],
    
    listeners : {
    	beforerender: function (obj, eOpts) {
    		obj.down("#map1").config.grp_cd = '172';
    		obj.down("#map4").config.region_cd = '44825';
    		obj.down("#map1").config.grp_nm = '태안화력';
    		obj.down("#map1").config.item_cd = 'PM2';
    		obj.down("#map1").config.center_tms_cd = '86108';
    		obj.down("#map2").config.grp_cd = '173';
    		obj.down("#map4").config.region_cd = '44270';
    		obj.down("#map2").config.grp_nm = '당진화력';
    		obj.down("#map2").config.item_cd = 'PM2';
    		obj.down("#map2").config.center_tms_cd = '00004';
    		obj.down("#map3").config.grp_cd = '171';
    		obj.down("#map4").config.region_cd = '44180';
    		obj.down("#map3").config.grp_nm = '보령화력';
    		obj.down("#map3").config.item_cd = 'PM2';
    		obj.down("#map3").config.center_tms_cd = '85906';
    		obj.down("#map4").config.grp_cd = '170';
    		obj.down("#map4").config.region_cd = '44770';
    		obj.down("#map4").config.grp_nm = '서천화력';
    		obj.down("#map4").config.item_cd = 'PM2';
    		obj.down("#map4").config.center_tms_cd = '77025300';
    	},
    	afterrender : function (obj, eOpts) {
    	}
    }
});

