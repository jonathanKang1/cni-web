Ext.define('cni.view.dashboard.Dashboard', {
	extend: 'Ext.panel.Panel',
    xtype: 'dashboard',
    
    border: true,
    bodyBorder: false,
    
    layout: {type: 'vbox',pack: 'start',align: 'stretch'},
    
    //bodyPadding: 10,
    title: '대시보드',
    iconCls : 'x-fa fa-desktop',
    
    tools:[{
        iconCls : 'x-fa fa-wrench',
        itemId: 'tms_item_setting',
        tooltip: '설정',
        handler : function () {
        }
    }],  

    items: [{
    	xtype: 'panel',  
    	itemId: 'row1',
        flex: 1.2,
        //margin: '0 10 0 0',
        layout: {type: 'hbox',pack: 'start',align: 'stretch'},
        items: [{
        	xtype: 'nowmap',
        	itemId: 'nowmap',
        	flex: 1,
        	margin: '3',
        	item_cd: ''
        },{
        	//xtype: 'dashboardGraph',
        	//itemId: 'dashboardGraph',
        	flex: 1,
        	margin: '3',
        	item_cd: ''
        }]	
    }, {
    	xtype: 'dashboardGraph',
    	itemId: 'dashboardGraph',
    	flex: 1,
    	margin: '3',
    	item_cd: ''
    }],
    
    listeners : {
    	beforerender: function (obj, eOpts) {
    		obj.down("#nowmap").config.item_cd = 'CAI';
    		obj.down("#dashboardGraph").config.item_cd = 'CAI';
    	},
    	render : function (obj, eOpts) {
    		console.log('render');
    	},
    	afterrender : function (obj, eOpts) {
    		console.log('afterrender');
    	}, 
    	boxready : function(obj) {
    		console.log('boxready');
		},
		destroy: function(obj, eOpts) {
    	}
    }
});

