Ext.define('cni.view.dashboard.DashboardGraphPanel', {
	extend: 'Ext.panel.Panel',
    xtype: 'dashboardGraphPanel',

    controller: 'dashboard.dashboardGraphController',
    
    id: 'dashboardGraphPanel',
    reference: 'dashboardGraphPanel',
    
    border: true,
    layout: 'fit',

    items: {
    	xtype: 'cartesian',
    	id: 'real_time_graph',
    	itemId: 'real_time_graph',
        reference: 'real_time_graph',
        insetPadding: '20 10 10 10',
        innerPadding: '10 10 10 10',
        legend: {
            docked: 'right'
        },
        // 그래프 확대축소 
        /*interactions: {
            type: 'panzoom',
            zoomOnPanGesture: true
        },*/
        animation: {
            duration: 200
        },
        axes: [{
        	
            type: 'numeric',
            minimum: -1,
            maximum: 50,
            grid: true,
            position: 'left',
            title: '측정값',
           	label: {fontSize: 10}
           	//renderer: 'onAxisLabelRender'
        },{
            type: 'time',
            //dateFormat: 'G:i:s',
            dateFormat: 'H:i',
            segmenter: {
                type: 'time',
                step: {
                    unit: Ext.Date.HOUR,
                    step: 1
                }
            },
            label: {fontSize: 10},
            grid: true,
            position: 'bottom',
            title: '측정시간',
            fields: ['DSP_DT'],
            majorTickSteps: 23        
        }],

        listeners: {
            //afterrender: 'onTimeChartRendered',
        	destroy: 'onTimeChartDestroy'
        }
    },
    
    listeners: {
    	beforerender: function (obj, eOpts) {
    	},
    	afterrender: 'onTimeChartRendered',
        //destroy: 'onTimeChartDestroy'
    	resize: function (obj, width, height, oldWidth, oldHeight, eOpts) {
        }, 
    }
});
