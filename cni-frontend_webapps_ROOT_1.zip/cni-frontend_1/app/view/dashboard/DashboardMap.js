//var monitorListTask = null;
Ext.define('cni.view.dashboard.DashboardMap', {
	extend: 'Ext.panel.Panel',
    xtype: 'dashboardMap',

    /*id: 'dashboardMap',
    reference: 'dashboardMap',
    alias: 'widget.dashboardMap',*/
    
    /*requires: [
        'Ext.plugin.Viewport',
        'Ext.window.MessageBox'
    ],*/
    
    border: true,
    layout: 'fit',
    
    title: '',
    iconCls : 'x-fa fa-flag',
    
    tools:[{
        //type:'gear',
    	iconCls : 'x-fa fa-wrench',
        itemId: 'tms_item_setting',
        tooltip: '설정',
        handler : function () {
        	//Ext.widget("dashboardMapDataConfigWindow");	
        }
    },{
    	//iconCls : 'x-fa fa-desktop',
    	type : 'maximize',
    	tooltip: '전체화면',
        handler : function () {
        	Ext.widget('dashboardRegionPanel', {
        		grp_nm: this.up('dashboardMap').config.grp_nm,
        		grp_cd: this.up('dashboardMap').config.grp_cd,
        		region_cd: this.up('dashboardMap').config.region_cd,
        		item_cd: this.up('dashboardMap').config.item_cd,
        		center_tms_cd: this.up('dashboardMap').config.center_tms_cd
        	}).show();
        }
    }],  
    
    listeners : {
    	beforerender: function (obj, eOpts) {
    		obj.setTitle(obj.config.grp_nm+' ( PM2.5 시간자료 )');
    		obj.setHtml('<iframe src="gmap.html?v=1&grp_cd='+obj.config.grp_cd+'&item_cd='+obj.config.item_cd+'&center_tms_cd='+obj.config.center_tms_cd+'" width="100%" height="100%"></iframe>');
    	},
    	afterrender : function (obj, eOpts) {
    	},
    	boxready : function(obj) {
		},
		resize: function (obj, width, height, oldWidth, oldHeight, eOpts) {
        },
		destroy: function(obj, eOpts) {
    		//Ext.TaskManager.stop(obj.task);
    		/*if (monitorListTask) {
    			Ext.TaskManager.destroy(monitorListTask); 
			}
    		monitorListTask = null;*/
    	} 
    }
});

