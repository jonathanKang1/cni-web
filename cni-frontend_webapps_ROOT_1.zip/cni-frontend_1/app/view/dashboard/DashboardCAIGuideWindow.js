Ext.define('cni.view.dashboard.DashboardCAIGuideWindow', {
	//extend: 'Ext.panel.Panel',
	extend: 'Ext.window.Window',
    xtype: 'dashboardCAIGuideWindow',
    
    //controller: 'system.tmsController',
    
    title: '통합대기환경지수안내',
    
    width : 900,
    //closable : true,	//default true
    autoShow : true,
    modal : true,
    layout : 'fit',
    onEsc : function(){
    	this.close();
    	return true;
    },
    padding: '0 5 5 5',
    defaults: {
        anchor: '100%',
        labelWidth: 100
    },
    listeners : {
    	beforerender: function (obj, eOpts) {
    		//obj.setHtml('<iframe src="gmap_region.html?v=3" width="100%" height="100%"></iframe>');
    		obj.setHtml('<div id="conts">'
    				+'<div id="cont_body">'
    				+'<h6>개요</h6>'
    				+'<ul class="list">'
    				+'<li><span class="f1">통합대기환경지수(CAI, Comprehensive air-quality index)</span>는 대기오염도 측정치를 국민이 쉽게 알 수 있도록 하고 대기오염으 로부터 피해를 예방하기 위한 행동지침을 국민에게 제시하기 위하여 대기오염도에 따른 인체 영향 및 체감오염도를 고려하여 개발된 대기오염도 표현방식</li>'
    				+'</ul>'
    				+'<h6 class="MgT50">지수 산출방법</h6>'
    				+'<ul class="list">'
    				+'<li>6개 대기오염물질별로 통합대기환경지수 점수를 산정하며 가장 높은 점수를 통합 지수값으로 사용</li>'
    				+'<li>산출된 각각의 오염물질별 지수점수가 &#39;나쁨&#39;이상의 등급이 2개 물질 이상일 경우 통합지수값에 가산점을 부여'
    				+'<ul class="low_list">'
    				+'<li>1개일 경우 : 점수가 가장 높은 지수점수를 통합지수로 사용</li>'
    				+'<li>2개일 경우 : 가장 높은 점수가 나온 오염물질을 영향 오염물질로 표시하고 그 오염물질의 점수에 50점을 가산</li>'
    				+'<li>3개 이상일 경우 : 가장 높은 점수가 나온 오염물질을 영향 오염물질로 표시하고 그 오염물질의 점수에 75점 가산</li>'
    				+'</ul>'
    				+'</li>'
    				+'<li>통합대기환경지수는 0에서 500까지의 지수를 4단계로 나누어 점수가 커질수록 대기상태가 좋지 않음을 나타냄</li>'
    				+'</ul>'
    				+'<table class="st_1 stoke">'
    				+'<h6 class="MgT50">지수산출에 필요한 변수</h6>'
    				+'<caption>지수산출에 필요한 변수</caption>'
    				+'<colgroup>'
    				+'<col /><col style="width: 80px;" /><col style="width: 80px;" /><col style="width: 80px;" /><col style="width: 80px;" /><col style="width: 80px;" /><col style="width: 80px;" /><col style="width: 80px;" /><col style="width: 80px;" /><col style="width: 80px;" />'
    				+'</colgroup>'
    				+'<thead><tr><th colspan="2">지수구분</th><th colspan="2">좋음</th><th colspan="2">보통</th><th colspan="2">나쁨</th><th colspan="2">매우나쁨</th></tr></thead>'
    				+'<tbody>'
    				+'<tr><td rowspan="2">점수구분 값</td><td>I<sub>LO</sub></td><td colspan="2">0</td><td colspan="2">51</td><td colspan="2">101</td><td colspan="2">251</td></tr>'
    				+'<tr><td>I<sub>HI</sub></td><td colspan="2">50</td><td colspan="2">100</td><td colspan="2">250</td><td colspan="2">500</td></tr>'
    				+'<tr><td colspan="2">농도구분</td><td>BP<sub>LO</sub></td><td>BP<sub>HI</sub></td><td>BP<sub>LO</sub></td><td>BP<sub>HI</sub></td><td>BP<sub>LO</sub></td><td>BP<sub>HI</sub></td><td>BP<sub>LO</sub></td><td>BP<sub>HI</sub></td></tr>'
    				+'<tr><td>아황산가스(ppm)</td><td>1hr</td><td>0</td><td>0.02</td><td>0.021</td><td>0.05</td><td>0.051</td><td>0.15</td><td>0.151</td><td>1</td></tr>'
    				+'<tr><td>일산화탄소(ppm)</td><td>1hr</td><td>0</td><td>2</td><td>2.01</td><td>9</td><td>9.01</td><td>15</td><td>15.01</td><td>50</td></tr>'
    				+'<tr><td>오존(ppm)</td><td>1hr</td><td>0</td><td>0.03</td><td>0.031</td><td>0.09</td><td>0.091</td><td>0.15</td><td>0.151</td><td>0.6</td></tr>'
    				+'<tr><td>이산화질소(ppm)</td><td>1hr</td><td>0</td><td>0.03</td><td>0.031</td><td>0.06</td><td>0.061</td><td>0.2</td><td>0.201</td><td>2</td></tr>'
    				+'<tr><td>미세먼지 PM<sub>10</sub>(㎍/㎥)</td><td>24hr<sub>주1)</sub></td><td>0</td><td>30</td><td>31</td><td>80</td><td>81</td><td>150</td><td>151</td><td>600</td></tr>'
    				+'<tr><td>초미세먼지 PM<sub>2.5</sub>(㎍/㎥)</td><td>24hr<sub>주2)</sub></td><td>0</td><td>15</td><td>16</td><td>35</td><td>36</td><td>75</td><td>76</td><td>500</td></tr>'
    				+'</tbody>'
    				+'</table>'
    				+'<table class="st_1 stoke">'
    				+'<caption>통합대기환경지수 표현방법</caption>'
    				+'<colgroup><col /><col style="width: 180px;" /><col style="width: 180px;" /><col style="width: 180px;" /><col style="width: 180px;" /></colgroup>'
    				+'<thead>'
    				+'<tr><th>&nbsp;</th><th>좋음(0~50)</th><th>보통(51~100)</th><th>나쁨(101~250)</th><th>매우나쁨(250~)</th></tr>'
    				+'</thead>'
    				+'<tbody>'
    				+'<tr><td>상징색</td><td class="lv1">파랑</td><td class="lv2">초록</td><td class="lv3">노랑</td><td class="lv4">빨강</td></tr>'
    				+'<tr><td>RGB Code</td><td>0000FF</td><td>00FF00</td><td>FFFF00</td><td>FF0000</td></tr>'
    				+'</tbody>'
    				+'</table>'
    				+'</div>');
    	},
    	afterrender : function (obj, eOpts) {
    		//등록이 아닌 수정인 경우 비교
    		/*obj.down('#work_cd').setValue('I');
    		if (obj.config.selectedRecord != '') {
    			obj.down('#region_cd').setValue(obj.config.selectedRecord.data.REGION_CD);
	    		obj.down('#tms_cd').setValue(obj.config.selectedRecord.data.TMS_CD).setReadOnly(true);
	    		obj.down('#tms_nm').setValue(obj.config.selectedRecord.data.TMS_NM);
	    		obj.down('#net_cd').setValue(obj.config.selectedRecord.data.NET_CD);
	    		obj.down('#comm_cd').setValue(obj.config.selectedRecord.data.COMM_CD);
	    		obj.down('#lat').setValue(obj.config.selectedRecord.data.LAT);
	    		obj.down('#lng').setValue(obj.config.selectedRecord.data.LNG);
	    		obj.down('#addr').setValue(obj.config.selectedRecord.data.ADDR);
	    		obj.down('#use_yn').setValue(obj.config.selectedRecord.data.USE_YN=='Y'?true:false);
	    		obj.down('#order_seq').setValue(obj.config.selectedRecord.data.ORDER_SEQ);
	    		obj.down('#work_cd').setValue('U');
    		}*/
    	}
    }

});

