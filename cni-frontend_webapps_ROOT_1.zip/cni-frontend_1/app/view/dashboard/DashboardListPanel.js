var monitorListTask = null;
Ext.define('cni.view.dashboard.DashboardListPanel', {
	extend: 'Ext.grid.Panel',
    xtype: 'dashboardListPanel',
    id: 'dashboardListPanel',
    
    title: '측정자료현황',
    iconCls : 'x-fa fa-list-ul',	
    columnLines: true,
    border: true,
    layout: 'fit',

    tools:[{
        iconCls : 'x-fa fa-bell',
        itemId:'bell',
        tooltip: '경보음 on/off',
        handler : function () {
        		gAlarm.currentTime=0;
        		gAlarm.pause();
        }
    },{
        type:'gear',
        tooltip: '설정',
        handler: function() {
        	Ext.widget('monitorListConfigWindow');
        }
    },{
        type:'refresh',
        tooltip: '새로고침', 
        handler: function (me) {
        	Ext.StoreManager.lookup('comm.listStore').load();
        }
    }],
    
    columns : [{
    	//header : '측정시간',
    	text : '측정시간',
    	flex : 1,
    	dataIndex : 'DSP_DT',
    	//style: 'color:#fff;font-weight:bold;font-size:16px;line-height:40px;background-color:#32404e;',
    	style: 'font-weight:bold;font-size:16px;line-height:40px;',
    	align: 'center',
    	renderer: function(value, meta, record) {
    		meta.css = 'monitor-list-column-value';
            return value;
        }
    },{
    	header : '측정소명',
    	flex : 1,
    	dataIndex : 'TMS_NM',
    	style: 'font-weight:bold;font-size:16px;',
    	align: 'center',
    	renderer: function(value, meta, record) {
    		meta.css = 'monitor-list-column-value';
            return value;
        }
    }/*,{
    	header : '이전측정값',
    	flex : 1,
    	dataIndex : 'before_msr',
    	style: 'font-weight:bold;font-size:16px;',
    	align: 'center',
    	renderer: function(value, meta, record) {
    		if (value) value = "<span style='font-size:16px;line-height:40px;' >"+value+"</span>";
            return value;
        }
    }*/,{
    	header : '현재측정값',
    	flex : 1,
    	dataIndex : 'MSR_VL',
    	align: 'center',
    	style: 'font-weight:bold;font-size:16px;',
    	renderer: function(value, meta, record) {
    		meta.css = 'monitor-list-column-value';
            return value;
        }
    },{
    	header : '등급',
    	flex : 1,
    	dataIndex : 'LEVEL_NM',
    	align: 'center',
    	style: 'font-weight:bold;font-size:16px;',
    	renderer: function(value, meta, record) {
            if (record.get('LEVEL_CD') == 'A') {
            	value = "<span style='color:#0000ff;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'level-A';
            } else if (record.get('lLEVEL_CD') == 'B') {
            	value = "<span style='color:#008080;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'level-B';
            } else if (record.get('LEVEL_CD') == 'C') {
            	value = "<span style='color:#ffa500;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'level-C';
            } else if (record.get('LEVEL_CD') == 'D') {
            	value = "<span style='color:#ff0000;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'level-D';
            } else {
            	meta.css = 'monitor-list-column-value';
            }
            return value;
        }
    },{
    	header : '상태',
    	flex : 1,
    	dataIndex : 'STATUS_NM',
    	align: 'center',
    	style: 'font-weight:bold;font-size:16px;',
    	renderer: function(value, meta, record) {
            if (record.get('STATUS_CD') == '1') {
            	value = "<span style='color:#008080;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'msr-status-1';
            } else if (record.get('STATUS_CD') == '2') {
            	value = "<span style='color:#ff8040;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'msr-status-2';
            } else if (record.get('STATUS_CD') == '4') {
            	value = "<span style='color:#ff0000;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'msr-status-4';
            } else if (record.get('STATUS_CD') == '8') {
            	value = "<span style='color:#ffa500;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'msr-status-8';
            } else {
            	meta.css = 'monitor-list-column-value';
            }
            return value;
        }
    },{
    	header : '기준초과',
    	flex : 1,
    	dataIndex : 'OVER_NM',
    	align: 'center',
    	style: 'font-weight:bold;font-size:16px;',
    	renderer: function(value, meta, record) {
            if (record.get('OVER_YN') == 'Y') {
            	value = "<span style='color:#9400D3;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'msr-status-1';
            } else {
            	meta.css = 'monitor-list-column-value';
            }
            return value;
        }
    }],
    store: {
    	type: 'comm.listStore',
    	listeners: {
    		beforeload: function(obj, records, successful, operation, eOpts) {
    			obj.getProxy().setUrl('/dashboard/getRegionTmsData.ax');
    			obj.proxy.extraParams = {
	   	    			grp_cd: Ext.getCmp('dashboardListPanel').config.grp_cd,
	   			   	    item_cd: Ext.getCmp('dashboardListPanel').config.item_cd
	   				};
        	},
            load: function(obj, records, successful, operation, eOpts) {
            	cni.app.storeTemp = obj; 
            	//var data = obj.getData();
            	//var snapshot = data.getSource();
            	//var unfilteredCollection = snapshot || data;
            	//var allRecords = unfilteredCollection.getRange();

            	var alarm_cnt = 0;
            	var alarm_tms = '';
            	var alarm_nm = '';
            	var alert_yn = 'N';
            	var record;
            	for (var i=0; i<records.length; i++) {
            		record = records[i];
            		if (record.get('LEVEL_CD') > 'B' || record.get('LEVEL_CD') == '-') {
            		
            			if (cni.app.soundYN == 'Y' || cni.app.alertYN == 'Y') {
                			
            				alarm_cnt++;
    						alarm_tms = alarm_tms==''? record.get('TMS_NM'):alarm_tms;
    						alarm_nm = alarm_nm==''? record.get('LEVEL_NM'):alarm_nm;
    						
    						if (cni.app.alertTM == '' || (cni.app.alertTM != record.get('DSP_DT') && cni.app.alertTM < record.get('DSP_DT'))) {
								cni.app.alertTM = record.get('DSP_DT');
								alert_yn = 'Y';
    						}
            			}
					}
            		
            	}
            	
            	if (alert_yn == 'Y') {
            		var hour = Ext.Date.format(new Date(), 'H');
            		if (cni.app.soundYN == 'Y' && cni.app.sTime <= hour &&  hour <= cni.app.eTime) {
           				 var playPromise = gAlarm.play();
           				 if (playPromise !== undefined) {
       					    playPromise.then(_ => {}).catch(error => {
       					    	cni.app.soundYN = 'N';
       					    	Ext.toast('현재 브라우저에서는 경보음이 자동으로 재생되지 않습니다.<br />* 엣지 브라우저를 사용하시기 바랍니다!');
       					    });
           				}
           			} else gAlarm.pause();

           			if (cni.app.alertYN == 'Y') {
            			if (alarm_cnt == 1) {
            				Ext.Msg.alert('알림', alarm_tms+' 측정소에 '+alarm_nm+' 상태가 발생 하였습니다.');
            			} else {
            				Ext.Msg.alert('알림', alarm_tms+' 외 '+(alarm_cnt-1)+'개 측정소에 나쁨 이상의 상태가 발생 하였습니다.');
            			}
           			}
        		} else {
        			gAlarm.pause();
        		}
            	
            	//var scroll_interval = cni.app.scrollInterval; 
            	var scroll_interval = 5;
            	if (!scroll_interval) {
            		scroll_interval = 5000;
            	} else {
            		scroll_interval = scroll_interval * 1000;
            	}
            	if (records.length * 56.6666667 > cni.app.contentPanelHeigt && obj.getData() && !monitorListTask) {
            		//monitorListTask = Ext.TaskManager.start({
            		monitorListTask = Ext.TaskManager.newTask({
            			interval: scroll_interval,
	             		//repeat: 120,
	                    scope: obj,
	                    run: function() {
	                    	var allRecords = obj.getData().getRange();
	                    	obj.add({DSP_DT: allRecords[0].data.DSP_DT
	                    		//, msr_tm: allRecords[0].data.msr_tm
	                    		, TMS_CD: allRecords[0].data.TMS_CD
	                    		, TMS_NM: allRecords[0].data.TMS_NM
	                    		, ITEM_CD: allRecords[0].data.ITEM_CD
	                    		//, before_msr: allRecords[0].data.before_msr
	                    		, MSR_VL: allRecords[0].data.MSR_VL
	                    		, LEVEL_CD: allRecords[0].data.LEVEL_CD
	                    		, LEVEL_NM: allRecords[0].data.LEVEL_NM
	                    		, STATUS_CD: allRecords[0].data.STATUS_CD
	                    		, STATUS_NM: allRecords[0].data.STATUS_NM
	                    		, OVER_YN: allRecords[0].data.OVER_YN
	                    		, OVER_NM: allRecords[0].data.OVER_NM
	                    	});
	                		obj.removeAt(0);
	                    }
	                    
	                });
            		monitorListTask.start();
            		
            	}
            }
        }
    },
    task : {
    	interval: 60000,
		run: function () {
			if (cni.app.dataType == 'M') {
				Ext.StoreManager.lookup('comm.listStore').load();
			} else {
				//매시 0, 2, 4, 30, 45분일때 수행
				var min = Ext.Date.format(new Date(), 'i');
				if (min == 0 || min == 2 || min == 4 || min == 30 || min == 45) {
					console.log(">> region list task RUN!"); 
					Ext.StoreManager.lookup('comm.listStore').load();
				}
			}
		}
	},
    listeners : {
		beforerender : function(obj, eOpts) {
			Ext.StoreManager.lookup('comm.listStore').load();
    	},
    	render: function(obj, eOpts) {
    	},
        afterrender: function(obj, eOpts) {
        	Ext.TaskManager.start(obj.task);
        },
        resize: function (obj, width, height, oldWidth, oldHeight, eOpts) {
        	//console.log('resize = '+this.getHeight());
        	cni.app.contentPanelHeigt = this.getHeight();
        }, 
    	boxready : function(obj) {
		},
		rowdblclick :  function (obj, record, element, rowIndex, e, eOpts) {
			/*Ext.widget('dashboardMapWindow', {
				tms_cd: record.get('tms_cd'),
				tms_nm: record.get('tms_nm'),
				msr_dt: record.get('msr_dt'),
				selectedRecord: record,    
				myParentStore: cni.app.storeTemp
			});
			return true;*/
		},
		destroy: function(obj, eOpts) {
    		Ext.TaskManager.stop(obj.task);
    		if (monitorListTask) {
    			//monitorListTask.destroy();
				Ext.TaskManager.destroy(monitorListTask);
			}
    		monitorListTask = null;
    		
    		gAlarm.currentTime=0;
   			gAlarm.pause();
    	}
	}
    
});
/*Ext.on('resize', function(w, h){
	console.log('h='+h);
});*/
