var monitorListTask = null;
Ext.define('cni.view.dashboard.DashboardCAIListPanel', {
	extend: 'Ext.grid.Panel',
    xtype: 'dashboardCAIListPanel',
 
    id: 'dashboardCAIListPanel',
    
    title: '측정소별대기환경',
    iconCls : 'x-fa fa-list-ul',	
    columnLines: true,
    border: true,
    layout: 'fit',

    tools:[{
        iconCls : 'x-fa fa-bell',
        itemId:'bell',
        tooltip: '경보음 on/off',
        handler : function () {
        		gAlarm.currentTime=0;
        		gAlarm.pause();
        }
    },{
        type:'gear',
        tooltip: '설정',
        handler: function() {
        	Ext.widget('dashboardConfigWindow');
        }
    },{
        type:'refresh',
        tooltip: '새로고침', 
        handler: function (me) {
        	Ext.StoreManager.lookup('comm.listStore').load();
        }
    }],
    
    columns : [{
    	//header : '측정시간',
    	text : '측정시간',
    	flex : 1.2,
    	dataIndex : 'DSP_FM',
    	//style: 'color:#fff;font-weight:bold;font-size:16px;line-height:40px;background-color:#32404e;',
    	style: 'font-weight:bold;font-size:16px;line-height:40px;',
    	align: 'center',
    	renderer: function(value, meta, record) {
    		meta.css = 'monitor-list-column-value';
            return value;
        }
    },{
    	header : '지역',
    	flex : 1,
    	dataIndex : 'REGION_NM',
    	style: 'font-weight:bold;font-size:16px;',
    	align: 'center',
    	renderer: function(value, meta, record) {
    		meta.css = 'monitor-list-column-value';
    		meta.tdAttr = 'data-qtip="' + record.get('NET_NM') + '"';
            return value;
        }
    },{
    	header : '측정망',
    	flex : 0.8,
    	dataIndex : 'NET_NM',
    	style: 'font-weight:bold;font-size:16px;',
    	align: 'center',
    	hidden: true,
    	renderer: function(value, meta, record) {
    		meta.css = 'monitor-list-column-value';
            return value;
        }
    },{
    	header : '측정소명',
    	flex : 1,
    	dataIndex : 'TMS_NM',
    	style: 'font-weight:bold;font-size:16px;',
    	align: 'center',
    	renderer: function(value, meta, record) {
    		if (record.get('STATUS_CD') == '1' || record.get('STATUS_CD') == '2' || record.get('STATUS_CD') == '4' || record.get('STATUS_CD') == '8') {
            	value = "<span style='color:#ffa500;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	meta.tdAttr = 'data-qtip="' + record.get('STATUS_NM') + '"';
    		} else {
    			meta.css = 'monitor-list-column-value';
    		}
    		
            return value;
        }
    }/*,{
    	header : '이전측정값',
    	flex : 1,
    	dataIndex : 'before_msr',
    	style: 'font-weight:bold;font-size:16px;',
    	align: 'center',
    	renderer: function(value, meta, record) {
    		if (value) value = "<span style='font-size:16px;line-height:40px;' >"+value+"</span>";
            return value;
        }
    }*/,{
    	header : '통합환경지수',
    	flex : 1,
    	dataIndex : 'CI_VL',
    	align: 'center',
    	style: 'font-weight:bold;font-size:16px;',
    	renderer: function(value, meta, record) {
    		meta.css = 'monitor-list-column-value';
            return value;
        }
    },{
    	header : '등급',
    	flex : 0.7,
    	dataIndex : 'CI_LV_NM',
    	align: 'center',
    	style: 'font-weight:bold;font-size:16px;',
    	renderer: function(value, meta, record) {
            if (record.get('CI_LV') == 'A') {
            	value = "<span style='color:#0000ff;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'level-A';
            } else if (record.get('CI_LV') == 'B') {
            	value = "<span style='color:#008080;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'level-B';
            } else if (record.get('CI_LV') == 'C') {
            	value = "<span style='color:#ffa500;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'level-C';
            } else if (record.get('CI_LV') == 'D') {
            	value = "<span style='color:#ff0000;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'level-D';
            } else {
            	meta.css = 'monitor-list-column-value';
            }
            return value;
        }
    },{
    	header : '주오염물질',
    	flex : 0.8,
    	dataIndex : 'CI_ITEM_NM',
    	align: 'center',
    	style: 'font-weight:bold;font-size:16px;',
    	renderer: function(value, meta, record) {
            if (record.get('CI_LV') > 'B') {
            	value = "<span style='color:#9400D3;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'msr-status-1';
            } else {
            	meta.css = 'monitor-list-column-value';
            }
            return value;
        }
    },{
    	header : '경보현황',
    	flex : 0.7,
    	dataIndex : 'WARNING_NM',
    	align: 'center',
    	style: 'font-weight:bold;font-size:16px;',
    	hidden: true,
    	renderer: function(value, meta, record) {
            if (record.get('WARNING_CD') == 'C') {
            	value = "<span style='color:#ffa500;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'msr-status-1';
            } else if ('DE'.indexOf(record.get('WARNING_CD')) > -1) {
            	value = "<span style='color:#ff0000;font-weight:bold;font-size:16px;line-height:40px;' >"+value+"</span>";
            	//meta.css = 'level-D';
            } else {
            	meta.css = 'monitor-list-column-value';
            	value = '';
            }
            return value;
        }
    }],
    store: {
    	type: 'comm.listStore',
    	listeners: {
    		beforeload: function(obj, records, successful, operation, eOpts) {
    			obj.getProxy().setUrl('/dashboard/getDashboardRegionTMSList.ax');
    			obj.proxy.extraParams = {
    					item_cd: cni.app.dashboardItem
    			}
        	},
            load: function(obj, records, successful, operation, eOpts) {
            	cni.app.storeTemp = obj; 
            	//var data = obj.getData();
            	//var snapshot = data.getSource();
            	//var unfilteredCollection = snapshot || data;
            	//var allRecords = unfilteredCollection.getRange();

            	var alarm_cnt = 0;
            	var alarm_tms = '';
            	var alarm_nm = '';
            	var alert_yn = 'N';
            	var record;
            	for (var i=0; i<records.length; i++) {
            		record = records[i];
            		if (record.get('CI_LV') > 'B' || record.get('CI_LV') == '-' || record.get('WARNING_CD') > 'B') {
            		
            			if (cni.app.soundYN == 'Y' || cni.app.alertYN == 'Y') {
                			
            				alarm_cnt++;
    						alarm_tms = alarm_tms==''? record.get('TMS_NM'):alarm_tms;
    						alarm_nm = alarm_nm==''? record.get('CI_LV_NM'):alarm_nm;
    						
    						if (cni.app.alertTM == '' || (cni.app.alertTM != record.get('DSP_DT') && cni.app.alertTM < record.get('DSP_DT'))) {
								cni.app.alertTM = record.get('DSP_DT');
								alert_yn = 'Y';
    						}
            			}
					}
            	}

            	if (alert_yn == 'Y') {
            		var hour = Ext.Date.format(new Date(), 'H');
            		if (cni.app.soundYN == 'Y' && cni.app.sTM <= hour &&  hour <= cni.app.eTM) {
            			var playPromise = gAlarm.play();

        				if (playPromise !== undefined) {
        					console.log('>> defined'); 
        					playPromise.then().catch(function(){
        						cni.app.soundYN = 'N';
       					    	Ext.toast('현재 브라우저에서는 경보음이 자동으로 재생되지 않습니다.<br />* 엣지 브라우저를 사용하시기 바랍니다!');
        					});
        				} else {
        					Ext.toast('현재 브라우저에서는 경보음이 자동으로 재생되지 않습니다.<br />* 엣지 브라우저를 사용하시기 바랍니다!');
        				}
            			
            			/** var playPromise = gAlarm.play();
            			if (playPromise !== undefined) {
           					 playPromise.then(_ => {}).catch(error => {
       					    	cni.app.soundYN = 'N';
       					    	Ext.toast('현재 브라우저에서는 경보음이 자동으로 재생되지 않습니다.<br />* 엣지 브라우저를 사용하시기 바랍니다!');
       					    });
           				}*/
           			} else gAlarm.pause();

           			if (cni.app.alertYN == 'Y') {
            			if (alarm_cnt == 1) {
            				Ext.Msg.alert('알림', alarm_tms+' 측정소에 '+alarm_nm+' 상태가 발생 하였습니다.');
            			} else {
            				Ext.Msg.alert('알림', alarm_tms+' 외 '+(alarm_cnt-1)+'개 측정소에 나쁨 이상의 상태가 발생 하였습니다.');
            			}
           			}
        		} else {
        			gAlarm.pause();
        		}
            	
            	var scroll_interval = cni.app.scrollInterval;
            	if (!scroll_interval) {
            		scroll_interval = 3000;
            	} else {
            		scroll_interval = scroll_interval * 1000;
            	}
            	if (records.length * 56.6666667 > cni.app.contentPanelHeigt && obj.getData() && !monitorListTask) {
            		//monitorListTask = Ext.TaskManager.start({
            		monitorListTask = Ext.TaskManager.newTask({
            			interval: scroll_interval,
	             		//repeat: 120,
	                    scope: obj,
	                    run: function() {
	                    	var allRecords = obj.getData().getRange();
	                    	obj.add({REGION_CD:allRecords[0].data.REGION_CD
	                    		, REGION_NM: allRecords[0].data.REGION_NM
	                    		, NET_NM: allRecords[0].data.NET_NM
	                    		, TMS_CD: allRecords[0].data.TMS_CD
	                    		, TMS_NM: allRecords[0].data.TMS_NM
	                    		, MSR_DT: allRecords[0].data.MSR_DT
	                    		, DSP_DT: allRecords[0].data.DSP_DT
	                    		, DSP_FM: allRecords[0].data.DSP_FM
	                    		, ITEM_CD: allRecords[0].data.ITEM_CD
	                    		, STATUS_CD: allRecords[0].data.STATUS_CD
	                    		, STATUS_NM: allRecords[0].data.STATUS_NM
	                    		, CI_VL: allRecords[0].data.CI_VL
	                    		, CI_LV: allRecords[0].data.CI_LV
	                    		, CI_LV_NM: allRecords[0].data.CI_LV_NM
	                    		, CI_ITEM_CD: allRecords[0].data.CI_ITEM_CD
	                    		, CI_ITEM_NM: allRecords[0].data.CI_ITEM_NM
	                    	});
	                		obj.removeAt(0);
	                    }
	                    
	                });
            		monitorListTask.start();
            		
            	}
            }
        }
    },
    task : {
    	interval: 60000,
		run: function () {
			//var min = Ext.Date.format(new Date(), 'i');
			if (new Date().getMinutes() % 10 > 3) return true;
			Ext.StoreManager.lookup('comm.listStore').load();
		}
	},
    listeners : {
		beforerender : function(obj, eOpts) {
			obj.setTitle('측정소별대기환경 ('+cni.app.dashboardItemNM+')');
			Ext.StoreManager.lookup('comm.listStore').load();
    	},
    	render: function(obj, eOpts) {
    	},
        afterrender: function(obj, eOpts) {
        	Ext.TaskManager.start(obj.task);
        	
        	if (cni.app.dashboardItem != 'CAI') {
	        	obj.headerCt.getHeaderAtIndex(4).setText('환경지수');
	        	obj.headerCt.getHeaderAtIndex(6).setText('지수항목');
        	}
        },
        resize: function (obj, width, height, oldWidth, oldHeight, eOpts) {
        	cni.app.contentPanelHeigt = this.getHeight();
        }, 
    	boxready : function(obj) {
		},
		rowclick :  function (obj, record, element, rowIndex, e, eOpts) {
			if (monitorListTask.stopped)
				monitorListTask.start();
			else
				monitorListTask.stop();
		},
		rowdblclick :  function (obj, record, element, rowIndex, e, eOpts) {
			Ext.widget('dashboardCAIListWindow', {
				region_nm: record.get('REGION_NM'),
				tms_cd: record.get('TMS_CD'),
				tms_nm: record.get('TMS_NM'),
				msr_dt: record.get('MSR_DT'),
				item_cd: cni.app.dashboardItem,
				selectedRecord: record,    
				myParentStore: cni.app.storeTemp
			});
			return true;
		},
		destroy: function(obj, eOpts) {
    		Ext.TaskManager.stop(obj.task);
    		if (monitorListTask) {
    			//monitorListTask.destroy();
				Ext.TaskManager.destroy(monitorListTask);
			}
    		monitorListTask = null;
    		
    		//gAlarm.currentTime=0;
   			gAlarm.pause();
    	}
	}
    
});
/*Ext.on('resize', function(w, h){
	console.log('h='+h);
});*/
