Ext.define('cni.view.dashboard.DashboardConfigWindow', {
    extend: 'Ext.window.Window',
    xtype: 'dashboardConfigWindow',
   
    id: 'id_dashboardConfigWindow',
    title: '환경설정',
    iconCls : 'x-fa fa-wrench',
    width : 300,
    //closable : true,	//default true
    autoShow : true,
    modal : true,
    layout : 'fit',
    onEsc : function(){
    	this.close();
    	return true;
    },
    
    items : [{
    	xtype : 'form',
    	itemId: 'config_form',
    	frame: false,
        bodyPadding: 10,
        
        fieldDefaults: {
            labelAlign: 'right',
            labelWidth: 100,
            anchor: '100%',
            msgTarget: 'side'
        },
        
    	items : [,{
        	xtype: 'combo',
        	itemId:'dashboard_item',
        	name: 'dashboard_item',
        	fieldLabel: '지수항목',
        	displayField: 'item_nm',
            valueField: 'item_cd',
            value: 'CAI',
            width: 110,
            queryMode: 'local',
        	store: {
        		fields: ['item_cd', 'item_nm'],
        	    data : [
        	        {'item_cd':'CAI', 'item_nm':'통합대기환경지수'},
        	        {'item_cd':'SO2', 'item_nm':'아황산가스'},
        	        {'item_cd':'COb', 'item_nm':'일산화탄소'},
        	        {'item_cd':'O3b', 'item_nm':'오존'},
        	        {'item_cd':'NO2', 'item_nm':'이산화질소'},
        	        {'item_cd':'PMb', 'item_nm':'미세먼지'},
        	        {'item_cd':'PM2', 'item_nm':'초미세먼지'}
        	    ]
        	}
        },{
        	xtype: 'combo',
        	itemId:'s_tm',
        	name:'s_tm',
        	fieldLabel: '경보음시작시간',
        	displayField: 'value',
            valueField: 'value',
            value: '09',
            width: 110,
            queryMode: 'local',
        	store: {
        		fields: ['value'],
        	    data : [
        	        {'value':'00'},{'value':'01'},{'value':'02'},{'value':'03'},{'value':'04'},{'value':'05'},{'value':'06'},{'value':'07'},{'value':'08'},{'value':'09'},{'value':'10'},{'value':'11'}
        	        ,{'value':'12'},{'value':'13'},{'value':'14'},{'value':'15'},{'value':'16'},{'value':'17'},{'value':'18'},{'value':'19'},{'value':'20'},{'value':'21'},{'value':'22'},{'value':'23'}
        	    ]
        	}
        },{
        	xtype: 'combo',
        	itemId:'e_tm',
        	name:'e_tm',
        	fieldLabel: '경보음종료시간',
        	displayField: 'value',
            valueField: 'value',
            value: '20',
            width: 110,
            queryMode: 'local',
        	store: {
        		fields: ['value'],
        	    data : [
        	    	{'value':'00'},{'value':'01'},{'value':'02'},{'value':'03'},{'value':'04'},{'value':'05'},{'value':'06'},{'value':'07'},{'value':'08'},{'value':'09'},{'value':'10'},{'value':'11'}
        	    	,{'value':'12'},{'value':'13'},{'value':'14'},{'value':'15'},{'value':'16'},{'value':'17'},{'value':'18'},{'value':'19'},{'value':'20'},{'value':'21'},{'value':'22'},{'value':'23'}
        	    ]
        	}
        },{
            xtype:'checkbox',
            name: 'sound_yn',
            itemId: 'sound_yn',
            fieldLabel: '경보음 재생',
            //checked: true
        },{
            xtype:'checkbox',
            name: 'alert_yn',
            itemId: 'alert_yn',
            fieldLabel: '알림창 표시',
            //checked: true
        }],
    	buttons: [{
        	xtype : 'button',
        	text : '저장',
        	formBind: true,
        	iconCls : 'x-fa fa-save',
        	listeners : {
        		click: function(btn, e, eOpts) {
        			
        			var params = btn.up('window').down('form').getForm().getValues();
            		Ext.Ajax.request({
                		//url : '/dashboard/setMonitorConfig.ax',
            			url : '/dashboard/setUserConfig.ax',
                		method : 'POST',
                		//params : params,
                		params : {
                			dashboard_item: btn.up('form').down('#dashboard_item').getValue(),
                			dashboard_item_nm: btn.up('form').down('#dashboard_item').getRawValue(),
                			s_tm: btn.up('form').down('#s_tm').getValue(),
                			e_tm: btn.up('form').down('#e_tm').getValue(),
                			sound_yn: btn.up('form').down('#sound_yn').getValue()==true?'on':'N',
                			alert_yn: btn.up('form').down('#alert_yn').getValue()==true?'on':'N',
                		},
                		success : function(res){
                			var result = Ext.decode(res.responseText);            
                			if (result['code'] == '200') {
                				cni.app.soundYN = btn.up('form').down('#sound_yn').getValue()==true?'Y':'N';
                    			cni.app.alertYN = btn.up('form').down('#alert_yn').getValue()==true?'Y':'N';
                    			cni.app.sTM = btn.up('form').down('#s_tm').getValue();
                    			cni.app.eTM = btn.up('form').down('#e_tm').getValue();
                    			cni.app.dashboardItem = btn.up('form').down('#dashboard_item').getValue();
                    			cni.app.dashboardItemNM = btn.up('form').down('#dashboard_item').getRawValue();
                    			
                				var store = Ext.StoreManager.lookup('comm.listStore');
                				store.reload();
                				btn.up('window').close();
                				window.location.assign('/manager.html');
                			} else {
                				Ext.Msg.alert('정보', result['msg']);
                			}
                		}
                	});
            	}
        	}
        }]
    }],
    
    listeners : {
    	afterrender : function (obj, eOpts) {
    		
    		if (cni.app.soundYN == 'Y') {
    			obj.down('#config_form').down('#sound_yn').setValue('on');
			} else {
				obj.down('#config_form').down('#sound_yn').setValue('');
			}
    		
    		if (cni.app.alertYN == 'Y') {
    			obj.down('#config_form').down('#alert_yn').setValue('on');
			} else {
				obj.down('#config_form').down('#alert_yn').setValue('');
			}
    		obj.down('#config_form').down('#dashboard_item').setValue(cni.app.dashboardItem);
    		obj.down('#config_form').down('#s_tm').setValue(cni.app.sTM);
    		obj.down('#config_form').down('#e_tm').setValue(cni.app.eTM);
    	}
    }
    
});

