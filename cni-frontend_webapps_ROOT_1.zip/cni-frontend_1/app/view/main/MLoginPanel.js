Ext.define('cni.view.main.MLoginPanel', {
    extend: 'Ext.form.Panel',
    xtype: 'mLoginPanel',

    title: '마을대기측정망 관제시스템',

    padding: "80 30 0 30",
    items: [{
        xtype: 'textfield',
        itemId: 'user_id',
        name: 'user_id',
        label: 'Login ID'
    },
    {
        xtype: 'passwordfield',
        itemId: 'user_pw',
        name: 'user_pw',
        label: 'Password'
    },{
    	xtype: 'button',
    	text: 'Login',
    	listeners: {
    		tap: function (btn, e, eOpts) {
    			Ext.Ajax.request({
    	    		url: '/system/getLoginInfo.ax',
    	    		method: 'POST',
    	    		params: {
    	    			user_id: btn.up('mLoginPanel').down('#user_id').getValue(),
    	    			user_pw: btn.up('mLoginPanel').down('#user_pw').getValue(),
    	    		},
    	    		waitMsg: 'login...',
    	    		success : function(res){
    	    			var result = Ext.decode(res.responseText);
    	    			if(result['code'] == 200) {
    	    				try {
    	    					cni.app.mLoginYN = 'Y';
    	    					btn.up('mLoginPanel').up('app-main').setActiveItem(1);
    	    					return true;
    	    				} catch (err) {
    	    		    		console.log('>> LoginController Message  : '+err.message);
    	    		    		return true;
    	    		    	}
    	    				
    	    			} else {
    	    				Ext.toast(result['msg']);
    	    				return false;
    	    			}
    	    		}
    	    	});
    		}
    	}
    }],
    listeners: {
    	activate: function (newActiveItem, me, oldActiveItem, eOpts) {
    	},
    	painted: function (me) {
        }
    }
});
