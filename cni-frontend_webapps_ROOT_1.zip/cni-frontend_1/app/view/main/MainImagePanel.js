Ext.define('cni.view.main.MainImagePanel', {
	extend: 'Ext.panel.Panel',
    xtype: 'mainImagePanel',

    id: 'mainImagePanel',
    reference: 'mainImagePanel',
    
    layout: 'fit',
    header:{
        //cls: 'header-cls1',
        title: {
            cls: 'header-title-cls',
            text: 'EMS Ver 3.0'
        }
    },
    items:[{
    	xtype: 'image',
    	reference: 'main_image',
    	src: '/images/main.jpg',
    	flex: 1
    }]
    	
});
