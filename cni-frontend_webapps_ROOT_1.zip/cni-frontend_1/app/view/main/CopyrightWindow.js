Ext.define('cni.view.main.CopyrightWindow', {
    extend: 'Ext.window.Window',
    xtype: 'copyrightWindow',
    title : 'System Information',
    iconCls : 'x-fa fa-info-circle',
    width : 430,
    autoShow : true,
    modal : true,
    layout : 'fit',
    bodyPadding: 20,
    html: '<p>System Name : 마을대기측정망통합관제시스템</p>'
    	+'<p>System Version : 1.0</p>'
    	+'<p>개발사 : (주)두일테크</p>'
    	+'<p>* 일부 데이터는 <b>Airkorea</b>에서 제공되는 자료이며,<br/>&nbsp;&nbsp;&nbsp;측정소 현지상태나 수신상태에 따라 미수신 될 수 있습니다.</p>'
    	+'<p>* Airkorea 제공자료는 충남도 내 도시대기측정망 등 국가 또는 <br/>&nbsp;&nbsp;&nbsp;지자체에서 운영하는 측정소 자료에 해당합니다.</p>'
});