Ext.define('cni.view.www.GaugePanel', {
	extend: 'Ext.panel.Panel',
    xtype: 'gaugePanel',

    requires: [
    	'Ext.chart.PolarChart',
    	'Ext.chart.series.sprite.PieSlice',
    	'Ext.chart.axis.Numeric',
    	'Ext.chart.series.Gauge'
   	],
    
   	
    //controller: 'dashboard.dashboardGraphController',
    id: 'gaugePanel',
    reference: 'gaugePanel',
    
    border: true,
    layout: 'fit',

    items: {
    	xtype: 'polar',
    	id: 'id_gauge',
    	itemId: 'itm_gauge',
        reference: 'ref_gauge',
        //insetPadding: '20 10 10 10',
        innerPadding: '10 10 10 10',
        insetPadding: 30,
        padding: '0 0 0 10',
        store: {
            fields: ['mph', 'fuel', 'temp', 'rpm'],
            data: [{
                mph: 65,
                fuel: 20,
                temp: 150,
                rpm: 6000
            }]
        },
        sprites: [{
            type: 'path',
            path: 'm9.21399,0c-5.07404,0 -9.21399,3.43396 -9.21399,7.62198l0,80.2005l44.935,0.6257l0.05701,-46.8692l8.47498,0c1.94702,0 3.526,1.29001 3.526,2.901l0,35.32199c0,4.7373 5.383,8.87372 11.48999,8.87372c5.76801,0 12.172,-3.78342 12.172,-8.87372c-0.08801,-1.18399 -4.664,-22.23999 -4.664,-22.23999c0,-0.048 -0.96698,-5.91501 -0.96698,-5.91501l0,-26.90399c0,-2.88098 -1.16602,-5.258 -3.526,-7.224l-15.01703,-12.40002c-1.03198,0 -3.92395,2.38904 -3.92395,2.38904c0,0.867 7.45099,6.996 7.45099,6.996l-0.22803,10.46597c0,3.70001 3.63501,6.71201 8.13403,6.71201l2.04797,0l-0.73999,19.965l1.02399,6.88202l4.55103,20.19299c0.17596,3.28369 -3.45203,5.2327 -6.31403,5.2327c-2.64099,0 -5.745,-1.82098 -5.745,-4.15271l0.05701,-35.379c0,-4.30899 -4.25,-7.79199 -9.44202,-7.79199l-9.04401,0c0.63403,-0.03699 0.62604,-23.23599 0.62604,-28.15601l0,-0.853c0,-4.18802 -4.09802,-7.62198 -9.15802,-7.62198l-26.56299,0l0,0zm0,5.517l26.56299,0c1.41602,0 2.50299,0.94498 2.50299,2.10498l0,18.48599c0,1.172 -1.08698,2.048 -2.50299,2.048l-26.56299,0c-1.43103,0 -2.50201,-0.87601 -2.50201,-2.048l0,-18.48599c0,-1.16 1.07098,-2.10498 2.50201,-2.10498zm55.401,14.84598c0,0 2.25598,0.39001 2.78699,0.51202c1.09198,0.23196 1.79102,1.59097 1.82001,2.78699c0.02997,1.20901 0,4.83499 0,4.83499c-3.34802,-0.61099 -4.60699,-2.03799 -4.60699,-3.35602l0,-4.77798z',
            fillStyle: 'rgb(255, 0, 0)',
            strokeStyle: 'none',
            scale: {
                x: 0.5,
                y: 0.5
            },
            translate: {
                x: 600,
                y: 600
            }
        }],
        axes: {
            title: 'Fuel',
            type: 'numeric',
            position: 'gauge',
            majorTickSteps: 4,
            renderer: function (axis, label, layoutContext, lastLabel) {
            	console.log('label = '+label);   
            	if (label === 20) return 'E';
                if (label === 25) return '1/4';
                if (label === 50) return '1/2';
                if (label === 75) return '3/4';
                if (label === 100) return 'F';
                return ' ';
            }
        },
        series: {
            type: 'gauge',
            colors: ['#0ff', '#666', '#00f', '#0ff'],
            angleField: 'fuel',
            //needle: true,
            donut: 50,
            /*renderer: function(sprite, config, rendererData, index) {
            	console.log('rendererData.value='+rendererData.value);
            	var value = rendererData.value;
                var color;
                if (value >= 95) {
                    color = "#0000ff";
                } else if (value < 85) {
                    color = "#00ff00";
                } else {
                    color = "#ff0000";
                }
                return {
                    fill: color
                };
                return Ext.apply(config, {
                    fill: color
                });
                
            }*/
        },
        
    },
    
    listeners: {
    	beforerender: function (obj, eOpts) {
    	},
    	render : function (obj, eOpts) {
    	},
    	afterrender: function (obj, eOpts) {
    	},
        //destroy: 'onTimeChartDestroy'
    	resize: function (obj, width, height, oldWidth, oldHeight, eOpts) {
			//obj.setWidth(Ext.getBody().getViewSize().width);
    		//obj.setHeight(Ext.getBody().getViewSize().height);
        }, 
    }
    
});
