Ext.define('cni.view.www.BarChartPanel', {
	extend: 'Ext.panel.Panel',
    xtype: 'barChartPanel',

    //controller: 'dashboard.dashboardGraphController',
    
    id: 'barChartPanel',
    reference: 'barChartPanel',
    
    border: true,
    layout: 'fit',

    items: {
    	xtype: 'cartesian',
    	id: 'id_barChart',
    	itemId: 'item_barChart',
        reference: 'ref_barChart',
        insetPadding: '20 10 10 10',
        innerPadding: '10 10 10 10',
        /*legend: {
            docked: 'right'
        },*/
        // 그래프 확대축소 
        /*interactions: {
            type: 'panzoom',
            zoomOnPanGesture: true
        },*/
        animation: {
        	easing: 'elasticOut',
            duration: 200
        },
        store: {
            type: 'comm.dataStore',
            listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/dashboard/getRegionTmsData.ax');
    				//var view = Ext.getCmp('barChartPanel');
    				obj.proxy.extraParams = {
    					grp_cd: '172',
    					item_cd: 'PM2'
        				//tms_cd: view.down("#tms_cd").getValue(),
        				//prevnt_no: view.down("#prevnt_no").getValue(),
        				//data_type: view.down("#data_type").getValue(),
    					//s_date: view.down("#s_date").getValue(),
	    				//e_date: view.down("#e_date").getValue()
					}
    	    	},
    	    	load: function (obj, records, successful, operation, eOpts) {
    	    		//Ext.getCmp('barChartPanel').down('#item_barChart').redraw();
    	    	}
            }
        },
        
        axes: [{
            type: 'numeric3d',
            //minimum: -1,
            //maximum: 50,
            position: 'left',
            title: {
            	text: '측정값',
            	fontSize: 15
            },
            grid: {
            	odd: {
            		fillStyle: 'rgba(255, 255, 255, 0.06)'
            	},
            	even: {
            		fillStyle: 'rgba(0, 0, 0, 0.03)'
            	}
            },
            label: {
            	fontSize: 10,
                textAlign: 'right'
            },
            //label: {fontSize: 10}
           	renderer: function (axis, label, layoutContext) {
                //return Ext.util.Format.number(layoutContext.renderer(label) / 1000, '0,000');
                return Ext.util.Format.number(layoutContext.renderer(label));
            }
        },{
        	type: 'category3d',
            position: 'bottom',
/*            title: {
                text: '측정소',
                fontSize: 15
            },*/
            fields: 'TMS_NM',
            label: {
            	//fontSize: 20,
            	rotate: {degrees: -45}
            }
        }],
        series: {
            type: 'bar3d',
            xField: 'TMS_NM',
            //yField: ['apples', 'oranges']
            yField: 'MSR_VL',
            
            style: {
                minGapWidth: 20
            },
            highlightCfg: {
                saturationFactor: 1.5
            },
            label: {
                field: 'MSR_VL',
                display: 'insideEnd',
                /*renderer: function (v) {
                	return Ext.util.Format.number(v / 1000, '0,000');
                }*/
                
            },
            tooltip: {
                trackMouse: true,
                renderer: function (tooltip, record, item) {
                    tooltip.setHtml(record.get('TMS_NM') + ': ' + Ext.util.Format.number(record.get('MSR_VL'), '0,000 (μg/m³)'));
                }
            	
            },
            renderer: function(sprite, config, rendererData, index){
            	console.log((rendererData.store.getAt(index)).get('LEVEL_CD'));
            	var fillColor;
            	switch ((rendererData.store.getAt(index)).get('LEVEL_CD')) {
	            	case 'A':
	            		fillColor = '#00F';break;
	            	case 'B':
	            		fillColor = '#0F0';break;
	            	case 'C':
	            		fillColor = '#FF0';break;
	            	case 'D':
	            		fillColor = '#F00';break;
	            	case 'X':
	            		fillColor = '#666';	break;
	            	default:
	            		fillColor = '#333';	break;
            	}

            	return Ext.apply(config, {
                   fill: fillColor
                });
             }
        },
        listeners: {
            //afterrender: 'onTimeChartRendered',
        	//destroy: 'onTimeChartDestroy'
        }
    },
    
    listeners: {
    	beforerender: function (obj, eOpts) {
    		console.log(1);
    		Ext.StoreManager.lookup('comm.dataStore').load();
    	},
    	render : function (obj, eOpts) {
    		console.log(2);
    		//new Ext.LoadMask(obj.down('#item_barChart'), {msg: 'Please Wait...', store: Ext.StoreManager.lookup('comm.dataStore')});
    	},
    	afterrender: function () {
    		console.log(3);
    	},
        //destroy: 'onTimeChartDestroy'
    	resize: function (obj, width, height, oldWidth, oldHeight, eOpts) {
			//obj.setWidth(Ext.getBody().getViewSize().width);
    		//obj.setHeight(Ext.getBody().getViewSize().height);
        }, 
    }
    
});
