Ext.define('cni.view.analysis.WeekPanel', {
	extend: 'Ext.form.Panel',
    xtype: 'weekPanel',

    requires: [
    	'cni.controller.analysis.AnalysisController'
    ],
    
    controller: 'analysis.analysisController',
    
    id: 'weekPanel',
    reference: 'weekPanel',
    
    title: '요일평균',
    iconCls : 'x-fa fa-stack-overflow',
    border: true,
    layout: 'fit',
    
    tools:[{
        iconCls : 'x-fa fa-save',
        tooltip: 'PDF',
        handler : 'fnWeekPDFDown'
    },{
    	iconCls : 'x-fa fa-table',
        tooltip: '엑셀',
        handler : 'fnWeekExcelDown'
    }],

    tbar: [{
        xtype: 'datefield',
        id:'s_date',
        name: 's_date',
        itemId:'s_date',
        fieldLabel: '시작일',
        format: 'Y/m/d',
        //value: Ext.Date.add(new Date(), Ext.Date.DAY, -7),
        value: new Date(),
        labelWidth: 50,
        width: 180,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -30),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },{xtype: 'label', text: ' ~ ' },{
        xtype: 'datefield',
        name: 'e_date',
        itemId:'e_date',
        fieldLabel: '종료일',
        format: 'Y/m/d',
        value: new Date(),
        labelWidth: 50,
        width: 180,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -29),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },{
    	xtype: 'combobox',
    	itemId: 'item_cd',
    	displayField:'ITEM_NM',
    	valueField:'ITEM_CD',
    	emptyText: '항목선택',
    	width: 150,
    	queryMode: 'local',
    	store: {
    		type : 'comm.itemStore',
    		autoLoad: true,
    		listeners : {
    			beforeload: function(store, records, successful, operation, eOpts) {
    				store.getProxy().setUrl('/comm/getItemList.ax');
    				store.proxy.extraParams = {
            				use_yn: 'Y'
					};
    	    	},
    			load: function(store, records, successful, operation, eOpts) {
    				Ext.getCmp('weekPanel').down('#item_cd').setValue(records[0].get('ITEM_CD'));
    			}
    		}
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.itemCD = newValue;
    		}
    	}
    },'->', {
    	xtype: 'button',
    	itemId: 'search_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : 'fnWeekSearch'
    }],
    
    items:[{
    	xtype: 'grid',
    	itemId: 'data_grid',
    	columnLines: true,
        height: '100%',
        loadMask: true,
        
    	columns : [{
        	text : '<b>시군</b>',
        	flex : 2,
        	dataIndex : 'REGION_NM',
        	//style: 'font-size: 16px',
        	align: 'center'
        },{
        	text : '<b>측정소</b>',
        	flex : 2,
        	dataIndex : 'TMS_NM',
        	//style: 'font-size: 16px',
        	align: 'center'
        }
    	,{text:'<b>월요일</b>',flex:1,dataIndex:'W0',align:'center',renderer:function(value,meta,record){value?value+=' '+record.get('ITEM_UNIT'):''; return value;}}
        ,{text:'<b>화요일</b>',flex:1,dataIndex:'W1',align:'center',renderer:function(value,meta,record){value?value+=' '+record.get('ITEM_UNIT'):''; return value;}}
        ,{text:'<b>수요일</b>',flex:1,dataIndex:'W2',align:'center',renderer:function(value,meta,record){value?value+=' '+record.get('ITEM_UNIT'):''; return value;}}
        ,{text:'<b>목요일</b>',flex:1,dataIndex:'W3',align:'center',renderer:function(value,meta,record){value?value+=' '+record.get('ITEM_UNIT'):''; return value;}}
        ,{text:'<b>금요일</b>',flex:1,dataIndex:'W4',align:'center',renderer:function(value,meta,record){value?value+=' '+record.get('ITEM_UNIT'):''; return value;}}
        ,{text:'<b>토요일</b>',flex:1,dataIndex:'W5',align:'center',renderer:function(value,meta,record){value?value+=' '+record.get('ITEM_UNIT'):''; return value;}}
        ,{text:'<b>일요일</b>',flex:1,dataIndex:'W6',align:'center',renderer:function(value,meta,record){value?value+=' '+record.get('ITEM_UNIT'):''; return value;}}
        ],
        store: {
        	type: 'comm.listStore',
    		autoLoad: false,
        	listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				var view = Ext.getCmp('weekPanel');
    				obj.getProxy().setUrl('/analysis/getWeekList.ax');
    				obj.proxy.extraParams = {
	    				s_date: view.down("#s_date").getValue(),
	    				e_date: view.down("#e_date").getValue(),
	    				item_cd: view.down("#item_cd").getValue()
					}
    	    	},
    	    	load: function(obj, records, successful, operation, eOpts) {
    	    	}
        	}	
        },
        
        listeners : {
        	rowdblclick : function (obj, record, element, rowIndex, e, eOpts) {
        	},
        	cellclick : function (obj, td, cellIndex, record, tr, rowIndex, e, eOpts) {
        	},
        	cellmouseup : function (obj, td, cellIndex, record, tr, rowIndex, e, eOpts) {
        	},
        	rowmouseup : function (obj, record, element, rowIndex, e, eOpts) {
        	}
    	}
    
    }],
    
    listeners : {
    	beforerender : function (obj, eOpts) {
    	},
    	render : function (obj, eOpts) {
    	},
    	afterrender : function (obj, eOpts) {
    		Ext.getCmp('weekPanel').down("#s_date").setValue(new Date());
    		Ext.getCmp('weekPanel').down("#e_date").setValue(new Date());
    	}, 
    	boxready : function(obj) {
		},
		destroy: function(obj, eOpts) {
    	}
	}
});
