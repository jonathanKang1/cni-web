Ext.define('cni.view.analysis.TimePanel', {
	extend: 'Ext.form.Panel',
    xtype: 'timePanel',

    requires: [
        'cni.controller.analysis.AnalysisController'
    ],
    
    controller: 'analysis.analysisController',
    
    id: 'timePanel',
    reference: 'timePanel',
    
    title: '시간평균',
    iconCls : 'x-fa fa-hourglass',
    border: true,
    layout: 'fit',
    
    tools:[{
        iconCls : 'x-fa fa-save',
        tooltip: 'PDF',
        handler : 'fnTimePDFDown'
    },{
    	iconCls : 'x-fa fa-table',
        tooltip: '엑셀',
        handler : 'fnTimeExcelDown'
    }],

    tbar: [{
        xtype: 'datefield',
        id:'s_date',
        name: 's_date',
        itemId:'s_date',
        fieldLabel: '시작일',
        format: 'Y/m/d',
        //value: Ext.Date.add(new Date(), Ext.Date.DAY, -7),
        value: new Date(),
        labelWidth: 50,
        width: 180,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -30),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },{xtype: 'label', text: ' ~ ' },{
        xtype: 'datefield',
        name: 'e_date',
        itemId:'e_date',
        fieldLabel: '종료일',
        format: 'Y/m/d',
        value: new Date(),
        labelWidth: 50,
        width: 180,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -29),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },{
    	xtype: 'combobox',
    	itemId: 'item_cd',
    	displayField:'ITEM_NM',
    	valueField:'ITEM_CD',
    	emptyText: '항목선택',
    	width: 150,
    	queryMode: 'local',
    	store: {
    		type : 'comm.itemStore',
    		autoLoad: true,
    		listeners : {
    			beforeload: function(store, records, successful, operation, eOpts) {
    				store.getProxy().setUrl('/comm/getItemList.ax');
    				store.proxy.extraParams = {
            				use_yn: 'Y'
					};
    	    	},
    			load: function(store, records, successful, operation, eOpts) {
    				Ext.getCmp('timePanel').down('#item_cd').setValue(records[0].get('ITEM_CD'));
    			}
    		}
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.itemCD = newValue;
    		}
    	}
    },'->', {
    	xtype: 'button',
    	itemId: 'search_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : 'fnTimeSearch'
    }],
    
    items:[{
    	xtype: 'grid',
    	itemId: 'data_grid',
    	columnLines: true,
        height: '100%',
        loadMask: true,
        
    	columns : [{
        	text : '<b>시군</b>',
        	flex : 2,
        	dataIndex : 'REGION_NM',
        	//style: 'font-size: 16px',
        	align: 'center'
        },{
        	text : '<b>측정소</b>',
        	flex : 2,
        	dataIndex : 'TMS_NM',
        	//style: 'font-size: 16px',
        	align: 'center'
        }
    	,{text:'<b>00시</b>',flex:1,dataIndex:'H00',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>01시</b>',flex:1,dataIndex:'H01',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>02시</b>',flex:1,dataIndex:'H02',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>03시</b>',flex:1,dataIndex:'H03',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>04시</b>',flex:1,dataIndex:'H04',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>05시</b>',flex:1,dataIndex:'H05',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>06시</b>',flex:1,dataIndex:'H06',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>07시</b>',flex:1,dataIndex:'H07',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>08시</b>',flex:1,dataIndex:'H08',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>09시</b>',flex:1,dataIndex:'H09',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>10시</b>',flex:1,dataIndex:'H10',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>11시</b>',flex:1,dataIndex:'H11',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>12시</b>',flex:1,dataIndex:'H12',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>13시</b>',flex:1,dataIndex:'H13',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>14시</b>',flex:1,dataIndex:'H14',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>15시</b>',flex:1,dataIndex:'H15',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>16시</b>',flex:1,dataIndex:'H16',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>17시</b>',flex:1,dataIndex:'H17',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>18시</b>',flex:1,dataIndex:'H18',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>19시</b>',flex:1,dataIndex:'H19',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>20시</b>',flex:1,dataIndex:'H20',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>21시</b>',flex:1,dataIndex:'H21',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>22시</b>',flex:1,dataIndex:'H22',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ,{text:'<b>23시</b>',flex:1,dataIndex:'H23',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
        ],
        store: {
        	type: 'comm.listStore',
        	listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				var view = Ext.getCmp('timePanel');
    				obj.getProxy().setUrl('/analysis/getTimeList.ax');
    				obj.proxy.extraParams = {
	    				s_date: view.down("#s_date").getValue(),
	    				e_date: view.down("#e_date").getValue(),
	    				item_cd: view.down("#item_cd").getValue()
					}
    	    	},
    	    	load: function(obj, records, successful, operation, eOpts) {
    	    	}
        	}	
        },
        
        listeners : {
        	cellclick : function (obj, td, cellIndex, record, tr, rowIndex, e, eOpts) {
        	}
    	}
    
    }],
    
    listeners : {
    	beforerender : function (obj, eOpts) {
    	},
    	render : function (obj, eOpts) {
    	},
    	afterrender : function (obj, eOpts) {
    		Ext.getCmp('timePanel').down("#s_date").setValue(new Date());
    		Ext.getCmp('timePanel').down("#e_date").setValue(new Date());
    	}, 
    	boxready : function(obj) {
		},
		destroy: function(obj, eOpts) {
    	}
	}
});
