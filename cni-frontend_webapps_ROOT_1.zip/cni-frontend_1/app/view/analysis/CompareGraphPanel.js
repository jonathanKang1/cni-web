Ext.define('cni.view.analysis.CompareGraphPanel', {
	extend: 'Ext.panel.Panel',
    xtype: 'compareGraphPanel',
    id: 'compareGraphPanel',
    reference: 'compareGraphPanel',
    
    requires: ['Ext.chart.theme.Muted'],
    
    border: true,
    layout: 'fit',

    items: {
    	xtype: 'cartesian',
    	id: 'compare_graph',
    	itemId: 'compare_graph',
        reference: 'compare_graph',
        theme: 'Muted',
        insetPadding: '30 10 10 10',
        innerPadding: '10 10 10 10',
        legend: false,
        /*legend: {
            docked: 'bottom'
        },*/
        // 그래프 확대축소 
        /*interactions: {
            type: 'panzoom',
            zoomOnPanGesture: true
        },*/
        interactions: ['itemhighlight'],
        /*animation: {
        	easing: 'elasticOut',
            duration: 200
        },*/
        store: {
            type: 'comm.dataStore',
            listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/data/getCompareDataList.ax');
    				obj.proxy.extraParams = {
    					region_cd  : Ext.getCmp('comparePanel').down("#region_cd").getValue(),
    					tms_cd     : Ext.getCmp('comparePanel').down("#tms_cd").getValue(),
    					region_cd_2: Ext.getCmp('comparePanel').down("#region_cd_2").getValue(),
    					tms_cd_2   : Ext.getCmp('comparePanel').down("#tms_cd_2").getValue(),
    					item_cd    : Ext.getCmp('comparePanel').down("#item_cd").getValue(),
	    				s_date     : Ext.getCmp('comparePanel').down("#s_date").getValue(),
	    				e_date     : Ext.getCmp('comparePanel').down("#e_date").getValue()
					}
    	    	},
    	    	load: function (obj, records, successful, operation, eOpts) {
    	    		//Ext.getCmp('compareGraphPanel').down('#item_barChart').redraw();
    	    		Ext.getCmp('compare_graph').setSprites({
    	                type: 'text',
    	                text: Ext.getCmp('comparePanel').down("#item_cd").getRawValue()+' ('+ Ext.getCmp('comparePanel').down("#tms_cd").getRawValue()+' vs '+Ext.getCmp('comparePanel').down("#tms_cd_2").getRawValue()+') 그래프',
    	                font: '20px Arial',
    	                x: 100, 
    	                y: 30  
    	        	});
    	    	}
            }
        },
        
        axes: [{
            type: 'numeric3d',
            //minimum: -1,
            //maximum: 50,
            fields: ['TMS_A', 'TMS_B'],
            position: 'left',
            title: {
            	text: '측정값',
            	fontSize: 15
            },
            grid: {
            	odd: {
            		fillStyle: 'rgba(255, 255, 255, 0.06)'
            	},
            	even: {
            		fillStyle: 'rgba(0, 0, 0, 0.03)'
            	}
            },
            label: {
            	fontSize: 10,
                textAlign: 'right'
            },
           	//renderer: function (axis, label, layoutContext) {
                //return Ext.util.Format.number(layoutContext.renderer(label) / 1000, '0,000');
                //return Ext.util.Format.number(layoutContext.renderer(label));
           		//var value = layoutContext.renderer(label) / 1000;
                //return value === 0 ? '$0' : Ext.util.Format.number(value, '$0K');
            //}
        },{
        	type: 'category3d',
            position: 'bottom',
            /*title: {
                text: '측정소',
                fontSize: 15
            },*/
            fields: 'DSP_DT',
            label: {
            	//fontSize: 20,
            	rotate: {degrees: -45}
            }
        }],
        series: {
            type: 'bar3d',
            stacked: false,
            title: ['측정소A', '측정소B'],
            xField: 'DSP_DT',
            yField: ['TMS_A', 'TMS_B'],
            //yField: 'MSR_VL',
            
            style: {
                minGapWidth: 10
            },
            highlightCfg: {
                saturationFactor: 1.5
            },
            /*label: {
                field: ['TMS_A', 'TMS_B'],
                display: 'insideEnd',
                renderer: function (v) {
                	//return Ext.util.Format.number(v / 1000, '0,000');
                }
                
            },*/
            /*tooltip: {
                trackMouse: true,
                renderer: function (tooltip, record, item) {
                    //tooltip.setHtml(record.get('TMS_NM') + ': ' + Ext.util.Format.number(record.get('MSR_VL'), '0,000 (μg/m³)'));
                }
            	
            },*/
            renderer: function(sprite, config, rendererData, index){
            	/*var fillColor;
            	switch ((rendererData.store.getAt(index)).get('LEVEL_CD')) {
	            	case 'A':
	            		fillColor = '#00F';break;
	            	case 'B':
	            		fillColor = '#0F0';break;
	            	case 'C':
	            		fillColor = '#FF0';break;
	            	case 'D':
	            		fillColor = '#F00';break;
	            	case 'X':
	            		fillColor = '#666';	break;
	            	default:
	            		fillColor = '#333';	break;
            	}
            	return Ext.apply(config, {
                   fill: fillColor
                });*/
             }
        }
    },
    
    bbar: [
        '->',
        {
            text: 'Preview',
            platformConfig: {
                desktop: {
                    text: 'Preview'
                }
            },
            handler: 'onCompareGraphPreview'
        },
        {
            text: 'Download',
            handler: 'onCompareGraphDownload'
        }
    ],
    
    listeners: {
    	beforerender: function (obj, eOpts) {
    	},
    	render : function (obj, eOpts) {
    	},
    	afterrender: function () {
    	},
        //destroy: 'onTimeChartDestroy'
    	resize: function (obj, width, height, oldWidth, oldHeight, eOpts) {
			//obj.setWidth(Ext.getBody().getViewSize().width);
    		//obj.setHeight(Ext.getBody().getViewSize().height);
        }, 
    }
    
});
