Ext.define('cni.view.analysis.DayPanel', {
	extend: 'Ext.form.Panel',
    xtype: 'dayPanel',
    id: 'dayPanel',
    reference: 'dayPanel',
    
    requires: [
    	'cni.controller.analysis.AnalysisController'
    ],
    
    controller: 'analysis.analysisController',
    
    title: '일평균',
    iconCls : 'x-fa fa-list-ol',
    border: true,
    layout: 'fit',
    
    tools:[{
        iconCls : 'x-fa fa-save',
        tooltip: 'PDF',
        handler : 'fnDayPDFDown'
    },{
    	iconCls : 'x-fa fa-table',
        tooltip: '엑셀',
        handler : 'fnDayExcelDown'
    }],

    tbar: [{
        xtype: 'datefield',
        id:'s_date',
        name: 's_date',
        itemId:'s_date',
        fieldLabel: '시작일',
        format: 'Y/m/d',
        //value: Ext.Date.add(new Date(), Ext.Date.DAY, -7),
        value: new Date(),
        labelWidth: 50,
        width: 180,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -30),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },{xtype: 'label', text: ' ~ ' },{
        xtype: 'datefield',
        name: 'e_date',
        itemId:'e_date',
        fieldLabel: '종료일',
        format: 'Y/m/d',
        value: new Date(),
        labelWidth: 50,
        width: 180,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -29),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },{
    	xtype: 'combobox',
    	itemId: 'item_cd',
    	displayField:'ITEM_NM',
    	valueField:'ITEM_CD',
    	emptyText: '항목선택',
    	width: 150,
    	queryMode: 'local',
    	store: {
    		type : 'comm.itemStore',
    		autoLoad: true,
    		listeners : {
    			beforeload: function(store, records, successful, operation, eOpts) {
    				store.getProxy().setUrl('/comm/getItemList.ax');
    				store.proxy.extraParams = {
            				use_yn: 'Y'
					};
    	    	},
    			load: function(store, records, successful, operation, eOpts) {
    				Ext.getCmp('dayPanel').down('#item_cd').setValue(records[0].get('ITEM_CD'));
    			}
    		}
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.itemCD = newValue;
    		}
    	}
    },'->', {
    	xtype: 'button',
    	itemId: 'search_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : 'fnDaySearch'
    }],
    
    items:[{
    	xtype: 'grid',
    	itemId: 'data_grid',
    	columnLines: true,
        height: '100%',
        loadMask: true,
        
    	columns : [{
        	text : '<b>시군</b>',
        	flex : 2,
        	dataIndex : 'REGION_NM',
        	//style: 'font-size: 16px',
        	align: 'center'
        },{
        	text : '<b>측정소</b>',
        	flex : 2,
        	dataIndex : 'TMS_NM',
        	//style: 'font-size: 16px',
        	align: 'center'
        }
    	,{text:'<b>1일</b>',flex:1,dataIndex:'D01',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>2일</b>',flex:1,dataIndex:'D02',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>3일</b>',flex:1,dataIndex:'D03',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>4일</b>',flex:1,dataIndex:'D04',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>5일</b>',flex:1,dataIndex:'D05',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>6일</b>',flex:1,dataIndex:'D06',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>7일</b>',flex:1,dataIndex:'D07',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>8일</b>',flex:1,dataIndex:'D08',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>9일</b>',flex:1,dataIndex:'D09',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>10일</b>',flex:1,dataIndex:'D10',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>11일</b>',flex:1,dataIndex:'D11',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>12일</b>',flex:1,dataIndex:'D12',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>13일</b>',flex:1,dataIndex:'D13',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>14일</b>',flex:1,dataIndex:'D14',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>15일</b>',flex:1,dataIndex:'D15',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>16일</b>',flex:1,dataIndex:'D16',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>17일</b>',flex:1,dataIndex:'D17',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>18일</b>',flex:1,dataIndex:'D18',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>19일</b>',flex:1,dataIndex:'D19',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>20일</b>',flex:1,dataIndex:'D20',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>21일</b>',flex:1,dataIndex:'D21',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>22일</b>',flex:1,dataIndex:'D22',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>23일</b>',flex:1,dataIndex:'D23',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>24일</b>',flex:1,dataIndex:'D24',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>25일</b>',flex:1,dataIndex:'D25',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>26일</b>',flex:1,dataIndex:'D26',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>27일</b>',flex:1,dataIndex:'D27',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>28일</b>',flex:1,dataIndex:'D28',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>29일</b>',flex:1,dataIndex:'D29',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>30일</b>',flex:1,dataIndex:'D30',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	,{text:'<b>31일</b>',flex:1,dataIndex:'D31',align:'center',renderer:function(value,meta,record){meta.tdAttr='data-qtip="'+(value?value+' '+record.get('ITEM_UNIT'):'')+'"'; return value;}}
    	
        ],
        store: {
        	type: 'comm.listStore',
        	listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				var view = Ext.getCmp('dayPanel');
    				obj.getProxy().setUrl('/analysis/getDayList.ax');
    				obj.proxy.extraParams = {
	    				s_date: view.down("#s_date").getValue(),
	    				e_date: view.down("#e_date").getValue(),
	    				item_cd: view.down("#item_cd").getValue()
					}
    	    	},
    	    	load: function(obj, records, successful, operation, eOpts) {
    	    	}
        	}	
        }
    }],
    
    listeners : {
    	beforerender : function (obj, eOpts) {
    	},
    	render : function (obj, eOpts) {
    	},
    	afterrender : function (obj, eOpts) {
    		Ext.getCmp('dayPanel').down("#s_date").setValue(new Date());
    		Ext.getCmp('dayPanel').down("#e_date").setValue(new Date());
    	}, 
    	boxready : function(obj) {
		},
		destroy: function(obj, eOpts) {
    	}
	}
});
