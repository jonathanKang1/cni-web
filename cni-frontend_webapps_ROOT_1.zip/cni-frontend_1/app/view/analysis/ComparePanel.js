Ext.define('cni.view.analysis.ComparePanel', {
	extend: 'Ext.panel.Panel',
    xtype: 'comparePanel',
    id: 'comparePanel',
    reference: 'comparePanel',
    //requires: 'Ext.chart.theme.Category2',
    controller: 'data.dataController',
    
    
    title: '자료비교',
    iconCls : 'x-fa fa-compress',
    
    layout: {type: 'hbox', pack: 'start', align: 'stretch'},

    /*bodyPadding: 10,
    defaults: {frame: true, bodyPadding: 10},*/

    tools:[{
        iconCls : 'x-fa fa-save',
        tooltip: 'PDF',
        handler : 'fnComparePDFDown'
    },{
        //type:'gear',
    	iconCls : 'x-fa fa-table',
        tooltip: '엑셀',
        handler : 'fnCompareExcelDown'
    }],
    
    tbar: [{
    	xtype: 'combo',
    	itemId:'net_cd',
    	displayField: 'net_nm',
        valueField: 'net_cd',
        value: 'ALL',
        width: 110,
        queryMode: 'local',
    	store: {
    		fields: ['net_cd', 'net_nm'],
    	    data : [
    	    	{'net_cd':'ALL', 'net_nm':'망구분(전체)'},
    	    	{'net_cd':'C', 'net_nm':'마을대기'},
    	        {'net_cd':'A', 'net_nm':'국가대기'}
    	    ]
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.netCD = newValue;
    			Ext.getCmp('comparePanel').down('#region_cd').getStore().load();
    			Ext.getCmp('comparePanel').down('#region_cd_2').getStore().load();
    			//Ext.StoreManager.lookup('comm.regionStore').load();
    		}
    	}
    },'|',{
    	xtype: 'combobox',
    	itemId: 'region_cd',
    	displayField:'REGION_NM',
    	valueField:'REGION_CD',
    	emptyText: '지역선택',
    	width: 120,
    	queryMode: 'local',
    	store: {
    		type : 'comm.regionStore',
    		autoLoad: true,
    		listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/comm/getUseRegionList.ax');
    				obj.proxy.extraParams = {
    					net_cd: cni.app.netCD
    				};
    	    	},
    			load: function(obj, records, successful, operation, eOpts) {
    				if (records.length > 0) {
    					Ext.getCmp('comparePanel').down('#region_cd').setValue(records[0].get('REGION_CD'));
    					cni.app.regionCD = records[0].get('REGION_CD');
    					Ext.getCmp('comparePanel').down('#tms_cd').getStore().load();
    				}
        		}
        	}	
    	}, 
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.regionCD = newValue;
    			combo.up('comparePanel').down('#tms_cd').getStore().load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'tms_cd',
    	displayField:'TMS_NM',
    	valueField:'TMS_CD',
    	emptyText: '측정소선택',
    	width: 100,
    	queryMode: 'local',
    	store: {
    		type : 'comm.tmsStore',
    		autoLoad: false,
    		listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/comm/getUseTmsList.ax');
    				obj.proxy.extraParams = {
    					net_cd: cni.app.netCD,	
    	    			region_cd: Ext.getCmp('comparePanel').down('#region_cd').getValue()
    				};
    	    	},
    			load: function(obj, records, successful, operation, eOpts) {
    				Ext.getCmp('comparePanel').down('#tms_cd').setValue(records[0].get('TMS_CD'));
    			}
    		}
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.tmsCD = newValue;
    			Ext.StoreManager.lookup('comm.itemStore').load();
    			
    		}
    	}
    },'|',{
    	xtype: 'combobox',
    	itemId: 'region_cd_2',
    	displayField:'REGION_NM',
    	valueField:'REGION_CD',
    	emptyText: '지역선택',
    	width: 120,
    	queryMode: 'local',
    	store: {
    		type : 'comm.regionStore',
    		autoLoad: true,
    		listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/comm/getUseRegionList.ax');
    				obj.proxy.extraParams = {
    					net_cd: cni.app.netCD
    				};
    	    	},
    			load: function(obj, records, successful, operation, eOpts) {
    				if (records.length > 0) {
    					Ext.getCmp('comparePanel').down('#region_cd_2').setValue(records[0].get('REGION_CD'));
    					cni.app.regionCD = records[0].get('REGION_CD');
    					Ext.getCmp('comparePanel').down('#tms_cd_2').getStore().load();
    				}
        		}
        	}	
    	}, 
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.regionCD = newValue;
    			combo.up('comparePanel').down('#tms_cd_2').getStore().load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'tms_cd_2',
    	displayField:'TMS_NM',
    	valueField:'TMS_CD',
    	emptyText: '측정소선택',
    	width: 100,
    	queryMode: 'local',
    	store: {
    		type : 'comm.tmsStore',
    		autoLoad: false,
    		listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/comm/getUseTmsList.ax');
    				obj.proxy.extraParams = {
    					net_cd: cni.app.netCD,
    					region_cd: Ext.getCmp('comparePanel').down('#region_cd_2').getValue()
    				};
    	    	},
    			load: function(obj, records, successful, operation, eOpts) {
    				Ext.getCmp('comparePanel').down('#tms_cd_2').setValue(records[0].get('TMS_CD'));
    			}
    		}
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			//cni.app.tmsCD = newValue;
    		}
    	}
    },'|',{
    	xtype: 'combobox',
    	itemId: 'item_cd',
    	displayField:'ITEM_NM',
    	valueField:'ITEM_CD',
    	emptyText: '항목선택',
    	width: 100,
    	queryMode: 'local',
    	store: {
    		type : 'comm.itemStore',
    		autoLoad: false,
    		listeners : {
    			beforeload: function(store, records, successful, operation, eOpts) {
    				store.getProxy().setUrl('/comm/getUseItemList.ax');
    				store.proxy.extraParams = {
            				tms_cd: cni.app.tmsCD
					};
    	    	},
    			load: function(store, records, successful, operation, eOpts) {
    				Ext.getCmp('comparePanel').down('#item_cd').setValue(records[0].get('ITEM_CD'));
    			}
    		}
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.itemCD = newValue;
    		}
    	}
    },{
        xtype: 'datefield',
        id:'s_date',
        name: 's_date',
        itemId:'s_date',
        fieldLabel: '시작일',
        format: 'Y/m/d',
        value: new Date(),
        labelWidth: 45,
        width: 150,
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },{
        xtype: 'datefield',
        name: 'e_date',
        itemId:'e_date',
        fieldLabel: '종료일',
        format: 'Y/m/d',
        value: new Date(),
        labelWidth: 45,
        width: 150,
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },'->', {
    	xtype: 'button',
    	itemId: 'search_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : 'fnCompareDataSearch'
    	/*handler : function (btn) {
    		console.log('>> btn.up("dataPanel").down("#tms_cd").getValue() = '+btn.up('dataPanel').down('#tms_cd').getValue());
    		btn.up('dataPanel').getStore('comm.listStore').reload();
    	}*/
    }],
    
    items: [{
    	xtype: 'grid',
    	itemId: 'compare_grid',
        flex: 1,
        margin: '0 5 0 0',
        border: true,
        layout: 'fit',
        height: '100%',
        loadMask: true,
    	columns : [{
        	text : '측정시간',
        	flex : 1,
        	dataIndex : 'DSP_DT',
        	align: 'center'
        },{
        	text : '측정값',
        	flex : 1,
        	align: 'center',
        	columns : [{
        		text : '측정소A',
            	flex : 1,
            	align: 'center',
            	dataIndex : 'MSR_VL'
        	},{
        		text : '측정소B',
        		flex : 1,
        		align: 'center',
        		dataIndex : 'MSR_VL_2'
            }]
        	
        },{
        	text : '<b>8h평균</b>',
        	flex : 1,
        	align: 'center',
        	columns : [{
        		text : '측정소A',
            	flex : 1,
            	align: 'center',
            	dataIndex : 'AVG_08'
        	},{
        		text : '측정소B',
        		flex : 1,
        		align: 'center',
        		dataIndex : 'AVG_08_2'
            }]
        },{
        	text : '<b>24h평균</b>',
        	flex : 1,
        	align: 'center',
        	columns : [{
        		text : '측정소A',
            	flex : 1,
            	align: 'center',
            	dataIndex : 'AVG_08'
        	},{
        		text : '측정소B',
        		flex : 1,
        		align: 'center',
        		dataIndex : 'AVG_08_2'
            }]
        },{
        	text : '<b>지수</b>',
        	flex : 1,
        	align: 'center',
        	columns : [{
        		text : '측정소A',
            	flex : 1,
            	align: 'center',
            	dataIndex : 'AI_VL'
        	},{
        		text : '측정소B',
        		flex : 1,
        		align: 'center',
        		dataIndex : 'AI_VL_2'
            }]
        }],
        
        store: {
        	type: 'comm.listStore',
        	autoLoad: false,
        	listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/data/getCompareDataList.ax');
    				obj.proxy.extraParams = {
    					region_cd  : Ext.getCmp('comparePanel').down("#region_cd").getValue(),
    					tms_cd     : Ext.getCmp('comparePanel').down("#tms_cd").getValue(),
    					region_cd_2: Ext.getCmp('comparePanel').down("#region_cd_2").getValue(),
    					tms_cd_2   : Ext.getCmp('comparePanel').down("#tms_cd_2").getValue(),
    					item_cd    : Ext.getCmp('comparePanel').down("#item_cd").getValue(),
	    				s_date     : Ext.getCmp('comparePanel').down("#s_date").getValue(),
	    				e_date     : Ext.getCmp('comparePanel').down("#e_date").getValue()
					}
    	    	},
    	    	load: function(obj, records, successful, operation, eOpts) {
    	    	}
        	}	
        }
    },{
    	//title: 'Panel 3',
    	xtype: 'compareGraphPanel',
    	flex: 1,
    	margin: '0 0 0 5',
        border: true,
    	//html: 'flex : 1'
    }],
    
    listeners : {
    	beforerender : function (obj, eOpts) {
    		obj.down('#net_cd').setValue(cni.app.netCD);
    		//obj.down('#region_cd').setValue(cni.app.regionCD);
    		//obj.down("#s_date").setValue(new Date());
    		//obj.down("#e_date").setValue(new Date());
    		/*obj.down('grid').headerCt.getHeaderAtIndex(0).setText('Name0');
    		obj.down('grid').headerCt.getHeaderAtIndex(1).setText('Name1');
    		obj.down('grid').headerCt.getHeaderAtIndex(2).setText('Name2');*/
    	},
    	render : function (obj, eOpts) {
    	},
    	afterrender : function (obj, eOpts) {
    	}, 
    	boxready : function(obj) {
		},
		destroy: function(obj, eOpts) {
    	}
	}
    
});