Ext.define('cni.view.login.ChangePasswordWindow', {
    extend: 'Ext.window.Window',
    xtype: 'changePasswordWindow',
    
    title : '비밀번호 변경',
    iconCls : 'x-fa fa-key',
    width : 400,
    //height : 200,
    //closable : true,	//default true
    //maximizable : true,
    autoShow : true,
    modal : true,
    layout : 'fit',
    onEsc : function(){
    	this.close();
    	return true;
    },

    items : [{
    	xtype : 'form',
    	frame: false,
        bodyPadding: 10,
        
        fieldDefaults: {
            labelAlign: 'right',
            labelWidth: 100,
            anchor: '100%',
            msgTarget: 'side',
            minLength: 9,
        	maxLength: 15
        },
        
    	items : [{
    		xtype : 'textfield',
    		inputType :'password',
    		itemId: 'user_pw',
    		name: 'user_pw',
    		fieldLabel : '현재비밀번호',
    		allowBlank:false,
    		minLength: 9, maxLength: 15,
    		emptyText: '현재 비밀번호를 입력하세요'
    	},{
    		xtype : 'textfield',
    		inputType :'password',
    		itemId: 'new_pw',
    		name: 'new_pw',
    		fieldLabel : '신규비밀번호',
    		allowBlank:false,
    		minLength: 9, maxLength: 15,
    		emptyText: '신규 비밀번호를 입력하세요'
    	},{
    		xtype : 'textfield',
    		inputType :'password',
    		itemId: 'confirm_pw',
    		name: 'confirm_pw',
    		fieldLabel : '비밀번호 확인',
    		allowBlank:false,
    		minLength: 9, maxLength: 15,
    		emptyText: '다시 한번 입력하세요',
    		enableKeyEvents: true,
    		listeners: {                   
                'keypress': function(field,event){
                    if (event.getKey() == event.ENTER) {
                    	var chgBtn = this.up('changePasswordWindow').down('#chg_btn');
                    	chgBtn.fireEvent('click', chgBtn);
                    }
                }                                   
            }
    	},{
    		//border:false,
    		html:'<img align=absbottom src="/images/icon/fam/information.png"/> 비밀번호는 영문, 숫자, 특수문자(!@#$%^&*)를 포함하여<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;9~15자  이내 이어야 하며, 동일문자의 반복 또는 연속되는<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;문자가 3자리 이상 될 수 없습니다!'
    	}],
    	buttons: [{
        	xtype : 'button',
        	text : '비밀번호변경',
        	itemId: 'chg_btn',
        	formBind: true,
        	//handler : 'fnUpdate'
        	listeners : {
        		click: function(btn, e, eOpts) {

        			if (btn.up('changePasswordWindow').down('#new_pw').getValue() != btn.up('changePasswordWindow').down('#confirm_pw').getValue()) {
        				Ext.Msg.alert('정보', '신규 비밀번호가 일치하지 않습니다.');
        				return false;
        			}
        			
        	    	var params = btn.up('changePasswordWindow').down('form').getForm().getValues();
        	    	
        	    	if (fnPasswdValidater(params['new_pw'])) {

        	    		Ext.Ajax.request({
	                		url : '/system/setUserInfo.ax',
	                		method : 'POST',
	                		params : params,
	                		success : function(res){
	                			var result = Ext.decode(res.responseText);            
	                			if (result['msg'] == 'Y') {
	                				Ext.toast({
	                					html: '비밀번호가 변경되었습니다.'
	                                });
	                				btn.up('window').close();
	                				
	                			} else {
	                				Ext.Msg.alert('정보', result['msg']);
	                			}
	                		}
	                	});
        	    	} else {
        	    		Ext.Msg.alert("알림","비밀번호 규칙을 확인하세요");
        				return false;
        	    	}
            	}
        	}
        }]
    }],
    
    listeners : {
    	afterrender : function (obj, eOpts) {

    	}
    }
    
});