//test_code
var viewSize = Ext.getBody().getViewSize();
Ext.define('cni.view.login.LoginWindow', {
    extend: 'Ext.window.Window',
    xtype: 'loginWindow',
    
    controller: 'loginController',

    width : 400,
    closable : false,
    //maximizable: true,
    autoShow : true,
    modal : true,
    title : 'Log-in',
    iconCls : 'x-fa fa-key',	
    renderTo: Ext.getBody(),
    onEsc : function(){
    	return false;
    },
    
    items : [{
    	xtype : 'form',
    	frame: false,	//default false
    	bodyPadding: 10,
    	
    	fieldDefaults: {
            labelAlign: 'right',
            labelWidth: 100,
            anchor: '100%',
            msgTarget: 'side'
        },
        
    	items : [{
    		xtype : 'textfield',
    		reference: 'user_id',
            allowBlank: false,
            fieldLabel: 'User ID',
            name: 'user_id',
            emptyText: 'user id',
            msgTarget: 'under',
            value: Ext.util.Cookies.get('user_id')
        }, {
        	xtype : 'textfield',
            allowBlank: false,
            fieldLabel: 'Password',
            name: 'user_pw',
            emptyText: 'password',
            inputType: 'password',
            minLength: 9,
        	maxLength: 15,
            enableKeyEvents: true,
            listeners: {                   
                'keypress': function(field,event){
                    if (event.getKey() == event.ENTER) {
                    	var loginBtn = this.up('loginWindow').down('#login_btn');
                    	loginBtn.fireEvent('click', loginBtn);
                    }
                }                                   
            }
        }, {
            xtype:'checkbox',
            reference: 'remember',
            fieldLabel: 'ID 저장',
            checked: Ext.util.Cookies.get('user_id'),
            name: 'remember'
        }],
	    buttons: [
	        {text:'Login', itemId: 'login_btn', formBind: true,/*handler : 'fnLogin', */listeners: {click: 'fnLogin'}}
	    ]
    }],
   
    listeners : {
    	beforerender : function (obj, eOpts) {
    	},
    	render : function (obj, eOpts) {
    	},
    	afterrender : function (obj, eOpts) {
    	}, 
    	boxready : function(obj) {
		}
	}

});

