Ext.define('cni.view.system.UserRoleWindow', {
    extend: 'Ext.window.Window',
    xtype: 'userRoleWindow',      

    title: '사용자권한등록',
    width : 600,
    closable : true,
    autoShow : true,
    modal : true,
    layout : 'fit',
    
    
    items : [{
    	xtype : 'form',
    	frame: false,
        bodyPadding: 10,
        scrollable:true,
        method: 'POST',
        fieldDefaults: {
            labelAlign: 'right',
            labelWidth: 100,
            msgTarget: 'side'
        },

        items: [{
            xtype: 'fieldset',
            title: '사용자 권한 정보',
            itemId: 'userRoleTitle',
            defaultType: 'textfield',
            defaults: {
                anchor: '100%'
            },

            items: [{
            	xtype: 'itemselector',
                itemId: 'user_role_menus',
                name: 'user_role_menus',
                flex : 1,
                height: 250,
                store: {
                	type: 'comm.listStore',
                	autoLoad: true,
                	listeners : {
            			beforeload: function(obj, records, successful, operation, eOpts) {
            				obj.getProxy().setUrl('/system/getMenuList.ax');
            			}
                	}
                },
                displayField: 'MENU_NM',
                valueField: 'MENU_ID',
                //value: ['COb', 'NOX'],
                allowBlank: false,
                msgTarget: 'side',
                fromTitle: '전체권한',
                toTitle: '사용자권한'
            }]
        }],
        fbar : [{
        	xtype : 'button', 
        	text : '저장', 
        	iconCls: 'x-fa fa-save',
        	formBind: true,
        	handler : function(sbtn){ 
        		var form = sbtn.up('userRoleWindow').down('form').getForm();
    			if (form.isValid()) {
    				
    				form.submit({
                    	clientValidation: true,
                    	params: {
                    		user_id : sbtn.up('userRoleWindow').config.selectedUserId.getValue()
                        },
                        url: '/system/setUserRoles.ax',
                        waitMsg: 'Uploading your Content...',
                        success: function(frm, action) {
                        	var result = Ext.JSON.decode(action.response.responseText);
                            Ext.Msg.confirm('정보', result.msg, function(btn) {
                            	if (btn == 'yes') {
                            		sbtn.up('userRoleWindow').close();
                            	}
                            });
                        },
                        failure: function(frm, action) {
                        	console.log('failure');
                        	var result = Ext.JSON.decode(action.response.responseText);
                        	Ext.MessageBox.show({
                            	title : '정보',
                            	msg : result.msg,
                                buttons : Ext.MessageBox.YES,
                                icon : Ext.MessageBox.INFO
                            });
                        }
                    });
    			}
        	}
        }]
        /*buttons: [{
            text: '저장',
            iconCls: 'x-fa fa-save',
            formBind: true,
            listeners : {
        		click: function(btn, e, eOpts) {
        			//var params = btn.up('userRoleWindow').down('form').getForm().getValues(true); ","가 "%2C"로 전달됨
        			var params = btn.up('userRoleWindow').down('form').getForm().getValues();
        	    	
            		Ext.Ajax.request({
                		url : '/system/setUserRoles.ax',
                		method : 'POST',
                		params : {params, user_id : btn.up('userRoleWindow').config.selectedUserId.getValue()},
                		success : function(res){
                			var result = Ext.decode(res.responseText);            
                			if (result['code'] == '200') {
                				//btn.up('window').config.myParentStore.reload();
                				btn.up('window').close();
                			} else {
                				Ext.Msg.alert('정보', '시스템오류가 발생하였습니다</br>관리자에게 문의하시기 바랍니다.');
                			}
                		}
                	});
            	}
        	}
        }]*/  
    }],

    defaults: {
        anchor: '100%',
        labelWidth: 100
    },
    
    listeners : {
    	afterrender : function (obj, eOpts) {
    		obj.down('#userRoleTitle').setTitle(obj.config.selectedUserName.getValue()+'('+obj.config.selectedUserId.getValue()+')'+' 사용자 권한 정보');
    		Ext.Ajax.request({
        		url : '/system/getUserRoleList.ax',
        		method : 'POST',
        		params : {user_id: obj.config.selectedUserId.getValue()},
        		success : function(res){
        			var result = Ext.decode(res.responseText);            
        			obj.down('#user_role_menus').setValue(result['roles']);
        		}
        	});
    	}
    }

});

