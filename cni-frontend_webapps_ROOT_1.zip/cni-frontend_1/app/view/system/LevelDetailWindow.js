Ext.define('cni.view.system.LevelDetailWindow', {
    extend: 'Ext.window.Window',
    xtype: 'levelDetailWindow',
    
    //controller: 'system.systemController',
    
    title: '항목별등급정보',
    
    width : 400,
    //closable : true,	//default true
    autoShow : true,
    modal : true,
    layout : 'fit',
    onEsc : function(){
    	this.close();
    	return true;
    },
    
    items : [{
    	xtype : 'form',
    	frame: false,
        bodyPadding: 10,
        scrollable:true,

        fieldDefaults: {
            labelAlign: 'right',
            labelWidth: 100,
            msgTarget: 'side'
        },

        items: [{
            xtype: 'fieldset',
            title: '사용자 정보',
            defaultType: 'textfield',
            defaults: {
                anchor: '100%'
	        },
	
	        items: [
	        	{ allowBlank:false, fieldLabel: '항목', itemId: 'item_nm', name: 'item_nm', maxLength: 20, emptyText: '항목명'},
		        { hidden: true, allowBlank:false, fieldLabel: '항목코드', itemId: 'item_cd', name: 'item_cd', maxLength: 20, emptyText: '항목코드'},
		        { allowBlank:false, fieldLabel: '등급', itemId: 'level_nm', name: 'level_nm', maxLength: 20, emptyText: '등급명'},
		        { hidden: true, allowBlank:false, fieldLabel: '등급코드', itemId: 'level_cd', name: 'level_cd', maxLength: 20, emptyText: '등급코드'},
		        { hidden: true, allowBlank:false, fieldLabel: '구분코드', itemId: 'level_type', name: 'level_type', maxLength: 20, emptyText: '구분코드'},
		        { allowBlank:false, fieldLabel: '하한값', itemId: 'l_vl', name: 'l_vl', maxLength: 6, emptyText: '숫자입력', validator: function (val) {
		        	if (/[^0-9.]/g.test(val)) return '6자리 이내의 숫자로 입력하세요';
		        	else return true;
		        }},
		        { allowBlank:false, fieldLabel: '상한값', itemId: 'h_vl', name: 'h_vl', maxLength: 6, emptyText: '숫자입력', validator: function (val) {
		        	if (/[^0-9.]/g.test(val)) return '6자리 이내의 숫자로 입력하세요';
		        	else return true;
		        }},
		        { allowBlank:false, fieldLabel: '소수점자리수', itemId: 'decimal_point', name: 'decimal_point', maxLength: 1, emptyText: '숫자입력', validator: function (val) {
		        	if (/[^0-9.]/g.test(val)) return '1자리 이내의 숫자로 입력하세요';
		        	else return true;
		        }}
		    ]
        },{
        	xtype: 'textfield', itemId: 'job_cd', name: 'job_cd', value: 'I', hidden: true
    	}],
    	
        buttons: [{
            text: '저장',
            iconCls: 'x-fa fa-save',
            formBind: true,
            listeners : {
        		click: function(btn, e, eOpts) {
        			if(btn.up('levelDetailWindow').down('#level_cd').getValue() == 'Z') {
        				btn.up('levelDetailWindow').down('#l_vl').setValue('');
        				btn.up('levelDetailWindow').down('#h_vl').setValue('');
        			} else {
        				btn.up('levelDetailWindow').down('#decimal_point').setValue('');
        			}
        			var rtn_tf = false;
        			var params = btn.up('levelDetailWindow').down('form').getForm().getValues();
        			Ext.Ajax.request({
                		url : '/system/setLevelInfo.ax',
                		method : 'POST',
                		params : params,
                		success : function(res){
                			var result = Ext.decode(res.responseText);            
                			if (result['code'] == '200') {
                				btn.up('window').config.myParentStore.reload();
                				Ext.toast({html: '등급정보가 등록(수정)되었습니다.'});
                				btn.up('window').close();
                			} else {
                				Ext.Msg.alert('정보', result['msg']);
                			}
                		}
                	});
            	}
        	}
        }]
    }],

    defaults: {
        anchor: '100%',
        labelWidth: 100
    },
    
    listeners : {
    	afterrender : function (obj, eOpts) {
    		
    		//등록이 아닌 수정인 경우 비교
    		if (obj.config.selectedRecord != '') {
    			//Ext.Msg.alert('정보', obj.config.selectedRecord.data.user_id);
    			obj.down('#job_cd').setValue('U');
	    		obj.down('#item_cd').setValue(obj.config.selectedRecord.data.ITEM_CD).setReadOnly(true);
	    		obj.down('#item_nm').setValue(obj.config.selectedRecord.data.ITEM_NM).setReadOnly(true);
	    		obj.down('#level_cd').setValue(obj.config.selectedRecord.data.LEVEL_CD).setReadOnly(true);
	    		obj.down('#level_nm').setValue(obj.config.selectedRecord.data.LEVEL_NM).setReadOnly(true);
	    		obj.down('#level_type').setValue(obj.config.selectedRecord.data.LEVEL_TYPE).setReadOnly(true);
	    		
	    		if(obj.config.selectedRecord.data.LEVEL_CD == 'Z') {
	    			obj.down('#l_vl').setValue(0).setHidden(true);
	    			obj.down('#h_vl').setValue(0).setHidden(true);
	    			obj.down('#decimal_point').setValue(obj.config.selectedRecord.data.DECIMAL_POINT);
	    		} else {
	    			obj.down('#l_vl').setValue(obj.config.selectedRecord.data.L_VL);
	    			obj.down('#h_vl').setValue(obj.config.selectedRecord.data.H_VL);
	    			obj.down('#decimal_point').setValue(0).setHidden(true);
	    		}
    		}
    	}
    }

});

