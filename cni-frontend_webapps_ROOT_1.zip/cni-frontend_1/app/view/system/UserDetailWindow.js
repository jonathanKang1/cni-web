Ext.define('cni.view.system.UserDetailWindow', {
    extend: 'Ext.window.Window',
    xtype: 'userDetailWindow',

    title: '사용자등록',
    width : 400,
    //closable : true,	//default true
    autoShow : true,
    modal : true,
    layout : 'fit',
    onEsc : function(){
    	this.close();
    	return true;
    },
    
    items : [{
    	xtype : 'form',
    	frame: false,
        bodyPadding: 10,
        scrollable:true,
        method: 'POST',
        fieldDefaults: {
            labelAlign: 'right',
            labelWidth: 100,
            msgTarget: 'side'
        },

        items: [{
            xtype: 'fieldset',
            title: '사용자 정보',
            defaultType: 'textfield',
            defaults: {
                anchor: '100%'
            },

            items: [
	            { allowBlank:false, fieldLabel: '계정ID', itemId: 'user_id', name: 'user_id', maxLength: 20, emptyText: '계정 ID'},
	            { allowBlank:false, fieldLabel: '계정명', itemId: 'user_nm', name: 'user_nm', maxLength: 20, emptyText: '계정명'},
	            //{ allowBlank:true, fieldLabel: '담당자명', itemId: 'mgr_nm', name: 'mgr_nm', maxLength: 20, emptyText: '담당자명'},
	            { allowBlank:false, fieldLabel: 'SMS수신번호', itemId: 'receive_num', name: 'receive_num', maxLength: 11, emptyText: '숫자만입력하세요',
	            	validator: function(input_value) {
	                	if (/[^0-9]/g.test(input_value)) {
	                		input_value = input_value.replace(/[^0-9]/g,'');
	                	}
	                	this.setValue(input_value);
	                	return true;
	            	}
	            },
	            { allowBlank:true,  fieldLabel: '비밀번호', itemId: 'new_pw', name: 'new_pw', minLength: 9, maxLength: 15, inputType: 'password', emptyText: '비밀번호'},
	            { allowBlank:false, fieldLabel: '비밀번호확인', itemId: 'confirm_pw', name: 'confirm_pw', minLength: 9, maxLength: 15, inputType: 'password', emptyText: '비밀번호 확인'},
	            { allowBlank:false, fieldLabel: '관리권한여부', itemId: 'admin_yn', name: 'admin_yn', xtype: 'checkbox'},
	            { allowBlank:false, fieldLabel: 'SMS수신', itemId: 'sms_yn', name: 'sms_yn', xtype: 'checkbox', inputValue: 'Y'},
	            { allowBlank:false, fieldLabel: '사용여부', itemId: 'use_yn', name: 'use_yn', xtype: 'checkbox', checked: true}
            ]
        },{
    		html:'<img align=absbottom src="/images/icon/fam/information.png"/> 비밀번호는 영문, 숫자, 특수문자(!@#$%^&*)를 포함하여<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;9~15자  이내 이어야 하며, 동일문자의 반복 또는 연속되는<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;문자가 3자리 이상 될 수 없습니다!'
    	},{ 
    		xtype: 'textfield', itemId: 'job_cd', name: 'job_cd', value: 'I', hidden: true
    	},{ 
    		xtype: 'textfield', itemId: 'reg_pw_yn', name: 'reg_pw_yn', value: 'N', hidden: true
    	}],
    	

        buttons: [{
            text: '저장',
            iconCls: 'x-fa fa-save',
            formBind: true,
            listeners : {
        		click: function(btn, e, eOpts) {
        			var rtn_tf = false;
        			var params = btn.up('userDetailWindow').down('form').getForm().getValues();
        	    	
        			
    				if (params['new_pw'] || params['confirm_pw']) {
    					params['reg_pw_yn'] = 'Y';
        			}
        				
        			if (params['job_cd'] == 'I' || params['reg_pw_yn'] == 'Y') {
	    				if (params['new_pw'] != params['confirm_pw']) {
	        				Ext.Msg.alert('정보', '비밀번호가 일치하지 않습니다.');
	        				return false;
	        			} else {
	        	    		if (!fnPasswdValidater(params['confirm_pw'])) {
	        	    			Ext.Msg.alert("알림","비밀번호 규칙을 확인하세요");
	            				return false;
	        	    		}
	        			}
        			}
        			
            		Ext.Ajax.request({
                		url : '/system/setUserInfo.ax',
                		method : 'POST',
                		params : params,
                		success : function(res){
                			var result = Ext.decode(res.responseText);            
                			if (result['msg'] == 'Y') {
                				btn.up('window').config.myParentStore.reload();
                				Ext.toast({html: '사용자정보가 변경되었습니다.'});
                				btn.up('window').close();
                			} else {
                				Ext.Msg.alert('정보', result['msg']);
                			}
                		}
                	});
            	}
        	}
        }]
    }],

    defaults: {
        anchor: '100%',
        labelWidth: 100
    },
    
    listeners : {
    	afterrender : function (obj, eOpts) {
    		
    		//등록이 아닌 수정인 경우 비교
    		if (obj.config.selectedRecord != '') {
    			//Ext.Msg.alert('정보', obj.config.selectedRecord.data.user_id);
    			obj.down('#job_cd').setValue('U');
	    		obj.down('#user_id').setValue(obj.config.selectedRecord.data.USER_ID).setReadOnly(true);
	    		obj.down('#user_nm').setValue(obj.config.selectedRecord.data.USER_NM);
	    		obj.down('#receive_num').setValue(obj.config.selectedRecord.data.RECEIVE_NUM);
	    		obj.down('#new_pw').allowBlank = true;
	    		obj.down('#confirm_pw').allowBlank = true;
	    		obj.down('#admin_yn').setValue(obj.config.selectedRecord.data.ADMIN_YN=='Y'?true:false);
	    		obj.down('#sms_yn').setValue(obj.config.selectedRecord.data.SMS_YN=='Y'?true:false);
	    		obj.down('#use_yn').setValue(obj.config.selectedRecord.data.USE_YN=='Y'?true:false);
    		}
    	}
    }

});

