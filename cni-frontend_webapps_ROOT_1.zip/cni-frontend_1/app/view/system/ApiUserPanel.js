Ext.define('cni.view.system.ApiUserPanel', {
	extend: 'Ext.grid.Panel',
    xtype: 'apiUserPanel',
    id: 'apiUserPanel',
    reference: 'apiUserPanel',
    /*requires: [
    	'cni.model.comm.CheckBoxModel'
    ],*/
    //controller: 'system.smsController',
    
    
    title: 'API사용자',
    iconCls : 'x-fa fa-user',
    
    columnLines: true,
    border: true,
    //height: '100%',
    tbar: [{
		text : '사용자등록',
		iconCls : 'x-fa fa-plus',
		handler : function (btn) {
			Ext.widget('apiDetailWindow', {
				selectedRecord: '',
				myParentStore: btn.up('apiUserPanel').getStore()
			});
			return true;
	    }
	},'->',{
    	xtype: 'combo',
    	id: 'search_key',
    	itemId: 'searchKey',
    	displayField:'key_name',
    	valueField:'key_code',
    	value: 'user_nm',
    	width: 100,
    	store: {
    		fields: ['key_name', 'key_code'],
    		data: [{
    			key_name: '이름',
    			key_code: 'user_nm' 
    		},{
    			key_name: '전화번호',
    			key_code: 'user_tel' 
    		}]
    	}
    },{
    	xtype: 'textfield',
    	id: 'search_txt',
    	itemId: 'searchText',
    	emptyText: '검색어를 입력하세요'
    },{
    	xtype: 'button',
    	id: 'search_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : function (btn) {
    		var vGrid = btn.up('apiUserPanel'); 
    		vGrid.getStore().proxy.extraParams = {
    			search_key: vGrid.down("#searchKey").getValue(), 
    			search_txt: vGrid.down("#searchText").getValue()
    		};
    		vGrid.getStore().reload();
    	}
    }/*,{
    	xtype: 'textfield', 
    	itemId: 'selected_user_nm',
    	name: 'selected_user_nm',
    	hidden: true, 
    	value: ''
    },{
    	xtype: 'textfield', 
    	itemId: 'selected_service_key',
    	name: 'selected_service_key',
    	hidden: true, 
    	value: ''
    }*/],
    
    columns : [{
    	xtype : 'rownumberer'
    },{
    	text : '이름',
    	flex : 1,
    	dataIndex : 'USER_NM',
    	align: 'center'
    },{
    	text : '전화번호',
    	flex : 1,
    	dataIndex : 'USER_TEL',
    	align: 'center'
    },{
    	text : '기관명',
    	flex : 1,
    	dataIndex : 'AGENCY_NM',
    	align: 'center'
    },{
    	text : 'API Key',
    	flex : 1,
    	dataIndex : 'API_KEY',
    	align: 'center'
    },{
    	text : '서비스개시일',
    	flex : 1,
    	dataIndex : 'S_DAY',
    	align: 'center'
    },{
    	text : '서비스종료일',
    	flex : 1,
    	dataIndex : 'E_DAY',
    	align: 'center'
    },{
    	text : '등록Id',
    	flex : 1,
    	dataIndex : 'REG_ID',
    	align: 'center'
    },{
    	text : '등록일시',
    	flex : 1,
    	dataIndex : 'REG_DT',
    	align: 'center'
    },{
    	//xtype: 'checkcolumn',
    	text : '사용여부',
    	flex : 1,
    	dataIndex : 'USE_YN',
    	align: 'center'
    }],
    
    store: {
    	type: 'comm.listStore',
    	//model: 'cni.model.comm.CheckBoxModel',
    	autoLoad: true,
    	listeners : {
			beforeload: function(obj, records, successful, operation, eOpts) {
				obj.getProxy().setUrl('/system/getApiUser.ax');
				obj.proxy.extraParams = {
					search_key: Ext.getCmp('apiUserPanel').down("#searchKey").getValue(), 
					search_txt: Ext.getCmp('apiUserPanel').down("#searchText").getValue()
				};
			},
			load: function(obj, records, successful, operation, eOpts) {
				
			}
    	},
    },
    
    listeners : {
		rowdblclick : function (obj, record, element, rowIndex, e, eOpts) {
			//Ext.Msg.alert('알림', record.get('receive_nm'));
			Ext.widget('apiDetailWindow', {
				selectedRecord: record,
				myParentStore: obj.up('apiUserPanel').getStore()
			});
			return true;
	    },
		cellclick : function (obj, td, cellIndex, record, tr, rowIndex, e, eOpts) {
			//obj.up('apiUserPanel').down('#selected_receive_nm').setValue(record.get('RECEIVE_NM'));
			//obj.up('apiUserPanel').down('#selected_receive_num').setValue(record.get('RECEIVE_NUM'));
			//console.log('>> '+record.get('receive_nm'))
		}
	}
    
});