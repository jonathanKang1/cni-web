Ext.define('cni.view.system.SmsUserTmsWindow', {
    extend: 'Ext.window.Window',
    xtype: 'smsUserTmsWindow',
    
    //controller: 'system.smsController',
    
    title: '수신자측정소정보',
    iconCls : 'x-fa fa-comment',
    width : 400,
    closable : true,
    autoShow : true,
    modal : true,
    layout : 'fit',
    
    items : [{
    	xtype : 'form',
    	frame: false,
        bodyPadding: 10,
        scrollable:true,
        method: 'POST',
        fieldDefaults: {
            labelAlign: 'right',
            labelWidth: 100,
            msgTarget: 'side'
        },

        items: [{
            xtype: 'fieldset',
            title: '수신자 측정소 정보',
            itemId: 'userTmsTitle',
            defaultType: 'textfield',
            defaults: {
                anchor: '100%'
            },

            items: [{
            	xtype: 'itemselector',
                itemId: 'user_tms_menus',
                name: 'user_tms_menus',
                flex : 1,
                height: 200,
            	store: {
                	type: 'comm.listStore',
                	autoLoad: true,
                	listeners : {
            			beforeload: function(obj, records, successful, operation, eOpts) {
            				obj.getProxy().setUrl('system/getTmsList.ax');
            				obj.proxy.extraParams = {
                					use_yn: 'Y'
                			};
            			}
                	}
                },
                displayField: 'TMS_NM',
                valueField: 'TMS_CD',
                allowBlank: false,
                msgTarget: 'side',
                fromTitle: '전체측정소',
                toTitle: '수신자측정소'
            }]
        },{
        	html: '&nbsp;* SMS발송은 "수신자 측정소" 항목에 등록되어 있는 측정소에<br/>'
        		+ '&nbsp;&nbsp;&nbsp;&nbsp;경보가 발령되는 경우에 발송 됩니다.<br/>'
        		+ '&nbsp;&nbsp;&nbsp;&nbsp;이때, "경보기준관리" 매뉴의 SMS 항목이 선택되어 있어야<br/>'
        		+ '&nbsp;&nbsp;&nbsp;&nbsp;합니다.<br/>'
        }],

        buttons: [{
            text: '저장',
            iconCls: 'x-fa fa-save',
            formBind: true,
            listeners : {
        		click: function(btn, e, eOpts) {
        			//var params = btn.up('smsUserTmsWindow').down('form').getForm().getValues(true); ","가 "%2C"로 전달됨
        			var params = btn.up('smsUserTmsWindow').down('form').getForm().getValues();
        	    	
            		/*var setSmsUserTms = Ext.Ajax.request({
                		url : '/system/setSmsUserTms.ax',
                		method : 'POST',
                		params : {
                			params, 
                			receive_nm : btn.up('smsUserTmsWindow').config.selected_receive_nm.getValue(),
                			receive_num : btn.up('smsUserTmsWindow').config.selected_receive_num.getValue()
                		},
                		success : function(res){
                			var result = Ext.decode(res.responseText);            
                			if (result['result'] == 'Y') {
                				//btn.up('window').config.myParentStore.reload();
                				btn.up('window').close();
                				Ext.toast({
                					html: 'SMS 수신자의 측정소 정보가 등록/수정 되었습니다.'
                                });
                			} else {
                				Ext.Msg.alert('정보', '시스템 오류가 발생하였습니다</br>관리자에게 문의하시기 바랍니다.');
                			}
                		}
                	});*/
        			
        			var form = btn.up('smsUserTmsWindow').down('form').getForm();
        			if (form.isValid()) {
        				form.submit({
                        	clientValidation: true,
                        	params: {
                        		receive_nm : btn.up('smsUserTmsWindow').config.selected_receive_nm.getValue(),
                    			receive_num : btn.up('smsUserTmsWindow').config.selected_receive_num.getValue()
                            },
                            url: '/system/setSmsUserTms.ax',
                            waitMsg: 'Uploading your Content...',
                            success: function(frm, action) {
                            	var result = Ext.JSON.decode(action.response.responseText);
                                Ext.Msg.confirm('정보', result.msg, function(ok_btn) {
                                	if (ok_btn == 'yes') {
                                		btn.up('smsUserTmsWindow').close();
                                	}
                                });
                            },
                            failure: function(frm, action) {
                            	var result = Ext.JSON.decode(action.response.responseText);
                            	Ext.MessageBox.show({
                                	title : '정보',
                                	msg : result.msg,
                                    buttons : Ext.MessageBox.YES,
                                    icon : Ext.MessageBox.INFO
                                });
                            }
                        });
        			}
            	}
        	}
        }]
    }],

    defaults: {
        anchor: '100%',
        labelWidth: 100
    },
    
    listeners : {
    	
    	afterrender : function (obj, eOpts) {
    		obj.down('#userTmsTitle').setTitle(obj.config.selected_receive_nm.getValue()+'('+obj.config.selected_receive_num.getValue()+')'+' 수신자 측정소 정보');
    		
    		//console.log('>> '+obj.config.selected_receive_nm.getValue())
    		var getSmsUserTmsList = Ext.Ajax.request({
        		url : '/system/getSmsUserTmsList.ax',
        		method : 'POST',
        		params : {
        			receive_nm: obj.config.selected_receive_nm.getValue(),
        			receive_num: obj.config.selected_receive_num.getValue()
        		},
        		success : function(res){
        			var result = Ext.decode(res.responseText);            
        			obj.down('#user_tms_menus').setValue(result['tms']);
        		}
        	});
    	}
    }

});

