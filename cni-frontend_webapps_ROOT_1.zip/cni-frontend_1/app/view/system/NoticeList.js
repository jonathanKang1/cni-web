Ext.define('cni.view.system.NoticeList', {
	extend: 'Ext.grid.Panel',
    xtype: 'noticeList',
    
    //controller: 'system.smsController',
    
    id: 'noticeList',
    reference: 'noticeList',
   
    title: '게시판관리',
    iconCls : 'x-fa fa-inbox',	
    
    columnLines: true,
    border: true,
    //height: '100%',
    tbar: [{
    	iconCls : 'x-fa fa-plus',
    	tooltip : '신규게시판등록',
    	text: '등록',
        handler : function(me) {
        	Ext.widget('noticeWindow', {
				myParentStore: Ext.getCmp('noticeList').getStore()
			});
    		return true;
        }
    },{
        xtype: 'datefield',
        id:'s_date',
        name: 's_date',
        itemId:'s_date',
        fieldLabel: '시작일',
        format: 'Y/m/d',
        //value: Ext.Date.add(new Date(), Ext.Date.DAY, -7),
        value: new Date(),
        labelWidth: 50,
        width: 180,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -30),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },{xtype: 'label', text: ' ~ ' },{
        xtype: 'datefield',
        name: 'e_date',
        itemId:'e_date',
        fieldLabel: '종료일',
        format: 'Y/m/d',
        labelWidth: 50,
        width: 180,
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },'->',{
    	xtype: 'combo',
    	//fieldLabel: '게시판구분',
    	itemId:'board_type',
    	name: 'board_type',
    	displayField: 'board_type_nm',
        valueField: 'board_type',
        value: 'A',
        width: 100,
        queryMode: 'local',
    	store: {
    		fields: ['board_type', 'board_type_nm'],
    	    data : [
    	    	{'board_type':'A', 'board_type_nm':'전체'},
    	    	{'board_type':'N', 'board_type_nm':'공지사항'},
    	        {'board_type':'F', 'board_type_nm':'FAQ'},
    	        {'board_type':'D', 'board_type_nm':'자료실'},
    	        {'board_type':'P', 'board_type_nm':'팝업'}
    	    ]
    	}
    },{
    	xtype: 'combo',
    	id: 's_key',
    	itemId: 's_key',
    	displayField:'key_name',
    	valueField:'key_code',
    	value: 'title',
    	width: 100,
    	store: {
    		fields: ['key_name', 'key_code'],
    		data: [{
    			key_name: '제목',
    			key_code: 'title' 
    		},{
    			key_name: '내용',
    			key_code: 'content' 
    		}]
    	}
    },{
    	xtype: 'textfield',
    	id: 's_txt',
    	itemId: 's_txt',
    	emptyText: '검색어를 입력하세요'
    },{
    	xtype: 'button',
    	id: 's_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : function(btn) {
    		var vGrid = btn.up('noticeList');
    		vGrid.getStore().proxy.extraParams = {
    			board_type: vGrid.down("#board_type").getValue(), 
    			search_key: vGrid.down("#s_key").getValue(), 
    			search_txt: vGrid.down("#s_txt").getValue(),
    			s_date: vGrid.down("#s_date").getValue(),
    			e_date: vGrid.down("#e_date").getValue()
    		};
    		vGrid.getStore().reload();
    	}
    }],
    
    columns : [{
    	text : '구분',
    	flex : 1,
    	dataIndex : 'BOARD_TYPE_NM',
    	align: 'center'
    },{
    	text : '번호',
    	flex : 0.6,
    	dataIndex : 'BOARD_TYPE',
    	align: 'center',
    	hidden : true
    },{
    	text : '번호',
    	flex : 0.6,
    	dataIndex : 'SEQ',
    	align: 'center'
    },{
    	text : '제목',
    	flex : 2,
    	dataIndex : 'TITLE',
    	align: 'center'
    },{
    	text : '내용',
    	flex : 7,
    	dataIndex : 'CONTENT',
    	align: 'center'
    },{
    	text : '첨부파일',
    	flex : 2,
    	dataIndex : 'ORG_FILE_NM',
    	align: 'center'
    },{
    	text : '공지시작일',
    	flex : 1,
    	dataIndex : 'S_DT',
    	align: 'center'
    },{
    	text : '공지종료일',
    	flex : 1,
    	dataIndex : 'E_DT',
    	align: 'center'
    },{
    	text : '등록자',
    	flex : 1,
    	dataIndex : 'REG_ID',
    	align: 'center'
    },{
    	text : '게시',
    	flex : 1,
    	dataIndex : 'USE_YN',
    	align: 'center'
    },{
    	text : '등록/수정시간',
    	flex : 1.5,
    	dataIndex : 'REG_DT',
    	align: 'center',
    	renderer: function(value, meta, record) {
    		if (record.get('MOD_YN') == 'Y') {   
            	meta.css = 'level-A';
            }
    		return value;
    	}
    }],
    
    store: {
    	type: 'comm.listStore',
    	autoLoad: false,
    	listeners : {
			beforeload: function(obj, records, successful, operation, eOpts) {
				obj.getProxy().setUrl('/system/getNoticeList.ax');
			},
			load: function(obj, records, successful, operation, eOpts) {
				
			}
    	}
    		
    },
    
    listeners : {
		rowdblclick : function (obj, record, element, rowIndex, e, eOpts) {
			Ext.widget('noticeWindow', {
				selectedRecord: record,
				//myParentStore: obj.up('noticeList').getStore('comm.listStore')
				myParentStore: obj.getStore()
			});
			return true;
		},
		cellclick : function (obj, td, cellIndex, record, tr, rowIndex, e, eOpts) {
			//obj.up('noticeList').down('#selected_receive_nm').setValue(record.get('receive_nm'));
			//obj.up('noticeList').down('#selected_receive_num').setValue(record.get('receive_num'));
		},
		afterrender : function (obj, eOpts) {
			let dt = new Date();
			dt.setMonth(dt.getMonth() - 1);
    		Ext.getCmp('noticeList').down("#s_date").setValue(dt);
    		Ext.getCmp('noticeList').down("#e_date").setValue(new Date());
    	},
    	boxready : function(obj) {
    		obj.getStore().proxy.extraParams = {
    			board_type: obj.down("#board_type").getValue(), 	
    			search_key: obj.down("#s_key").getValue(), 
    				search_txt: obj.down("#s_txt").getValue(),
    				s_date: obj.down("#s_date").getValue(),
    				e_date: obj.down("#e_date").getValue()
    		}
    		obj.getStore().load();
    		//Ext.StoreManager.lookup('comm.listStore').load();
		},
	}
    
});