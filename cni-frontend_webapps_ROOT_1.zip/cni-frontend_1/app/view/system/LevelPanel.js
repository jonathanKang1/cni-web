Ext.define('cni.view.dashboard.LevelPanel', {
	extend: 'Ext.grid.Panel',
    xtype: 'levelPanel',
    id: 'levelPanel',
    reference: 'levelPanel',
    
    requires: [
    	//'cni.store.comm.ListStore',
    	//'Ext.selection.CellModel',
    	//'Ext.selection.RowModel' 
    ],
   
    title: '항목별 기준값 관리',
    iconCls : 'x-fa fa-list-ul',	
    columnLines: true,
    border: true,
    layout: 'fit',
    
    tools:[{
        type:'refresh',
        tooltip: '새로고침', 
        handler: function (me) {
        	Ext.StoreManager.lookup('comm.listStore').load();
        }
    }],
    
    columns : [{
    	header : '항목',
    	dataIndex : 'ITEM_NM',
    	flex : 1,
    	align: 'center',
    	renderer: function(value, meta, record) {
    		if (value)
    			value = value+' ('+record.get('ITEM_CD')+')';
    		return value;
    	}
    },{
    	header : '항목코드', 
    	dataIndex : 'ITEM_CD', 
    	flex : 1, 
    	align: 'center', 
    	hidden: true
    },{
    	header : '등급',
    	dataIndex : 'LEVEL_NM',
    	flex : 1,
    	align: 'center',
    	renderer: function(value, meta, record) {
            return value;
        }
    },{header : '등급코드', dataIndex : 'LEVEL_CD', flex : 1, align: 'center', hidden: true
    },{
    	header : '하한값',
    	dataIndex : 'L_VL',
    	flex : 1,
    	align: 'center',
    	editor: {
    		maxLength: 6,
            allowBlank: false
        }
    },{
    	header : '상한값',
    	dataIndex : 'H_VL',
    	flex : 1,
    	align: 'center',
    	editor: {
    		maxLength: 6,
            allowBlank: false
        }
    },{
    	header : '소수점자리수',
    	dataIndex : 'DECIMAL_POINT',
    	flex : 1,
    	align: 'center'
    }],
    store: {
    	type: 'comm.listStore',
    	listeners: {
    		beforeload: function(obj, records, successful, operation, eOpts) {
    			obj.getProxy().setUrl('/system/getLevelInfoList.ax');
        	},
            load: function(store, records, successful, operation, eOpts) {
            	cni.app.storeTemp = store; 
            	/*var rec;
            	for (var i=0; i<records.length; i++) {
            		rec = records[i];
            		//console.log(rec.get('ITEM_CD')+rec.get('ITEM_NM')+rec.get('LEVEL_CD')+rec.get('LEVEL_NM')+rec.get('L_VL')+rec.get('H_VL'))
            	}*/
            }
        }
    },
    listeners : {
		beforerender : function(obj, eOpts) {
			Ext.StoreManager.lookup('comm.listStore').load();
    	},
    	render: function(obj, eOpts) {
    	},
        afterrender: function(obj, eOpts) {
        },
        resize: function (obj, width, height, oldWidth, oldHeight, eOpts) {
        }, 
    	boxready : function(obj) {
		},
		rowdblclick :  function (obj, record, element, rowIndex, e, eOpts) {
			//console.log(record.get('ITEM_CD')+record.get('ITEM_NM')+record.get('LEVEL_CD')+record.get('LEVEL_NM')+record.get('L_VL')+rec.get('H_VL'))
			Ext.widget('levelDetailWindow', {
				selectedRecord: record,    
				myParentStore: cni.app.storeTemp
			});
			return true;
		},
		destroy: function(obj, eOpts) {
    	}
	}
    
});