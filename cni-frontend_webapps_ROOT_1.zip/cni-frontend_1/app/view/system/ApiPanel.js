Ext.define('cni.view.system.ApiPanel', {
	extend: 'Ext.tab.Panel',
    xtype: 'apiPanel',
    
    id: 'apiPanel',
    reference: 'apiPanel',
    
    border: true,

    defaults: {
        //bodyPadding: 10,
        scrollable: true
    },
    
    items: [{
    	xtype: 'apiUserPanel'
    },{
    	xtype: 'apiReqListPanel'
    }/*,{
        title: 'Disabled Tab',
        itemId: 't2',
        closable: true,
        disabled: true
    }*/],
    
    listeners : {
    	beforerender: function (panel, eOpts) {
    	},
    	render: function (panel, eOpts) {
    	}
	}
});