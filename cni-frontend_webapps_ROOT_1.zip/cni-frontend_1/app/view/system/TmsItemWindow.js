Ext.define('cni.view.system.TmsItemWindow', {
    extend: 'Ext.window.Window',
    xtype: 'tmsItemWindow',
    
    title: '측정소별 측정항목 등록',
    
    width : 400,
    closable : true,
    autoShow : true,
    modal : true,
    layout : 'fit',
    /*onEsc : function() {
    	this.close();
    	return true;
    },*/
    
    items : [{
    	xtype : 'form',
    	frame: false,
        bodyPadding: 10,
        scrollable:true,
        method: 'POST',
        fieldDefaults: {
            labelAlign: 'right',
            labelWidth: 100,
            msgTarget: 'side'
        },

        items: [{
            xtype: 'fieldset',
            title: '측정소 측정항목 정보',
            itemId: 'tmsItemTitle',
            defaultType: 'textfield',
            defaults: {
                anchor: '100%'
            },

            items: [{
            	xtype: 'itemselector',
                itemId: 'tms_item_menus',
                name: 'tms_item_menus',
                flex : 1,
                height: 200,
                store: {
                	type: 'comm.listStore',
                	autoLoad: true,
                	listeners : {
            			beforeload: function(obj, records, successful, operation, eOpts) {
            				obj.getProxy().setUrl('/comm/getItemList.ax');
            				obj.proxy.extraParams = {
                					use_yn: 'Y'
                			};
            			}
                	}
                },
                displayField: 'ITEM_NM',
                valueField: 'ITEM_CD',
                //value: ['COb', 'NOX'],
                allowBlank: false,
                msgTarget: 'side',
                fromTitle: '전체항목',
                toTitle: '측정소별항목'
            }]
        }],
        fbar : [{
        	xtype : 'button', 
        	text : '저장', 
        	iconCls: 'x-fa fa-save',
        	formBind: true,
        	handler : function(sbtn){ 
        		var form = sbtn.up('tmsItemWindow').down('form').getForm();
    			if (form.isValid()) {
    				
    				form.submit({
                    	clientValidation: true,
                    	params: {
                    		tms_cd: sbtn.up('tmsItemWindow').config.selectedTmsCD.getValue()
                        },
                        url: '/system/setTmsItem.ax',
                        waitMsg: 'Uploading your Content...',
                        success: function(frm, action) {
                        	var result = Ext.JSON.decode(action.response.responseText);
                            Ext.Msg.confirm('정보', result.msg, function(btn) {
                            	console.log(result.msg);
                            	if (btn == 'yes') {
                            		sbtn.up('tmsItemWindow').close();
                            	}
                            });
                            console.log(result.code);
                        },
                        failure: function(frm, action) {
                        	console.log('failure');
                        	var result = Ext.JSON.decode(action.response.responseText);
                        	Ext.MessageBox.show({
                            	title : '정보',
                            	msg : result.msg,
                                buttons : Ext.MessageBox.YES,
                                icon : Ext.MessageBox.INFO
                            });
                        }
                    });
    			}
        	}
        }]
        /*buttons: [{
            text: '저장',
            iconCls: 'x-fa fa-save',
            formBind: true,
            listeners : {
        		click: function(btn, e, eOpts) {
        			var params = btn.up('tmsItemWindow').down('form').getForm().getValues();
        	    	//console.log('>> '+btn.up('tmsItemWindow').config.selectedTmsId.getValue());
        	    	
            		Ext.Ajax.request({
                		url : '/system/setTmsItem.ax',
                		method : 'POST',
                		params : {params, tms_cd : btn.up('tmsItemWindow').config.selectedTmsCD.getValue()},
                		success : function(res){
                			var result = Ext.decode(res.responseText);            
                			if (result['code'] == '200') {
                				//btn.up('window').config.myParentStore.reload();
                				btn.up('window').close();
                			} else {
                				Ext.Msg.alert('정보', '시스템오류가 발생하였습니다</br>관리자에게 문의하시기 바랍니다.');
                			}
                		}
                	});
            	}
        	}
        }]*/
    }],

    defaults: {
        anchor: '100%',
        labelWidth: 100
    },
    
    listeners : {
    	
    	afterrender : function (obj, eOpts) {
    		obj.down('#tmsItemTitle').setTitle(obj.config.selectedRecord.data.TMS_NM+'('+obj.config.selectedRecord.data.TMS_CD+')'+' 측정소별 항목 정보');

    		Ext.Ajax.request({
        		url : '/system/getTmsItemList.ax',
        		method : 'POST',
        		params : {tms_cd: obj.config.selectedRecord.data.TMS_CD},
        		success : function(res){
        			var result = Ext.decode(res.responseText);            
        			obj.down('#tms_item_menus').setValue(result['items']);
        			//console.log('정보 : '+result['items']);
        		}
        	});
    	}
    }

});

