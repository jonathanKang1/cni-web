Ext.define('cni.view.system.SmsPanel', {
	extend: 'Ext.tab.Panel',
    xtype: 'smsPanel',
    
    id: 'smsPanel',
    reference: 'smsPanel',
    
    border: true,

    defaults: {
        //bodyPadding: 10,
        scrollable: true
    },
    
    items: [{
    	xtype: 'smsUserPanel'
    },{
    	xtype: 'smsSendListPanel'
    }/*,{
        title: 'Disabled Tab',
        itemId: 't2',
        closable: true,
        disabled: true
    }*/],
    
    listeners : {
    	beforerender: function (panel, eOpts) {
    	},
    	render: function (panel, eOpts) {
    	}
	}
});