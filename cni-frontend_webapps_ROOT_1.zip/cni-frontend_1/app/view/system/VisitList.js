Ext.define('cni.view.system.VisitList', {
	extend: 'Ext.form.Panel',
    xtype: 'visitList',
    
    controller: 'system.systemController',
    
    id: 'visitList',
    reference: 'visitList',
    
    title: '방문기록',
    iconCls : 'x-fa fa-map',
    border: true,
    layout: 'fit',
    
    tools:[{
        //type:'gear',
    	iconCls : 'x-fa fa-table',
        tooltip: '엑셀',
        handler : function () {
        	var view = Ext.getCmp('visitList');
			if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -12)) {
				Ext.Msg.alert('알림', '조회 기간은 12개월을 초과할 수 없습니다.');
				return false;
			};
			
        	document.frm.action = '/system/getVisitExcel.do';
    		document.frm.uri_cd.value = view.down("#uri_cd").getValue(),
    		document.frm.content_group.value = view.down("#uri_cd").getRawValue(),
    		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
    		document.frm.e_date.value = Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
    		document.frm.submit();
        }
    }],

    tbar: [{
    	xtype: 'combo',
    	itemId:'uri_cd',
    	displayField: 'contnet_group',
        valueField: 'uri_cd',
        value: 'ALL',
        width: 150,
        queryMode: 'local',
    	store: {
    		fields: ['uri_cd', 'contnet_group'],
    	    data : [
    	    	{'uri_cd':'ALL', 'contnet_group':'전체'},
    	    	{'uri_cd':'/cni/main', 'contnet_group':'클린에어 메인'},
    	        {'uri_cd':'/cni/intro', 'contnet_group':'클린에어충남이란'},
    	        {'uri_cd':'/cni/real', 'contnet_group':'실시간자료조회'},
    	        {'uri_cd':'/cni/air', 'contnet_group':'대기주의보경보'},
    	        {'uri_cd':'/cni/statis', 'contnet_group':'통계정보'},
    	        {'uri_cd':'/cni/edu', 'contnet_group':'배움터'},
    	        {'uri_cd':'/cni/custom', 'contnet_group':'고객지원'}
    	        
    	    ]
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.netCD = newValue;
    			Ext.StoreManager.lookup('comm.regionStore').load();
    		}
    	}
    },{
        xtype: 'datefield',
        id:'s_date',
        name: 's_date',
        itemId:'s_date',
        fieldLabel: '시작일',
        format: 'Y/m/d',
        value: new Date(),
        labelWidth: 45,
        width: 150,
        maxValue: new Date()
    },{
        xtype: 'datefield',
        name: 'e_date',
        itemId:'e_date',
        fieldLabel: '종료일',
        format: 'Y/m/d',
        value: new Date(),
        labelWidth: 45,
        width: 150,
        maxValue: new Date()
    },'->',{
    	xtype: 'button',
    	itemId: 'search_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : function () {
    		Ext.getCmp('visitList').down('#data_grid').getStore().load();
    	}
    }],
    
    items:[{
    	xtype: 'grid',
    	itemId: 'data_grid',
    	columnLines: true,
        height: '100%',
        loadMask: true,
    	columns : [{
        	text : '<b>컨텐츠그룹</b>',
        	flex : 1,
        	dataIndex : 'CONTENT_GROUP',
        	//style: 'font-size: 16px',
        	align: 'center'
        },{
        	text : '<b>컨텐츠명</b>',
        	flex : 1,
        	dataIndex : 'CONTENT_NM',
        	align: 'center'
        },{
        	text : '<b>방문자수</b>',
        	flex : 1,
        	dataIndex : 'VISIT_CNT',
        	align: 'center'
        },{
        	text : '<b>히트수</b>',
        	flex : 3,
        	columns: [{
            	text : '<b>히트합계</b>',
            	flex : 1,
            	dataIndex : 'HIT_CNT',
            	align: 'center'
            },{
            	text : '<b>모바일</b>',
            	flex : 1,
            	dataIndex : 'MOBILE_CNT',
            	align: 'center'
            },{
            	text : '<b>PC</b>',
            	flex : 1,
            	dataIndex : 'PC_CNT',
            	align: 'center'
            }]
        }],
        store: {
        	type: 'comm.dataStore',
        	autoLoad: false,
        	listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {

    				var view = Ext.getCmp('visitList');
					if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -12)) {
						Ext.Msg.alert('알림', '조회 기간은 12개월을 초과할 수 없습니다.');
						return false;
					};

    				obj.getProxy().setUrl('/system/getVisitList.ax');
    				obj.proxy.extraParams = {
    					uri_cd: Ext.getCmp('visitList').down('#uri_cd').getValue(),
    					s_date: Ext.getCmp('visitList').down("#s_date").getValue(),
	    				e_date: Ext.getCmp('visitList').down("#e_date").getValue(),
					}
    	    	},
    	    	load: function(obj, records, successful, operation, eOpts) {
    	    	}
        	}	
        }
    }],
    
    listeners : {
    	beforerender : function (obj, eOpts) {
    	},
    	render : function (obj, eOpts) {
    	},
    	afterrender : function (obj, eOpts) {
    		obj.down("#s_date").setValue(Ext.Date.add(new Date(), Ext.Date.DAY, -30));
    		obj.down("#e_date").setValue(new Date());
    		obj.down('#data_grid').getStore().load();
    	}, 
    	boxready : function(obj) {
		},
		destroy: function(obj, eOpts) {
    	}
	}
});
