Ext.define('cni.view.system.NoticeWindow', {
    extend: 'Ext.window.Window',
    xtype: 'noticeWindow',
    
    title: '게시판관리',
    iconCls : 'x-fa fa-inbox',
    width : 820,
    //closable : true,	//default true
    autoShow : true,
    modal : true,
    layout : 'fit',
    /*onEsc : function(){
    	this.close();
    	return true;
    },*/
    items : [{
    	xtype : 'form',
    	frame: false,
        bodyPadding: 10,
        scrollable:true,
        method: 'POST',
        defaults: {
            anchor: '100%',
            labelWidth: 70
        },

        items: [{
        	xtype: 'combo',
        	fieldLabel: '게시판구분',
        	itemId:'board_type',
        	name: 'board_type',
        	displayField: 'board_type_nm',
            valueField: 'board_type',
            value: 'N',
            width: 110,
            queryMode: 'local',
        	store: {
        		fields: ['board_type', 'board_type_nm'],
        	    data : [
        	        {'board_type':'N', 'board_type_nm':'공지사항'},
        	        {'board_type':'F', 'board_type_nm':'FAQ'},
        	        {'board_type':'D', 'board_type_nm':'자료실'},
        	        {'board_type':'P', 'board_type_nm':'팝업'}
        	    ]
        	}
        },{
        	xtype : 'displayfield',
        	fieldLabel: '공지번호',
        	itemId: 'seq_no',
        	name : 'seq_no',
        	width: '100%',
        	hidden : true
        },{
        	xtype : 'textfield',
        	itemId: 'seq',
        	name : 'seq',
        	width: '100%',
        	hidden : true
        },{
        	xtype: 'fieldcontainer',
            fieldLabel: '게시기간',
            combineErrors: false,
            layout: 'hbox',
            defaults: {hideLabel: true,margin: '0 5 0 0'},
            items: [{
                xtype: 'datefield',
                name: 's_date',
                itemId:'s_date',
                format: 'Y/m/d',
                value: new Date(),
                width: 180,
                listeners : {
        	        change: function(obj, newValue, oldValue, eOpts) {
        	        } 
                }
            },{text: '~'},{
            	xtype: 'datefield',
                name: 'e_date',
                itemId:'e_date',
                format: 'Y/m/d',
                value: new Date(),
                width: 180,
                listeners : {
        	        change: function(obj, newValue, oldValue, eOpts) {
        	        } 
                }
            }]
        },{
        	xtype: 'textfield', 
        	fieldLabel: '제목',
        	width: '100%', 
        	itemId: 'title',
        	name: 'title',
        	maxLength: 30,
        	allowBlank: false
        }/*,{
            xtype: 'textareafield',
            grow: true,
            itemId: 'content',
        	name: 'content',
            fieldLabel: '내용',
            anchor    : '100%',
            allowBlank: false
        }*/,{
        	xtype: 'htmleditor',
        	itemId: 'content',
        	name: 'content',
        	fieldLabel: '내용',
        	allowBlank: false
        },{
        	xtype: 'fieldcontainer',
            fieldLabel: '첨부파일',
            combineErrors: false,
            itemId: 'att_file',
            layout: 'hbox',
            defaults: {hideLabel: true,margin: '0 5 0 0'},
            hidden: true,
            items:[{
            	//xtype : 'displayfield',
            	xtype: 'textfield', 
            	fieldLabel: '첨부파일',
            	itemId: 'org_file_nm',
            	name : 'org_file_nm',
            	width: 655,
            	readOnly: true
            },{
            	xtype: 'textfield', 
            	itemId: 'save_file_nm',
            	name : 'save_file_nm',
            	hidden: true,
            	readOnly: true
            },{
            	xtype: 'button',
            	iconCls: 'x-fa fa-trash',
            	tooltip: '파일삭제',
            	//text : '&nbsp;삭 제&nbsp;',
            	handler: function(xbtn) {
            		Ext.MessageBox.show({
                    	title : '알림',
                    	msg : '첨부파일을 삭제하시겠습니까?',
                        buttons : Ext.MessageBox.YESNO,
                        icon : Ext.MessageBox.INFO,
                        fn: function(btn) {
                            if (btn === 'yes') {
                            	xbtn.up('form').down('#org_file_nm').setValue('');
                            	xbtn.up('form').down('#save_file_nm').setValue('');
                            	xbtn.up('form').down('#down_btn').setDisabled(true);
                            	xbtn.up('form').down('#att_file').setHidden(true);
                            	xbtn.up('form').down('#fileupload').setHidden(false);
                            } else if (btn === 'no') {
                                
                            } else {
                                
                            }
                        }
                    });
            	}
            },{
            	xtype: 'button',
            	iconCls : 'x-fa fa-save',
            	tooltip: '다운로드',
            	itemId: 'down_btn',
            	handler: function(xbtn) {
            		document.frm.action = '/system/getNoticeFile.do';
            		document.frm.seq.value = xbtn.up('form').down('#seq').getValue();
            		document.frm.org_file_nm.value = xbtn.up('form').down('#org_file_nm').getValue();
            		document.frm.submit();	
            	}
            }]
        },{
        	xtype : 'filefield',
        	fieldLabel: '파일첨부',
        	buttonText  : '찾아보기',
        	itemId: 'fileupload',
        	name : 'fileupload',
        	maxLength: 150,
        	width: '100%'
        },{
        	xtype: 'checkbox',
        	fieldLabel: '게시여부',
        	itemId: 'use_yn',
        	name: 'use_yn',
        	inputValue: 'Y',
        	checked: true
        },{
        	html: '&nbsp;* 제목은 30자 이내로 작성하시기 바랍니다.<br/>'
        			+ '&nbsp;* 내용은 1,000자 이내로 작성하시기 바랍니다.<br/>'
        			+ '&nbsp;* 파일명은 50자 이내 이어야 합니다.<br/><br/>'
        			+ '&nbsp;* 일부 브라우져에서 게시물등록시에 저장여부를 확인하는 경우가 있을 수 있습니다.<br/>'
        			+ '&nbsp;&nbsp;&nbsp;이런 경우 "취소"를 선택하여 저장여부 메세지를 닫아주시기 바랍니다.<br/>'
        			+ '&nbsp;&nbsp;&nbsp;게시판관리 팝업창을 닫으시고 게시물 등록여부를 확인하시기 바랍니다.<br/>'
        }],
        fbar : [{
        	xtype : 'button', 
        	text : '저장', 
        	iconCls: 'x-fa fa-save',
        	formBind: true,
        	handler : function(sbtn){ 
        		if (!sbtn.up('form').down('#content').getValue() || sbtn.up('form').down('#content').getValue().length > 2000) {
    				Ext.MessageBox.show({
                    	title : '정보',
                    	msg : '내용은 1,000자 이내로 입력하셔야 합니다.',
                        icon : Ext.MessageBox.INFO
                    });
    				return true;
    			}
    			var form = sbtn.up('noticeWindow').down('form').getForm();
    			if (form.isValid()) {
    				form.submit({
                    	clientValidation: true,
                        url: '/system/setNotice.ax',
                        waitMsg: 'Uploading your Content...',
                        success: function(frm, action) {
                        	var result = Ext.JSON.decode(action.response.responseText);
                        	Ext.Msg.confirm('정보', result.msg, function(btn) {
                        		if (btn == 'yes') {
                            		//sbtn.up('noticeWindow').config.myParentStore.reload();
                            		sbtn.up('noticeWindow').close();
                            	}
                            });
                        },
                        failure: function(frm, action) {
                        	var result = Ext.JSON.decode(action.response.responseText);
                        	Ext.MessageBox.show({
                            	title : '정보',
                            	msg : result.msg,
                                buttons : Ext.MessageBox.YES,
                                icon : Ext.MessageBox.INFO
                            });
                        }
                    });
                } else {
                	Ext.MessageBox.show({
                    	title : '정보',
                    	msg : '파일명이 제한길이를 초과하였거나 입력항목을 확인하시기 바랍니다.',
                        buttons : Ext.MessageBox.YES,
                        icon : Ext.MessageBox.INFO
                    });
                }
        	}
        }]
        	
        /*buttons: [{
            text: '저장',
            iconCls: 'x-fa fa-save',
            formBind: true,
            listeners : {
        		click: function(sbtn, e, eOpts) {
        			if (!sbtn.up('form').down('#content').getValue()) {
        				Ext.MessageBox.show({
                        	title : '정보',
                        	msg : '내용을 입력하셔야 합니다.',
                            icon : Ext.MessageBox.INFO
                        });
        				return true;
        			}
        			var form = sbtn.up('noticeWindow').down('form').getForm();
        			if (form.isValid()) {
                       form.submit({
                            url: '/system/setNotice.ax',
                            waitMsg: 'Uploading your Image...',
                            success: function(fp, res) {
                            	var result = Ext.JSON.decode(res.response.responseText);
                                Ext.Msg.confirm('정보', result.msg, function(btn) {
                                	if (btn == 'yes') {
                                		sbtn.up('window').close();
                                	}
                                });
                            },
                            failure: function(fp, res) {
                            	var result = Ext.JSON.decode(res.response.responseText);
                            	Ext.MessageBox.show({
                                	title : '정보',
                                	msg : result.msg,
                                    buttons : Ext.MessageBox.YES,
                                    icon : Ext.MessageBox.INFO
                                });
                            }
                        });
                    }
            	}
        	}
        }]*/
    }],

    listeners : {
    	afterrender : function (obj, eOpts) {
    		if (obj.config.selectedRecord) {
    			obj.down('#board_type').setValue(obj.config.selectedRecord.data.BOARD_TYPE);
    			obj.down('#seq_no').setHidden(false);
    			obj.down('#seq_no').setValue(obj.config.selectedRecord.data.SEQ);
    			obj.down('#seq').setValue(obj.config.selectedRecord.data.SEQ);
    			if (obj.config.selectedRecord.data.ORG_FILE_NM) {
    				obj.down('#att_file').setHidden(false);
        			obj.down('#org_file_nm').setValue(obj.config.selectedRecord.data.ORG_FILE_NM);
        			obj.down('#save_file_nm').setValue(obj.config.selectedRecord.data.SAVE_FILE_NM);
        			obj.down('#fileupload').setHidden(true);
    			} else {
    				obj.down('#att_file').setHidden(true);
    			}
    			obj.down('#title').setValue(obj.config.selectedRecord.data.TITLE);
    			obj.down('#content').setValue(obj.config.selectedRecord.data.CONTENT);
    			obj.down('#use_yn').setValue(obj.config.selectedRecord.data.USE_YN=='Y'?true:false);
    			obj.down('#s_date').setValue(Ext.Date.format(new Date(obj.config.selectedRecord.data.S_DT.substring(0,4)+'-'+obj.config.selectedRecord.data.S_DT.substring(4,6)+'-'+obj.config.selectedRecord.data.S_DT.substring(6)), 'Y/m/d'));
	    		obj.down('#e_date').setValue(Ext.Date.format(new Date(obj.config.selectedRecord.data.E_DT.substring(0,4)+'-'+obj.config.selectedRecord.data.E_DT.substring(4,6)+'-'+obj.config.selectedRecord.data.E_DT.substring(6)), 'Y/m/d'));
    		}
    	},
    	close: function (win, eOpts) {
    		win.config.myParentStore.reload();
    	} 
    }
});

