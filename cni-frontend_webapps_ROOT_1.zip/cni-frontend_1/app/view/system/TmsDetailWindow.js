Ext.define('cni.view.system.TmsDetailWindow', {
    extend: 'Ext.window.Window',
    xtype: 'tmsDetailWindow',
    
    //controller: 'system.tmsController',
    
    title: '측정소등록',
    
    width : 400,
    //closable : true,	//default true
    autoShow : true,
    modal : true,
    layout : 'fit',
    onEsc : function(){
    	this.close();
    	return true;
    },
    
    items : [{
    	xtype : 'form',
    	frame: false,
        bodyPadding: 10,
        scrollable:true,

        fieldDefaults: {
            labelAlign: 'right',
            labelWidth: 120,
            msgTarget: 'side'
        },

        items: [{
            xtype: 'fieldset',
            title: '측정소 정보',
            defaultType: 'textfield',
            defaults: {
                anchor: '100%'
            },

            items: [
            	{ allowBlank:false, fieldLabel: '측정망', itemId: 'net_cd', name: 'net_cd', xtype: 'combo',
	            	displayField: 'net_nm',
	                valueField: 'net_cd',
	                value: 'C',
	                width: 110,
	            	store: {
	            		fields: ['net_cd', 'net_nm'],
	            	    data : [
	            	        {'net_cd':'A', 'net_nm':'도시대기'},
	            	        {'net_cd':'B', 'net_nm':'교외대기'},
	            	        {'net_cd':'D', 'net_nm':'도로변대기'},
	            	        {'net_cd':'C', 'net_nm':'마을대기'}
	            	    ]
	            	},
	            	listeners : {
	            		change : function (combo, newValue, oldValue, eOpts) {
	            			cni.app.netCD = newValue;
	            		}
	            	}
	            },
            	{ allowBlank:false, fieldLabel: '지역구분', itemId: 'region_cd', name: 'region_cd', xtype: 'combo',
	            	//displayField: 'region_nm',
	                //valueField: 'region_cd',
	                //value: '44180',
	                //width: 110,
	            	/*store: {
	            		fields: ['region_cd', 'region_nm'],
	            	    data : [
	            	        {'region_cd':'44180', 'region_nm':'보령시'},
	            	        {'region_cd':'44825', 'region_nm':'태안군'},
	            	        {'region_cd':'44770', 'region_nm':'서천군'},
	            	        {'region_cd':'44270', 'region_nm':'당진시'}
	            	    ]
	            	}*/
	            	displayField:'REGION_NM',
	            	valueField:'REGION_CD',
	            	emptyText: '지역선택',
	            	width: 130,
	            	queryMode: 'local',
	            	store: {
	            		type : 'comm.regionStore',
	            		autoLoad: true,
	            		listeners : {
	            			beforeload: function(obj, records, successful, operation, eOpts) {
	            				obj.getProxy().setUrl('/comm/getUseRegionList.ax');
	            	    	},
	            			load: function(obj, records, successful, operation, eOpts) {
	                		}
	                	}	
	            	}
	            },
	            { allowBlank:false, fieldLabel: '정보수집', itemId: 'comm_cd', name: 'comm_cd', xtype: 'combo',
	            	displayField: 'comm_nm',
	                valueField: 'comm_cd',
	                value: 'C',
	                width: 110,
	            	store: {
	            		fields: ['comm_cd', 'comm_nm'],
	            	    data : [
	            	        {'comm_cd':'A', 'comm_nm':'Airkorea'},
	            	        {'comm_cd':'C', 'comm_nm':'측정소'}
	            	    ]
	            	}
	            },
            	{ allowBlank:false, fieldLabel: '측정소코드', itemId: 'tms_cd', name: 'tms_cd', maxLength: 20, emptyText: '측정소코드'},
	            { allowBlank:false, fieldLabel: '측정소이름', itemId: 'tms_nm', name: 'tms_nm', maxLength: 20, emptyText: '측정소이름'},
	            { allowBlank:true, fieldLabel: '위도', itemId: 'lat', name: 'lat', maxLength: 30, emptyText: '예) 37.786399'},
	            { allowBlank:true, fieldLabel: '경도', itemId: 'lng', name: 'lng', maxLength: 30, emptyText: '예) 127.045674'},
	            { allowBlank:true, fieldLabel: 'X-Pos', itemId: 'xpos', name: 'xpos', maxLength: 30, emptyText: '225'},
	            { allowBlank:true, fieldLabel: 'Y-Pos', itemId: 'ypos', name: 'ypos', maxLength: 30, emptyText: '186'},
	            { allowBlank:true, fieldLabel: 'XX-Pos', itemId: 'xpos_detail', name: 'xpos_detail', maxLength: 30, emptyText: '225'},
	            { allowBlank:true, fieldLabel: 'YY-Pos', itemId: 'ypos_detail', name: 'ypos_detail', maxLength: 30, emptyText: '186'},
	            { allowBlank:true, fieldLabel: '주소', itemId: 'addr', name: 'addr', maxLength: 200},
	            { allowBlank:true, fieldLabel: '정열순서', itemId: 'order_seq', name: 'order_seq', xtype: 'numberfield', value: 1, minValue: 0, maxValue: 100},
	            { allowBlank:false, fieldLabel: '사용여부', itemId: 'use_yn', name: 'use_yn', xtype: 'checkbox', checked: true},
	            {
	            	xtype: 'textfield', 
	            	itemId: 'work_cd',
	            	name: 'work_cd',
	            	hidden: true, 
	            	value: ''
	            }
            ]
        }],

        buttons: [{
            text: '저장',
            iconCls: 'x-fa fa-save',
            formBind: true,
            listeners : {
        		click: function(btn, e, eOpts) {
        	    	var params = btn.up('tmsDetailWindow').down('form').getForm().getValues();
            		Ext.Ajax.request({
                		url : '/system/setTmsInfo.ax',
                		method : 'POST',
                		params : params,
                		success : function(res){
                			var result = Ext.decode(res.responseText);            
                			if (result['code'] == '200') {
                				try {
                					if (cni.app.tmsLocationPanel) cni.app.tmsLocationPanel.setHtml('');
                					if (btn.up('tmsDetailWindow').config.myParentStore) btn.up('tmsDetailWindow').config.myParentStore.reload();
                					Ext.toast({html: '측정소정보가 등록(수정) 되었습니다'});
                					btn.up('tmsDetailWindow').destroy();
                				} catch(e) {
                					console.log('exception');
                					console.log('e='+e.toString());
                				}
                			} else {
                				Ext.Msg.alert('정보', result['msg']);
                			}
                		}
                	});
            	}
        	}
        }]
    }],

    defaults: {
        anchor: '100%',
        labelWidth: 100
    },
    //renderTo: Ext.getBody(),
    listeners : {
    	afterrender : function (obj, eOpts) {
    		//등록이 아닌 수정인 경우 비교
    		obj.down('#work_cd').setValue('I');
    		if (obj.config.selectedRecord != '') {
    			obj.down('#net_cd').setValue(obj.config.selectedRecord.data.NET_CD);
    			obj.down('#region_cd').setValue(obj.config.selectedRecord.data.REGION_CD);
	    		obj.down('#tms_cd').setValue(obj.config.selectedRecord.data.TMS_CD).setReadOnly(true);
	    		obj.down('#tms_nm').setValue(obj.config.selectedRecord.data.TMS_NM);
	    		obj.down('#net_cd').setValue(obj.config.selectedRecord.data.NET_CD);
	    		obj.down('#comm_cd').setValue(obj.config.selectedRecord.data.COMM_CD);
	    		obj.down('#lat').setValue(obj.config.selectedRecord.data.LAT);
	    		obj.down('#lng').setValue(obj.config.selectedRecord.data.LNG);
	    		obj.down('#xpos').setValue(obj.config.selectedRecord.data.XPOS);
	    		obj.down('#ypos').setValue(obj.config.selectedRecord.data.YPOS);
	    		obj.down('#xpos_detail').setValue(obj.config.selectedRecord.data.XPOS_DETAIL);
	    		obj.down('#ypos_detail').setValue(obj.config.selectedRecord.data.YPOS_DETAIL);
	    		obj.down('#addr').setValue(obj.config.selectedRecord.data.ADDR);
	    		obj.down('#use_yn').setValue(obj.config.selectedRecord.data.USE_YN=='Y'?true:false);
	    		obj.down('#order_seq').setValue(obj.config.selectedRecord.data.ORDER_SEQ);
	    		obj.down('#work_cd').setValue('U');
    		}
    	}
    }

});

