Ext.define('cni.view.system.UserTmsWindow', {
    extend: 'Ext.window.Window',
    xtype: 'userTmsWindow',      
    
    title: '사용자 측정소 등록',
    width : 600,
    closable : true,
    autoShow : true,
    modal : true,
    layout : 'fit',
    onEsc : function(){
    	return true;
    },
    
    items : [{
    	xtype : 'form',
    	frame: false,
        bodyPadding: 10,
        scrollable:true,
        method: 'POST',
        fieldDefaults: {
            labelAlign: 'right',
            labelWidth: 100,
            msgTarget: 'side'
        },

        items: [{
            xtype: 'fieldset',
            title: '사용자 권한 정보',
            itemId: 'userTmsTitle',
            defaultType: 'textfield',
            defaults: {
                anchor: '100%'
            },

            items: [{
            	xtype: 'itemselector',
                itemId: 'user_tms_list',
                name: 'user_tms_list',
                flex : 1,
                height: 250,
                store: {
                	type: 'comm.listStore',
                	autoLoad: true,
                	listeners : {
            			beforeload: function(obj, records, successful, operation, eOpts) {
            				obj.getProxy().setUrl('system/getTmsList.ax');
            				obj.proxy.extraParams = {
                					use_yn: 'Y'
                			};
            			}
                	}
                },
                displayField: 'TMS_NM',
                valueField: 'TMS_CD',
                allowBlank: false,
                msgTarget: 'side',
                fromTitle: '전체 측정소',
                toTitle: '사용자 측정소'
            }]
        }],

        buttons: [{
            text: '저장',
            iconCls: 'x-fa fa-save',
            formBind: true,
            listeners : {
        		click: function(save_btn, e, eOpts) {
        			/*//var params = save_btn.up('userTmsWindow').down('form').getForm().getValues(true); ","가 "%2C"로 전달됨
        			var params = save_btn.up('userTmsWindow').down('form').getForm().getValues();
        	    	Ext.Ajax.request({
                		url : '/system/setUserTms.ax',
                		method : 'POST',
                		params : {params, user_id : btn.up('userTmsWindow').config.selectedUserId.getValue()},
                		success : function(res){
                			var result = Ext.decode(res.responseText);            
                			if (result['code'] == '200') {
                				//save_btn.up('window').config.myParentStore.reload();
                				save_btn.up('window').close();
                			} else {
                				Ext.Msg.alert('정보', '시스템오류가 발생하였습니다</br>관리자에게 문의하시기 바랍니다.');
                			}
                		}
                	});*/
        			var form = save_btn.up('userTmsWindow').down('form').getForm();
        			if (form.isValid()) {
        				form.submit({
                        	clientValidation: true,
                        	params: {
                        		user_id : save_btn.up('userTmsWindow').config.selectedUserId.getValue()
                            },
                            url: '/system/setUserTms.ax',
                            waitMsg: 'Uploading your Content...',
                            success: function(frm, action) {
                            	var result = Ext.JSON.decode(action.response.responseText);
                                Ext.Msg.confirm('정보', result.msg, function(btn) {
                                	console.log(result.msg);
                                	if (btn == 'yes') {
                                		save_btn.up('userTmsWindow').close();
                                	}
                                });
                                console.log(result.code);
                            },
                            failure: function(frm, action) {
                            	console.log('failure');
                            	var result = Ext.JSON.decode(action.response.responseText);
                            	Ext.MessageBox.show({
                                	title : '정보',
                                	msg : result.msg,
                                    buttons : Ext.MessageBox.YES,
                                    icon : Ext.MessageBox.INFO
                                });
                            }
                        });
        			}
            	}
        	}
        }]  
    }],

    defaults: {
        anchor: '100%',
        labelWidth: 100
    },
    
    listeners : {
    	afterrender : function (obj, eOpts) {
    		obj.down('#userTmsTitle').setTitle(obj.config.selectedUserName.getValue()+'('+obj.config.selectedUserId.getValue()+')'+' 사용자 권한 정보');
    		Ext.Ajax.request({
        		url : '/system/getUserTmsList.ax',
        		method : 'POST',
        		params : {user_id: obj.config.selectedUserId.getValue()},
        		success : function(res){
        			var result = Ext.decode(res.responseText);            
        			obj.down('#user_tms_list').setValue(result['user_tms']);
        		}
        	});
    	}
    }

});

