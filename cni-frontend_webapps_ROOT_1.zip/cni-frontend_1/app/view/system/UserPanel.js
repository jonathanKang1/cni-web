Ext.define('cni.view.system.UserPanel', {
	extend: 'Ext.grid.Panel',
    xtype: 'userPanel',
    id: 'userPanel',
    reference: 'userPanel',
   
    controller: 'system.systemController',
    
    title: '사용자관리',
    iconCls : 'x-fa fa-user',	
    columnLines: true,
    border: true,    
    //height: '100%',
    
    tbar: [{
		text : '사용자등록',
		iconCls : 'x-fa fa-plus',
		handler : 'fnUserRegster'
	},{
		text : '사용자권한등록',
		iconCls : 'x-fa fa-plus',
		handler : 'fnRoleReg'
	},{
		text : '사용자측정소등록',
		iconCls : 'x-fa fa-plus',
		handler : 'fnTmsReg'
	},'->',{
    	xtype: 'combo',
    	id: 'search_key',
    	itemId: 'searchKey',
    	displayField:'key_name',
    	valueField:'key_code',
    	value: 'user_nm',
    	width: 80,
    	store: {
    		fields: ['key_name', 'key_code'],
    		data: [{
    			key_name: '이름',
    			key_code: 'user_nm' 
    		},{
    			key_name: 'ID',
    			key_code: 'user_id' 
    		}]
    	}
    },{
    	xtype: 'textfield',
    	id: 'search_txt',
    	itemId: 'searchText',
    	emptyText: '검색어를 입력하세요'
    },{
    	xtype: 'button',
    	id: 'search_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : 'fnUserSearch'
    },{
    	xtype: 'textfield', 
    	itemId: 'selected_user_id',
    	name: 'selected_user_id',
    	hidden: true, 
    	value: ''
    },{
    	xtype: 'textfield', 
    	itemId: 'selected_user_nm',
    	name: 'selected_user_nm',
    	hidden: true, 
    	value: ''
    }],
    
    columns : [{
    	xtype : 'rownumberer'
    },{
    	text : '아이디',
    	flex : 1,
    	dataIndex : 'USER_ID',
    	align: 'center'
    },{
    	text : '계정명',
    	flex : 1,
    	dataIndex : 'USER_NM',
    	align: 'center'
    }/*,{
    	text : '담당자',
    	flex : 1,
    	dataIndex : 'mgr_nm',
    	align: 'center'
    },{
    	text : '연락처',
    	flex : 1,
    	dataIndex : 'tel_no',
    	align: 'center'
    }*/,{
    	text : '관리자여부',
    	flex : 1,
    	dataIndex : 'ADMIN_YN',
    	align: 'center'
    },{
    	text : 'SMS수신여부',
    	flex : 1,
    	dataIndex : 'SMS_YN',
    	align: 'center'
    },{
    	text : '사용여부',
    	flex : 1,
    	dataIndex : 'USE_YN',
    	align: 'center'
    },{
    	text : '등록Id',
    	flex : 1,
    	dataIndex : 'REG_ID',
    	align: 'center'
    },{
    	text : '등록시간',
    	flex : 1,
    	dataIndex : 'REG_DT',
    	align: 'center'
    }],
    
    store: {
    	type: 'comm.dataStore',
    	autoLoad: true,
    	listeners : {
			beforeload: function(obj, records, successful, operation, eOpts) {
				obj.getProxy().setUrl('/system/getUserList.ax');
			}
    	}
    },
    
    listeners : {
		rowdblclick : 'fnUserUpdate',
		cellclick : function (obj, td, cellIndex, record, tr, rowIndex, e, eOpts) {
			obj.up('userPanel').down('#selected_user_id').setValue(record.get('USER_ID'));
			obj.up('userPanel').down('#selected_user_nm').setValue(record.get('USER_NM'));
		}
	}
    
});