Ext.define('cni.view.system.TmsPanel', {
	extend: 'Ext.grid.Panel',
    xtype: 'tmsPanel',
    /*requires: [
    	'cni.controller.system.SystemController'
    ],
    controller: 'system.systemController',*/
    
    id: 'tmsPanel',
    reference: 'tmsPanel',
    title: '측정소 관리',
    iconCls : 'x-fa fa-home',	
    columnLines: true,
    border: true,
    
    tools:[{
        type:'plus',
        tooltip: '측정소등록',
        //handler: 'fnTmsRegster' 
        handler: function (me) {  
        	Ext.widget('tmsDetailWindow', {
    			selectedRecord: '',
    			myParentStore: Ext.StoreManager.lookup('comm.dataStore')
    		});
        	return true;
        }
    },{
        type:'gear',
        tooltip: '항목설정',
        handler: 'fnTmsItemReg2'
    },{
        type:'refresh',
        tooltip: '새로고침', 
        handler: function (me) {
        	Ext.StoreManager.lookup('comm.dataStore').reload();
        }
    }],
    tbar: [{
		text : '측정소등록',
		iconCls : 'x-fa fa-plus',
		//handler: 'fnTmsRegster' 
        handler: function (me) {  
        	Ext.widget('tmsDetailWindow', {
    			selectedRecord: '',
    			myParentStore: Ext.StoreManager.lookup('comm.dataStore')
    		});
        	return true;
        }
	},{
		text : '측정소항목등록',
		iconCls : 'x-fa fa-plus',
		//handler : 'fnTmsItemReg'
		handler: function(btn) {
			if (cni.app.clickRecord) { 
				Ext.widget('tmsItemWindow', {
					selectedRecord: cni.app.clickRecord,
					selectedTmsCD: btn.up('tmsPanel').down('#selected_tms_cd'),
					selectedTmsNM: btn.up('tmsPanel').down('#selected_tms_nm')
				});
				
				return true;
			} else {
				Ext.Msg.alert('정보', '측정소를 선택하세요');
				return false;
			}
		}
	},{
    	xtype: 'textfield', 
    	itemId: 'selected_tms_cd',
    	name: 'selected_tms_cd',
    	hidden: true, 
    	value: ''
    },{
    	xtype: 'textfield', 
    	itemId: 'selected_tms_nm',
    	name: 'selected_tms_nm',
    	hidden: true, 
    	value: ''
    }],
    columns : [{
    	xtype : 'rownumberer'
    },{
    	header : '측정망',
    	flex : 0.5,
    	dataIndex : 'NET_NM',
    	align: 'center'
    },{
    	header : '지역',
    	flex : 0.5,
    	dataIndex : 'REGION_NM',
    	align: 'center'
    },{
    	header : '측정소코드',
    	flex : 0.5,
    	dataIndex : 'TMS_CD',
    	align: 'center'
    },{
    	header : '측정소명',
    	flex : 1,
    	dataIndex : 'TMS_NM',
    	align: 'center'
    },{
    	header : '구글지도위경도',
    	flex : 1,
    	tooltip: '관제시스템 구글지도의 마커위치를 설정합니다.',
    	columns: [{
        	header : '위도',
        	flex : 0.5,
        	dataIndex : 'LAT',
        	align: 'center'
        },{
        	header : '경도',
        	flex : 0.5,
        	dataIndex : 'LNG',
        	align: 'center'
        }]
    },{
    	header : '지도이미지좌표',
    	flex : 2,
    	tooltip: '홈페이지 메인 지도 이미지 마커위치를 설정합니다.',
    	columns: [{
        	header : 'X-Pos',
        	flex : 0.5,
        	tooltip: '충남도 지도의 마커위치를 설정합니다.',
        	dataIndex : 'XPOS',
        	align: 'center'
        },{
        	header : 'Y-Pos',
        	flex : 0.5,
        	tooltip: '충남도 지도의 마커위치를 설정합니다.',
        	dataIndex : 'YPOS',
        	align: 'center'
        },{
        	header : 'XX-Pos',
        	flex : 0.5,
        	tooltip: '시군 지도의 마커위치를 설정합니다.',
        	dataIndex : 'XPOS_DETAIL',
        	align: 'center'
        },{
        	header : 'YY-Pos',
        	flex : 0.5,
        	tooltip: '시군 지도의 마커위치를 설정합니다.',
        	dataIndex : 'YPOS_DETAIL',
        	align: 'center'
        }]
    },{
    	header : '주소',
    	flex : 2,
    	dataIndex : 'ADDR',
    	align: 'center'
    },{
    	text : '사용여부',
    	flex : 0.5,
    	dataIndex : 'USE_YN',
    	align: 'center'
    }/*,{
        xtype: 'checkcolumn',
        header: '사용여부',
        flex : 0.5,
        dataIndex: 'USE_TF',
        listeners: {
        	beforecheckchange: function(checkcolumn, rowIndex, checked, record, e, eOpts) {
            	return false;
            }
        }
    }*/,{
    	header : '정렬',
    	flex : 0.5,
    	dataIndex : 'ORDER_SEQ',
    	align: 'center'
    }/*,{
    	xtype: 'widgetcolumn',
    	header: '트랜드',
    	flex : 1,
        widget: {
            xtype: 'sparklineline',
            values: [1, 10, 4, -3, 7, 2, 5, 7, 8, 6, 5, 8, 10]
        }
    }*/],
    store: {
    	type: 'comm.dataStore',
    	//autoLoad: true,
    	listeners : {
			beforeload: function(obj, records, successful, operation, eOpts) {
				obj.getProxy().setUrl('/system/getTmsList.ax');
			},
			load: function(obj, records, successful, operation, eOpts) {
			}
    	}
    },
    listeners : {
    	beforerender : function(obj, eOpts) {
			Ext.StoreManager.lookup('comm.dataStore').load();
    	},
		//rowdblclick : 'fnRowDblClick',
    	rowdblclick : function (obj, record, element, rowIndex, e, eOpts) {
    		Ext.widget('tmsDetailWindow', {
    			selectedRecord: record,
    			myParentStore: obj.getStore('comm.dataStore')
    		});
    		return true;
    	},
		cellclick : function (obj, td, cellIndex, record, tr, rowIndex, e, eOpts) {
			cni.app.clickRecord = record
			obj.up('tmsPanel').down('#selected_tms_cd').setValue(record.get('TMS_CD'));
			obj.up('tmsPanel').down('#selected_tms_nm').setValue(record.get('TMS_NM'));
		},
		destroy: function(obj, eOpts) {
			cni.app.clickRecord = '';
    	}
	}
});