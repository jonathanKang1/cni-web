Ext.define('cni.view.system.SmsConfigWindow', {
    extend: 'Ext.window.Window',
    xtype: 'smsConfigWindow',
    
    title: 'SMS환경정보',
    iconCls : 'x-fa fa-gear',
    width : 400,
    //closable : true,	//default true
    autoShow : true,
    modal : true,
    layout : 'fit',
    /*onEsc : function(){
    	this.close();
    	return true;
    },*/
    
    items : [{
    	xtype : 'form',
    	frame: false,
        bodyPadding: 10,
        scrollable:true,
        method: 'POST',
        fieldDefaults: {
            labelAlign: 'right',
            labelWidth: 100,
            msgTarget: 'side'
        },

        items: [{
            xtype: 'fieldset',
            title: 'SMS서비스등록정보',
            defaultType: 'textfield',
            defaults: {
                anchor: '100%'
            },

            items: [
            	{ fieldLabel: 'pk', itemId: 'pk', name: 'pk', maxLength: 3, hidden: true},
            	{ fieldLabel: '서비스ID', itemId: 'service_id', name: 'service_id', maxLength: 20, emptyText: '알리고ID를 입력하세요', allowBlank:false},
	            { fieldLabel: '발신자번호', itemId: 'send_num', name: 'send_num', maxLength: 20, emptyText: '발신자번호를 입력하세요', allowBlank:false,
	            	validator: function(input_value) {
	                	if (/[^0-9]/g.test(input_value)) {
	                		input_value = input_value.replace(/[^0-9]/g,'');
	                	}
	                	this.setValue(input_value);
	                	return true;
	            	}
	            },
	            /*{ fieldLabel: '발송서버IP', itemId: 'server_ip', name: 'server_ip', maxLength: 20, emptyText: '발송서버IP를 입력하세요', allowBlank:false,
	            	validator: function(input_value) {
	                	if (/[^0-9.]/g.test(input_value)) {
	                		input_value = input_value.replace(/[^0-9.]/g,'');
	                	}
	                	this.setValue(input_value);
	                	return true;
	            	}
	            },*/
	            { fieldLabel: '서비스 Key', itemId: 'service_key', name: 'service_key', maxLength: 50, emptyText: '알리고 서비스키를 입력하세요', allowBlank:false},
	            { allowBlank:false, fieldLabel: '테스트모드', itemId: 'testmode_yn', name: 'testmode_yn', xtype: 'checkbox', checked: false}
            ]
        },{
        	html: '&nbsp;* SMS 서비스를 이용하기 위하여 알리고 서비스에 가입이<br/>'
        		+ '&nbsp;&nbsp;&nbsp;&nbsp;필요합니다. 아래 URL을 확인하시기 바랍니다.<br/>'
        		+ '&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://smartsms.aligo.in" target="_blank">https://smartsms.aligo.in</a><br/><br/>'
        		+ '&nbsp;* 테스트모드가 체크되어 있는 경우 SMS는 발송되지 않습니다.'
        }],

        buttons: [{
            text: '저장',
            iconCls: 'x-fa fa-save',
            formBind: true,
            listeners : {
        		click: function(btn, e, eOpts) {

        	    	var params = btn.up('smsConfigWindow').down('form').getForm().getValues();
            		var set_sms_cnf = Ext.Ajax.request({
                		url : '/system/setSmsConfig.ax',
                		method : 'POST',
                		params : params,
                		success : function(res){
                			var result = Ext.decode(res.responseText); 
                			if (result['code'] == '200') {
                				btn.up('window').close();
                				Ext.toast({
                					html: 'SMS 환경정보가 등록(수정) 되었습니다.'
                                });
                			} else {
                				Ext.Msg.alert('정보', result['msg']);
                			}
                		}
                	});
            	}
        	}
        }]
    }],

    defaults: {
        anchor: '100%',
        labelWidth: 100
    },
    
    listeners : {
    	afterrender : function (obj, eOpts) {
    		
    		var get_sms_cnf = Ext.Ajax.request({
        		url : '/system/getSmsConfig.ax',
        		method : 'POST',
        		success : function(res){
        			var result = Ext.decode(res.responseText); 
        			if (result['code'] == '200') {
        				//obj.down('#service_id').setReadOnly(true);
        				obj.down('#pk').setValue(result['PK']);
	        			obj.down('#service_id').setValue(result['SERVICE_ID']);
	        			obj.down('#send_num').setValue(result['SEND_NUM']);
	        			obj.down('#service_key').setValue(result['SERVICE_KEY']);
	        			obj.down('#testmode_yn').setValue(result['TESTMODE_YN']=='Y'?true:false);
        			}
        		}
        	});
    	}
    }

});

