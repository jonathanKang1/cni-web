Ext.define('cni.view.system.SmsDetailWindow', {
    extend: 'Ext.window.Window',
    xtype: 'smsDetailWindow',
    
    //controller: 'system.smsController',
    
    title: '수신자정보',
    iconCls : 'x-fa fa-comment',
    width : 400,
    //closable : true,	//default true
    autoShow : true,
    modal : true,
    layout : 'fit',
    onEsc : function(){
    	this.close();
    	return true;
    },
    
    items : [{
    	xtype : 'form',
    	frame: false,
        bodyPadding: 10,
        scrollable:true,

        fieldDefaults: {
            labelAlign: 'right',
            labelWidth: 100,
            msgTarget: 'side'
        },

        items: [{
            xtype: 'fieldset',
            title: '수신자 정보',
            defaultType: 'textfield',
            defaults: {
                anchor: '100%'
            },

            items: [
	            { fieldLabel: '수신자이름', itemId: 'receive_nm', name: 'receive_nm', maxLength: 20, emptyText: '수신자명', allowBlank:false},
	            { fieldLabel: '수신번호', itemId: 'receive_num', name: 'receive_num', maxLength: 11, emptyText: '숫자만입력하세요', allowBlank:false,
	            	validator: function(input_value) {
	                	if (/[^0-9]/g.test(input_value)) {
	                		input_value = input_value.replace(/[^0-9]/g,'');
	                	}
	                	this.setValue(input_value);
	                	return true;
	            	}
	            },
	            { xtype: 'numberfield', fieldLabel: '수신시작시간', itemId: 'receive_st', name: 'receive_st', value: 9, maxValue: 12, minValue: 1, allowBlank:false },
	            { xtype: 'numberfield', fieldLabel: '수신종료시간', itemId: 'receive_ed', name: 'receive_ed', value: 18, maxValue: 24, minValue: 13, allowBlank:false },
	            { allowBlank:false, fieldLabel: '사용여부', itemId: 'use_yn', name: 'use_yn', xtype: 'checkbox', checked: true},
	            { allowBlank:false, fieldLabel: '삭제여부', itemId: 'del_yn', name: 'del_yn', xtype: 'checkbox', checked: false}
            ]
        },{
        	xtype: 'textfield',
        	itemId: 'job_cd',
        	name: 'job_cd', 
        	value: 'I',
        	hidden: true
        },{
        	html: '&nbsp;* SMS 서비스를 이용하기 위하여 알리고 서비스에 가입이<br/>'
        		+ '&nbsp;&nbsp;&nbsp;&nbsp;필요합니다. 아래 URL을 확인하시기 바랍니다.<br/>'
        		+ '&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://smartsms.aligo.in" target="_blank">https://smartsms.aligo.in</a><br/><br/>'
        		+ '&nbsp;* 서비스 가입 후 우측상단 설정 아이콘을 클릭하여<br/>'
        		+ '&nbsp;&nbsp;&nbsp;&nbsp;서비스 가입정보를 등록하시기 바랍니다.'
        }],

        buttons: [{
            text: '저장',
            iconCls: 'x-fa fa-save',
            formBind: true,
            listeners : {
        		click: function(btn, e, eOpts) {

        	    	var params = btn.up('smsDetailWindow').down('form').getForm().getValues();
            		var set_receive_info = Ext.Ajax.request({
                		url : '/system/setReceiveInfo.ax',
                		method : 'POST',
                		params : params,
                		success : function(res){
                			var result = Ext.decode(res.responseText);            
                			if (result['code'] == '200') {
                				btn.up('window').config.myParentStore.reload();
                				btn.up('window').close();
                				Ext.toast({
                					html: 'SMS 수신자 정보가 등록/수정/삭제 되었습니다.'
                                });
                			} else {
                				Ext.Msg.alert('정보', result['msg']);
                			}
                		}
                	});
            	}
        	}
        }]
    }],

    defaults: {
        anchor: '100%',
        labelWidth: 100
    },
    
    listeners : {
    	afterrender : function (obj, eOpts) {
    		
    		//등록이 아닌 수정인 경우 비교
    		if (obj.config.selectedRecord != '') {
    			//Ext.Msg.alert('정보', obj.config.selectedRecord.data.user_id);
    			obj.down('#job_cd').setValue('U');
	    		obj.down('#receive_nm').setValue(obj.config.selectedRecord.data.RECEIVE_NM);
	    		obj.down('#receive_nm').setReadOnly(true);
	    		obj.down('#receive_num').setValue(obj.config.selectedRecord.data.RECEIVE_NUM);
	    		obj.down('#receive_num').setReadOnly(true);
	    		obj.down('#receive_st').setValue(obj.config.selectedRecord.data.RECEIVE_ST);
	    		obj.down('#receive_ed').setValue(obj.config.selectedRecord.data.RECEIVE_ED);
	    		obj.down('#use_yn').setValue(obj.config.selectedRecord.data.USE_YN=='Y'?true:false);
    		}
    	}
    }

});

