Ext.define('cni.view.system.ApiReqListPanel', {
	extend: 'Ext.grid.Panel',
    xtype: 'apiReqListPanel',
    id: 'apiReqListPanel',
    reference: 'apiReqListPanel',
   
    title: 'API요청목록',
    iconCls : 'x-fa fa-share-square',
    
    columnLines: true,
    border: true,
    //height: '100%',
    tbar: [{
        xtype: 'datefield',
        id:'s_date',
        name: 's_date',
        itemId:'s_date',
        fieldLabel: '시작일',
        format: 'Y/m/d',
        //value: Ext.Date.add(new Date(), Ext.Date.DAY, -7),
        value: new Date(),
        labelWidth: 50,
        width: 180,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -30),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },{xtype: 'label', text: ' ~ ' },{
        xtype: 'datefield',
        name: 'e_date',
        itemId:'e_date',
        fieldLabel: '종료일',
        format: 'Y/m/d',
        value: new Date(),
        labelWidth: 50,
        width: 180,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -29),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },'->',{
    	xtype: 'combo',
    	id: 's_key',
    	itemId: 's_key',
    	displayField:'key_name',
    	valueField:'key_code',
    	value: 'api_key',
    	width: 100,
    	store: {
    		fields: ['key_name', 'key_code'],
    		data: [{
    			key_name: 'api_key',
    			key_code: 'api_key' 
    		},{
    			key_name: '요청 URL',
    			key_code: 'req_url' 
    		}]
    	}
    },{
    	xtype: 'textfield',
    	id: 's_txt',
    	itemId: 's_txt',
    	emptyText: '검색어를 입력하세요'
    },{
    	xtype: 'button',
    	id: 's_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : function (btn) {
        	var vGrid = btn.up('apiReqListPanel'); 
        	if (vGrid.down("#s_date").getValue() < Ext.Date.add(vGrid.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
    			Ext.Msg.alert('알림', '조회 기간은 3개월을 초과할 수 없습니다.');
    			return false;
    		};
    		vGrid.getStore().proxy.extraParams = {
    			search_key: vGrid.down("#s_key").getValue(), 
    			search_txt: vGrid.down("#s_txt").getValue(),
    			s_date: vGrid.down("#s_date").getValue(),
    			e_date: vGrid.down("#e_date").getValue()
    		};
    		vGrid.getStore().reload();
        }
    }],
    
    columns : [{
    	xtype : 'rownumberer'
    },{
    	text : 'API Key',
    	flex : 2,
    	dataIndex : 'API_KEY',
    	align: 'center'
    },{
    	text : '요청자 IP',
    	flex : 1,
    	dataIndex : 'REQ_IP',
    	align: 'center'
    },{
    	text : '요청 서비스',
    	flex : 2,
    	dataIndex : 'REQ_URL',
    	align: 'center'
    },{
    	text : 'API 버전',
    	flex : 1,
    	dataIndex : 'VER_NUM',
    	align: 'center'
    },{
    	text : '응답코드',
    	flex : 1,
    	dataIndex : 'ERR_CD',
    	align: 'center'
    },{
    	text : '성공여부',
    	flex : 1,
    	dataIndex : 'SUCCESS_YN',
    	align: 'center'
    },{
    	text : '등록시간',
    	flex : 1,
    	dataIndex : 'REG_DT',
    	align: 'center'
    }],
    
    store: {
    	type: 'comm.listStore',
    	autoLoad: false,
    	listeners : {
			beforeload: function(obj, records, successful, operation, eOpts) {
				obj.getProxy().setUrl('/system/getApiReqList.ax');
			},
			load: function(obj, records, successful, operation, eOpts) {
				
			}
    	}
    		
    },
    
    listeners : {
		//rowdblclick : 'fnRowDblClick',
		cellclick : function (obj, td, cellIndex, record, tr, rowIndex, e, eOpts) {
			//obj.up('apiReqListPanel').down('#selected_receive_nm').setValue(record.get('receive_nm'));
			//obj.up('apiReqListPanel').down('#selected_receive_num').setValue(record.get('receive_num'));
		},
		afterrender : function (obj, eOpts) {
			//let dt = new Date();
			//dt.setMonth(dt.getMonth() - 1);
    		//Ext.getCmp('apiReqListPanel').down("#s_date").setValue(dt);
			Ext.getCmp('apiReqListPanel').down("#s_date").setValue(new Date());
    		Ext.getCmp('apiReqListPanel').down("#e_date").setValue(new Date());
    	},
    	boxready : function(obj) {
    		obj.getStore().proxy.extraParams = {
    				search_key: obj.down("#s_key").getValue(), 
    				search_txt: obj.down("#s_txt").getValue(),
    				s_date: obj.down("#s_date").getValue(),
    				e_date: obj.down("#e_date").getValue()
    		}
    		obj.getStore().load();
    		//Ext.StoreManager.lookup('comm.listStore').load();
		},
	}
    
});