Ext.define('cni.view.system.SmsUserPanel', {
	extend: 'Ext.grid.Panel',
    xtype: 'smsUserPanel',
    
    //controller: 'system.smsController',
    
    id: 'smsUserPanel',
    reference: 'smsUserPanel',
   
    title: 'SMS수신자',
    iconCls : 'x-fa fa-comment',	
    
    columnLines: true,
    border: true,
    //height: '100%',
    /*tools:[{
    	type:'gear',
        tooltip: '설정',
        handler : 'fnSmsConfigSetting'
    }],*/
    tbar: [{
    	iconCls : 'x-fa fa-wrench',
    	tooltip : 'SMS설정정보',
        //handler : 'fnSmsConfigSetting'
    	handler: function () {
    		Ext.widget('smsConfigWindow');
    	}
    },{
		text : '수신자등록',
		iconCls : 'x-fa fa-plus',
		//handler : 'fnReceiver'
		handler: function (btn) {
			Ext.Ajax.request({
	    		url : '/system/getSmsConfig.ax',
	    		method : 'POST',
	    		success : function(res){
	    			var result = Ext.decode(res.responseText); 
	    			if (result['code'] == '200') {
	    				Ext.widget('smsDetailWindow', {
	    					selectedRecord: '',
	    					myParentStore: btn.up('smsUserPanel').getStore()
	    				});
	    			} else {
	    				//SMS환경설정정보가 미등록상태인 경우
	    				Ext.Msg.confirm('확인', 'SMS환경정보가 등록되어 있지 않습니다.<br/>환경정보를 등록 하시겠습니까?', function (id, value) {
	    					if (id === 'yes') {
	    						Ext.widget('smsConfigWindow');
	    					}
	    				});
	    			}
	    		}
	    	});
		}
	},{
		text : '수신자측정소등록',
		iconCls : 'x-fa fa-plus',
		//handler : 'fnTmsReg'
		handler: function (btn) {
			if (btn.up('smsUserPanel').down('#selected_receive_nm').getValue() && btn.up('smsUserPanel').down('#selected_receive_num').getValue()) { 
				Ext.widget('smsUserTmsWindow', {
					selected_receive_nm: btn.up('smsUserPanel').down('#selected_receive_nm'),
					selected_receive_num: btn.up('smsUserPanel').down('#selected_receive_num')
				});
				return true;
			} else {
				Ext.Msg.alert('정보', '수신자를 선택하세요');
				return false;
			}
    	}
	},'->',{
    	xtype: 'combo',
    	id: 'search_key',
    	itemId: 'searchKey',
    	displayField:'key_name',
    	valueField:'key_code',
    	value: 'receive_nm',
    	width: 100,
    	store: {
    		fields: ['key_name', 'key_code'],
    		data: [{
    			key_name: '이름',
    			key_code: 'receive_nm' 
    		},{
    			key_name: '전화번호',
    			key_code: 'receive_num' 
    		}]
    	}
    },{
    	xtype: 'textfield',
    	id: 'search_txt',
    	itemId: 'searchText',
    	emptyText: '검색어를 입력하세요'
    },{
    	xtype: 'button',
    	id: 'search_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	//handler : 'fnSearch'
    	handler: function (btn) {
    		var vGrid = btn.up('smsUserPanel'); 
    		vGrid.getStore().proxy.extraParams = {
    			search_key: vGrid.down("#searchKey").getValue(), 
    			search_txt: vGrid.down("#searchText").getValue()
    		};
    		vGrid.getStore().reload();
    	}
    },{
    	xtype: 'textfield', 
    	itemId: 'selected_receive_nm',
    	name: 'selected_receive_nm',
    	hidden: true, 
    	value: ''
    },{
    	xtype: 'textfield', 
    	itemId: 'selected_receive_num',
    	name: 'selected_receive_num',
    	hidden: true, 
    	value: ''
    }],
    
    columns : [{
    	xtype : 'rownumberer'
    },{
    	text : '이름',
    	flex : 1,
    	dataIndex : 'RECEIVE_NM',
    	align: 'center'
    },{
    	text : '전화번호',
    	flex : 1,
    	dataIndex : 'RECEIVE_NUM',
    	align: 'center'
    },{
    	text : '수신시작시간',
    	flex : 1,
    	dataIndex : 'RECEIVE_ST',
    	align: 'center'
    },{
    	text : '수신종료시간',
    	flex : 1,
    	dataIndex : 'RECEIVE_ED',
    	align: 'center'
    },{
    	text : '사용여부',
    	flex : 1,
    	dataIndex : 'USE_YN',
    	align: 'center'
    },{
    	text : '등록Id',
    	flex : 1,
    	dataIndex : 'REG_ID',
    	align: 'center'
    },{
    	text : '등록시간',
    	flex : 1,
    	dataIndex : 'REG_DT',
    	align: 'center'
    }],
    
    store: {
    	type: 'comm.listStore',
    	autoLoad: true,
    	listeners : {
			beforeload: function(obj, records, successful, operation, eOpts) {
				obj.getProxy().setUrl('/system/getReceiverList.ax');
			},
			load: function(obj, records, successful, operation, eOpts) {
				
			}
    	}
    		
    },
    
    listeners : {
		//rowdblclick : 'fnRowDblClick',
		rowdblclick: function (obj, record, element, rowIndex, e, eOpts) {
			Ext.widget('smsDetailWindow', {
				selectedRecord: record,
				myParentStore: obj.up('smsUserPanel').getStore()
			});
		},
		cellclick : function (obj, td, cellIndex, record, tr, rowIndex, e, eOpts) {
			obj.up('smsUserPanel').down('#selected_receive_nm').setValue(record.get('RECEIVE_NM'));
			obj.up('smsUserPanel').down('#selected_receive_num').setValue(record.get('RECEIVE_NUM'));
			//console.log('>> '+record.get('receive_nm'))
		}
	}
    
});