Ext.define('cni.view.system.ApiDetailWindow', {
    extend: 'Ext.window.Window',
    xtype: 'apiDetailWindow',
    
    controller: 'system.smsController',
    
    title: 'API사용자정보',
    iconCls : 'x-fa fa-share-square',
    
    width : 400,
    //closable : true,	//default true
    autoShow : true,
    modal : true,
    layout : 'fit',
    onEsc : function(){
    	this.close();
    	return true;
    },
    
    items : [{
    	xtype : 'form',
    	frame: false,
        bodyPadding: 10,
        scrollable:true,

        fieldDefaults: {
            labelAlign: 'right',
            labelWidth: 100,
            msgTarget: 'side'
        },

        items: [{
            xtype: 'fieldset',
            title: 'API사용자정보',
            defaultType: 'textfield',
            defaults: {
                anchor: '100%'
            },

            items: [
	            { fieldLabel: '담당자이름', itemId: 'user_nm', name: 'user_nm', maxLength: 20, emptyText: '담당자이름', allowBlank:false},
	            { fieldLabel: '전화번호', itemId: 'user_tel', name: 'user_tel', maxLength: 11, emptyText: '숫자만입력하세요', allowBlank:false,
	            	validator: function(input_value) {
	                	if (/[^0-9]/g.test(input_value)) {
	                		input_value = input_value.replace(/[^0-9]/g,'');
	                	}
	                	this.setValue(input_value);
	                	return true;
	            	}
	            },
	            { fieldLabel: '기관명', itemId: 'agency_nm', name: 'agency_nm', maxLength: 30, emptyText: '기관명'},
	            { fieldLabel: '시작일',itemId:'s_day',name: 's_day', xtype: 'datefield', format: 'Y-m-d', value: new Date()},
	            { fieldLabel: '종료일',itemId:'e_day',name: 'e_day', xtype: 'datefield', format: 'Y-m-d', value: Ext.Date.add(new Date(), Ext.Date.YEAR, +2)},
	            { fieldLabel: 'API Key', itemId: 'api_key', name: 'api_key', maxLength: 100, emptyText: '', readOnly : true, disable: true},
	            { allowBlank:false, fieldLabel: '사용여부', itemId: 'use_yn', name: 'use_yn', xtype: 'checkbox', inputValue: 'Y', checked: true}
            ]
        },{
        	xtype: 'textfield',
        	itemId: 'job_cd',
        	name: 'job_cd', 
        	value: 'I',
        	hidden: true
        },{
        	html: '&nbsp;* API Key는 사용자 등록시 자동생성 됩니다.<br/>'
        }],

        buttons: [{
            text: '저장',
            iconCls: 'x-fa fa-save',
            formBind: true,
            listeners : {
        		click: function(btn, e, eOpts) {

        	    	var params = btn.up('apiDetailWindow').down('form').getForm().getValues();
            		Ext.Ajax.request({
                		url : '/system/setApiUser.ax',
                		method : 'POST',
                		params : params,
                		success : function(res){
                			var result = Ext.decode(res.responseText);            
                			if (result['code'] == '200') {
                				btn.up('window').config.myParentStore.reload();
                				btn.up('window').close();
                				Ext.toast({
                					html: 'SMS 수신자 정보가 등록/수정/삭제 되었습니다.'
                                });
                			} else {
                				Ext.Msg.alert('정보', result['msg']);
                			}
                		}
                	});
            	}
        	}
        }]
    }],

    defaults: {
        anchor: '100%',
        labelWidth: 100
    },
    
    listeners : {
    	afterrender : function (obj, eOpts) {
    		//등록이 아닌 수정인 경우 비교
    		if (obj.config.selectedRecord != '') {
    			//Ext.Msg.alert('정보', obj.config.selectedRecord.data.user_id);
    			obj.down('#job_cd').setValue('U');
	    		obj.down('#user_nm').setValue(obj.config.selectedRecord.data.USER_NM);
	    		obj.down('#user_tel').setValue(obj.config.selectedRecord.data.USER_TEL);
	    		obj.down('#agency_nm').setValue(obj.config.selectedRecord.data.AGENCY_NM);
	    		obj.down('#api_key').setValue(obj.config.selectedRecord.data.API_KEY);
	    		//obj.down('#api_key').setReadOnly(true);
	    		
	    		var dt = obj.config.selectedRecord.data.S_DAY;
	    		var date_str = dt.substring(0,4);
	    		date_str += '-'+dt.substring(4,6);
	    		date_str += '-'+dt.substring(6);
	    		obj.down('#s_day').setValue(new Date(date_str));
	    		
	    		dt = obj.config.selectedRecord.data.E_DAY;
	    		date_str = dt.substring(0,4);
	    		date_str += '-'+dt.substring(4,6);
	    		date_str += '-'+dt.substring(6);
	    		obj.down('#e_day').setValue(new Date(date_str));
	    		
	    		obj.down('#use_yn').setValue(obj.config.selectedRecord.data.USE_YN=='Y'?true:false);
    		}
    	}
    }

});

