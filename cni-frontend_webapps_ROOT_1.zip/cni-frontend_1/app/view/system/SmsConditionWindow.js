Ext.define('cni.view.system.SmsConditionWindow', {
    extend: 'Ext.window.Window',
    xtype: 'smsConditionWindow',
    
    //controller: 'system.smsController',
    
    title: 'SMS발송조건정보',
    iconCls : 'x-fa fa-gear',
    width : 400,
    //closable : true,	//default true
    autoShow : true,
    modal : true,
    layout : 'fit',
    onEsc : function(){
    	this.close();
    	return true;
    },
    /*defaults: {
        anchor: '100%',
        labelWidth: 100
    },*/
    items : [{
    	xtype : 'form',
    	frame: false,
        bodyPadding: 10,
        scrollable:true,

        defaults: {
            anchor: '100%',
            labelWidth: 100
        },

        items: [{
            xtype: 'fieldset',
            title: 'SMS발송조건',
            collapsible: false,
            defaults: {labelWidth: 100, anchor: '100%',layout: 'hbox'},
            items: [{
            	xtype: 'fieldcontainer',
                fieldLabel: '주의보/경보',
                combineErrors: false,
                layout: 'hbox',
                defaults: {hideLabel: true,margin: '0 5 0 0'},
                items: [
                	{xtype: 'checkbox',boxLabel: '주의보',itemId: 'warning_c',name: 'warning_c',inputValue: 'Y'},
                	{xtype: 'checkbox',boxLabel: '경보',itemId: 'warning_d',name: 'warning_d',inputValue: 'Y'},
                	{xtype: 'checkbox',boxLabel: '중대경보',itemId: 'warning_e',name: 'warning_e',inputValue: 'Y',checked: true}
                ]
            },{
            	xtype: 'fieldcontainer',
                fieldLabel: '오염등급',
                combineErrors: false,
                layout: 'hbox',
                defaults: {hideLabel: true,margin: '0 5 0 0'},
                items: [
                	{xtype: 'checkbox',boxLabel: '나쁨',itemId: 'level_c',name: 'level_c',inputValue: 'Y'},
                	{xtype: 'checkbox',boxLabel: '매우나쁨',itemId: 'level_d',name: 'level_d',inputValue: 'Y',checked: true}
                ]
            }]
        },{
            xtype: 'fieldset',
            title: '관리자전용',
            collapsible: false,
            defaults: {labelWidth: 100, anchor: '100%',layout: 'hbox'},
            items: [{
            	xtype: 'fieldcontainer',
                fieldLabel: '전송상태',
                combineErrors: false,
                layout: 'hbox',
                defaults: {hideLabel: true,margin: '0 5 0 0'},
                items: [
                	{xtype: 'checkbox',boxLabel: '기준초과',itemId: 'over_yn',name: 'over_yn',inputValue: 'Y'},
                	{xtype: 'checkbox',boxLabel: '측정값이상',itemId: 'level_x',name: 'level_x',inputValue: 'Y'}, 
                	{xtype: 'checkbox',boxLabel: '미수신',itemId: 'level_z',name: 'level_z',inputValue: 'Y',checked: true}
                ]
            },{
            	xtype: 'fieldcontainer',
                fieldLabel: '수신허용시간',
                combineErrors: false,
                layout: 'hbox',
                defaults: {hideLabel: true,margin: '0 5 0 0'},
                items: [
                	{xtype: 'numberfield', fieldLabel: '수신시작시간', itemId: 'receive_st', name: 'receive_st', flex: 1, value: 9, maxValue: 12, minValue: 1, allowBlank:false },
    	            {xtype: 'numberfield', fieldLabel: '수신종료시간', itemId: 'receive_ed', name: 'receive_ed', flex: 1, value: 18, maxValue: 24, minValue: 13, allowBlank:false }
                ]
            }]
        },{
        	html: '&nbsp;* SMS 발송조건을 설정 합니다<br/>'
        		+ '&nbsp;* SMS는 시간자료 수신상태에 따라 발송됩니다<br/>'
        		+ '&nbsp;* 관리자전용은 관리자로 지정된 사용자에게 해당됩니다'
        }],

        buttons: [{
            text: '저장',
            iconCls: 'x-fa fa-save',
            formBind: true,
            listeners : {
        		click: function(btn, e, eOpts) {

        	    	var params = btn.up('smsConditionWindow').down('form').getForm().getValues();
        	    	var set_sms_condition = Ext.Ajax.request({
                		url : '/system/setSmsCondition.ax',
                		method : 'POST',
                		params : params,
                		success : function(res){
                			var result = Ext.decode(res.responseText); 
                			if (result['code'] == '200') {
                				btn.up('window').close();
                				Ext.toast({
                					html: 'SMS 발송조건이 등록(수정) 되었습니다.'
                                });
                			} else {
                				Ext.Msg.alert('정보', result['msg']);
                			}
                		}
                	});
            	}
        	}
        }]
    }],

    
    
    listeners : {
    	afterrender : function (obj, eOpts) {
    		
    		var get_sms_condition = Ext.Ajax.request({
        		url : '/system/getSmsCondition.ax',
        		method : 'POST',
        		success : function(res){
        			var result = Ext.decode(res.responseText); 
        			if (result['code'] == '200') {
            			obj.down('#warning_c').setValue(result['warning_c']=='Y'?true:false);
	        			obj.down('#warning_d').setValue(result['warning_d']=='Y'?true:false);
	        			obj.down('#warning_e').setValue(result['warning_e']=='Y'?true:false);
	        			obj.down('#level_c').setValue(result['level_c']=='Y'?true:false);
	        			obj.down('#level_d').setValue(result['level_d']=='Y'?true:false);
	        			obj.down('#over_yn').setValue(result['over_yn']=='Y'?true:false);
	        			obj.down('#level_x').setValue(result['level_x']=='Y'?true:false);
	        			obj.down('#level_z').setValue(result['level_z']=='Y'?true:false);
	        			obj.down('#receive_st').setValue(result['receive_st']);
	    	    		obj.down('#receive_ed').setValue(result['receive_ed']);
        			}
        		}
        	});
    	}
    }

});

