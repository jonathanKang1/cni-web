Ext.define('cni.view.system.SmsSendListPanel', {
	extend: 'Ext.grid.Panel',
    xtype: 'smsSendListPanel',
    
    id: 'smsSendListPanel',
    reference: 'smsSendListPanel',
   
    title: 'SMS발송목록',
    iconCls : 'x-fa fa-share',	
    
    columnLines: true,
    border: true,
    //height: '100%',
    tbar: [{
    	iconCls : 'x-fa fa-wrench',
    	tooltip : 'SMS조건설정',
        //handler : 'fnSmsConditionSetting'
    	handler: function (btn) {
    		Ext.widget('smsConditionWindow');
    	}
    },{
        xtype: 'datefield',
        id:'s_date',
        name: 's_date',
        itemId:'s_date',
        fieldLabel: '시작일',
        format: 'Y/m/d',
        //value: Ext.Date.add(new Date(), Ext.Date.DAY, -7),
        value: new Date(),
        labelWidth: 50,
        width: 180,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -30),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },{xtype: 'label', text: ' ~ ' },{
        xtype: 'datefield',
        name: 'e_date',
        itemId:'e_date',
        fieldLabel: '종료일',
        format: 'Y/m/d',
        value: new Date(),
        labelWidth: 50,
        width: 180,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -29),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },'->',{
    	xtype: 'combo',
    	id: 's_key',
    	itemId: 's_key',
    	displayField:'key_name',
    	valueField:'key_code',
    	value: 'receive_nm',
    	width: 100,
    	store: {
    		fields: ['key_name', 'key_code'],
    		data: [{
    			key_name: '이름',
    			key_code: 'receive_nm' 
    		},{
    			key_name: '전화번호',
    			key_code: 'receive_num' 
    		}]
    	}
    },{
    	xtype: 'textfield',
    	id: 's_txt',
    	itemId: 's_txt',
    	emptyText: '검색어를 입력하세요'
    },{
    	xtype: 'button',
    	id: 's_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	//handler : 'fnSendListSearch'
    	handler: function(btn) {
    		var vGrid = btn.up('smsSendListPanel');
    		if (vGrid.down("#s_date").getValue() < Ext.Date.add(vGrid.down('#e_date').getValue(), Ext.Date.MONTH, -6)) {
    			Ext.Msg.alert('알림', '조회 기간은 6개월을 초과할 수 없습니다.');
    		} else {
	    		vGrid.getStore('comm.listStore').proxy.extraParams = {
	    			search_key: vGrid.down("#s_key").getValue(), 
	    			search_txt: vGrid.down("#s_txt").getValue(),
	    			s_date: vGrid.down("#s_date").getValue(),
	    			e_date: vGrid.down("#e_date").getValue()
	    		};
	    		vGrid.getStore('comm.listStore').reload();
    		}
    	}
    }],
    
    columns : [{
    	xtype : 'rownumberer'
    },{
    	text : '수신자',
    	flex : 1,
    	dataIndex : 'RECEIVE_NM',
    	align: 'center'
    },{
    	text : '전화번호',
    	flex : 1,
    	dataIndex : 'RECEIVE_NUM',
    	align: 'center'
    },{
    	text : '발송시각',
    	flex : 1,
    	dataIndex : 'ISSUE_DT',
    	align: 'center'
    },{
    	text : '발송메세지',
    	flex : 3,
    	dataIndex : 'SEND_MSG',
    	align: 'center'
    },{
    	text : '등록시간',
    	flex : 1,
    	dataIndex : 'REG_DT',
    	align: 'center'
    }],
    
    store: {
    	type: 'comm.listStore',
    	autoLoad: false,
    	listeners : {
			beforeload: function(obj, records, successful, operation, eOpts) {
				obj.getProxy().setUrl('/system/getSmsSendList.ax');
			},
			load: function(obj, records, successful, operation, eOpts) {
				
			}
    	}
    		
    },
    
    listeners : {
		//rowdblclick : 'fnRowDblClick',
		cellclick : function (obj, td, cellIndex, record, tr, rowIndex, e, eOpts) {
			//obj.up('smsSendListPanel').down('#selected_receive_nm').setValue(record.get('receive_nm'));
			//obj.up('smsSendListPanel').down('#selected_receive_num').setValue(record.get('receive_num'));
		},
		afterrender : function (obj, eOpts) {
			let dt = new Date();
			dt.setMonth(dt.getMonth() - 1);
    		Ext.getCmp('smsSendListPanel').down("#s_date").setValue(dt);
    		Ext.getCmp('smsSendListPanel').down("#e_date").setValue(new Date());
    	},
    	boxready : function(obj) {
    		obj.getStore().proxy.extraParams = {
    				search_key: obj.down("#s_key").getValue(), 
    				search_txt: obj.down("#s_txt").getValue(),
    				s_date: obj.down("#s_date").getValue(),
    				e_date: obj.down("#e_date").getValue()
    		}
    		obj.getStore().load();
    		//Ext.StoreManager.lookup('comm.listStore').load();
		},
	}
    
});