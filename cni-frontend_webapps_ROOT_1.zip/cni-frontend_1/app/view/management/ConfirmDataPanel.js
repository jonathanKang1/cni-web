Ext.define('cni.view.management.ConfirmDataPanel', {
	extend: 'Ext.form.Panel',
    xtype: 'confirmDataPanel',

    requires: [
        'cni.controller.management.ConfirmController',
        'cni.store.comm.TmsStore'
    ],
    
    controller: 'management.confirmController',
    
    id: 'confirmDataPanel',
    reference: 'confirmDataPanel',
    
    title: '마감자료 조회',
    iconCls : 'x-fa fa-calculator',
    border: true,
    layout: 'fit',
    
    tools:[{
        iconCls : 'x-fa fa-save',
        tooltip: 'PDF',
        handler : 'fnConfirmPDFDown'
    },{
    	iconCls : 'x-fa fa-table',
        tooltip: '엑셀',
        handler : 'fnConfirmExcelDown'
    }],
    
    tbar: [{
    	xtype: 'combo',
    	itemId:'net_cd',
    	displayField: 'net_nm',
        valueField: 'net_cd',
        value: 'ALL',
        width: 110,
        queryMode: 'local',
    	store: {
    		fields: ['net_cd', 'net_nm'],
    	    data : [
    	    	{'net_cd':'ALL', 'net_nm':'망구분(전체)'},
    	    	{'net_cd':'C', 'net_nm':'마을대기'},
    	        {'net_cd':'A', 'net_nm':'국가대기'}
    	    ]
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.netCD = newValue;
    			Ext.StoreManager.lookup('comm.regionStore').load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'region_cd',
    	displayField:'REGION_NM',
    	valueField:'REGION_CD',
    	emptyText: '시군선택',
    	width: 120,
    	queryMode: 'local',
    	store: {
    		type : 'comm.regionStore',
    		autoLoad: true,
    		listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/comm/getUseRegionList.ax');
    				obj.proxy.extraParams = {
    					net_cd: Ext.getCmp('confirmDataPanel').down('#net_cd').getValue()
    				};
    	    	},
    			load: function(obj, records, successful, operation, eOpts) {
    				obj.insert(0, [{
    					REGION_CD: 'ALL',
    					REGION_NM: '전체'
			        }]);
    				Ext.getCmp('confirmDataPanel').down('#region_cd').setValue('ALL');
    				//Ext.getCmp('confirmDataPanel').down('#region_cd').setValue(records[0].get('REGION_CD'));
        		}
        	}	
    	}, 
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			Ext.StoreManager.lookup('comm.tmsStore').load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'tms_cd',
    	displayField:'TMS_NM',
    	valueField:'TMS_CD',
    	emptyText: '측정소선택',
    	width: 100,
    	queryMode: 'local',
    	store: {
    		type : 'comm.tmsStore',
    		listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/comm/getUseTmsList.ax');
    				obj.proxy.extraParams = {
        	    			region_cd: Ext.getCmp('confirmDataPanel').down('#region_cd').getValue()
        				};
    	    	},
    			load: function(obj, records, successful, operation, eOpts) {
    				obj.insert(0, [{
						TMS_CD: 'ALL',
			            TMS_NM: '전체'
			        }]);
    				Ext.getCmp('confirmDataPanel').down('#tms_cd').setValue('ALL');
    				//Ext.getCmp('confirmDataPanel').down('#tms_cd').setValue(records[0].get('TMS_CD'));
    			}
    		}
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    		}
    	}
    },{
		xtype: 'numberfield',
        fieldLabel: '조회기간',
        name: 's_year',
        itemId: 's_year',
        labelWidth: 60,
        width: 160,
        value: 2019,
        minValue: 2019,
        maxValue: 2099,
        listeners : {
        	afterrender: function(me, eOpts) {
        		//me.setValue(cni.app.monitorCol);
        	} 
        }
    },{
		xtype: 'numberfield',
        name: 's_month',
        itemId: 's_month',
        width: 70,
        value: 6,
        minValue: 1,
        maxValue: 12,
        listeners : {
        	afterrender: function(me, eOpts) {
        		//me.setValue(cni.app.monitorCol);
        	} 
        }
    },{
    	xtype: 'label',
    	text: ' ~ '
    },{
		xtype: 'numberfield',
        name: 'e_year',
        itemId: 'e_year',
        width: 100,
        value: 2019,
        minValue: 2019,
        maxValue: 2099,
        listeners : {
        	afterrender: function(me, eOpts) {
        		//me.setValue(cni.app.monitorCol);
        	} 
        }
    },{
		xtype: 'numberfield',
        name: 'e_month',
        itemId: 'e_month',
        width: 70,
        value: 6,
        minValue: 1,
        maxValue: 12,
        listeners : {
        	afterrender: function(me, eOpts) {
        		//me.setValue(cni.app.monitorCol);
        	} 
        }
    },{
    	xtype: 'combo',
    	itemId:'data_type',
    	displayField: 'data_type_nm',
        valueField: 'data_type',
        value: 'M',
        width: 110,
        queryMode: 'local',
    	store: {
    		fields: ['data_type', 'data_type_nm'],
    	    data : [
    	        {'data_type':'D', 'data_type_nm':'일마감'},
    	        {'data_type':'M', 'data_type_nm':'월마감'}
    	    ]
    	}
    }
    ,'->', {
    	xtype: 'button',
    	itemId: 'search_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : 'fnConfirmDataSearch'
    }],
    
    items:[{
    	xtype: 'grid',
    	itemId: 'data_grid',
    	columnLines: true,
        height: '100%',
        loadMask: true,
    	columns : [{
        	text : '<b>시군</b>',
        	flex : 1,
        	dataIndex : 'REGION_NM',
        	align: 'center'
        },{
        	text : '<b>측정소</b>',
        	flex : 1,
        	dataIndex : 'TMS_NM',
        	align: 'center'
        },{
        	text : '<b>측정항목</b>',
        	flex : 1,
        	dataIndex : 'ITEM_NM',
        	align: 'center'
        },{
        	text : '<b>마감월(일)</b>',
        	flex : 1,
        	dataIndex : 'MSR_DM_FM',
        	align: 'center'
        },{
        	text : '<b>유효자료<br/>획득률(%)</b>',
        	flex : 1,
        	dataIndex : 'VALID_RATE',
        	align: 'center'
        },{
        	text : '<b>유효측정<br/>일수(day)</b>',
        	flex : 1,
        	dataIndex : 'VALID_DD_CNT',
        	align: 'center'
        },{
        	text : '<b>유효측정<br/>횟수(8hour)</b>',
        	flex : 1,
        	dataIndex : 'VALID_08_CNT',
        	align: 'center'
        },{
        	text : '<b>유효측정<br/>시간(hour)</b>',
        	flex : 1,
        	dataIndex : 'VALID_CNT',
        	align: 'center'
        },{
        	text : '<b>평균값</b>',
        	align: 'center',
        	flex : 1.2,
        	dataIndex : 'MSR_AVG',
	        align: 'center'
        },{
        	text : '<b>1시간치</b>',
        	align: 'center',
        	flex : 5,
        	columns : [{
	        	text : '<b>최저</b>',
	        	flex : 1,
	        	dataIndex : 'MSR_MIN',
	        	align: 'center'
	        },{
	        	text : '<b>최고</b>',
	        	flex : 1,
	        	dataIndex : 'MSR_MAX',
	        	align: 'center'
	        },{
	        	text : '<b>최고일시</b>',
	        	flex : 1,
	        	dataIndex : 'MAX_DT',
	        	align: 'center'
	        },{
	        	text : '<b>기준초과<br/>(회)</b>',
	        	flex : 1,
	        	dataIndex : 'OVER_CNT',
	        	align: 'center'
	        },{
	        	text : '<b>초과율<br/>(%)</b>',
	        	flex : 1,
	        	dataIndex : 'OVER_RATE',
	        	align: 'center'
	        }]
        },{
        	text : '<b>8 or 24시간치</b>',
        	align: 'center',
        	flex : 5,
        	columns : [{
	        	text : '<b>최저</b>',
	        	flex : 1,
	        	dataIndex : 'MIN_0824_VL',
	        	align: 'center'
	        },{
	        	text : '<b>최고</b>',
	        	flex : 1,
	        	dataIndex : 'MAX_0824_VL',
	        	align: 'center'
	        },{
	        	text : '<b>최고일시</b>',
	        	flex : 1,
	        	dataIndex : 'MAX_0824_DT',
	        	align: 'center'
	        },{
	        	text : '<b>기준초과<br/>(회)</b>',
	        	flex : 1,
	        	dataIndex : 'OVER_0824_CNT',
	        	align: 'center'
	        },{
	        	text : '<b>초과율<br/>(%)</b>',
	        	flex : 1,
	        	dataIndex : 'OVER_0824_RATE',
	        	align: 'center'
	        },{
	        	text : '<b>시간구분</b>',
	        	flex : 1,
	        	dataIndex : 'HOUR_TYPE',
	        	align: 'center'
	        }]
        }],
        store: {
        	type: 'comm.listStore',
        	listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				var view = Ext.getCmp('confirmDataPanel');
    				obj.getProxy().setUrl('/management/getConfirmDataList.ax');
    				obj.proxy.extraParams = {
						net_cd: view.down("#net_cd").getValue(),
    					region_cd: view.down("#region_cd").getValue(),
    					tms_cd: view.down("#tms_cd").getValue(),
	    				s_date: view.down("#s_year").getValue() +''+ (view.down("#s_month").getValue() < 10 ? '0'+view.down("#s_month").getValue() : view.down("#s_month").getValue()),
	    				e_date: view.down("#e_year").getValue() +''+ (view.down("#e_month").getValue() < 10 ? '0'+view.down("#e_month").getValue() : view.down("#e_month").getValue()),
	    				data_type: view.down("#data_type").getValue()
					}
    	    	},
    	    	load: function(obj, records, successful, operation, eOpts) {
    	    		var view = Ext.getCmp('confirmDataPanel');
    	    		if (view.down("#data_type").getValue() == 'D') {
	    	    		view.down('#data_grid').headerCt.getHeaderAtIndex(14).setHidden(true);
	    	    		view.down('#data_grid').headerCt.getHeaderAtIndex(15).setHidden(true);
	    	    		view.down('#data_grid').headerCt.getHeaderAtIndex(16).setHidden(true);
	    	    		view.down('#data_grid').headerCt.getHeaderAtIndex(17).setHidden(true);
	    	    		view.down('#data_grid').headerCt.getHeaderAtIndex(18).setHidden(true);
	    	    		view.down('#data_grid').headerCt.getHeaderAtIndex(19).setHidden(true);
    	    		} else {
    	    			view.down('#data_grid').headerCt.getHeaderAtIndex(14).setHidden(false);
	    	    		view.down('#data_grid').headerCt.getHeaderAtIndex(15).setHidden(false);
	    	    		view.down('#data_grid').headerCt.getHeaderAtIndex(16).setHidden(false);
	    	    		view.down('#data_grid').headerCt.getHeaderAtIndex(17).setHidden(false);
	    	    		view.down('#data_grid').headerCt.getHeaderAtIndex(18).setHidden(false);
	    	    		view.down('#data_grid').headerCt.getHeaderAtIndex(19).setHidden(false);
    	    		}
    	    	}
        	}	
        }
    }],
    
    listeners : {
    	beforerender : function (obj, eOpts) {
    		//Ext.StoreManager.lookup('comm.tmsStore').load();
    	},
    	render : function (obj, eOpts) {
    	},
    	afterrender : function (obj, eOpts) {
    		obj.down('#net_cd').setValue(cni.app.netCD);
    		Ext.getCmp('confirmDataPanel').down("#s_year").setValue(Ext.Date.format(Ext.Date.add(new Date(), Ext.Date.MONTH, -5),'Y'));
    		Ext.getCmp('confirmDataPanel').down("#s_month").setValue(Ext.Date.format(Ext.Date.add(new Date(), Ext.Date.MONTH, -5),'m'));
    		Ext.getCmp('confirmDataPanel').down("#e_year").setValue(Ext.Date.format(new Date(),'Y'));
    		Ext.getCmp('confirmDataPanel').down("#e_month").setValue(Ext.Date.format(new Date(),'m'));
    		
    		//컬럼명 변경
    		//obj.down('#data_grid').headerCt.getHeaderAtIndex(1).setText('ㅋㅋㅋ');
    		
    		
    		//컬럼추가
    		/*var addCol = {
            	text : '<b>시군구</b>',
            	flex : 1,
            	dataIndex : 'REGION_NM',
            	align: 'center'
            };
    		obj.down('#data_grid').headerCt.insert(obj.down('#data_grid').columns.length, addCol);*/
    		
    		
    		/*var gridView = Ext.ComponentQuery.query("grid")[0];
    		var column = Ext.create('Ext.grid.column.Column', {
            	text : '<b>시군구!</b>',
            	flex : 1,
            	dataIndex : 'REGION_NM',
            	align: 'center'
            });
    		//gridView.headerCt.insert(gridView.columns.length, column);
    		gridView.headerCt.insert(2, column);
    		gridView.getView().refresh();*/
    		
    	}, 
    	boxready : function(obj) {
		},
		destroy: function(obj, eOpts) {
    	}
	}
});
