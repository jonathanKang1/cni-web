Ext.define('cni.view.system.ReportWindow', {
    extend: 'Ext.window.Window',
    xtype: 'reportWindow',
    
    title: '대기환경보고서관리',
    iconCls : 'x-fa fa-book',
    width : 450,
    height: 300,
    //closable : true,	//default true
    autoShow : true,
    modal : true,
    layout : 'fit',
    /*onEsc : function(){
    	this.close();
    	return true;
    },*/
    items : [{
    	xtype : 'form',
    	frame: false,
        bodyPadding: 10,
        scrollable:true,
        method: 'POST',
        defaults: {
            anchor: '100%',
            labelWidth: 70
        },

        items: [{
        	xtype: 'combo',
        	fieldLabel: '보고서구분',
        	itemId:'rpt_type',
        	name: 'rpt_type',
        	displayField: 'rpt_type_nm',
            valueField: 'rpt_type',
            value: 'Y',
            //width: 110,
            editable: false,
            queryMode: 'local',
        	store: {
        		fields: ['rpt_type', 'rpt_type_nm'],
        	    data : [
        	    	{'rpt_type':'Y', 'rpt_type_nm':'연간보고서'},
        	        {'rpt_type':'Q', 'rpt_type_nm':'분기보고서'},
        	        {'rpt_type':'M', 'rpt_type_nm':'월간간행물'},
        	        {'rpt_type':'F', 'rpt_type_nm':'연간확정자료'}
        	    ]
        	},
        	listeners : {
        		change : function (combo, newValue, oldValue, eOpts) {
        			if (newValue == 'Y' || newValue == 'F') {
        				combo.up('form').down('#qq').setHidden(true);
        				combo.up('form').down('#mm').setHidden(true);
        			} else if (newValue == 'Q') {
        				combo.up('form').down('#qq').setHidden(false);
        				combo.up('form').down('#mm').setHidden(true);
        			} else {
        				combo.up('form').down('#qq').setHidden(true);
        				combo.up('form').down('#mm').setHidden(false);
        			}
        		}
        	}
        },{
        	xtype: 'combobox',
        	fieldLabel: '보고 연도',
        	itemId: 'yyyy',
        	name: 'yyyy',
        	displayField:'YYYY_TXT',
        	valueField:'YYYY',
        	emptyText: '보고 연도',
        	//width: 110,
        	editable: false,
        	queryMode: 'local',
        	store: {
        		type : 'comm.listStore',
        		autoLoad: true,
        		listeners : {
        			beforeload: function(obj, records, successful, operation, eOpts) {
        				obj.getProxy().setUrl('/comm/getyearList.ax');
        	    	},
        			load: function(obj, records, successful, operation, eOpts) {
        				
        			}
        		}
        	}
        },{
        	xtype: 'combo',
        	fieldLabel: '분기',
        	itemId:'qq',
        	name: 'qq',
        	displayField: 'mm_txt',
            valueField: 'mm',
            value: '1',
            //width: 110,
            editable: false,
            hidden: true,
            queryMode: 'local',
        	store: {
        		fields: ['mm', 'mm_txt'],
        	    data : [
        	    	{'mm':'1', 'mm_txt':'1분기'},
        	        {'mm':'2', 'mm_txt':'2분기'},
        	        {'mm':'3', 'mm_txt':'3분기'},
        	        {'mm':'4', 'mm_txt':'4분기'}
        	    ]
        	}
        },{
        	xtype: 'combo',
        	fieldLabel: '보고 월',
        	itemId:'mm',
        	name: 'mm',
        	displayField: 'mm_txt',
            valueField: 'mm',
            value: '01',
            //width: 110,
            editable: false,
            queryMode: 'local',
        	store: {
        		fields: ['mm', 'mm_txt'],
        	    data : [
        	    	{'mm':'01', 'mm_txt':'1월'},
        	        {'mm':'02', 'mm_txt':'2월'},
        	        {'mm':'03', 'mm_txt':'3월'},
        	        {'mm':'04', 'mm_txt':'4월'},
        	        {'mm':'05', 'mm_txt':'5월'},
        	        {'mm':'06', 'mm_txt':'6월'},
        	        {'mm':'07', 'mm_txt':'7월'},
        	        {'mm':'08', 'mm_txt':'8월'},
        	        {'mm':'09', 'mm_txt':'9월'},
        	        {'mm':'10', 'mm_txt':'10월'},
        	        {'mm':'11', 'mm_txt':'11월'},
        	        {'mm':'12', 'mm_txt':'12월'},
        	    ]
        	}
        },{
        	xtype: 'fieldcontainer',
            fieldLabel: '첨부파일',
            combineErrors: false,
            itemId: 'att_file',
            layout: 'hbox',
            defaults: {hideLabel: true,margin: '0 5 0 0'},
            hidden: true,
            items:[{
            	//xtype : 'displayfield',
            	xtype: 'textfield', 
            	fieldLabel: '첨부파일',
            	itemId: 'org_file_nm',
            	name : 'org_file_nm',
            	width: 285,
            	readOnly: true
            },{
            	xtype: 'textfield', 
            	itemId: 'save_file_nm',
            	name : 'save_file_nm',
            	hidden: true,
            	readOnly: true
            },{
            	xtype: 'button',
            	iconCls: 'x-fa fa-trash',
            	tooltip: '파일삭제',
            	//text : '&nbsp;삭 제&nbsp;',
            	handler: function(xbtn) {
            		let confirm_msg = '첨부파일을 삭제하시겠습니까?<br>(삭제 후 되돌릴 수 없습니다.)';
            		if (xbtn.up('form').down('#rpt_type').getValue() == 'F') {
            			confirm_msg = '첨부파일 및 Data를 삭제하시겠습니까?<br>(삭제 후 되돌릴 수 없습니다.)';
            		}
            		Ext.MessageBox.show({
                    	title : '확인',
                    	msg : confirm_msg,
                        buttons : Ext.MessageBox.YESNO,
                        icon : Ext.MessageBox.INFO,
                        fn: function(btn) {
                            if (btn === 'yes') {
                            	var form = xbtn.up('reportWindow').down('form').getForm();
                            	form.submit({
                                	clientValidation: true,
                                	url: '/management/delReportList.ax',
                                    waitMsg: 'Processing your request...',
                                    success: function(frm, action) {
                                    	var result = Ext.JSON.decode(action.response.responseText);
                                    	Ext.Msg.confirm('정보', result.msg, function(btn) {
                                    		if (btn == 'yes') {
                                        		//sbtn.up('reportWindow').config.myParentStore.reload();
                                        		xbtn.up('reportWindow').close();
                                        	}
                                        });
                                    	xbtn.up('form').down('#org_file_nm').setValue('');
                                    	xbtn.up('form').down('#save_file_nm').setValue('');
                                    	xbtn.up('form').down('#down_btn').setDisabled(true);
                                    	xbtn.up('form').down('#att_file').setHidden(true);
                                    	xbtn.up('form').down('#fileupload').setHidden(false);
                                    },
                                    failure: function(frm, action) {
                                    	var result = Ext.JSON.decode(action.response.responseText);
                                    	let msg = result.msg;
                                    	if (!msg) msg = '요청처리에 문제가 발생하였습니다!';
                                    	Ext.MessageBox.show({
                                        	title : '정보',
                                        	msg : msg,
                                            buttons : Ext.MessageBox.YES,
                                            icon : Ext.MessageBox.INFO
                                        });
                                    	xbtn.up('reportWindow').close();
                                    }
                                });
	
                            } else if (btn === 'no') {
                                
                            } else {
                                
                            }
                        }
                    });
            	}
            },{
            	xtype: 'button',
            	iconCls : 'x-fa fa-save',
            	tooltip: '다운로드',
            	itemId: 'down_btn',
            	handler: function(xbtn) {
            		document.frm.action = '/management/getReportFile.do';
            		document.frm.rpt_type.value = xbtn.up('form').down('#rpt_type').getValue();
            		document.frm.yyyy.value = xbtn.up('form').down('#yyyy').getValue();
            		document.frm.qq.value = xbtn.up('form').down('#qq').getValue();
            		document.frm.mm.value = xbtn.up('form').down('#mm').getValue();
            		document.frm.org_file_nm.value = xbtn.up('form').down('#org_file_nm').getValue();
            		document.frm.use_yn.value = (xbtn.up('form').down('#use_yn').getValue()?'Y':'N');
            		document.frm.submit();	
            	}
            }]
        },{
        	xtype : 'filefield',
        	fieldLabel: '파일첨부',
        	buttonText  : '찾아보기',
        	itemId: 'fileupload',
        	name : 'fileupload',
        	maxLength: 150,
        	width: '100%'
        },{
        	xtype: 'checkbox',
        	fieldLabel: '게시여부',
        	itemId: 'use_yn',
        	name: 'use_yn',
        	inputValue: 'Y',
        	checked: true
        },{
        	html: '&nbsp;* 일부 브라우져의 경우 저장여부를 확인하는 경우가 있습니다.<br>'
        			+ '&nbsp;&nbsp;&nbsp;이런 경우 "취소"를 선택하여 메세지를 닫아주세요.<br>'
        			+ '&nbsp;&nbsp;&nbsp;팝업창을 닫으시고 파일 등록여부를 확인하시기 바랍니다.<br>'
        }],
        fbar : [{
        	xtype : 'button', 
        	text : '저장', 
        	iconCls: 'x-fa fa-save',
        	formBind: true,
        	handler : function(sbtn){ 
        		if(!sbtn.up('reportWindow').down('#org_file_nm').getValue() && !sbtn.up('reportWindow').down('#fileupload').getValue()) {
        			Ext.MessageBox.show({
                    	title : '정보',
                    	msg : '파일을 첨부하세요',
                        buttons : Ext.MessageBox.YES,
                        icon : Ext.MessageBox.INFO
                    });
        			return;
        		}
        		let confirm_msg = '다음 내용을 확인하셨습니까?';
        		confirm_msg += '<br><br><u>보고서구분 : '+sbtn.up('form').down('#rpt_type').getRawValue()+'</u>';
        		confirm_msg += '<br><u>보고서연도 : '+sbtn.up('form').down('#yyyy').getRawValue()+'</u>';
        		if (sbtn.up('form').down('#rpt_type').getValue() == 'Q') confirm_msg += '<br><u>보고서분기 : '+sbtn.up('form').down('#qq').getRawValue()+'</u>';
        		if (sbtn.up('form').down('#rpt_type').getValue() == 'M') confirm_msg += '<br><u>보고서  월 : '+sbtn.up('form').down('#mm').getRawValue()+'</u>';
        		
        		Ext.Msg.confirm('정보', confirm_msg, function(btn) {
        			if (btn == 'no') return;
        		
	        		let url = '/management/setReport.ax';
	        		if (sbtn.up('form').down('#rpt_type').getValue()=='F') url = '/management/setReportFinal.ax';	
	        		var form = sbtn.up('reportWindow').down('form').getForm();
	        		if (form.isValid()) {
	    				form.submit({
	                    	clientValidation: true,
	                    	url: url,
	                        waitMsg: 'Uploading your Content...',
	                        timeout:60,
	                        success: function(frm, action) {
	                        	var result = Ext.JSON.decode(action.response.responseText);
	                        	Ext.Msg.confirm('정보', result.msg, function(btn) {
	                        		if (btn == 'yes') {
	                            		//sbtn.up('reportWindow').config.myParentStore.reload();
	                            		sbtn.up('reportWindow').close();
	                            	}
	                            });
	                        },
	                        failure: function(frm, action) {
	                        	var result = Ext.JSON.decode(action.response.responseText);
	                        	let msg = result.msg;
	                        	if (!msg) msg = '파일처리에 시간이 많이 걸리고 있습니다.<br>잠시후 업로드 여부를 확인하시기 바랍니다. ';
	                        	Ext.MessageBox.show({
	                            	title : '정보',
	                            	msg : msg,
	                                buttons : Ext.MessageBox.YES,
	                                icon : Ext.MessageBox.INFO
	                            });
	                        	sbtn.up('reportWindow').close();
	                        }
	                    });
	                } else {
	                	Ext.MessageBox.show({
	                    	title : '정보',
	                    	msg : '파일명이 제한길이를 초과하였거나 입력항목을 확인하시기 바랍니다.',
	                        buttons : Ext.MessageBox.YES,
	                        icon : Ext.MessageBox.INFO
	                    });
	                }
        		});	
        	}
        }]
    }],

    listeners : {
    	afterrender : function (obj, eOpts) {
    		if (obj.config.selectedRecord) {
    			obj.down('#rpt_type').setValue(obj.config.selectedRecord.data.RPT_TYPE);
    			obj.down('#rpt_type').setReadOnly(true);
    			
    			obj.down('#yyyy').setValue(obj.config.selectedRecord.data.YYYY);
    			obj.down('#yyyy').setReadOnly(true);
    			
    			if (obj.config.selectedRecord.data.RPT_TYPE == 'Y') { 
    				obj.down('#qq').setHidden(true);
    				obj.down('#mm').setHidden(true);
    			} else if (obj.config.selectedRecord.data.RPT_TYPE == 'F') { 
    				obj.down('#qq').setHidden(true);
    				obj.down('#mm').setHidden(true);
    			} else if (obj.config.selectedRecord.data.RPT_TYPE == 'Q') {
    				obj.down('#qq').setHidden(false);
    				obj.down('#mm').setHidden(true);
    				obj.down('#qq').setValue(obj.config.selectedRecord.data.MM);
    				obj.down('#qq').setReadOnly(true);
    			} else { 
    				obj.down('#qq').setHidden(true);
    				obj.down('#mm').setHidden(false);
    				obj.down('#mm').setValue(obj.config.selectedRecord.data.MM);
    				obj.down('#mm').setReadOnly(true);
    			}
    			
    			if (obj.config.selectedRecord.data.ORG_FILE_NM) {
    				obj.down('#att_file').setHidden(false);
        			obj.down('#org_file_nm').setValue(obj.config.selectedRecord.data.ORG_FILE_NM);
        			obj.down('#save_file_nm').setValue(obj.config.selectedRecord.data.SAVE_FILE_NM);
        			obj.down('#fileupload').setHidden(true);
    			} else {
    				obj.down('#att_file').setHidden(true);
    			}
    			obj.down('#use_yn').setValue(obj.config.selectedRecord.data.USE_YN=='Y'?true:false);
    		} else {
    			obj.down('#yyyy').setValue(Ext.Date.format(new Date(), 'Y'));
    			obj.down('#mm').setValue(Ext.Date.format(new Date(), 'm'));
    			obj.down('#mm').setHidden(true);
    		}
    	},
    	close: function (win, eOpts) {
    		win.config.myParentStore.reload();
    	} 
    }
});

