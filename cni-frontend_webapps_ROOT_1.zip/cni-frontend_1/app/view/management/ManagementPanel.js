Ext.define('cni.view.data.ManagementPanel', {
	extend: 'Ext.form.Panel',
    xtype: 'managementPanel',

    requires: [
    	'cni.model.main.ManagementModel'
    ],
    
    controller: 'data.dataController',
    
    id: 'managementPanel',
    reference: 'managementPanel',
    
    title: '이상자료관리',
    iconCls : 'x-fa fa-tag',
    border: true,
    layout: 'fit',
    
    tools:[{
        iconCls : 'x-fa fa-save',
        tooltip: 'PDF',
        handler : 'fnMgrPDFDown'
    },{
    	iconCls : 'x-fa fa-table',
        tooltip: '엑셀',
        handler : 'fnMgrExcelDown'
    }],

    viewModel: {
        stores: {
            useStateStore: {
                type: 'comm.statusStore',
                autoLoad: true,
                listeners: {
                	beforeload: function(obj, records, successful, operation, eOpts) {
                		obj.getProxy().setUrl('/comm/getUseStatusList.ax');
                	},
                    load: function(obj, records, successful, operation, eOpts) {
                    	var result = Ext.decode(operation.getResponse().responseText);
                    	if (result['code'] == 404) {
            				return;
                    	} else if (result['code'] == 500) { 
                    		Ext.Msg.alert('알림', result['msg']);
                    	} else {
	                        var menu = Ext.getCmp('managementPanel').down('#status_nm').menu;
	                        var items = [];
	                        var selectedItems = '';
	                        for (i = 0, len = records.length; i < len; ++i) {
	                       		items.push({
	                                xtype: 'menucheckitem',
	                                text: records[i].get('STATUS_NM'),
	                                //checked: (records[i].get('code_name')=='정상' || records[i].get('code_name')=='자료없음')?true:false,
	                                checked: true,
	                                handler: 'fnMgrSelectState'
	                            });
	                       		selectedItems += records[i].get('STATUS_NM')+':';
	                        }
	                        menu.removeAll(true);
	                        if (items.length) {
	                            menu.add(items);
	                        }
	                        Ext.getCmp('managementPanel').down('#status_nms').setText(selectedItems);
                    	}
                    }
                }
            },
            useItemStore: {
                type: 'comm.itemStore',
                //autoLoad: true,
                listeners: {
                	beforeload: function(obj, records, successful, operation, eOpts) {
                		obj.getProxy().setUrl('/comm/getUseItemList.ax');
                		obj.proxy.extraParams = {
                				tms_cd: Ext.getCmp('managementPanel').down("#tms_cd").getValue()
    					};
                	},
                    load: function(obj, records, successful, operation, eOpts) {
                    	var result = Ext.decode(operation.getResponse().responseText);
                    	if (result['code'] == 404) {
            				return;
                    	} else if (result['code'] == 500) { 
                    		Ext.Msg.alert('알림', result['msg']);
                    	} else {
	                        var menu = Ext.getCmp('managementPanel').down('#item_nm').menu;
	                        var items = [];
	                        var selectedItems = ':전체';
	                        items.push({
                                xtype: 'menucheckitem',
                                text: '전체',
                                itemId: 'menu0',
                                checked: true,
                                listeners : {
                                	click:function (itm, e, eOpts) {
                                		var menus = Ext.getCmp('managementPanel').down('#item_nm').menu.items;
                                		var menu_nms = '';
                            			Ext.Array.each(menus, function(obj, idx, arr) {
                                			Ext.getCmp('managementPanel').down(('#menu'+idx)).setChecked(itm.checked);
                                			if (itm.checked) {
                                				menu_nms += ':'+Ext.getCmp('managementPanel').down(('#menu'+idx)).text;
                                			}
                                			Ext.getCmp('managementPanel').down('#item_nms').setText(menu_nms);
                                    	});
	                                }
                                }
                            });
	                        for (i = 0, len = records.length; i < len; ++i) {
	                       		items.push({
	                                xtype: 'menucheckitem',
	                                text: records[i].get('ITEM_NM'),
	                                itemId: 'menu'+(i+1),
	                                //checked: (records[i].get('code_name')=='정상' || records[i].get('code_name')=='자료없음')?true:false,
	                                checked: true,
	                                handler: 'fnMgrSelectItem'
	                            });
	                       		selectedItems += ':'+records[i].get('ITEM_NM');
	                        }
	                        menu.removeAll(true);
	                        if (items.length) {
	                            menu.add(items);
	                        }
	                        Ext.getCmp('managementPanel').down('#item_nms').setText(selectedItems);
                    	}
                    }
                }
            }
        }
    },

    tbar: [{
    	xtype: 'combo',
    	itemId:'net_cd',
    	displayField: 'net_nm',
        valueField: 'net_cd',
        value: 'ALL',
        width: 110,
        queryMode: 'local',
    	store: {
    		fields: ['net_cd', 'net_nm'],
    	    data : [
    	    	{'net_cd':'ALL', 'net_nm':'망구분(전체)'},
    	    	{'net_cd':'C', 'net_nm':'마을대기'},
    	        {'net_cd':'A', 'net_nm':'국가대기'}
    	    ]
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.netCD = newValue;
    			Ext.StoreManager.lookup('comm.regionStore').load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'region_cd',
    	displayField:'REGION_NM',
    	valueField:'REGION_CD',
    	emptyText: '지역선택',
    	width: 120,
    	queryMode: 'local',
    	store: {
    		type : 'comm.regionStore',
    		autoLoad: true,
    		listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/comm/getUseRegionList.ax');
    				obj.proxy.extraParams = {
    					net_cd: Ext.getCmp('managementPanel').down('#net_cd').getValue()
    				};
    	    	},
    			load: function(obj, records, successful, operation, eOpts) {
    				if (records.length > 0) 
    					Ext.getCmp('managementPanel').down('#region_cd').setValue(records[0].get('REGION_CD'));
        		}
        	}	
    	}, 
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.regionCD = newValue;
    			Ext.StoreManager.lookup('comm.tmsStore').load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'tms_cd',
    	displayField:'TMS_NM',
    	valueField:'TMS_CD',
    	emptyText: '측정소선택',
    	width: 100,
    	queryMode: 'local',
    	store: {
    		type : 'comm.tmsStore',
    		autoLoad: false,
    		listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/comm/getUseTmsList.ax');
    				obj.proxy.extraParams = {
    					//line_no: Ext.getCmp('managementPanel').down("#line_no").getValue()=='0'?'':Ext.getCmp('managementPanel').down("#line_no").getValue()
    	    			region_cd: cni.app.regionCD
    				};
    	    	},
    			load: function(obj, records, successful, operation, eOpts) {
    				if (records.length > 0) {
    					Ext.getCmp('managementPanel').down('#tms_cd').setValue(records[0].get('TMS_CD'));
    				} else {
    					obj.insert(0, [{
    						tms_cd: '--',
    			            tms_nm: '--'
    			        }]);
    					Ext.getCmp('managementPanel').down('#tms_cd').setValue('--');
    				}
    			}
    		}
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			Ext.StoreManager.lookup('comm.itemStore').load();
    		}
    	}
    },{
        text: '항목선택',
        reference: 'itemBtn',
        itemId: 'item_nm',
        destroyMenu: true,
        groupField: 'item_nm',
        menu: {
            hideOnScroll: false,
            items: []
        }
    },{
    	xtype: 'label',
    	itemId: 'item_nms',
    	hidden: true,
    	text: ''
    },{
        xtype: 'datefield',
        id:'s_date',
        name: 's_date',
        itemId:'s_date',
        fieldLabel: '시작일',
        format: 'Y/m/d',
        //value: Ext.Date.add(new Date(), Ext.Date.DAY, -7),
        value: new Date(),
        labelWidth: 45,
        width: 150,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -30),
        maxValue: new Date()        
    },{
        xtype: 'datefield',
        name: 'e_date',
        itemId:'e_date',
        fieldLabel: '종료일',
        format: 'Y/m/d',
        value: new Date(),
        labelWidth: 45,
        width: 150,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -29),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        } 
        }
    },{
        text: '상태선택',
        reference: 'stateBtn',
        itemId: 'status_nm',
        destroyMenu: true,
        groupField: 'status_nm',
        menu: {
            hideOnScroll: false,
            items: []
        }
    },{
    	xtype: 'label',
    	itemId: 'status_nms',
    	hidden: true,
    	text: ''
    },'-',{
    	xtype: 'textfield',
    	fieldLabel: '이상여부판단값',
    	itemId: 'excess_vl',
    	labelWidth: 100,
        width: 165
    },'-',{
    	xtype: 'numberfield',
    	fieldLabel: '전시간대비증감율',
    	itemId: 'suspicion_ratio',
    	labelWidth: 110,
        width: 185,
        maxValue: 300,
        minValue: 0,
        value: 100
    },'-',{
    	xtype: 'numberfield',
    	fieldLabel: '동일값(연속시간)',
    	itemId: 'same_tm',
    	labelWidth: 110,
        width: 170,
        maxValue: 24,
        minValue: 0,
        value: 5
    }
    ,'->', {
    	xtype: 'button',
    	itemId: 'search_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : 'fnDataSearch'
    }],
    
    items:[{
    	xtype: 'grid',
    	itemId: 'data_grid',
    	columnLines: true,
        height: '100%',
        loadMask: true,
        plugins: {
	        ptype: 'cellediting',
	        clicksToEdit: 2,
	        listeners : {
	        	canceledit: function(editor, context, eOpts) {
	        	},
	        	beforeedit: function(editor, context, eOpts) {
	        	},
	        	edit: function(editor, context, eOpts) {
	        	} 
	        }
	    },
    	columns : [{
        	text : '<b>측정시간</b>',
        	flex : 1,
        	dataIndex : 'DSP_DT',
        	//style: 'font-size: 16px',
        	align: 'center'
        },{
        	text : '<b>측정항목</b>',
        	flex : 1,
        	dataIndex : 'ITEM_NM',
        	align: 'center',
        	/*renderer: function(value, meta, record) {
        		if (value)
        			value = value + ' (' + record.get('ITEM_CD') + ')';
        		return value;
        	}*/
        },{
        	text : '<b>전월평균</b>',
        	flex : 1,
        	dataIndex : 'BEFORE_AVG',
        	align: 'center',
        	/*editor: {
                allowBlank: false
            },*/
        	/*renderer: function(value, meta, record) {
        		if (value)
        			value = value+' '+record.get('ITEM_UNIT');
        		return value;
        	}*/
        },{
        	text : '<b>이전시간값</b>',
        	flex : 1,
        	dataIndex : 'PRE_VL',
        	align: 'center'
        },{
        	text : '<b>측정값</b>',
        	flex : 1,
        	dataIndex : 'MSR_VL',
        	align: 'center',
        	/*editor: {
                allowBlank: false
            },*/
        	renderer: function(value, meta, record) {
        		var qtip = '';
        		if (record.get('EXCESS_YN') == 'Y' || record.get('SAME_YN') == 'Y' || record.get('PM2_OVER_YN') == 'Y' || record.get('MINUS_YN') == 'Y') {
        			meta.css = 'level-D';

        			if (record.get('EXCESS_YN') == 'Y') qtip = '이상여부판단값';
        			if (record.get('MINUS_YN') == 'Y') qtip = qtip==''?'음의값(-)':qtip+'<br/>음의값(-)';
        			if (record.get('SAME_YN') == 'Y') qtip = qtip==''?'장시간동일값':qtip+'<br/>장시간동일값';
        			if (record.get('PM2_OVER_YN') == 'Y') qtip = qtip==''?'값이상(PM2.5>PM10)':qtip+'<br/>값이상(PM2.5>PM10)';
        			
        			meta.tdAttr = 'data-qtip="' + qtip + '"';
        		}
        		return value;
        		/*if (value)
        			value = value+' '+record.get('ITEM_UNIT');
        		return value;*/
        	}
        },{
        	text : '<b>증감율</b>',
        	flex : 1,
        	dataIndex : 'RATIO',
        	align: 'center',
        	/*editor: {
                allowBlank: false
            },*/
        	renderer: function(value, meta, record) {
        		if (record.get('SUSPICION_YN') == 'Y') {
        			meta.css = 'level-D';
        			meta.tdAttr = 'data-qtip="' + '전시간대비증감율' + '"';
        		}
        		return value;
        	}
        },{
        	text : '<b>상태표시</b>',
        	flex : 1,
        	dataIndex : 'STATUS_NM',
        	align: 'center'
        },{
        	text : '<b>등급표시</b>',
        	flex : 1,
        	dataIndex : 'LEVEL_NM',
        	align: 'center'
        },{
        	text : '<b>기준초과</b>',
        	flex : 1,
        	dataIndex : 'OVER_NM',
        	align: 'center'
        },{
        	text : '<b>8h평균</b>',
        	flex : 1,
        	dataIndex : 'AVG_08',
        	align: 'center'
        },{
        	text : '<b>24h평균</b>',
        	flex : 1,
        	dataIndex : 'AVG_24',
        	align: 'center'
        },{
        	text : '<b>지수</b>',
        	flex : 1,
        	dataIndex : 'AI_VL',
        	align: 'center',
        	renderer: function(value, meta, record) {
        		if (value)
        			value = value+' ('+record.get('AI_LV_NM') + ')';
        		return value;
        	}
        },{
            xtype: 'checkcolumn',
            header: '이상여부',
            dataIndex: 'ABNORMAL_YN',
            flex : 0.6,
            //width: 90,
            editor: {
                xtype: 'checkbox',
                cls: 'x-grid-checkheader-editor'
            }
        },{
            //xtype: 'gridcolumn',
            header: '이상표시(Flag)',
            dataIndex: 'ABNORMAL_CD',
            flex : 1,
            align: 'center',
            editor: {
                xtype: 'combobox',
                itemId:'abnormal_cd',
                //allowBlank: false,
                displayField: 'ABNORMAL_NM',
                valueField: 'ABNORMAL_CD',
                queryMode: 'local',
            	store: {
            		fields: ['ABNORMAL_CD', 'ABNORMAL_NM'],
            	    data : [
            	    	{'ABNORMAL_CD':'-', 'ABNORMAL_NM':'-'},
            	    	{'ABNORMAL_CD':'I002', 'ABNORMAL_NM':'음의값(-)'},
            	    	{'ABNORMAL_CD':'I003', 'ABNORMAL_NM':'임계값이하'},
            	    	{'ABNORMAL_CD':'I004', 'ABNORMAL_NM':'측정범위초과'},
            	    	{'ABNORMAL_CD':'I005', 'ABNORMAL_NM':'정성확인불가'},
            	    	{'ABNORMAL_CD':'J001', 'ABNORMAL_NM':'급격한변화'},
            	    	{'ABNORMAL_CD':'J002', 'ABNORMAL_NM':'PM2.5>PM10'},
            	        {'ABNORMAL_CD':'J005', 'ABNORMAL_NM':'일평균농도차이'},
            	        {'ABNORMAL_CD':'J006', 'ABNORMAL_NM':'과거자료비교이상'},
            	        {'ABNORMAL_CD':'J009', 'ABNORMAL_NM':'장시간동일값'},
            	    	{'ABNORMAL_CD':'J010', 'ABNORMAL_NM':'오염도범위초과'}
            	    ]
            	},
            	listeners: {
            		change : function (combo, newValue, oldValue, eOpts) {
            			//cni.app.rawValue = combo.getRawValue();
            			Ext.getCmp('managementPanel').down('#data_grid').store.data.items[cni.app.rowIndex].set('ABNORMAL_CD', newValue);
            			Ext.getCmp('managementPanel').down('#data_grid').store.data.items[cni.app.rowIndex].set('ABNORMAL_NM', combo.getRawValue());
            		}
            	}
            },
            renderer: function(value, meta, record) {
                //if (cni.app.rawValue) return cni.app.rawValue;
                //else return record.get('ABNORMAL_NM');
                
                return record.get('ABNORMAL_NM');
            }
        }],
        queryMode: 'local',
        store: {
        	type: 'comm.dataStore',
        	model: 'cni.model.main.ManagementModel',
        	autoLoad: false,
        	listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				cni.app.rawValue = '';
    				var view = Ext.getCmp('managementPanel');
					if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
						Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
						return false;
					};
    				obj.getProxy().setUrl('/management/getAbnormalDatas.ax');
    				obj.proxy.extraParams = {
    					net_cd: Ext.getCmp('managementPanel').down("#net_cd").getValue(),
    					region_cd: Ext.getCmp('managementPanel').down("#region_cd").getValue(),
    					tms_cd: Ext.getCmp('managementPanel').down("#tms_cd").getValue(),
    					item_nms: Ext.getCmp('managementPanel').down("#item_nms").text,
	    				s_date: Ext.getCmp('managementPanel').down("#s_date").getValue(),
	    				e_date: Ext.getCmp('managementPanel').down("#e_date").getValue(),
	    				status_nms: Ext.getCmp('managementPanel').down("#status_nms").text,
	    				excess_vl: Ext.getCmp('managementPanel').down("#excess_vl").getValue(),
	    				suspicion_ratio: Ext.getCmp('managementPanel').down("#suspicion_ratio").getValue(),
	    				same_tm: Ext.getCmp('managementPanel').down("#same_tm").getValue()
					}
    	    	}
        	}	
        },
        listeners : {
        	cellclick : function (obj, td, cellIndex, record, tr, rowIndex, e, eOpts) {
    			cni.app.rowIndex = rowIndex;
        	}
        }
    }],
    
    bbar:['->',{
    	xtype: 'button',
    	text: '저장',
    	iconCls : 'x-fa fa-save',
    	handler : function (btn) {
    		cni.app.rawValue = '';
    		
    		var data = [];
    		var modifiedRecords = Ext.StoreManager.lookup('comm.dataStore').getModifiedRecords();
    		for(i=0;i<modifiedRecords.length;i++) {
			   data.push(modifiedRecords[i].data);
			}
			//var encodedJson = Ext.encode(data);
			//console.log(JSON.stringify(encodedJson));
			//console.log(JSON.stringify(data));
    		
    		if (modifiedRecords.length < 1) {
        		Ext.Msg.alert('알림', '등록자료가 없거나, 등록할 수 없는 자료 입니다.');
    			return true;
        	} 

        	Ext.Ajax.request({
        		url: '/management/setAbnormalDatas.ax',
        		method: 'POST',
        		//params: btn.up('managementPanel').getForm().getValues(),
        		params:{
        			region_cd: Ext.getCmp('managementPanel').down('#region_cd').getValue(),
        			tms_cd: Ext.getCmp('managementPanel').down('#tms_cd').getValue(),
        			excess_vl: Ext.getCmp('managementPanel').down('#excess_vl').getValue(),
        			editRecords: JSON.stringify(data)
        		},

        		success : function(res){
        			var result = Ext.decode(res.responseText);
        			
        			if(result['code'] == 200) {
        				Ext.toast('등록(수정)되었습니다.');
        				Ext.StoreManager.lookup('comm.dataStore').reload();
        			} else if(result['code'] == 404) {
        				Ext.toast(result['msg']);
        				Ext.StoreManager.lookup('comm.dataStore').reload();
        			} else {
        				Ext.Msg.alert('알림',result['msg']);
        				return;
        			}
        		},        		
        		callback: function(options, success, response) {
        			// do stuff
        		}
        	});
        }
    }],
    
    listeners : {
    	beforerender : function (obj, eOpts) {
    		cni.app.rowIndex = '';
    	},
    	render : function (obj, eOpts) {
    	},
    	afterrender : function (obj, eOpts) {
    		Ext.getCmp('managementPanel').down('#net_cd').setValue(cni.app.netCD);
    		//Ext.getCmp('managementPanel').down('#region_cd').setValue(cni.app.regionCD);
    		Ext.getCmp('managementPanel').down("#s_date").setValue(new Date());
    		Ext.getCmp('managementPanel').down("#e_date").setValue(new Date());
    	}, 
    	boxready : function(obj) {
    		//obj.down('#data_grid').getStore().load();
		},
		destroy: function(obj, eOpts) {
    	}
	}
});
