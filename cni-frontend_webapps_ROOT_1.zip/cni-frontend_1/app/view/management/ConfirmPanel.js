Ext.define('cni.view.management.ConfirmPanel', {
	extend: 'Ext.form.Panel',
    xtype: 'confirmPanel',

    requires: [
        'cni.controller.management.ConfirmController'
    ],
    
    controller: 'management.confirmController',
    
    id: 'confirmPanel',
    reference: 'confirmPanel',
    
    title: '측정자료마감',
    iconCls : 'x-fa fa-inbox',
    border: true,
    layout: 'fit',
    
    tbar: [{
		xtype: 'numberfield',
        fieldLabel: '조회기간',
        name: 's_year',
        itemId: 's_year',
        labelWidth: 60,
        width: 160,
        value: 2019,
        minValue: 2019,
        maxValue: 2099,
        listeners : {
        	afterrender: function(me, eOpts) {
        		//me.setValue(cni.app.monitorCol);
        	} 
        }
    },{
		xtype: 'numberfield',
        name: 's_month',
        itemId: 's_month',
        width: 70,
        value: 6,
        minValue: 1,
        maxValue: 12,
        listeners : {
        	afterrender: function(me, eOpts) {
        		//me.setValue(cni.app.monitorCol);
        	} 
        }
    },{
    	xtype: 'label',
    	text: ' ~ '
    },{
		xtype: 'numberfield',
        name: 'e_year',
        itemId: 'e_year',
        width: 100,
        value: 2019,
        minValue: 2019,
        maxValue: 2099,
        listeners : {
        	afterrender: function(me, eOpts) {
        		//me.setValue(cni.app.monitorCol);
        	} 
        }
    },{
		xtype: 'numberfield',
        name: 'e_month',
        itemId: 'e_month',
        width: 70,
        value: 6,
        minValue: 1,
        maxValue: 12,
        listeners : {
        	afterrender: function(me, eOpts) {
        		//me.setValue(cni.app.monitorCol);
        	} 
        }
    }
    ,'->', {
    	xtype: 'button',
    	itemId: 'search_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : 'fnDataSearch'
    }],
    
    items:[{
    	xtype: 'grid',
    	itemId: 'edit_grid',
    	columnLines: true,
        height: '100%',
        loadMask: true,
    	columns : [{
        	text : '<b>마감월</b>',
        	flex : 1,
        	dataIndex : 'YYYYMM',
        	//style: 'font-size: 16px',
        	align: 'center'
        },{
        	text : '<b>마감측정소</b>',
        	flex : 1,
        	dataIndex : 'TMS_CNT',
        	align: 'center'
        },{
        	text : '<b>작업자</b>',
        	flex : 1,
        	dataIndex : 'REG_ID',
        	align: 'center'
        },{
        	text : '<b>작업일시</b>',
        	flex : 1,
        	dataIndex : 'REG_DT',
        	align: 'center'
        }],
        //queryMode: 'local',
        store: {
        	//type: 'management.confirmStore',
        	type : 'comm.regionStore',
    		autoLoad: true,
        	listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				var view = Ext.getCmp('confirmPanel');
    				obj.getProxy().setUrl('/management/getConfirmList.ax');
    				obj.proxy.extraParams = {
    					//tms_cd: view.down("#tms_cd").getValue(),
	    				s_date: view.down("#s_year").getValue() +''+ (view.down("#s_month").getValue() < 10 ? '0'+view.down("#s_month").getValue() : view.down("#s_month").getValue()),
	    				e_date: view.down("#e_year").getValue() +''+ (view.down("#e_month").getValue() < 10 ? '0'+view.down("#e_month").getValue() : view.down("#e_month").getValue())
					}
    	    	}
        	}	
        },
        
        listeners : {
        	rowdblclick : function (obj, record, element, rowIndex, e, eOpts) {
        		var msg = '마감 하시겠습니까?<br />*다소 시간이 걸릴수 있습니다.';
        		if (record.get('REG_DT')) {
        			msg = '다시 마감 하시겠습니까?<br />*다소 시간이 걸릴수 있습니다.';
        		}
        		
        		Ext.Msg.confirm('알림',msg, function(btn) {
        			if (btn=='yes') {

        				Ext.MessageBox.wait('Loading ...','Wait',{interval:500, text:'Please wait...'});
        				
        				Ext.Ajax.request({
        		    		url: '/management/setConfirmDate.ax',
        		    		actionMethods : {create: "POST", read: "POST", update: "POST", destroy: "POST"},
        		    		timeout: 300000,
        		    		params:{
        		    			msr_mm: record.get('YYYYMM')
        		    			//tms_cd: record.get('tms_cd')
        		    		},
        		    		success : function(res){
        		    			Ext.MessageBox.hide();
        		    			var result = Ext.decode(res.responseText);
        		    			if(result['code'] == 200) {
        		    				Ext.toast('마감 되었습니다.');
        		    				Ext.StoreManager.lookup('comm.regionStore').reload();
        		    			} else {
        		    				Ext.Msg.alert("알림",result['msg']);
        		    				return;
        		    			}
        		    		},        		
        		    		callback: function(options, success, response) {
        		    		},
        		    		failure : function(){
        		    			Ext.MessageBox.hide();
        		    			Ext.Msg.alert("알림",'마감 완료 대기시간이 지났습니다.<br />*시간이 좀더 필요 합니다. 잠시후 마감내역을 확인하시기 바랍니다.')
        		    		}
        		    	});
        			}
        		});
        	}
    	}
    
    }],

    listeners : {
    	beforerender : function (obj, eOpts) {
    		//Ext.StoreManager.lookup('comm.useTmsStore').load();
    	},
    	render : function (obj, eOpts) {
    	},
    	afterrender : function (obj, eOpts) {
    		Ext.getCmp('confirmPanel').down("#s_year").setValue(Ext.Date.format(Ext.Date.add(new Date(), Ext.Date.MONTH, -5),'Y'));
    		Ext.getCmp('confirmPanel').down("#s_month").setValue(Ext.Date.format(Ext.Date.add(new Date(), Ext.Date.MONTH, -5),'m'));
    		Ext.getCmp('confirmPanel').down("#e_year").setValue(Ext.Date.format(new Date(),'Y'));
    		Ext.getCmp('confirmPanel').down("#e_month").setValue(Ext.Date.format(new Date(),'m'));
    	}, 
    	boxready : function(obj) {
		},
		destroy: function(obj, eOpts) {
    	}
	}
});
