Ext.define('cni.view.system.ReportPanel', {
	extend: 'Ext.grid.Panel',
    xtype: 'reportPanel',
    
    //controller: 'system.smsController',
    
    id: 'reportPanel',
    reference: 'reportPanel',
   
    title: '대기환경월·연간보고서·확정자료',
    iconCls : 'x-fa fa-book',	
    
    columnLines: true,
    border: true,
    //height: '100%',
    tbar: [{
    	iconCls : 'x-fa fa-plus',
    	tooltip : '보고서등록',
    	text: '등록',
        handler : function(me) {
        	Ext.widget('reportWindow', {
				myParentStore: Ext.getCmp('reportPanel').getStore()
			});
    		return true;
        }
    },{
    	xtype: 'combo',
    	//fieldLabel: '게시판구분',
    	itemId:'rpt_type',
    	name: 'rpt_type',
    	displayField: 'rpt_type_nm',
        valueField: 'rpt_type',
        value: 'A',
        width: 100,
        queryMode: 'local',
    	store: {
    		fields: ['rpt_type', 'rpt_type_nm'],
    	    data : [
    	    	{'rpt_type':'A', 'rpt_type_nm':'전체'},
    	        {'rpt_type':'Y', 'rpt_type_nm':'연간보고서'},
    	        {'rpt_type':'Q', 'rpt_type_nm':'분기보고서'},
    	        {'rpt_type':'M', 'rpt_type_nm':'월간간행물'},
    	        {'rpt_type':'F', 'rpt_type_nm':'연간확정자료'}
    	    ]
    	}
    },'->',{
    	xtype: 'combo',
    	id: 's_key',
    	itemId: 's_key',
    	displayField:'key_name',
    	valueField:'key_code',
    	value: 'org_file_nm',
    	width: 100,
    	store: {
    		fields: ['key_name', 'key_code'],
    		data: [{
    			key_name: '보고서명',
    			key_code: 'org_file_nm' 
    		},{
    			key_name: '등록자ID',
    			key_code: 'reg_id' 
    		}]
    	}
    },{
    	xtype: 'textfield',
    	id: 's_txt',
    	itemId: 's_txt',
    	emptyText: '검색어를 입력하세요'
    },{
    	xtype: 'button',
    	id: 's_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : function(btn) {
    		var vGrid = btn.up('reportPanel');
    		vGrid.getStore().proxy.extraParams = {
    			rpt_type: vGrid.down("#rpt_type").getValue(), 
    			search_key: vGrid.down("#s_key").getValue(), 
    			search_txt: vGrid.down("#s_txt").getValue(),
    		};
    		vGrid.getStore().reload();
    	}
    }],
    
    columns : [{
    	text : '구분',
    	flex : 1,
    	dataIndex : 'RPT_TYPE_NM',
    	align: 'center'
    },{
    	text : '연도',
    	flex : 1,
    	dataIndex : 'YYYY_TXT',
    	align: 'center'
    },{
    	text : '월',
    	flex : 0.6,
    	dataIndex : 'MM_TXT',
    	align: 'center'
    },{
    	text : '보고서명',
    	flex : 2,
    	dataIndex : 'ORG_FILE_NM',
    	align: 'center'
    },{
    	text : '게시',
    	flex : 0.5,
    	dataIndex : 'USE_YN',
    	align: 'center'
    },{
    	text : '등록(수정)자 ID',
    	flex : 1,
    	dataIndex : 'REG_ID',
    	align: 'center'
    },{
    	text : '등록(수정)일',
    	flex : 1,
    	dataIndex : 'REG_DT',
    	align: 'center'
    }],
    
    store: {
    	type: 'comm.listStore',
    	autoLoad: false,
    	listeners : {
			beforeload: function(obj, records, successful, operation, eOpts) {
				obj.getProxy().setUrl('/management/getReportList.ax');
			},
			load: function(obj, records, successful, operation, eOpts) {
				
			}
    	}
    		
    },
    
    listeners : {
		rowdblclick : function (obj, record, element, rowIndex, e, eOpts) {
			Ext.widget('reportWindow', {
				selectedRecord: record,
				//myParentStore: obj.up('reportPanel').getStore('comm.listStore')
				myParentStore: obj.getStore()
			});
			return true;
		},
		cellclick : function (obj, td, cellIndex, record, tr, rowIndex, e, eOpts) {
			//obj.up('reportPanel').down('#selected_receive_nm').setValue(record.get('receive_nm'));
			//obj.up('reportPanel').down('#selected_receive_num').setValue(record.get('receive_num'));
		},
		afterrender : function (obj, eOpts) {

    	},
    	boxready : function(obj) {
    		obj.getStore().proxy.extraParams = {
    			rpt_type: obj.down("#rpt_type").getValue(), 	
    			search_key: obj.down("#s_key").getValue(), 
    			search_txt: obj.down("#s_txt").getValue()
    		}
    		obj.getStore().load();
    		//Ext.StoreManager.lookup('comm.listStore').load();
		},
	}
    
});