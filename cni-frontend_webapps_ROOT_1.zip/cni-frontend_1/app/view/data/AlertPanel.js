Ext.define('cni.view.data.AlertPanel', {
	extend: 'Ext.form.Panel',
    xtype: 'alertPanel',
    
    controller: 'data.dataController',
    
    id: 'alertPanel',
    reference: 'alertPanel',
    
    title: '경보이력조회',
    iconCls : 'x-fa fa-bell',
    border: true,
    layout: 'fit',
    
    tools:[{
        iconCls : 'x-fa fa-save',
        tooltip: 'PDF',
        handler : 'fnWarningPDFDown'
    },{
        //type:'gear',
    	iconCls : 'x-fa fa-table',
        tooltip: '엑셀',
        handler : 'fnWarningExcelDown'
    }],

    tbar: [{
    	xtype: 'combo',
    	itemId:'net_cd',
    	displayField: 'net_nm',
        valueField: 'net_cd',
        value: 'ALL',
        width: 110,
        queryMode: 'local',
    	store: {
    		fields: ['net_cd', 'net_nm'],
    	    data : [
    	    	{'net_cd':'ALL', 'net_nm':'망구분(전체)'},
    	    	{'net_cd':'C', 'net_nm':'마을대기'},
    	        {'net_cd':'A', 'net_nm':'국가대기'}
    	    ]
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.netCD = newValue;
    			Ext.StoreManager.lookup('comm.regionStore').load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'region_cd',
    	displayField:'REGION_NM',
    	valueField:'REGION_CD',
    	emptyText: '지역선택',
    	value: 'ALL',
    	width: 120,
    	queryMode: 'local',
    	store: {
    		type : 'comm.regionStore',
    		autoLoad: true,
    		listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/comm/getUseRegionList.ax');
    				obj.proxy.extraParams = {
    					net_cd: Ext.getCmp('alertPanel').down("#net_cd").getValue()
    				};
    	    	},
    			load: function(obj, records, successful, operation, eOpts) {
    				obj.insert(0, [{
    					REGION_CD: 'ALL',
    					REGION_NM: '전체'
			        }]);
    				Ext.getCmp('alertPanel').down('#region_cd').setValue('ALL');
    				Ext.StoreManager.lookup('comm.tmsStore').load();
        		}
        	}	
    	}, 
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			//cni.app.regionCD = newValue;
    			if (newValue != 'ALL')
    				Ext.StoreManager.lookup('comm.tmsStore').load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'tms_cd',
    	displayField:'TMS_NM',
    	valueField:'TMS_CD',
    	value: 'ALL',
    	emptyText: '전체',
    	width: 100,
    	queryMode: 'local',
    	store: {
    		type : 'comm.tmsStore',
    		autoLoad: false,
    		listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/comm/getUseTmsList.ax');
    				obj.proxy.extraParams = {
    					net_cd: Ext.getCmp('alertPanel').down('#net_cd').getValue(),
    	    			region_cd: Ext.getCmp('alertPanel').down('#region_cd').getValue()
    				};
    	    	},
    			load: function(obj, records, successful, operation, eOpts) {
    				obj.insert(0, [{
						TMS_CD: 'ALL',
			            TMS_NM: '전체'
			        }]);
    				Ext.getCmp('alertPanel').down('#tms_cd').setValue('ALL');
    			}
    		}
    	}
    },{
        text: '항목선택',
        reference: 'itemBtn',
        itemId: 'item_nm',
        destroyMenu: true,
        groupField: 'item_nm',
        menu: {
            hideOnScroll: false,
            items: [{
            	xtype: 'menucheckitem',
                text: '오존',
                checked: true,
                handler: function (item) {
                	var item_nms = Ext.getCmp('alertPanel').down('#item_nms').text;
                	if (item_nms.indexOf(':'+item.text) > -1)
                		item_nms = item_nms.replace(':'+item.text, '');
                	else 
                		item_nms += ':'+item.text;
                	Ext.getCmp('alertPanel').down('#item_nms').setText(item_nms);
                }
            },{
            	xtype: 'menucheckitem',
                text: '미세먼지',
                checked: true,
                handler: function (item) {
                	var item_nms = Ext.getCmp('alertPanel').down('#item_nms').text;
                	if (item_nms.indexOf(':'+item.text) > -1)
                		item_nms = item_nms.replace(':'+item.text, '');
                	else 
                		item_nms += ':'+item.text;
                	Ext.getCmp('alertPanel').down('#item_nms').setText(item_nms);
                }
            },{
            	xtype: 'menucheckitem',
                text: '초미세먼지',
                checked: true,
                handler: function (item) {
                	var item_nms = Ext.getCmp('alertPanel').down('#item_nms').text;
                	if (item_nms.indexOf(':'+item.text) > -1)
                		item_nms = item_nms.replace(':'+item.text, '');
                	else 
                		item_nms += ':'+item.text;
                	Ext.getCmp('alertPanel').down('#item_nms').setText(item_nms);
                }
            }]
        }
    },{
    	xtype: 'label',
    	itemId: 'item_nms',
    	text: ':오존:미세먼지:초미세먼지',
    	hidden: true
    },{
        xtype: 'datefield',
        id:'s_date',
        name: 's_date',
        itemId:'s_date',
        fieldLabel: '시작일',
        format: 'Y/m/d',
        //value: Ext.Date.add(new Date(), Ext.Date.DAY, -7),
        value: new Date(),
        labelWidth: 45,
        width: 150,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -30),
        maxValue: new Date()
    },{
        xtype: 'datefield',
        name: 'e_date',
        itemId:'e_date',
        fieldLabel: '종료일',
        format: 'Y/m/d',
        value: new Date(),
        labelWidth: 45,
        width: 150,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -29),
        maxValue: new Date()
    },'->', {
    	xtype: 'button',
    	itemId: 'search_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : 'fnWarningSearch' 
    }],
    
    items:[{
    	xtype: 'grid',
    	itemId: 'data_grid',
    	columnLines: true,
        height: '100%',
        loadMask: true,
    	columns : [{
        	text : '<b>지역명</b>',
        	flex : 1,
        	dataIndex : 'REGION_NM',
        	//style: 'font-size: 16px',
        	align: 'center'
        },{
        	text : '<b>측정소</b>',
        	flex : 1,
        	dataIndex : 'TMS_NM',
        	align: 'center'
        },{
        	text : '<b>경보항목</b>',
        	flex : 1,
        	dataIndex : 'ITEM_NM',
        	align: 'center',
        	renderer: function(value, meta, record) {
        		if (value)
        			value = value + '('+record.get('ITEM_CD')+')';
        		return value;
        	}
        },{
        	text : '<b>측정값</b>',
        	flex : 1,
        	dataIndex : 'MSR_VL',
        	align: 'center',
        	renderer: function(value, meta, record) {
        		if (value)
        			value = value + record.get('ITEM_UNIT');
        		return value;
        	}
        },{
        	text : '<b>경보명</b>',
        	flex : 1,
        	dataIndex : 'WARNING_NM',
        	align: 'center',
        	renderer: function(value, meta, record) {
        		if (record.get('WARNING_CD') == 'A') {   
                	meta.css = 'level-A';
                } else if (record.get('WARNING_CD') == 'B') {
                	meta.css = 'level-B';
                } else if (record.get('WARNING_CD') == 'C') {
                	meta.css = 'level-C';
                } else if (record.get('WARNING_CD') == 'D') {
                	meta.css = 'level-D';
                } else if (record.get('WARNING_CD') == 'E') {
                	meta.css = 'level-E';
                } else {
                	
                }
                return value;
            }
        },{
        	text : '<b>경보일시</b>',
        	flex : 1,
        	dataIndex : 'WARNING_DT',
        	align: 'center'
        },{
        	text : '<b>해제명</b>',
        	flex : 1,
        	dataIndex : 'RESET_NM',
        	align: 'center',
        	renderer: function(value, meta, record) {
        		if (record.get('RESET_CD') == 'A') {
                	meta.css = 'level-A';
                } else if (record.get('RESET_CD') == 'B') {
                	meta.css = 'level-B';
                } else if (record.get('RESET_CD') == 'C') {
                	meta.css = 'level-C';
                } else if (record.get('RESET_CD') == 'D') {
                	meta.css = 'level-D';
                } else if (record.get('RESET_CD') == 'E') {
                	meta.css = 'level-E';
                } else {
                	
                }
                return value;
            }
        },{
        	text : '<b>해제일시</b>',
        	flex : 1,
        	dataIndex : 'RESET_DT',
        	align: 'center'
        }],
        //queryMode: 'local',
        store: {
        	type: 'comm.dataStore',
        	autoLoad: false,
        	listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {

    				var view = Ext.getCmp('alertPanel');

					if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
						Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
						return false;
					};

    				obj.getProxy().setUrl('/data/getWarningList.ax');
    				obj.proxy.extraParams = {
    					net_cd: Ext.getCmp('alertPanel').down("#net_cd").getValue(),
    					region_cd: Ext.getCmp('alertPanel').down("#region_cd").getValue(),
    					tms_cd: Ext.getCmp('alertPanel').down("#tms_cd").getValue(),
    					item_nms: Ext.getCmp('alertPanel').down("#item_nms").text,
	    				s_date: Ext.getCmp('alertPanel').down("#s_date").getValue(),
	    				e_date: Ext.getCmp('alertPanel').down("#e_date").getValue()
					}
    	    	},
    	    	load: function(obj, records, successful, operation, eOpts) {
    	    	}
        	}	
        }
    
    }],
    
    listeners : {
    	beforerender : function (obj, eOpts) {
    	},
    	render : function (obj, eOpts) {
    	},
    	afterrender : function (obj, eOpts) {
    		Ext.getCmp('alertPanel').down('#net_cd').setValue('ALL');
    		//Ext.getCmp('alertPanel').down('#region_cd').setValue(cni.app.regionCD);
    		Ext.getCmp('alertPanel').down("#s_date").setValue(new Date());
    		Ext.getCmp('alertPanel').down("#e_date").setValue(new Date());
    	}, 
    	boxready : function(obj) {
		},
		destroy: function(obj, eOpts) {
    	}
	}
});
