Ext.define('cni.view.data.GraphPanel', {
	extend: 'Ext.Panel',
    xtype: 'graphPanel',
    id: 'graphPanel',
    reference: 'graphPanel',
    requires: 'Ext.chart.theme.Category2',
    controller: 'data.dataController',
    
    iconCls : 'x-fa fa-share-alt',
    title: '그래프조회',
    border: true,
    layout: 'fit',
    
    tools:[{
        //type:'gear',
    	iconCls : 'x-fa fa-save',
        tooltip: '그래프다운로드',
        handler : 'onDownload'
    },{
    	iconCls : 'x-fa fa-laptop',
        tooltip: '그래프보기',
        handler : 'onPreview'
    }],
    
    tbar: [{
    	xtype: 'combo',
    	itemId:'net_cd',
    	displayField: 'net_nm',
        valueField: 'net_cd',
        value: 'ALL',
        width: 110,
        queryMode: 'local',
    	store: {
    		fields: ['net_cd', 'net_nm'],
    	    data : [
    	    	{'net_cd':'ALL', 'net_nm':'망구분(전체)'},
    	    	{'net_cd':'C', 'net_nm':'마을대기'},
    	        {'net_cd':'A', 'net_nm':'국가대기'}
    	    ]
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.netCD = newValue;
    			Ext.StoreManager.lookup('comm.regionStore').load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'region_cd',
    	displayField:'REGION_NM',
    	valueField:'REGION_CD',
    	emptyText: '지역선택',
    	width: 120,
    	queryMode: 'local',
    	store: {
    		type : 'comm.regionStore',
    		autoLoad: true,
    		listeners : {
    			beforeload: function(store, records, successful, operation, eOpts) {
    				store.getProxy().setUrl('/comm/getUseRegionList.ax');
    				store.proxy.extraParams = {
    					net_cd: cni.app.netCD
    				};
    	    	},
    			load: function(store, records, successful, operation, eOpts) {
    				if (records.length > 0) {
    					Ext.getCmp('graphPanel').down('#region_cd').setValue(records[0].get('REGION_CD'));
    					cni.app.regionCD = records[0].get('REGION_CD');
    					Ext.StoreManager.lookup('comm.tmsStore').load();
    				}
    				/*var select_item = records[0].get('item_cd');
        			for (i = 0, len = records.length; i < len; ++i) {
		                if (records[i].get('item_cd') == Ext.getCmp('graphPanel').down('#select_item').text) {
		                	select_item = records[i].get('item_cd');
		                	break;
		                }
		            }
                	Ext.getCmp('graphPanel').down('#selected_item').setValue(select_item);
        			Ext.getCmp('graphPanel').down('#data_grid').getStore('comm.dataStore').load();*/
        		}
        	}	
    	}, 
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.regionCD = newValue;
    			Ext.StoreManager.lookup('comm.tmsStore').load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'tms_cd',
    	displayField:'TMS_NM',
    	valueField:'TMS_CD',
    	emptyText: '측정소선택',
    	width: 100,
    	queryMode: 'local',
    	store: {
    		type : 'comm.tmsStore',
    		autoLoad: false,
    		listeners : {
    			beforeload: function(store, records, successful, operation, eOpts) {
    				store.getProxy().setUrl('/comm/getUseTmsList.ax');
    				store.proxy.extraParams = {
    					net_cd: cni.app.netCD,
    					region_cd: cni.app.regionCD
    				};
    	    	},
    			load: function(store, records, successful, operation, eOpts) {
    				if (records.length > 0) {
    					Ext.getCmp('graphPanel').down('#tms_cd').setValue(records[0].get('TMS_CD'));
    				} else {
    					store.insert(0, [{
    						tms_cd: '--',
    			            tms_nm: '--'
    			        }]);
    					Ext.getCmp('graphPanel').down('#tms_cd').setValue('--');
    				}
    			}
    		}
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.tmsCD = newValue;
    			Ext.StoreManager.lookup('comm.itemStore').load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'item_cd',
    	displayField:'ITEM_NM',
    	valueField:'ITEM_CD',
    	emptyText: '항목선택',
    	width: 100,
    	queryMode: 'local',
    	store: {
    		type : 'comm.itemStore',
    		autoLoad: false,
    		listeners : {
    			beforeload: function(store, records, successful, operation, eOpts) {
    				store.getProxy().setUrl('/comm/getUseItemList.ax');
    				store.proxy.extraParams = {
            				tms_cd: cni.app.tmsCD
					};
    	    	},
    			load: function(store, records, successful, operation, eOpts) {
    				if (records.length > 0) {
    					Ext.getCmp('graphPanel').down('#item_cd').setValue(records[0].get('ITEM_CD'));
    				} else {
    					store.insert(0, [{
    						item_cd: '--',
    			            item_nm: '--'
    			        }]);
    					Ext.getCmp('graphPanel').down('#item_cd').setValue('--');
    				}
    			}
    		}
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			//Ext.StoreManager.lookup('comm.itemStore').load();
    			//combo.up('graphPanel').down('#item_cd').getStore('comm.tmsItemStore').reload();
    		}
    	}
    },{
        xtype: 'datefield',
        id:'s_date',
        name: 's_date',
        itemId:'s_date',
        fieldLabel: '시작일',
        format: 'Y/m/d',
        //value: Ext.Date.add(new Date(), Ext.Date.DAY, -7),
        value: new Date(),
        labelWidth: 45,
        width: 150,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -30),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        	/*if (newValue > obj.up('graphPanel').down('#e_date').getValue()) {
	        		Ext.Msg.alert('알림', '시작일이 종료일 보다 클수 없습니다.');
	        		obj.setValue(Ext.Date.add(obj.up('graphPanel').down('#e_date').getValue(), Ext.Date.DAY, -7));
	        	};
	        	if (newValue < Ext.Date.add(obj.up('graphPanel').down('#e_date').getValue(), Ext.Date.DAY, -30)) {
	        		Ext.Msg.alert('알림', '시작일이 종료일 보다 클수 없습니다.');
	        		obj.setValue(Ext.Date.add(obj.up('graphPanel').down('#e_date').getValue(), Ext.Date.DAY, -7));
	        	};*/
	        } 
        }
    },{
        xtype: 'datefield',
        name: 'e_date',
        itemId:'e_date',
        fieldLabel: '종료일',
        format: 'Y/m/d',
        value: new Date(),
        labelWidth: 45,
        width: 150,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -29),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        	//obj.up('graphPanel').down('#s_date').setValue(Ext.Date.add(obj.up('graphPanel').down('#e_date').getValue(), Ext.Date.DAY, -1) ); 
	        } 
        }
    }/*,{
    	xtype: 'combo',
    	itemId:'data_type',
    	displayField: 'data_type_nm',
        valueField: 'data_type',
        value: 'H',
        width: 110,
        queryMode: 'local',
    	store: {
    		fields: ['data_type', 'data_type_nm'],
    	    data : [
    	        {'data_type':'M', 'data_type_nm':'5분자료'},
    	        {'data_type':'H', 'data_type_nm':'시간자료'}
    	    ]
    	}
    }*/,'->', {
    	xtype: 'button',
    	itemId: 'search_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : 'fnGraphSearch'
    	/*handler : function (btn) {
    		console.log('>> btn.up("graphPanel").down("#tms_cd").getValue() = '+btn.up('graphPanel').down('#tms_cd').getValue());
    		btn.up('graphPanel').getStore('comm.dataStore').reload();
    	}*/
    }],
    
    items: [{
        xtype: 'cartesian',
        id: 'item_graph',
    	itemId: 'item_graph',
        reference: 'item_graph',
        theme: 'category2',
        width: '100%',
        height: 500,
        store: {
            type: 'comm.dataStore',
            listeners : {
    			beforeload: function(store, records, successful, operation, eOpts) {
    				store.getProxy().setUrl('/data/getGraphList.ax');
    				var view = Ext.getCmp('graphPanel');
    				store.proxy.extraParams = {
    					region_cd: view.down("#region_cd").getValue(),
        				tms_cd: view.down("#tms_cd").getValue(),
        				item_cd: view.down("#item_cd").getValue(),
        				//data_type: view.down("#data_type").getValue(),
    					s_date: view.down("#s_date").getValue(),
	    				e_date: view.down("#e_date").getValue()
					}
    	    	},
    	    	load: function(store, records, successful, operation, eOpts) {
    	    		var max_msr_vl = 0;
    	    		store.each(function (rec) {
    	    			if (max_msr_vl < rec.get('MSR_VL')+0) max_msr_vl = rec.get('MSR_VL')+0;
		            });
    	    		//console.log('max_msr_vl='+max_msr_vl);
    	    		
    	    		var item_cd = Ext.getCmp('graphPanel').down("#item_cd").getValue();
    	    		if (item_cd == 'SO2' || item_cd == 'O3b' || item_cd == 'NO2')
    	    			max_msr_vl = max_msr_vl + 0.002;
	   	    		else if (item_cd == 'PMb' || item_cd == 'PM2')
	   	    			max_msr_vl = max_msr_vl + 2;
	   	    		else 
	   	    			max_msr_vl = max_msr_vl + 0.1;
    	    		Ext.getCmp('graphPanel').down('#item_graph').getAxes()[0].setMaximum(max_msr_vl);
    	    		//Ext.getCmp('graphPanel').down('#item_graph').redraw();
    	    	}
        	}	
        },
        insetPadding: '60 40 20 40',
        innerPadding: '20 10 10 10',
        //interactions: {type: 'panzoom', zoomOnPan: true},
        //animation: {duration: 200},
        legend: {docked: 'bottom'},
        axes: [{
            type: 'numeric',
            title: '측정값',
            position: 'left',
            fields: ['MSR_VL'],
            //majorTickSteps: 10,
            //reconcileRange: true,
            grid: true,
            minimum: 0
            //maximum: 0.003
            //renderer: 'onAxisLabelRender'
        }, {
            type: 'category',
            position: 'bottom',
            fields: 'DSP_DT',
            label: {
                rotate: {
                    degrees: -45
                }
            }
        }, {
            type: 'numeric',
            title: '대기환경지수',
            position: 'right',
            fields: ['AI_VL'],
            //reconcileRange: true,
            //majorTickSteps: 10,
            minimum: 0,
            maximum: 500
            //renderer: 'onAxisLabelRender'
        }],
        series: [{
            type: 'line',
            title: '측정값',
            xField: 'DSP_DT',
            yField: 'MSR_VL',
            style: {
                lineWidth: 2,
                opacity: 0.80
            },
            marker: {
            	radius: 2,
                lineWidth: 1
                /*type: 'cross',
                fx: {
                    duration: 200
                }*/
            },
            highlightCfg: {
                scaling: 2,
                rotationRads: Math.PI / 4
            },
            tooltip: {
                trackMouse: true,
                renderer: 'onLineSeriesTooltipRender'
            }
        },{
            type: 'bar',
            title: '대기환경지수',
            xField: 'DSP_DT',
            yField: 'AI_VL',
            style: {
                opacity: 0.80
            },
            highlight: {
                fillStyle: 'rgba(204, 230, 73, 1.0)',
                strokeStyle: 'black'
            },
            tooltip: {
                trackMouse: true,
                renderer: 'onBarSeriesTooltipRender'
            }
        }]
    }],
    
    listeners : {
    	beforerender : function (obj, eOpts) {
    	},
    	render : function (obj, eOpts) {
    	},
    	afterrender : function (obj, eOpts) {
    		obj.down('#net_cd').setValue(cni.app.netCD);
    		//obj.down('#region_cd').setValue(cni.app.regionCD);
    		obj.down("#s_date").setValue(new Date());
    		obj.down("#e_date").setValue(new Date());
    	}, 
    	boxready : function(obj) {
		},
		destroy: function(obj, eOpts) {
    	}
	}
});