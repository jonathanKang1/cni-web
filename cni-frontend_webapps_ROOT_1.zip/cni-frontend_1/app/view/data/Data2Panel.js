Ext.define('cni.view.data.Data2Panel',{
	extend: 'Ext.form.Panel',
    xtype: 'data2Panel',

    /*requires: [
        'cni.controller.data.DataController'
    ],*/
    
    controller: 'data.dataController',
    
    id: 'data2Panel',
    reference: 'data2Panel',
    
    title: '측정자료조회 2',
    iconCls: 'x-fa fa-list-ol',
    border: true,
    layout: 'fit',
    
    tools:[/*{
        iconCls: 'x-fa fa-save',
        tooltip: 'PDF',
        handler: 'fnPDFDown'
    },*/{
        //type:'gear',
    	iconCls: 'x-fa fa-table',
        tooltip: '엑셀',
        handler: 'fnExcelDown2'
    }],

    viewModel: {
        stores: {
            useStateStore: {
                type: 'comm.statusStore',
                autoLoad: true,
                listeners: {
                	beforeload: function(obj, records, successful, operation, eOpts) {
                		obj.getProxy().setUrl('/comm/getUseStatusList.ax');
                	},
                    load: function(obj, records, successful, operation, eOpts) {
                    	var result = Ext.decode(operation.getResponse().responseText);
                    	if (result['code'] == 404) {
            				//Ext.widget("loginWindow");
            				return;
                    	} else if (result['code'] == 500) { 
                    		Ext.Msg.alert('알림', result['msg']);
                    	} else {
	                        var menu = Ext.getCmp('data2Panel').down('#status_nm').menu;
	                        var items = [];
	                        var selectedItems = '';
	                        for (i = 0, len = records.length; i < len; ++i) {
	                       		items.push({
	                                xtype: 'menucheckitem',
	                                text: records[i].get('STATUS_NM'),
	                                //checked: (records[i].get('code_name')=='정상' || records[i].get('code_name')=='자료없음')?true:false,
	                                checked: true,
	                                handler: 'fnSelectState'
	                            });
	                       		selectedItems += records[i].get('STATUS_NM')+':';
	                        }
	                        menu.removeAll(true);
	                        if (items.length) {
	                            menu.add(items);
	                        }
	                        Ext.getCmp('data2Panel').down('#status_nms').setText(selectedItems);
                    	}
                    }
                }
            },
            useItemStore: {
                type: 'comm.itemStore',
                //autoLoad: true,
                listeners: {
                	beforeload: function(obj, records, successful, operation, eOpts) {
                		obj.getProxy().setUrl('/comm/getUseItemList.ax');
                		obj.proxy.extraParams = {
                				tms_cd: Ext.getCmp('data2Panel').down("#tms_cd").getValue()
    					};
                	},
                    load: function(obj, records, successful, operation, eOpts) {
                    	var result = Ext.decode(operation.getResponse().responseText);
                    	if (result['code'] == 404) {
            				//Ext.widget("loginWindow");
            				return;
                    	} else if (result['code'] == 500) { 
                    		Ext.Msg.alert('알림', result['msg']);
                    	} else {
	                        var menu = Ext.getCmp('data2Panel').down('#item_nm').menu;
	                        var items = [];
	                        var selectedItems = ':전체';
	                        items.push({
                                xtype: 'menucheckitem',
                                text: '전체',
                                itemId: 'menu0',
                                checked: true,
                                listeners: {
                                	click:function (itm, e, eOpts) {
                                		var menus = Ext.getCmp('data2Panel').down('#item_nm').menu.items;
                                		var menu_nms = '';
                            			Ext.Array.each(menus, function(obj, idx, arr) {
                                			Ext.getCmp('data2Panel').down(('#menu'+idx)).setChecked(itm.checked);
                                			if (itm.checked) {
                                				menu_nms += ':'+Ext.getCmp('data2Panel').down(('#menu'+idx)).text;
                                			}
                                			Ext.getCmp('data2Panel').down('#item_nms').setText(menu_nms);
                                    	});
	                                }
                                }
                            });
	                        for (i = 0, len = records.length; i < len; ++i) {
	                       		items.push({
	                                xtype: 'menucheckitem',
	                                text: records[i].get('ITEM_NM'),
	                                itemId: 'menu'+(i+1),
	                                //checked: (records[i].get('code_name')=='정상' || records[i].get('code_name')=='자료없음')?true:false,
	                                checked: true,
	                                handler: 'fnSelectItem'
	                            });
	                       		selectedItems += ':'+records[i].get('ITEM_NM');
	                        }
	                        menu.removeAll(true);
	                        if (items.length) {
	                            menu.add(items);
	                        }
	                        Ext.getCmp('data2Panel').down('#item_nms').setText(selectedItems);
                    	}
                    }
                }
            }
        }
    },

    tbar: [{
    	xtype: 'combo',
    	itemId:'net_cd',
    	displayField: 'net_nm',
        valueField: 'net_cd',
        value: 'ALL',
        width: 110,
        queryMode: 'local',
    	store: {
    		fields: ['net_cd', 'net_nm'],
    	    data: [
    	    	{'net_cd':'ALL', 'net_nm':'망구분(전체)'},
    	    	{'net_cd':'C', 'net_nm':'마을대기'},
    	        {'net_cd':'A', 'net_nm':'국가대기'}
    	    ]
    	},
    	listeners: {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change: function (combo, newValue, oldValue, eOpts) {
    			cni.app.netCD = newValue;
    			Ext.StoreManager.lookup('comm.regionStore').load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'region_cd',
    	displayField:'REGION_NM',
    	valueField:'REGION_CD',
    	emptyText: '지역선택',
    	width: 120,
    	queryMode: 'local',
    	store: {
    		type: 'comm.regionStore',
    		autoLoad: true,
    		listeners: {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/comm/getUseRegionList.ax');
    				obj.proxy.extraParams = {
    					net_cd: Ext.getCmp('data2Panel').down("#net_cd").getValue()
    				};
    	    	},
    			load: function(obj, records, successful, operation, eOpts) {
    				if (records.length > 0) {
    					Ext.getCmp('data2Panel').down('#region_cd').setValue(records[0].get('REGION_CD'));
    					cni.app.regionCD = records[0].get('REGION_CD');
    					Ext.StoreManager.lookup('comm.tmsStore').load();
    				}
        		}
        	}	
    	}, 
    	listeners: {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change: function (combo, newValue, oldValue, eOpts) {
    			cni.app.regionCD = newValue;
    			Ext.StoreManager.lookup('comm.tmsStore').load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'tms_cd',
    	displayField:'TMS_NM',
    	valueField:'TMS_CD',
    	emptyText: '측정소선택',
    	width: 100,
    	queryMode: 'local',
    	store: {
    		type: 'comm.tmsStore',
    		autoLoad: false,
    		listeners: {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/comm/getUseTmsList.ax');
    				obj.proxy.extraParams = {
    					//line_no: Ext.getCmp('data2Panel').down("#line_no").getValue()=='0'?'':Ext.getCmp('data2Panel').down("#line_no").getValue()
    					net_cd: cni.app.netCD,
    					region_cd: cni.app.regionCD
    				};
    	    	},
    			load: function(obj, records, successful, operation, eOpts) {
    				if (records.length > 0) {
    					Ext.getCmp('data2Panel').down('#tms_cd').setValue(records[0].get('TMS_CD'));
    				} else {
    					obj.insert(0, [{
    						tms_cd: '--',
    			            tms_nm: '--'
    			        }]);
    					Ext.getCmp('data2Panel').down('#tms_cd').setValue('--');
    				}
    			}
    		}
    	},
    	listeners: {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change: function (combo, newValue, oldValue, eOpts) {
    			Ext.StoreManager.lookup('comm.itemStore').load();
    		}
    	}
    },{
        text: '항목선택',
        reference: 'itemBtn',
        itemId: 'item_nm',
        destroyMenu: true,
        groupField: 'item_nm',
        menu: {
            hideOnScroll: false,
            items: []
        }
    },{
    	xtype: 'label',
    	itemId: 'item_nms',
    	hidden: true,
    	text: ''
    },{
        xtype: 'datefield',
        id:'s_date',
        name: 's_date',
        itemId:'s_date',
        fieldLabel: '시작일',
        format: 'Y/m/d',
        //value: Ext.Date.add(new Date(), Ext.Date.DAY, -7),
        value: new Date(),
        labelWidth: 45,
        width: 150,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -30),
        maxValue: new Date(),
        listeners: {
	        change: function(obj, newValue, oldValue, eOpts) {
	        	/*if (newValue > obj.up('data2Panel').down('#e_date').getValue()) {
	        		Ext.Msg.alert('알림', '시작일이 종료일 보다 클수 없습니다.');
	        		obj.setValue(Ext.Date.add(obj.up('data2Panel').down('#e_date').getValue(), Ext.Date.DAY, -7));
	        	};
	        	if (newValue < Ext.Date.add(obj.up('data2Panel').down('#e_date').getValue(), Ext.Date.DAY, -30)) {
	        		Ext.Msg.alert('알림', '시작일이 종료일 보다 클수 없습니다.');
	        		obj.setValue(Ext.Date.add(obj.up('data2Panel').down('#e_date').getValue(), Ext.Date.DAY, -7));
	        	};*/
	        } 
        }
    },{
        xtype: 'datefield',
        name: 'e_date',
        itemId:'e_date',
        fieldLabel: '종료일',
        format: 'Y/m/d',
        value: new Date(),
        labelWidth: 45,
        width: 150,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -29),
        maxValue: new Date(),
        listeners: {
	        change: function(obj, newValue, oldValue, eOpts) {
	        	//obj.up('data2Panel').down('#s_date').setValue(Ext.Date.add(obj.up('data2Panel').down('#e_date').getValue(), Ext.Date.DAY, -1) ); 
	        } 
        }
    },{
    	xtype: 'combo',
    	itemId:'data_type',
    	displayField: 'data_type_nm',
        valueField: 'data_type',
        value: 'H',
        width: 110,
        queryMode: 'local',
    	store: {
    		fields: ['data_type', 'data_type_nm'],
    	    data: [
    	        {'data_type':'M', 'data_type_nm':'5분자료'},
    	        {'data_type':'H', 'data_type_nm':'시간자료'}
    	    ]
    	}
    },{
        text: '상태선택',
        reference: 'stateBtn',
        itemId: 'status_nm',
        destroyMenu: true,
        groupField: 'status_nm',
        menu: {
            hideOnScroll: false,
            items: []
        }
    },{
    	xtype: 'label',
    	itemId: 'status_nms',
    	hidden: true,
    	text: ''
    }
    ,'->',{
    	xtype: 'button',
    	itemId: 'search_btn',
    	text: '검색',	
    	iconCls: 'x-fa fa-search',
    	handler: 'fnDataSearch'
    }],
    
    items:[{
    	xtype: 'grid',
    	itemId: 'data_grid',
    	columnLines: true,
        height: '100%',
        loadMask: true,
    	columns: [{
        	text: '<b>측정시간</b>',
        	//flex: 1,
        	width: 140,
        	dataIndex: 'DSP_DT',
        	//style: 'font-size: 16px',
        	align: 'center'
        },{
        	text: '<b>SO2 (ppm)</b>',
        	flex: 3,
        	columns: [{
        		text: '<b>측정값</b>',
            	flex: 1,
            	dataIndex: 'SO2',
            	align: 'center',
            	renderer: function(value, meta, record) {
            		if (value) {
            			if (record.get('SO2_ST') && record.get('SO2_ST') != '0') {
            				value = value + ' (' + record.get('SO2_ST_NM') + ')';
            			} else {	
            				if (record.get('SO2_OV_YN') && record.get('SO2_OV_YN') == 'Y') {
            					value = value + ' (기준초과)';
            				} else {
	            				if (value && record.get('SO2_LV_NM') && record.get('SO2_LV_CD')) {
				            		value = value + ' (' + record.get('SO2_LV_NM') + ')';
				            		if (record.get('SO2_LV_CD') == 'A') meta.css = 'level-A';
				                    else if (record.get('SO2_LV_CD') == 'B') meta.css = 'level-B';
				                    else if (record.get('SO2_LV_CD') == 'C') meta.css = 'level-C';
				                    else if (record.get('SO2_LV_CD') == 'D') meta.css = 'level-D';
				    			}
            				}
            			}
            			//meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls" data-qwidth=200';
            			meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
            		}
            		return value;
            	}
            },{
            	text: '<b>8h / 24h평균</b>',
            	flex: 1,
            	dataIndex: 'SO2_08',
            	align: 'center',
            	renderer: function(value, meta, record) {
            		if (!value) value = '-';
            		if (record.get('SO2_24')) value = value + ' / ' + record.get('SO2_24');
            		else value = value + ' / -';
            		meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
            		return value;
            	}
            },{
            	text: '<b>지수</b>',
            	flex: 1,
            	dataIndex: 'SO2_AI_VL',
            	align: 'center',
        		renderer: function(value, meta, record) {
        			if (value && record.get('SO2_LV_NM')) {
                    	value = value + ' (' + record.get('SO2_AI_NM') + ')';
                    	if (record.get('SO2_AI_LV') == 'A') meta.css = 'level-A';
                        else if (record.get('SO2_AI_LV') == 'B') meta.css = 'level-B';
                        else if (record.get('SO2_AI_LV') == 'C') meta.css = 'level-C';
                        else if (record.get('SO2_AI_LV') == 'D') meta.css = 'level-D';
                    }
        			meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
                    return value;
                }
            }]
        },{
        	text: '<b>CO (ppm)</b>',
        	flex: 3,
        	columns: [{
        		text: '<b>측정값</b>',
            	flex: 1,
        		dataIndex: 'COB',
            	align: 'center',
            	renderer: function(value, meta, record) {
            		if (value) {
            			if (record.get('COB_ST') && record.get('COB_ST') != '0') {
            				value = value + ' (' + record.get('COB_ST_NM') + ')';
            			} else {	
            				if (record.get('COB_OV_YN') && record.get('COB_OV_YN') == 'Y') {
            					value = value + ' (기준초과)';
            				} else {
	            				if (value && record.get('COB_LV_NM') && record.get('COB_LV_CD')) {
				            		value = value + ' (' + record.get('COB_LV_NM') + ')';
				            		if (record.get('COB_LV_CD') == 'A') meta.css = 'level-A';
				                    else if (record.get('COB_LV_CD') == 'B') meta.css = 'level-B';
				                    else if (record.get('COB_LV_CD') == 'C') meta.css = 'level-C';
				                    else if (record.get('COB_LV_CD') == 'D') meta.css = 'level-D';
				    			}
            				}
            			}
            		}
            		meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
            		return value;
            	}
            },{
            	text: '<b>8h / 24h평균</b>',
            	flex: 1,
            	dataIndex: 'COB_08',
            	align: 'center',
            	renderer: function(value, meta, record) {
            		if (!value) value = '-';
            		if (record.get('COB_24')) value = value + ' / ' + record.get('COB_24');
            		else value = value + ' / -';
            		return value;
            	}
            },{
            	text: '<b>지수</b>',
            	flex: 1,
            	dataIndex: 'COB_AI_VL',
            	align: 'center',
        		renderer: function(value, meta, record) {
        			if (value && record.get('COB_LV_NM')) {
                    	value = value + ' (' + record.get('COB_AI_NM') + ')';
                    	if (record.get('COB_AI_LV') == 'A') meta.css = 'level-A';
                        else if (record.get('COB_AI_LV') == 'B') meta.css = 'level-B';
                        else if (record.get('COB_AI_LV') == 'C') meta.css = 'level-C';
                        else if (record.get('COB_AI_LV') == 'D') meta.css = 'level-D';
                    }
        			meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
                    return value;
                }
            }]
        },{
        	text: '<b>O3 (ppm)</b>',
        	flex: 3,
        	columns: [{
        		text: '<b>측정값</b>',
            	flex: 1,
            	dataIndex: 'O3B',
            	align: 'center',
            	renderer: function(value, meta, record) {
            		if (value) {
            			if (record.get('O3B_ST') && record.get('O3B_ST') != '0') {
            				value = value + ' (' + record.get('O3B_ST_NM') + ')';
            			} else {	
            				if (record.get('O3B_OV_YN') && record.get('O3B_OV_YN') == 'Y') {
            					value = value + ' (기준초과)';
            				} else {
	            				if (value && record.get('O3B_LV_NM') && record.get('O3B_LV_CD')) {
				            		value = value + ' (' + record.get('O3B_LV_NM') + ')';
				            		if (record.get('O3B_LV_CD') == 'A') meta.css = 'level-A';
				                    else if (record.get('O3B_LV_CD') == 'B') meta.css = 'level-B';
				                    else if (record.get('O3B_LV_CD') == 'C') meta.css = 'level-C';
				                    else if (record.get('O3B_LV_CD') == 'D') meta.css = 'level-D';
				    			}
            				}
            			}
            		}
            		meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
            		return value;
            	}
            },{
            	text: '<b>8h / 24h평균</b>',
            	flex: 1,
            	dataIndex: 'O3B_08',
            	align: 'center',
            	renderer: function(value, meta, record) {
            		if (!value) value = '-';
            		if (record.get('O3B_24')) value = value + ' / ' + record.get('O3B_24');
            		else value = value + ' / -';
            		meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
            		return value;
            	}
            },{
            	text: '<b>지수</b>',
            	flex: 1,
            	dataIndex: 'O3B_AI_VL',
            	align: 'center',
        		renderer: function(value, meta, record) {
        			if (value && record.get('O3B_LV_NM')) {
                    	value = value + ' (' + record.get('O3B_AI_NM') + ')';
                    	if (record.get('O3B_AI_LV') == 'A') meta.css = 'level-A';
                        else if (record.get('O3B_AI_LV') == 'B') meta.css = 'level-B';
                        else if (record.get('O3B_AI_LV') == 'C') meta.css = 'level-C';
                        else if (record.get('O3B_AI_LV') == 'D') meta.css = 'level-D';
                    }
        			meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
                    return value;
                }
            }]
        },{
        	text: '<b>PM10 (㎍/㎥)</b>',
        	flex: 3,
        	columns: [{
        		text: '<b>측정값</b>',
            	flex: 1,
            	dataIndex: 'PMB',
            	align: 'center',
            	renderer: function(value, meta, record) {
            		if (value) {
            			if (record.get('PMB_ST') && record.get('PMB_ST') != '0') {
            				value = value + ' (' + record.get('PMB_ST_NM') + ')';
            			} else {	
            				if (record.get('PMB_OV_YN') && record.get('PMB_OV_YN') == 'Y') {
            					value = value + ' (기준초과)';
            				} else {
	            				if (value && record.get('PMB_LV_NM') && record.get('PMB_LV_CD')) {
				            		value = value + ' (' + record.get('PMB_LV_NM') + ')';
				            		if (record.get('PMB_LV_CD') == 'A') meta.css = 'level-A';
				                    else if (record.get('PMB_LV_CD') == 'B') meta.css = 'level-B';
				                    else if (record.get('PMB_LV_CD') == 'C') meta.css = 'level-C';
				                    else if (record.get('PMB_LV_CD') == 'D') meta.css = 'level-D';
				    			}
            				}
            			}
            		}
            		meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
            		return value;
            	}
            },{
            	text: '<b>8h / 24h평균</b>',
            	flex: 1,
            	dataIndex: 'PMB_08',
            	align: 'center',
            	renderer: function(value, meta, record) {
            		if (!value) value = '-';
            		if (record.get('PMB_24')) value = value + ' / ' + record.get('PMB_24');
            		else value = value + ' / -';
            		meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
            		return value;
            	}
            },{
            	text: '<b>지수</b>',
            	flex: 1,
            	dataIndex: 'PMB_AI_VL',
            	align: 'center',
        		renderer: function(value, meta, record) {
        			if (value && record.get('PMB_LV_NM')) {
                    	value = value + ' (' + record.get('PMB_AI_NM') + ')';
                    	if (record.get('PMB_AI_LV') == 'A') meta.css = 'level-A';
                        else if (record.get('PMB_AI_LV') == 'B') meta.css = 'level-B';
                        else if (record.get('PMB_AI_LV') == 'C') meta.css = 'level-C';
                        else if (record.get('PMB_AI_LV') == 'D') meta.css = 'level-D';
                    }
        			meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
                    return value;
                }
            }]
        },{
        	text: '<b>PM2.5 (㎍/㎥)</b>',
        	flex: 3,
        	columns: [{
        		text: '<b>측정값</b>',
            	flex: 1,
            	dataIndex: 'PM2',
            	align: 'center',
            	renderer: function(value, meta, record) {
            		if (value) {
            			if (record.get('PM2_ST') && record.get('PM2_ST') != '0') {
            				value = value + ' (' + record.get('PM2_ST_NM') + ')';
            			} else {	
            				if (record.get('PM2_OV_YN') && record.get('PM2_OV_YN') == 'Y') {
            					value = value + ' (기준초과)';
            				} else {
	            				if (value && record.get('PM2_LV_NM') && record.get('PM2_LV_CD')) {
				            		value = value + ' (' + record.get('PM2_LV_NM') + ')';
				            		if (record.get('PM2_LV_CD') == 'A') meta.css = 'level-A';
				                    else if (record.get('PM2_LV_CD') == 'B') meta.css = 'level-B';
				                    else if (record.get('PM2_LV_CD') == 'C') meta.css = 'level-C';
				                    else if (record.get('PM2_LV_CD') == 'D') meta.css = 'level-D';
				    			}
            				}
            			}
            			meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
            		}
            		return value;
            	}
            },{
            	text: '<b>8h / 24h평균</b>',
            	flex: 1,
            	dataIndex: 'PM2_08',
            	align: 'center',
            	renderer: function(value, meta, record) {
            		if (!value) value = '-';
            		if (record.get('PM2_24')) value = value + ' / ' + record.get('PM2_24');
            		else value = value + ' / -';
            		meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
            		return value;
            	}
            },{
            	text: '<b>지수</b>',
            	flex: 1,
            	dataIndex: 'PM2_AI_VL',
            	align: 'center',
        		renderer: function(value, meta, record) {
        			if (value && record.get('PM2_LV_NM')) {
                    	value = value + ' (' + record.get('PM2_AI_NM') + ')';
                    	if (record.get('PM2_AI_LV') == 'A') meta.css = 'level-A';
                        else if (record.get('PM2_AI_LV') == 'B') meta.css = 'level-B';
                        else if (record.get('PM2_AI_LV') == 'C') meta.css = 'level-C';
                        else if (record.get('PM2_AI_LV') == 'D') meta.css = 'level-D';
                    }
        			meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
                    return value;
                }
            }]
        },{
        	text: '<b>NO2 (ppm)</b>',
        	flex: 3,
        	columns: [{
        		text: '<b>측정값</b>',
            	flex: 1,
            	dataIndex: 'NO2',
            	align: 'center',
            	renderer: function(value, meta, record) {
            		if (value) {
            			if (record.get('NO2_ST') && record.get('NO2_ST') != '0') {
            				value = value + ' (' + record.get('NO2_ST_NM') + ')';
            			} else {	
            				if (record.get('NO2_OV_YN') && record.get('NO2_OV_YN') == 'Y') {
            					value = value + ' (기준초과)';
            				} else {
	            				if (value && record.get('NO2_LV_NM') && record.get('NO2_LV_CD')) {
				            		value = value + ' (' + record.get('NO2_LV_NM') + ')';
				            		if (record.get('NO2_LV_CD') == 'A') meta.css = 'level-A';
				                    else if (record.get('NO2_LV_CD') == 'B') meta.css = 'level-B';
				                    else if (record.get('NO2_LV_CD') == 'C') meta.css = 'level-C';
				                    else if (record.get('NO2_LV_CD') == 'D') meta.css = 'level-D';
				    			}
            				}
            			}
            			meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
            		}
            		return value;
            	}
            },{
            	text: '<b>8h / 24h평균</b>',
            	flex: 1,
            	dataIndex: 'NO2_08',
            	align: 'center',
            	renderer: function(value, meta, record) {
            		if (!value) value = '-';
            		if (record.get('NO2_24')) value = value + ' / ' + record.get('NO2_24');
            		else value = value + ' / -';
            		meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
            		return value;
            	}
            },{
            	text: '<b>지수</b>',
            	flex: 1,
            	dataIndex: 'NO2_AI_VL',
            	align: 'center',
        		renderer: function(value, meta, record) {
        			if (value && record.get('NO2_LV_NM')) {
                    	value = value + ' (' + record.get('NO2_AI_NM') + ')';
                    	if (record.get('NO2_AI_LV') == 'A') meta.css = 'level-A';
                        else if (record.get('NO2_AI_LV') == 'B') meta.css = 'level-B';
                        else if (record.get('NO2_AI_LV') == 'C') meta.css = 'level-C';
                        else if (record.get('NO2_AI_LV') == 'D') meta.css = 'level-D';
                    }
        			meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
                    return value;
                }
            }]
        },{
        	text: '<b>풍향(º)<br/>/ 풍속(㎧)</b>',
        	flex: 1,
        	dataIndex: 'DIR',
        	align: 'center',
        	renderer: function(value, meta, record) {
                if (value && record.get('DIR_NM')) value = value + ' (' + record.get('DIR_NM') + ')';
                else value = '-';
                if (record.get('SPD')) value = value + ' / ' + record.get('SPD');
                else value = value + ' / -';
                meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
                return value;
            }
        },{
        	text: '<b>온도(℃)<br/>/ 습도(%)</b>',
        	flex: 1,
        	dataIndex: 'TMP',
        	align: 'center',
        	renderer: function(value, meta, record) {
                if (!value) value = '-';
                if (record.get('HUM')) value = value + ' / ' + record.get('HUM');
                else value = value + ' / -';
                meta.tdAttr = 'data-qtip= "' + value + '" data-qclass="tipCls"';
                return value;
            }
        }],
        //queryMode: 'local',
        store: {
        	type: 'comm.dataStore',
        	autoLoad: false,
        	listeners: {
    			beforeload: function(obj, records, successful, operation, eOpts) {

    				var view = Ext.getCmp('data2Panel');
    				if (view.down("#data_type").getValue() == 'H') {
    					if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
    						Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
    						return false;
    					};
    				} else {
    					if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -1)) {
    						Ext.Msg.alert('알림', '5분자료 조회 기간은 1개월을 초과할 수 없습니다.');
    						return false;
    					};
    				}
    				obj.getProxy().setUrl('/data/getData2List.ax');
    				obj.proxy.extraParams = {
   						net_cd: Ext.getCmp('data2Panel').down('#net_cd').getValue(),
   						region_cd: Ext.getCmp('data2Panel').down("#region_cd").getValue(),
    					tms_cd: Ext.getCmp('data2Panel').down("#tms_cd").getValue(),
    					item_nms: Ext.getCmp('data2Panel').down("#item_nms").text,
	    				s_date: Ext.getCmp('data2Panel').down("#s_date").getValue(),
	    				e_date: Ext.getCmp('data2Panel').down("#e_date").getValue(),
	    				data_type: Ext.getCmp('data2Panel').down("#data_type").getValue(),
	    				status_nms: Ext.getCmp('data2Panel').down("#status_nms").text
					}
    	    	},
    	    	load: function(obj, records, successful, operation, eOpts) {
    	    	}
        	}	
        }
    
    }],
    
    listeners: {
    	beforerender: function (obj, eOpts) {
    	},
    	render: function (obj, eOpts) {
    	},
    	afterrender: function (obj, eOpts) {
    		Ext.getCmp('data2Panel').down('#net_cd').setValue(cni.app.netCD);
    		//Ext.getCmp('data2Panel').down('#region_cd').setValue(cni.app.regionCD);
    		Ext.getCmp('data2Panel').down("#s_date").setValue(new Date());
    		Ext.getCmp('data2Panel').down("#e_date").setValue(new Date());
    	}, 
    	boxready: function(obj) {
		},
		destroy: function(obj, eOpts) {
    	}
	}
});
