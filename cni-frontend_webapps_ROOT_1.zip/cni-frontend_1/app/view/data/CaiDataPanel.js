Ext.define('cni.view.data.CaiDataPanel', {
	//extend: 'Ext.form.Panel',
	extend: 'Ext.grid.Panel',
    xtype: 'caiDataPanel',

    /*requires: [
        'cni.controller.data.DataController'
    ],*/
    
    controller: 'data.dataController',
    
    id: 'caiDataPanel',
    reference: 'caiDataPanel',
    
    title: '통합대기환경지수',
    iconCls : 'x-fa fa-list-ul',
    border: true,
    layout: 'fit',
    
    viewConfig:{markDirty:false},
    columnLines: true,
    height: '100%',
    loadMask: true,
    
    tools:[{
        //type:'gear',
    	iconCls : 'x-fa fa-table',
        tooltip: '엑셀',
        handler : function () {
        	document.frm.action = '/data/getCaiDataExcel.do';
        	document.frm.net_cd.value = Ext.getCmp('caiDataPanel').down('#net_cd').getValue();
        	document.frm.region_cd.value = Ext.getCmp('caiDataPanel').down("#region_cd").getValue();
    		document.frm.s_date.value = Ext.Date.format(Ext.getCmp('caiDataPanel').down("#s_date").getValue(), 'Y-m-d');
    		document.frm.e_date.value = Ext.Date.format(Ext.getCmp('caiDataPanel').down("#e_date").getValue(), 'Y-m-d');
    		document.frm.submit();
        	
        	/*Ext.Ajax.request({
        		url : '/data/getCaiDataExcel.do',
        		method : 'POST',
        		params : {
        			net_cd: Ext.getCmp('caiDataPanel').down('#net_cd').getValue(),
					region_cd: Ext.getCmp('caiDataPanel').down("#region_cd").getValue(),
    				s_date: Ext.getCmp('caiDataPanel').down("#s_date").getValue(),
    				e_date: Ext.getCmp('caiDataPanel').down("#e_date").getValue(),
        		},
        		success : function(res){
        			
        		}
        	});*/
        }
    }],

    tbar: [{
    	xtype: 'combo',
    	itemId:'net_cd',
    	displayField: 'net_nm',
        valueField: 'net_cd',
        value: 'ALL',
        width: 110,
        queryMode: 'local',
    	store: {
    		fields: ['net_cd', 'net_nm'],
    	    data : [
    	    	{'net_cd':'ALL', 'net_nm':'망구분(전체)'},
    	    	{'net_cd':'C', 'net_nm':'마을대기'},
    	        {'net_cd':'A', 'net_nm':'국가대기'}
    	    ]
    	},
    	listeners : {
    		expand: function (field, eOpts)  {
            },
            select: function (combo, records) {
            },
            beforedeselect: function (combo, rec) {
            },
            beforeselect: function(combo, record, index) {
            },
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.netCD = newValue;
    			Ext.StoreManager.lookup('comm.regionStore').load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'region_cd',
    	displayField:'REGION_NM',
    	valueField:'REGION_CD',
    	emptyText: '지역선택',
    	width: 120,
    	queryMode: 'local',
    	store: {
    		type : 'comm.regionStore',
    		autoLoad: true,
    		listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/comm/getUseRegionList.ax');
    				obj.proxy.extraParams = {
    					net_cd: Ext.getCmp('caiDataPanel').down("#net_cd").getValue()
    				};
    	    	},
    			load: function(obj, records, successful, operation, eOpts) {
    				if (records.length > 0) {
    					Ext.getCmp('caiDataPanel').down('#region_cd').setValue(records[0].get('REGION_CD'));
    					cni.app.regionCD = records[0].get('REGION_CD');
    					Ext.StoreManager.lookup('comm.tmsStore').load();
    				}
        		}
        	}	
    	}, 
    	listeners : {
    		change : function (combo, newValue, oldValue, eOpts) {
    			cni.app.regionCD = newValue;
    			Ext.StoreManager.lookup('comm.tmsStore').load();
    		}
    	}
    },{
    	xtype: 'combobox',
    	itemId: 'tms_cd',
    	displayField:'TMS_NM',
    	valueField:'TMS_CD',
    	emptyText: '측정소선택',
    	width: 100,
    	hidden: true,
    	//queryMode: 'local',
    	store: {
    		type : 'comm.tmsStore',
    		autoLoad: false,
    		listeners : {
    			beforeload: function(obj, records, successful, operation, eOpts) {
    				obj.getProxy().setUrl('/comm/getUseTmsList.ax');
    				obj.proxy.extraParams = {
    					net_cd: cni.app.netCD,
    					region_cd: cni.app.regionCD
    				};
    	    	},
    			load: function(store, records, successful, operation, eOpts) {
    				if (records.length > 0) {
    					let grid = Ext.getCmp('caiDataPanel');
    					grid.setColumns([{
        			    	header: '측정시간',
        			    	dataIndex:'DSP_DT',width:150,sortable:false,align:'center',menuDisabled:true,
    				    	//locked: true,
        			    	renderer: function(value, meta, record) {
        			    		//meta.css = DEMS.app.DSP_FONT_CSS;
        			    		//meta.style = 'color:#87CEEB;'
        			    		return value;
        			    	}
        			    }]);
    					
    					store.each(function(record, idx) {
    						grid.headerCt.insert(idx+1, 
    							Ext.create('Ext.grid.column.Column', {
    								header:record.data.TMS_NM,align:'center',menuDisabled:true,
    								columns: [{	
    									header: '오염물질',dataIndex:'TMS_'+(idx+1)+'_ITEM',align:'center',width:80,sortable:false,menuDisabled:true
    								},{	
    									header: '값(지수)',dataIndex:'TMS_'+(idx+1)+'_VL',align:'center',width:80,sortable:false,menuDisabled:true
    								},{	
    									header: '등급',dataIndex:'TMS_'+(idx+1)+'_LV',align:'center',width:80,sortable:false,menuDisabled:true
    								}]	
    							})
    						);
    						
    					});
    					grid = null;
    					Ext.StoreManager.lookup('comm.dataStore').removeAll();
    				}
    			}
    		}
    	}
    },{
        xtype: 'datefield',
        id:'s_date',
        name: 's_date',
        itemId:'s_date',
        fieldLabel: '시작일',
        format: 'Y/m/d',
        //value: Ext.Date.add(new Date(), Ext.Date.DAY, -7),
        value: new Date(),
        labelWidth: 45,
        width: 150,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -30),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        	/*if (newValue > obj.up('caiDataPanel').down('#e_date').getValue()) {
	        		Ext.Msg.alert('알림', '시작일이 종료일 보다 클수 없습니다.');
	        		obj.setValue(Ext.Date.add(obj.up('caiDataPanel').down('#e_date').getValue(), Ext.Date.DAY, -7));
	        	};
	        	if (newValue < Ext.Date.add(obj.up('caiDataPanel').down('#e_date').getValue(), Ext.Date.DAY, -30)) {
	        		Ext.Msg.alert('알림', '시작일이 종료일 보다 클수 없습니다.');
	        		obj.setValue(Ext.Date.add(obj.up('caiDataPanel').down('#e_date').getValue(), Ext.Date.DAY, -7));
	        	};*/
	        } 
        }
    },{
        xtype: 'datefield',
        name: 'e_date',
        itemId:'e_date',
        fieldLabel: '종료일',
        format: 'Y/m/d',
        value: new Date(),
        labelWidth: 45,
        width: 150,
        //minValue: Ext.Date.add(new Date(), Ext.Date.DAY, -29),
        maxValue: new Date(),
        listeners : {
	        change: function(obj, newValue, oldValue, eOpts) {
	        	//obj.up('caiDataPanel').down('#s_date').setValue(Ext.Date.add(obj.up('caiDataPanel').down('#e_date').getValue(), Ext.Date.DAY, -1) ); 
	        } 
        }
    },'->', {
    	xtype: 'button',
    	itemId: 'search_btn',
    	text: '검색',	
    	iconCls : 'x-fa fa-search',
    	handler : function () {
    		Ext.StoreManager.lookup('comm.dataStore').load();
    	}
    }],
    
    
    store: {
    	type: 'comm.dataStore',
    	autoLoad: false,
    	listeners : {
			beforeload: function(obj, records, successful, operation, eOpts) {
				/*var view = Ext.getCmp('caiDataPanel');
				if (view.down("#data_type").getValue() == 'H') {
					if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
						Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
						return false;
					};
				} else {
					if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -1)) {
						Ext.Msg.alert('알림', '5분자료 조회 기간은 1개월을 초과할 수 없습니다.');
						return false;
					};
				}*/
				obj.getProxy().setUrl('/data/getCaiData.ax');
				obj.proxy.extraParams = {
					net_cd: Ext.getCmp('caiDataPanel').down('#net_cd').getValue(),
					region_cd: Ext.getCmp('caiDataPanel').down("#region_cd").getValue(),
    				s_date: Ext.getCmp('caiDataPanel').down("#s_date").getValue(),
    				e_date: Ext.getCmp('caiDataPanel').down("#e_date").getValue()
				}
	    	},
	    	load: function(store, records, successful, operation, eOpts) {
	    		let arr = null;
	    		store.each(function(record, idx) {
	    			for	(key in record.data) {
	    				//console.log('key='+key+', value='+record.get(key));
	    				if (key.includes('TMS_') && record.get(key) && record.get(key) != 'null') {
	    					arr = record.get(key).toString().split(':');
	    					record.set(key+'_ITEM', arr[1]);
	    					record.set(key+'_VL', arr[2]);
	    					record.set(key+'_LV', arr[3]);
	    				}
	    				arr = null;
	    			}
	    		});
	    	}
    	}	
    },

    listeners : {
    	beforerender : function (obj, eOpts) {
    	},
    	render : function (obj, eOpts) {
    	},
    	afterrender : function (obj, eOpts) {
    		Ext.getCmp('caiDataPanel').down('#net_cd').setValue(cni.app.netCD);
    		Ext.getCmp('caiDataPanel').down("#s_date").setValue(new Date());
    		Ext.getCmp('caiDataPanel').down("#e_date").setValue(new Date());
    	}, 
    	boxready : function(obj) {
		},
		destroy: function(obj, eOpts) {
    	}
	}
});
