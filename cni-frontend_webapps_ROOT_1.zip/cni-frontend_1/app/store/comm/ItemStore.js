Ext.define('cni.store.comm.ItemStore', {
	extend: 'cni.store.comm.BaseStore',
    alias: 'store.comm.itemStore',
    
    storeId: 'comm.itemStore',
    reference: 'comm.itemStore',
});
