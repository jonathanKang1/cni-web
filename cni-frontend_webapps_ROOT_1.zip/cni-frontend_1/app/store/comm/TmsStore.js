Ext.define('cni.store.comm.TmsStore', {
	extend: 'cni.store.comm.BaseStore',
    alias: 'store.comm.tmsStore',
    
    storeId: 'comm.tmsStore',
    reference: 'comm.tmsStore',

});
