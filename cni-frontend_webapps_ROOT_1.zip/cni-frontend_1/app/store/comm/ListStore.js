Ext.define('cni.store.comm.ListStore', {
	extend: 'cni.store.comm.BaseStore',
    alias: 'store.comm.listStore',
    
    storeId: 'comm.listStore',
    reference: 'comm.listStore'
});
