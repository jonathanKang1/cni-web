Ext.define('cni.store.comm.WindowStore', {
	extend: 'cni.store.comm.BaseStore',
    alias: 'store.comm.windowStore',
    storeId: 'comm.windowStore',
    reference: 'comm.windowStore'
});
