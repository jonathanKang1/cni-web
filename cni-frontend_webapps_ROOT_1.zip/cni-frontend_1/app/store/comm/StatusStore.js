Ext.define('cni.store.comm.StatusStore', {
	extend: 'cni.store.comm.BaseStore',
    alias: 'store.comm.statusStore',
    
    storeId: 'comm.statusStore',
    reference: 'comm.statusStore',

});
