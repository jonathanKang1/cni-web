Ext.define('cni.store.comm.DataStore', {
	extend: 'cni.store.comm.BaseStore',
    alias: 'store.comm.dataStore',
    storeId: 'comm.dataStore', 
    reference: 'comm.dataStore',
});
