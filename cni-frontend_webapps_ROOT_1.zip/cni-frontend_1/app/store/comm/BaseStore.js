Ext.define('cni.store.comm.BaseStore', {
    extend: 'Ext.data.Store',
    alias: 'store.comm.baseStore',
    
    //storeId: 'comm.baseStore',
    //reference: 'comm.baseStore',

    proxy: {
        type: 'ajax',
        method: 'POST',
        actionMethods : {create: "POST", read: "POST", update: "POST", destroy: "POST"},
        reader: {
            type: 'json',
            timeout: 100000,
            rootProperty: 'data' 
        }
    },
    autoLoad: false,
    autoDestroy: true,

    listeners: {
        load: function(obj, records, successful, operation, eOpts) {
        	var result = Ext.decode(operation.getResponse().responseText);
        	
        	if (result) {
	        	if (result['code'] == '404') {
					if (result['msg'])
						Ext.toast({html: result['msg']});
	        	
	        	} else if (result['code'] == '500') { 
	        		Ext.toast({html: result['msg']});
	        	
	        	} else if (result['code'] == '000') { 
	        		Ext.Msg.alert('알림', result['msg']);
	        		window.location.assign('/');
	        	
	        	}
        	}
        }
    }

});
