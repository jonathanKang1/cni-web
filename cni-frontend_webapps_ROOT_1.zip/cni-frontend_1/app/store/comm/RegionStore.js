Ext.define('cni.store.comm.RegionStore', {
	extend: 'cni.store.comm.BaseStore',
    alias: 'store.comm.regionStore',
    
    storeId: 'comm.regionStore',
    reference: 'comm.regionStore',

});
