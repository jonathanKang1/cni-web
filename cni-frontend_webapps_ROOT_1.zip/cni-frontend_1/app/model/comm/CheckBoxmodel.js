Ext.define('cni.model.comm.CheckBoxModel', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'USE_TF', type: 'bool'}
    ]
});    