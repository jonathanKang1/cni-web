Ext.define('cni.model.main.ManagementModel', {
    extend: 'Ext.data.Model',
    fields: [
        {name: 'ABNORMAL_YN', type: 'bool'}
    ]
});    