Ext.define('cni.model.system.LevelInfoModel', {
    extend: 'Ext.app.ViewModel',
    
    alias: 'viewmodel.system.levelInfoModel',
    
    fields: [
        {name: 'ITEM_CD', type: 'string'},
        {name: 'ITEM_NM', type: 'string'},
        {name: 'LEVEL_CD', type: 'string'},
        {name: 'LEVEL_NM', type: 'string'},
        {name: 'L_VL', type: 'string'},
        {name: 'h_vl', type: 'string'}
    ]
});