Ext.define('cni.model.main.MenuModel', {
    extend: 'Ext.app.ViewModel',

    alias: 'viewmodel.main.menuModel',

    /*formulas: {
        selectionText: function(get) {
            var selection = get('treelist.selection'), path;
            if (selection) {
            	path = selection.getPath('text');
                path = path.replace(/^\/Root/, '');
                return 'Selected: ' + path;
            } else {
                //return 'No node selected';
            	return '';
            }
        }
    },*/

    stores: {
        navItems: {
            type: 'tree',
            itemId: 'menu_tree',
            root: {
                expanded: true,
                children: [{
                    text: '대시보드',
                    iconCls : 'x-fa fa-desktop',
                    page: 'dashboardCAIPanel',
                    leaf: true
                },{  
                    text: '자료조회',
                    id: 'depth1_data',
                    reference: 'depth1_data',
                    iconCls : 'x-fa fa-search',
                    children: [{
                        text: '측정자료조회',
                        iconCls : 'x-fa fa-list-ul',
                        page: 'dataPanel',
                        leaf: true
                    },{
                        text: '측정자료조회2',
                        iconCls : 'x-fa fa-list-ul',
                        page: 'data2Panel',
                        leaf: true
                    },{
                        text: '통합대기환경지수',
                        iconCls : 'x-fa fa-bell',
                        page: 'caiDataPanel',
                        leaf: true
                    },{
                        text: '경보이력조회',
                        iconCls : 'x-fa fa-bell',
                        page: 'alertPanel',
                        leaf: true
                    },{
                        text: '그래프조회',
                        iconCls : 'x-fa fa-share-alt',
                        page: 'graphPanel',
                        leaf: true
                    },{
                        text: '미수신조회',
                        iconCls : 'x-fa fa-share-square',
                        page: 'receivePanel',
                        leaf: true
                    },{
                        text: '자료비교',
                        iconCls : 'x-fa fa-compress',
                        page: 'comparePanel',
                        leaf: true
                    }]
                },{
                	text: '자료관리',
                	iconCls : 'x-fa fa-folder',
                    children: [{
                    	text: '이상자료관리',
	                    iconCls: 'x-fa fa-tag',
	                    page: 'managementPanel',
	                    leaf: true
                    },{
                    	text: '측정자료마감',
	                    iconCls: 'x-fa fa-download',
	                    page: 'confirmPanel',
	                    leaf: true
                    },{
                    	text: '마감자료조회',
	                    iconCls: 'x-fa fa-clipboard',
	                    page: 'confirmDataPanel',
	                    leaf: true
                    },{
                    	text: '보고서업로드',
	                    iconCls: 'x-fa fa-book',
	                    page: 'reportPanel',
	                    leaf: true
                    }]
                },{
                    text: '분석통계',
                    iconCls: 'x-fa fa-sliders',
                    children: [{
                        text: '시간평군',
                        iconCls : 'x-fa fa-hourglass',
                        page: 'timePanel',
                        leaf: true
                    },{
                        text: '일평균',
                        iconCls : 'x-fa fa-list-ol',
                        page: 'dayPanel',
                        leaf: true
                    },{
                        text: '요일평균',
                        iconCls : 'x-fa fa-stack-overflow',
                        page: 'weekPanel',
                        leaf: true
                    },{
                        text: '월평균',
                        iconCls : 'x-fa fa-calendar',
                        page: 'monthPanel',
                        leaf: true
                    }]
                },{
                    text: '시스템관리',
                    iconCls: 'x-fa fa-cog',
                    children: [{
                        text: '측정소관리',
                        iconCls: 'x-fa fa-home',
                        page: 'tmsPanel',
                        leaf: true
                    },{
                    	text: '사용자관리',
                    	iconCls: 'x-fa fa-user',
                    	page: 'userPanel',
                    	leaf: true
                    },{
						text: '기준값관리',
						iconCls : 'x-fa fa-flag',
						page: 'levelPanel',
						leaf : true
					},{
                    	text: 'SMS관리',
                    	iconCls: 'x-fa fa-comment',
                    	page: 'smsPanel',
                    	leaf: true
                    },{
                    	text: 'API관리',
                    	iconCls : 'x-fa fa-share-square',
						page: 'apiPanel',
						leaf : true
                    },{
                    	text: '게시판관리',
                    	iconCls : 'x-fa fa-inbox',
						page: 'noticeList',
						leaf : true
                    },{
                    	text: '방문기록',
                    	iconCls : 'x-fa fa-share-square',
						page: 'visitList',
						leaf : true
                    }/*,{
                    	text: 'x-fa fa-book',
						iconCls : 'x-fa fa-book',
						leaf : true
                    },{
                    	text: 'x-fa fa-bookmark',
						iconCls : 'x-fa fa-bookmark',
						leaf : true
                    },{
                    	text: 'x-fa fa-copy',
						iconCls : 'x-fa fa-copy',
						leaf : true
                    },{
                    	text: 'x-fa fa-paste or clipboard',
						iconCls : 'x-fa fa-paste',
						leaf : true
                    },{
                    	text: 'x-fa fa-at',
						iconCls : 'x-fa fa-at',
						leaf : true
                    },{
                    	text: 'x-fa fa-mobile',
						iconCls : 'x-fa fa-mobile',
						leaf : true
                    },{
                    	text: 'x-fa fa-headphones',
						iconCls : 'x-fa fa-headphones',
						leaf : true
                    },{
                    	text: 'x-fa fa-share-square',
						iconCls : 'x-fa fa-share-square',
						leaf : true
                    },{
                    	text: 'x-fa fa-laptop',
						iconCls : 'x-fa fa-laptop',
						leaf : true
                    },{
						text: 'x-fa fa-sitemap',
						iconCls : 'x-fa fa-sitemap',
						leaf : true
					},{
						text: 'x-fa fa-map-pin',
						iconCls: 'x-fa fa-map-pin',
						leaf : true
					},{
						text: 'x-fa fa-history',
						iconCls : 'x-fa fa-history',
						leaf : true
					},{
						text: 'x-fa fa-star',
						iconCls : 'x-fa fa-star',
						leaf : true
					},{
                        text: 'x-fa fa-wrench',
                        iconCls: 'x-fa fa-wrench',
                        leaf: true
                    },{
                        text: 'x-fa fa-signal',
                        iconCls: 'x-fa fa-signal',
                        leaf: true
                    },{
                        text: 'x-fa fa-share-alt',
                        iconCls: 'x-fa fa-share-alt',
                        leaf: true
                    },{
                    	text: 'x-fa fa-trash',
                    	iconCls: 'x-fa fa-trash',
                    	leaf: true
                    },{
                    	text: 'x-fa fa-tag',
                    	iconCls: 'x-fa fa-tag',
                    	leaf: true
                    },{
                    	text: 'x-fa fa-user',
                    	iconCls: 'x-fa fa-user',
                    	leaf: true
                    },{
                    	text: 'x-fa fa-inbox',
                    	iconCls: 'x-fa fa-inbox',
                    	leaf: true
                    },{
                    	text: 'x-fa fa-envelope',
                    	iconCls: 'x-fa fa-envelope',
                    	leaf: true
                    },{
                    	text: 'x-fa fa-map-pin',
                    	iconCls: 'x-fa fa-map-pin',
                    	leaf: true
                    },{
                        text: 'x-fa fa-search',
                        iconCls : 'x-fa fa-search',
                        leaf: true
                    },{
                        text: 'x-fa fa-home',
                        iconCls: 'x-fa fa-home',
                        leaf: true
                    },{
                    	text: 'x-fa fa-database',
                    	iconCls: 'x-fa fa-database',
                    	leaf: true
                    },{
                        text: 'x-fa fa-flag',
                        iconCls: 'x-fa fa-flag',
                        leaf: true
                    },{
                        text: 'x-fa fa-sliders',
                        iconCls: 'x-fa fa-sliders',
                        leaf: true
                    },{
                        text: 'x-fa fa-desktop',
                        iconCls : 'x-fa fa-desktop',
                        leaf: true
                    },{
                        text: 'x-fa fa-music',
                        iconCls: 'x-fa fa-music',
                        leaf: true
                    },{
                        text: 'x-fa fa-film',
                        iconCls: 'x-fa fa-film',
                        leaf: true
                    }*/]
                }]
            }
        }
    }
});