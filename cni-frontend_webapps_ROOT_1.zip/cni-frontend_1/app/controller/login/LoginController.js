Ext.define('cni.controller.login.LoginController', {
	extend: 'Ext.app.ViewController',
    alias: 'controller.loginController',
    
    /**
     * Login 버튼 클릭 이벤트
     */
    fnLogin : function(btn) {
    	var view = this.getView();
    	var params = view.down("form").getForm().getValues();
    	
    	if (this.lookupReference('remember').getValue()) {
    		var expires = new Date();
        	expires.setDate(expires.getDate() + 15); //15일 더하여 setting
        	Ext.util.Cookies.set('user_id', this.lookupReference('user_id').getValue(), expires);
    	} else {
    		Ext.util.Cookies.clear('user_id'); 
    	};

    	Ext.Ajax.request({
    		url : '/system/getLoginInfo.ax',
    		method : 'POST',
    		params : params,
    		waitMsg: 'login...',
    		success : function(res){
    			var result = Ext.decode(res.responseText);
    			if(result['code'] == 200) {
    				cni.app.soundYN = result['SOUND_YN'];
    				cni.app.alertYN = result['ALERT_YN'];
    				cni.app.sTM = result['S_TM'];
    				cni.app.eTM = result['E_TM'];
    				cni.app.dashboardItem = result['DASHBOARD_ITEM'];
    				cni.app.dashboardItemNM = result['DASHBOARD_ITEM_NM'];
    				
    				try {
    					
    					//인트로 페이지에서 로그인 후 대시보드로 이동 
						var center = view.config.center;
						center.removeAll(true);
        				
						center.add({
							xtype : 'dashboardCAIPanel'
        				});

						btn.up('loginWindow').close();
    					
        				return true;
    				} catch (err) {
    		    		console.log('>> LoginController Message  : '+err.message);
    		    		return true;
    		    	}
    				
    				
    				
    			} else {
    				Ext.Msg.alert("알림",result['msg']);
    				return false;
    			}
    		}
    	});

    }
});
