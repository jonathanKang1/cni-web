Ext.define('cni.controller.main.MainController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.main.mainController',
    
    onAfterRender: function(token) {
		
		Ext.util.History.on('change', function(token) {	// history 가 변경되었을 경우 감시할 리스너
       		//console.log('History id = ', token);
			cni.app.center.removeAll(true);
			cni.app.center.add({xtype: token});
       	});
		
		var oldToken = Ext.util.History.getToken();
		if (oldToken === null || oldToken.search(token) === -1) {
			//console.log(oldToken+' = '+token);
			Ext.util.History.add(token);
		}
	},
    
    /*모니터링 더블클릭*/
    fnRowDblClick : function (obj, record, element, rowIndex, e, eOpts) {
    	Ext.widget('monitorPanelWindow', {
			selectedRecord: record,
			//myParentStore: obj.getStore('comm.dataStore')
		});
		return true;
    },
    
    /*시스템정보 클릭*/
    fnViewCopyright : function(obj, record) {
    	Ext.widget("copyrightWindow");
    },
    
    /*비밀번호변경 클릭*/
    fnChangePasswordWindow : function(btn) {
    	Ext.widget("changePasswordWindow");
    },
    /*로그아웃 클릭*/
    fnLogout : function(btn) {
    	var me = this;
    	var view = me.getView();
    	
    	/*try {
    		if (view.down('monitorPanel').task != null)
        		Ext.TaskManager.stop(view.down('monitorPanel').task);
        		
    	} catch (err) {
    		console.log('>> err.message  : '+err.message);
    		
    	}*/
    	
    	Ext.Ajax.request({
    		url : '/system/logout.ax',
    		method : 'POST',
    		success : function(res){
    			var result = Ext.decode(res.responseText);
    			if(result['code'] == 200) {
    				//view.destroy();
    				//console.log('>> '+'mainController loginWindow open');
    				
    		    	//레프트 메뉴 접기
    		    	//view.down('#menu_panel').setCollapsed(true);
    		    	
    		    	//로그인창 오픈 (로그인 성공시 센터판넬 변경을 목적으로 config변수에 센터 컴포넌트 전달)
    				/*var center = view.down('component[region=center]');
    		    	center.removeAll(true)
    		    	center.add({
    					xtype : 'mainImagePanel'
    				});
    		    	Ext.widget('loginWindow',{
    					center: center
    				});	*/		
    				window.location.assign('/');
    			}
    			else {
    				Ext.Msg.alert("알림",result['msg']);
    				return;
    			}
    		}
    	});
    },  
    
    
    
    
    
    
    
    
    onItemSelected: function (sender, record) {
        Ext.Msg.confirm('Confirm', 'Are you sure?', 'onConfirm', this);
    },

    onConfirm: function (choice) {
        if (choice === 'yes') {
            //
        }
    },
    
    onToggleConfig: function (menuitem) {
        var treelist = this.lookupReference('treelist');

        treelist.setConfig(menuitem.config, menuitem.checked);
    },

    onToggleMicro: function (button, pressed) {
        var treelist = this.lookupReference('treelist'),
            navBtn = this.lookupReference('navBtn'),
            ct = treelist.ownerCt;

        treelist.setMicro(pressed);

        if (pressed) {
            navBtn.setPressed(true);
            navBtn.disable();
            this.oldWidth = ct.width;
            ct.setWidth(44);
        } else {
            ct.setWidth(this.oldWidth);
            navBtn.enable();
        }

        if (Ext.isIE8) {
            this.repaintList(treelist, pressed);
        }
    },

    onToggleNav: function (button, pressed) {
        var treelist = this.lookupReference('treelist');
        var ct = this.lookupReference('treelistContainer');

        treelist.setExpanderFirst(!pressed);
        treelist.setUi(pressed ? 'nav' : null);
        treelist.setHighlightPath(pressed);
        ct[pressed ? 'addCls' : 'removeCls']('treelist-with-nav');

        if (Ext.isIE8) {
            this.repaintList(treelist);
        }
    },
    
    repaintList: function(treelist, microMode) {
        treelist.getStore().getRoot().cascade(function(node) {
            var item, toolElement;

            item = treelist.getItem(node);

            if (item && item.isTreeListItem) {
                if (microMode) {
                    toolElement = item.getToolElement();

                    if (toolElement && toolElement.isVisible(true)) {
                        toolElement.syncRepaint();
                    }
                }
                else {
                    if (item.element.isVisible(true)) {
                        item.iconElement.syncRepaint();
                        item.expanderElement.syncRepaint();
                    }
                }
            }
        });
    },
    fnMenuChange : function(obj) {
    	var me = this;
    	var rtn_tf = false;
    	console.log(obj.page);
    	Ext.Ajax.request({
    		url : '/system/getAuthorityCheck.ax',
    		method : 'POST',
    		params:{req_page: obj.name},
    		success : function(res) {
    			var result = Ext.decode(res.responseText);
    			if (result) {
	    			if (result['code'] == 200) {
	    				if (obj.name.indexOf('Window') > -1) {
	    					Ext.widget(obj.name);
	    				} else {
	    					//me.redirectTo(obj.name);
	    					var center = obj.up('app-main').down('component[region=center]');
		    				center.removeAll(true);
		    				center.add({
		    					xtype : obj.name
		    				});
	    				}
	    				rtn_tf = true;
	    			//세션 타임아웃	
	    			} else if (result['code'] == '000') {
	    				/*if (dashboardImportantTmsTask != null)
	    					Ext.TaskManager.stop(dashboardImportantTmsTask);*/
	    				
	    				/*me.redirectTo('mainImagePanel');
	    				Ext.toast(result['msg']);
	    				Ext.widget('loginWindow');*/
	    		    	var center = obj.up('app-main').down('component[region=center]');
	    				center.removeAll(true);
	    				center.add({
	    					xtype : 'mainImagePanel'
	    				});
	    				Ext.toast(result['msg']);
	    				Ext.widget('loginWindow',{
        					center: obj.up('app-main').down('component[region=center]')
        				});
	    				rtn_tf = false;
	    			} else {
	    				Ext.Msg.alert("알림",result['msg']);
	    				rtn_tf = false;
	    			}
    			}
    		},
    		failure: function(res) {
    			Ext.Msg.alert('알림', "요청처리에 문제가 발생하였습니다.");
            }
    	});
    	return rtn_tf;
    },
    /*메인페이지 이동시 권한 체크*/
    onSelectionchange : function(obj, record, eOpts) {
    	//obj.setExpanderOnly(true);
    	console.log(record.get('page'));
    	let page = record.get('page');
    	var rtn_tf = false;
    	if (page) {
	    	Ext.Ajax.request({
	    		url : '/system/getAuthorityCheck.ax',
	    		method : 'POST',
	    		params:{req_page: page},
	    		
	    		success : function(res){
	    			var result = Ext.decode(res.responseText);
	    			if (result) {
		    			if (result['code'] == 200) {
		    				if (page.indexOf('Window') > -1) {
		    					Ext.widget(page);
		    				} else {
			    				var center = obj.up('app-main').down('component[region=center]');
			    				center.removeAll(true);
			    				center.add({
			    					xtype : page
			    				});
		    				}
		    				rtn_tf = true;
		    			//세션 타임아웃	
		    			} else if (result['code'] == '000') {
		    				/*if (dashboardImportantTmsTask != null)
		    					Ext.TaskManager.stop(dashboardImportantTmsTask);*/
		    				
		    		    	var center = obj.up('app-main').down('component[region=center]');
		    				center.removeAll(true);
		    				center.add({
		    					xtype : 'mainImagePanel'
		    				});
		    				
		    				obj.up('app-main').down('#menu_panel').setCollapsed(true);
		    				
		    				Ext.toast(result['msg']);
		    				Ext.widget('loginWindow',{
	        					center: obj.up('app-main').down('component[region=center]')
	        				});
		    				rtn_tf = false;
		    			} else {
		    				Ext.Msg.alert("알림",result['msg']);
		    				rtn_tf = false;
		    			}
	    			}
	    		},
	    		failure: function(res) {
	    			Ext.Msg.alert('알림', "요청처리에 문제가 발생하였습니다.");
	            }
	    	});
	    	return rtn_tf;
    	}

    }
});
