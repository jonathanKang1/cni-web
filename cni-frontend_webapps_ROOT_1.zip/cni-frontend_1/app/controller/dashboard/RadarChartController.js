Ext.define('cni.controller.dashboard.RadarChartController', {
    extend: 'Ext.app.ViewController',
    alias: 'controller.dashboard.radarChartController',

    onCharttttRendered: function (obj, eOpts) {
    },
    onChartRendered: function (obj, eOpts) {    	
    	var me = this;
    	//var chart = obj.lookupReference('#polarChart');
    	var chart = cni.app.objTemp;
    	
    	var seriesStore = Ext.create('Ext.data.Store', {
    		proxy: {
    			type: 'ajax',
    			url: '/dashboard/getDashboardRadarChartSeries.ax',
    			actionMethods : {create: "POST", read: "POST", update: "POST", destroy: "POST"},
    			reader: {
    				type: 'json',
    				rootProperty: 'data' 
    			},
		   	    extraParams: {
		   	    	grp_cd: '172',
		   	    	region_cd: '44825'
		        }
    		},
    		autoLoad: true,
    		listeners: {
    			beforeload: function(obj, records, successful, operation, eOpts) {
             	},
             	load: function(obj, records, successful, operation, eOpts) {
             		var series = new Array();
             		chart.setSeries(null);
                 	for (i = 0, len = records.length; i < len; ++i) {
                     	if (i == 3) break;
                 		series.push({
                     		type: 'radar',
                            title: records[i].get('RN'),
                            angleField: 'RN',
                            radiusField: 'REGION'+(i+1),
                            style: {
                                opacity: 0.40
                            }
                            
                     		/*tooltip: {
                     			trackMouse: true,
                     			showDelay: 0,
                     			dismissDelay: 0,
                     			hideDelay: 0,
                     			renderer: function (tooltip, record, item) {
                     				//tooltip.setHtml('측정소: '+item.series.getTitle()+'<br/>측정값: '+record.get(item.series.getYField())+'<br/>시간: ' + Ext.Date.format(record.get(item.series.getXField()),'m-d H:i'));
                     			}
                     		}*/
                     	});
                 	}
                 	chart.setSeries(series);
                 	//chart.redraw();
                 	
                 	//chart.setStore(Ext.create('Ext.data.Store'));
                 	//chart.getStore().removeAll();

                 	//me.addNewTimeData();
                 	/*me.timeChartTask = Ext.TaskManager.start({
                 		run: me.addNewTimeData,
                        interval: 60000,
                        //repeat: 120,
                        scope: me
                    });*/
                 }
             }
    	 });
        
    },



});