Ext.define('cni.controller.dashboard.DashboardCAIGraphController', {
	extend: 'Ext.app.ViewController',
    alias: 'controller.dashboard.dashboardCAIGraphController',

    /*트랜드그래프 설정(사용안함)*/
    fnChartSetting: function() {
    	//var me = this;
    	//var view = me.getView();
    	//view.down('#chart_setting').setType('plus');
    	//this.getView().down('#chart_setting').setType('plus');
    	//Ext.getCmp('chart_setting').setType('plus');
    	
    	Ext.widget("dashboardChartConfigWindow");
    },
    fnGraphItemSetting: function() {
    	Ext.widget("dashboardGraphConfigWindow");
    },
    
    /*트랜드그래프 새창(사용안함)*/
    fnChartWindow: function() {
    	Ext.widget("dashboardChartWindow");
    },
    
    onAxisLabelRender: function (axis, label, layoutContext) { // only render interger values
        //return Math.abs(layoutContext.renderer(label) % 1) < 1e-5 ? Math.round(label) : '';
    	return layoutContext.renderer(label);
    },
    


    /*트랜드그래프 시작*/
    onTimeChartRendered: function (obj, eOpts) {
    	var me = this;
    	//Ext.getCmp('dashboardGraphPanel').setTitle('트랜드그래프 ('+cni.app.dashBoardGraphItemNM+(cni.app.tmsType=='S'?' 30분자료)':' 시간자료)'));
    	//var chart = Ext.getCmp('dashboardGraphPanel').down('#real_time_graph');
    	var chart = obj.lookupReference('real_time_graph');

    	var tmsStore = Ext.create('Ext.data.Store', {
    		proxy: {
    			type: 'ajax',
    			url: '/comm/getUseTmsList.ax',
    			reader: {
    				type: 'json',
    				rootProperty: 'data' 
    			},
		   	    extraParams: {
		   	    	//grp_cd: Ext.getCmp('dashboardGraphPanel').config.grp_cd,
		   	    	//region_cd: Ext.getCmp('dashboardGraphPanel').config.region_cd
		   	    	grp_cd: obj.config.grp_cd,
		   	    	region_cd: obj.config.region_cd
		        }
    		},
    		autoLoad: true,
    		listeners: {
    			beforeload: function(obj, records, successful, operation, eOpts) {
             	},
             	load: function(obj, records, successful, operation, eOpts) {
             		var series = new Array();
                 	for (i = 0, len = records.length; i < len; ++i) {
                     	series.push({
                     		type: 'line',
                     		//fill: true,
                     		title: records[i].get('TMS_NM'),
                     		marker: {
                     			//type: 'cross',
                     			//size: 1,
                     			radius: 3,
                                lineWidth: 2
                     		},
                     		style: {
                     			//fill: '#96D4C6',
                     			//fillOpacity: .6,
                                //stroke: '#0A3F50',
                                //strokeOpacity: .6,
                     			miterLimit: 0
                     		},
                     		label: {
                     			field: 'METRIC'+(i+1),
                     			display: 'over',
                     			fontSize: 10
                     		},
                     		highlight: {
                                fillStyle: '#fff',
                                radius: 5,
                                lineWidth: 2,
                                strokeStyle: '#000'
                            },
                            levelField: 'CI_LV_NM'+(i+1),
                     		xField: 'DSP_DT',
                     		yField: 'METRIC'+(i+1),
                     		tooltip: {
                     			trackMouse: true,
                     			showDelay: 0,
                     			dismissDelay: 0,
                     			hideDelay: 0,
                     			renderer: function (tooltip, record, item) {
                     				tooltip.setHtml('측정소: '+item.series.getTitle()+'<br/>통합환경지수: '+record.get(item.series.getYField())+'('+chart.getStore().getAt(chart.getStore().find('DSP_DT', record.get('DSP_DT'))).get(item.series.getYField().replace('METRIC','CI_LV_NM'))
                     						+')<br/>주요염물질: ' +chart.getStore().getAt(chart.getStore().find('DSP_DT', record.get('DSP_DT'))).get(item.series.getYField().replace('METRIC','CI_ITEM_NM'))
                     						+'<br/>시간: ' + Ext.Date.format(record.get(item.series.getXField()),'m-d H:i'));
                     			}
                     		}
                     	});
                 	}
                 	chart.setSeries(series);
                 	chart.redraw();
                 	
                 	chart.setStore(Ext.create('Ext.data.Store'));
                 	chart.getStore().removeAll();

                 	me.addNewTimeData();
                 	/*me.timeChartTask = Ext.TaskManager.start({
                 		run: me.addNewTimeData,
                        interval: 60000,
                        //repeat: 120,
                        scope: me
                    });*/
                 }
             }
    	 });
        
    },

    addNewTimeData: function() {
		var me = this,
			chart = me.lookupReference('real_time_graph'),
	        store = chart.getStore(),
			count = store.getCount(),
	        yAxis = chart.getAxes()[0],
	        xAxis = chart.getAxes()[1],
	        second = 3600000,			//1시간
	        //visibleRange = second * (cni.app.dashBoardGraphTimeAxisLength-1),
	        visibleRange = second * (24-1),
	        //visibleRange = 39600000,	//11시간
	        //visibleRange = 82800000,	//23시간
	        lastRecord;
		
		me.startTime = Math.floor(Ext.Date.add(new Date(), Ext.Date.HOUR, -(24-1)) / second) * second;
		//me.startTime = Math.floor(Ext.Date.add(new Date(), Ext.Date.HOUR, -11) / second) * second;
		//me.startTime = Math.floor(Ext.Date.add(new Date(), Ext.Date.HOUR, -23) / second) * second;
		xAxis.setMinimum(me.startTime);
		xAxis.setMaximum(me.startTime + visibleRange);
		/*if (count > 0) {
			if (Ext.Date.format(new Date(), 'i') % 10 > 2) return true;
		}*/

    	//var dataStore = Ext.create('Ext.data.Store', {
    	cni.app.dashBoardGraphStore = Ext.create('Ext.data.Store', {
	   	    proxy: {
	   	    	type: 'ajax',
	   	        url: '/dashboard/getCAIRealTimeGraphList.ax',
	   	        reader: {
	   	        	type: 'json',
	   	            rootProperty: 'data' 
	   	        }
		   	    /*,extraParams: {
		   	    	grp_cd: Ext.getCmp('dashboardGraphPanel').config.grp_cd,
		   	    	item_cd: Ext.getCmp('dashboardGraphPanel').config.item_cd
		        }*/
	   	    },
	   	    autoLoad: true,
	   	    listeners: {
	   	    	beforeload: function(obj, records, successful, operation, eOpts) {
	   	    		obj.proxy.extraParams = {
	   	    			grp_cd: me.getView().config.grp_cd,
	   	    			region_cd: me.getView().config.region_cd,
	   	    			item_cd: me.getView().config.item_cd,
	   			   	    //x_axis_length: cni.app.dashBoardGraphTimeAxisLength
	   					x_axis_length: "'24'"
	   				};
	   	    	},
	   	    	load: function(obj, records, successful, operation, eOpts) {
	   	    		var max_value = 0;
	   	    		for (i = 0, len = records.length; i < len; ++i) {
	   	    			//records[i].set('msr_dt', Math.floor(Ext.Date.parse(records[i].get('msr_dt'), "Y-m-d H:i") / second) * second);
	   	    			//console.log(Ext.Date.parse(records[i].get('DSP_DT'), "Y-m-d H:i"));
	   	    			
	   	    			records[i].set('DSP_DT', Ext.Date.parse(records[i].get('DSP_DT'), "Y-m-d H:i"));
	   	    			
	   	    			if (max_value < Number(records[i].get('METRIC1'))) max_value = Number(records[i].get('METRIC1'));
	   	    			if (max_value < Number(records[i].get('METRIC2'))) max_value = Number(records[i].get('METRIC2'));
	   	    			if (max_value < Number(records[i].get('METRIC3'))) max_value = Number(records[i].get('METRIC3'));
	   	    			if (max_value < Number(records[i].get('METRIC4'))) max_value = Number(records[i].get('METRIC4'));
	   	    			if (max_value < Number(records[i].get('METRIC5'))) max_value = Number(records[i].get('METRIC5'));
	   	    			if (max_value < Number(records[i].get('METRIC6'))) max_value = Number(records[i].get('METRIC6'));
	   	    			if (max_value < Number(records[i].get('METRIC7'))) max_value = Number(records[i].get('METRIC7'));
	   	    			if (max_value < Number(records[i].get('METRIC8'))) max_value = Number(records[i].get('METRIC8'));
	   	    			if (max_value < Number(records[i].get('METRIC9'))) max_value = Number(records[i].get('METRIC9'));
	   	    			if (max_value < Number(records[i].get('METRIC10'))) max_value = Number(records[i].get('METRIC10'));
	   	    			if (max_value < Number(records[i].get('METRIC11'))) max_value = Number(records[i].get('METRIC11'));
	   	    			if (max_value < Number(records[i].get('METRIC12'))) max_value = Number(records[i].get('METRIC12'));
	   	    			if (max_value < Number(records[i].get('METRIC13'))) max_value = Number(records[i].get('METRIC13'));
	   	    			if (max_value < Number(records[i].get('METRIC14'))) max_value = Number(records[i].get('METRIC14'));
	   	    			if (max_value < Number(records[i].get('METRIC15'))) max_value = Number(records[i].get('METRIC15'));
	   	    			if (max_value < Number(records[i].get('METRIC16'))) max_value = Number(records[i].get('METRIC16'));
	   	    			if (max_value < Number(records[i].get('METRIC17'))) max_value = Number(records[i].get('METRIC17'));
	   	    			if (max_value < Number(records[i].get('METRIC18'))) max_value = Number(records[i].get('METRIC18'));
	   	    			if (max_value < Number(records[i].get('METRIC19'))) max_value = Number(records[i].get('METRIC19'));
	   	    			if (max_value < Number(records[i].get('METRIC20'))) max_value = Number(records[i].get('METRIC20'));
	   	    			
	   	    		}
	   	    		if (me.getView().config.item_cd == 'SO2' || me.getView().config.item_cd == 'O3b' || me.getView().config.item_cd == 'NO2')
	   	    			max_value = max_value + 0.002;
	   	    		else if (me.getView().config.item_cd == 'PMb' || me.getView().config.item_cd == 'PM2')
	   	    			max_value = max_value + 2;
	   	    		else 
	   	    			max_value = max_value + 0.1;
	   	    		
	   	    		yAxis.setMaximum(max_value);

	   	    		if (count > 0) {
	   	    			lastRecord = store.getAt(count - 1);
	   	    		}
	   	    		
	   	    		chart.getStore().removeAll();
                 	chart.setStore(obj);
                 	chart.redraw();
	   	    		//store.removeAll();	
	   	    	}
	   	    }
   	 	});
    },
    
    onTimeChartDestroy: function () {
    	/*if (this.timeChartTask) {
    		Ext.TaskManager.stop(this.timeChartTask);
        }*/
    },
    
    onDownload: function() {
        if (Ext.isIE8) {
            Ext.Msg.alert('알림', '최신버전의 브라우져가 필요 합니다.');
            return;
        }
        var chart = this.lookupReference('real_time_graph');
        if (Ext.os.is.Desktop) {
            chart.download({
                filename: 'chart'
            });
        } else {
            chart.preview();
        }
    },
    onPreview: function () {
        if (Ext.isIE8) {
            Ext.Msg.alert('Unsupported Operation', 'This operation requires a newer version of Internet Explorer.');
            return;
        }
        var chart = this.lookupReference('real_time_graph');
        chart.preview();
    }
});