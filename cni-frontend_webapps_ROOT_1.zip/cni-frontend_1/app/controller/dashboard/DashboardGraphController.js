Ext.define('cni.controller.dashboard.DashboardGraphController', {
	extend: 'Ext.app.ViewController',
    alias: 'controller.dashboard.dashboardGraphController',

    /*트랜드그래프 시작*/
    dashboardGraphRendered: function (obj, eOpts) {
    	var me = this;
    	var chart = obj.lookupReference('real_time_graph');
    	
    	var series = Ext.create('Ext.data.Store', {
    		proxy: {
    			type: 'ajax',
    			url: '/comm/getUseRegionList.ax',
    			actionMethods : {create: "POST", read: "POST", update: "POST", destroy: "POST"},
    			reader: {
    				type: 'json',
    				rootProperty: 'data' 
    			},
		   	    extraParams: {
		   	    	//grp_cd: Ext.getCmp('dashboardGraphPanel').config.grp_cd,
		   	    	//region_cd: Ext.getCmp('dashboardGraphPanel').config.region_cd
		   	    	grp_cd: obj.config.grp_cd,
		   	    	region_cd: obj.config.region_cd
		        }
    		},
    		autoLoad: true,
    		listeners: {
    			beforeload: function(obj, records, successful, operation, eOpts) {
             	},
             	load: function(obj, records, successful, operation, eOpts) {
             		var series = new Array();
                 	for (i = 0, len = records.length; i < len; ++i) {
                     	series.push({
                     		type: 'line',
                     		title: records[i].get('REGION_NM'),
                     		marker: {
                     			//type: 'cross',
                     			//size: 1,
                     			radius: 3,
                                lineWidth: 2
                     		},
                     		style: {
                     			miterLimit: 0
                     		},
                     		label: {
                     			field: 'V'+(i+1),
                     			display: 'over',
                     			fontSize: 10
                     		},
                     		highlight: {
                                fillStyle: '#fff',
                                radius: 5,
                                lineWidth: 2,
                                strokeStyle: '#000'
                            },
                     		xField: 'DSP_DT',
                     		yField: 'V'+(i+1),
                     		tooltip: {
                     			trackMouse: true,
                     			showDelay: 0,
                     			dismissDelay: 0,
                     			hideDelay: 0,
                     			renderer: function (tooltip, record, item) {
                     				tooltip.setHtml('시군: '+item.series.getTitle()+'<br/>측정값: '+record.get(item.series.getYField())+'<br/>시간: ' + Ext.Date.format(record.get(item.series.getXField()),'m-d H:i'));
                     			}
                     		}
                     	});
                 	}
                 	chart.setSeries(series);
                 	chart.redraw();
                 	
                 	chart.setStore(Ext.create('Ext.data.Store'));
                 	chart.getStore().removeAll();

                 	//me.addNewTimeData();
                 	me.timeChartTask = Ext.TaskManager.start({
                 		run: me.newTimeData,
                        interval: 60000,
                        //repeat: 120,
                        scope: me
                    });
                 }
             }
    	 });
        
    },
    newTimeData: function() {
		var me = this,
			chart = me.lookupReference('real_time_graph'),
	        store = chart.getStore(),
			count = store.getCount(),
	        yAxis = chart.getAxes()[0],
	        xAxis = chart.getAxes()[1],
	        second = 3600000,			//1시간
	        visibleRange = second * (24-1),
	        lastRecord;
		
		me.startTime = Math.floor(Ext.Date.add(new Date(), Ext.Date.HOUR, -(24-1)) / second) * second;
		xAxis.setMinimum(me.startTime);
		xAxis.setMaximum(me.startTime + visibleRange);
		
		if (count > 0) {
			if (Ext.Date.format(new Date(), 'i') % 10 > 2) return true;
		}
		var dataStore = Ext.create('Ext.data.Store', {
    	//cni.app.dashBoardGraphStore = Ext.create('Ext.data.Store', {
	   	    proxy: {
	   	    	type: 'ajax',
	   	        url: '/dashboard/getDashboardGraphList.ax',
	   	        actionMethods : {create: "POST", read: "POST", update: "POST", destroy: "POST"},
	   	        reader: {
	   	        	type: 'json',
	   	            rootProperty: 'data' 
	   	        }
	   	    },
	   	    autoLoad: true,
	   	    listeners: {
	   	    	beforeload: function(obj, records, successful, operation, eOpts) {
	   	    		obj.proxy.extraParams = {
	   	    			item_cd: me.getView().config.item_cd,
	   					x_axis_length: "'24'"
	   				};
	   	    	},
	   	    	load: function(obj, records, successful, operation, eOpts) {
	   	    		//Ext.getCmp('dashboardGraphPanel').setTitle('트랜드그래프 ('+cni.app.dashBoardGraphItemNM+' 시간자료)');
	   	    		//Ext.getCmp('dashboardGraphPanel').setTitle('트랜드그래프 ('+cni.app.dashBoardGraphItemNM+(cni.app.tmsType=='S'?' 30분자료)':' 시간자료)'));
	   	    		var max_value = 0;
	   	    		for (i = 0, len = records.length; i < len; ++i) {
	   	    			//records[i].set('msr_dt', Math.floor(Ext.Date.parse(records[i].get('msr_dt'), "Y-m-d H:i") / second) * second);
	   	    			records[i].set('DSP_DT', Ext.Date.parse(records[i].get('DSP_DT'), "Y-m-d H:i"));
	   	    			
	   	    			if (max_value < Number(records[i].get('V1'))) max_value = Number(records[i].get('V1'));
	   	    			if (max_value < Number(records[i].get('V2'))) max_value = Number(records[i].get('V2'));
	   	    			if (max_value < Number(records[i].get('V3'))) max_value = Number(records[i].get('V3'));
	   	    			if (max_value < Number(records[i].get('V4'))) max_value = Number(records[i].get('V4'));
	   	    			if (max_value < Number(records[i].get('V5'))) max_value = Number(records[i].get('V5'));
	   	    			if (max_value < Number(records[i].get('V6'))) max_value = Number(records[i].get('V6'));
	   	    			if (max_value < Number(records[i].get('V7'))) max_value = Number(records[i].get('V7'));
	   	    			if (max_value < Number(records[i].get('V8'))) max_value = Number(records[i].get('V8'));
	   	    			if (max_value < Number(records[i].get('V9'))) max_value = Number(records[i].get('V9'));
	   	    			if (max_value < Number(records[i].get('V10'))) max_value = Number(records[i].get('V10'));
	   	    			if (max_value < Number(records[i].get('V11'))) max_value = Number(records[i].get('V11'));
	   	    			if (max_value < Number(records[i].get('V12'))) max_value = Number(records[i].get('V12'));
	   	    			if (max_value < Number(records[i].get('V13'))) max_value = Number(records[i].get('V13'));
	   	    			if (max_value < Number(records[i].get('V14'))) max_value = Number(records[i].get('V14'));
	   	    			if (max_value < Number(records[i].get('V15'))) max_value = Number(records[i].get('V15'));
	   	    			if (max_value < Number(records[i].get('V16'))) max_value = Number(records[i].get('V16'));
	   	    			if (max_value < Number(records[i].get('V17'))) max_value = Number(records[i].get('V17'));
	   	    			if (max_value < Number(records[i].get('V18'))) max_value = Number(records[i].get('V18'));
	   	    			if (max_value < Number(records[i].get('V19'))) max_value = Number(records[i].get('V19'));
	   	    			if (max_value < Number(records[i].get('V20'))) max_value = Number(records[i].get('V20'));
	   	    			
	   	    		}
	   	    		if (me.getView().config.item_cd == 'SO2' || me.getView().config.item_cd == 'O3b' || me.getView().config.item_cd == 'NO2')
	   	    			max_value = max_value + 0.002;
	   	    		else if (me.getView().config.item_cd == 'PMb' || me.getView().config.item_cd == 'PM2')
	   	    			max_value = max_value + 2;
	   	    		else 
	   	    			max_value = max_value + 0.1;
	   	    		
	   	    		yAxis.setMaximum(max_value);

	   	    		if (count > 0) {
	   	    			lastRecord = store.getAt(count - 1);
	   	    		}
	   	    		
	   	    		store.removeAll();	
	   	    		for (i = 0, len = records.length; i < len; ++i) {
	   	    			store.add(records[i]);
	   	    			
	   	    			/*if (lastRecord != null) {
	   	    				if (lastRecord.get('msr_dt') == records[i].get('msr_dt')) {
	   	    					store.removeAt(count - 1);
	   	    					store.add(records[i]);
	   	    				} else if (lastRecord.get('msr_dt') < records[i].get('msr_dt')) {
	   	    					store.removeAt(0);
	   	    					store.add(records[i]);
	   	    				}
	   	    				
	   	    				if (Ext.Date.format(lastRecord.get('msr_dt'), 'Y-m-d H:i') == Ext.Date.format(records[i].get('Y-m-d msr_dt'), 'H:i')) {
	   	    					store.removeAt(count - 1);
	   	    					store.add(records[i]);
	   	    				} else if (lastRecord.get('msr_dt') < records[i].get('msr_dt')) {
	   	    					store.removeAt(0);
	   	    					store.add(records[i]);
	   	    				}
	   	    			} else {
	   	    				store.add(records[i]);
	   	    			}*/
	   	    		}
	   	    	}
	   	    }
   	 	});
    },
    
    
    
    
    
    
    
    
    
    
    /*트랜드그래프 설정(사용안함)*/
    fnChartSetting: function() {
    	//var me = this;
    	//var view = me.getView();
    	//view.down('#chart_setting').setType('plus');
    	//this.getView().down('#chart_setting').setType('plus');
    	//Ext.getCmp('chart_setting').setType('plus');
    	
    	Ext.widget("dashboardChartConfigWindow");
    },
    fnGraphItemSetting: function() {
    	Ext.widget("dashboardGraphConfigWindow");
    },
    
    /*트랜드그래프 새창(사용안함)*/
    fnChartWindow: function() {
    	Ext.widget("dashboardChartWindow");
    },
    
    onAxisLabelRender: function (axis, label, layoutContext) { // only render interger values
        //return Math.abs(layoutContext.renderer(label) % 1) < 1e-5 ? Math.round(label) : '';
    	return layoutContext.renderer(label);
    },
    


    /*트랜드그래프 시작*/
    onTimeChartRendered: function (obj, eOpts) {
    	var me = this;
    	//Ext.getCmp('dashboardGraphPanel').setTitle('트랜드그래프 ('+cni.app.dashBoardGraphItemNM+(cni.app.tmsType=='S'?' 30분자료)':' 시간자료)'));
    	//var chart = Ext.getCmp('dashboardGraphPanel').down('#real_time_graph');
    	var chart = obj.lookupReference('real_time_graph');
    	
    	var tmsStore = Ext.create('Ext.data.Store', {
    		proxy: {
    			type: 'ajax',
    			url: '/comm/getUseTmsList.ax',
    			reader: {
    				type: 'json',
    				rootProperty: 'data' 
    			},
		   	    extraParams: {
		   	    	//grp_cd: Ext.getCmp('dashboardGraphPanel').config.grp_cd,
		   	    	//region_cd: Ext.getCmp('dashboardGraphPanel').config.region_cd
		   	    	grp_cd: obj.config.grp_cd,
		   	    	region_cd: obj.config.region_cd
		        }
    		},
    		autoLoad: true,
    		listeners: {
    			beforeload: function(obj, records, successful, operation, eOpts) {
             	},
             	load: function(obj, records, successful, operation, eOpts) {
             		var series = new Array();
                 	for (i = 0, len = records.length; i < len; ++i) {
                     	series.push({
                     		type: 'line',
                     		title: records[i].get('TMS_NM'),
                     		marker: {
                     			//type: 'cross',
                     			//size: 1,
                     			radius: 3,
                                lineWidth: 2
                     		},
                     		style: {
                     			miterLimit: 0
                     		},
                     		label: {
                     			field: 'METRIC'+(i+1),
                     			display: 'over',
                     			fontSize: 10
                     		},
                     		highlight: {
                                fillStyle: '#fff',
                                radius: 5,
                                lineWidth: 2,
                                strokeStyle: '#000'
                            },
                     		xField: 'DSP_DT',
                     		yField: 'METRIC'+(i+1),
                     		tooltip: {
                     			trackMouse: true,
                     			showDelay: 0,
                     			dismissDelay: 0,
                     			hideDelay: 0,
                     			renderer: function (tooltip, record, item) {
                     				tooltip.setHtml('측정소: '+item.series.getTitle()+'<br/>측정값: '+record.get(item.series.getYField())+'<br/>시간: ' + Ext.Date.format(record.get(item.series.getXField()),'m-d H:i'));
                     			}
                     		}
                     	});
                 	}
                 	chart.setSeries(series);
                 	chart.redraw();
                 	
                 	chart.setStore(Ext.create('Ext.data.Store'));
                 	chart.getStore().removeAll();

                 	//me.addNewTimeData();
                 	me.timeChartTask = Ext.TaskManager.start({
                 		run: me.addNewTimeData,
                        interval: 60000,
                        //repeat: 120,
                        scope: me
                    });
                 }
             }
    	 });
        
    },

    addNewTimeData: function() {
		var me = this,
			chart = me.lookupReference('real_time_graph'),
	        store = chart.getStore(),
			count = store.getCount(),
	        yAxis = chart.getAxes()[0],
	        xAxis = chart.getAxes()[1],
	        second = 3600000,			//1시간
	        //visibleRange = second * (cni.app.dashBoardGraphTimeAxisLength-1),
	        visibleRange = second * (24-1),
	        //visibleRange = 39600000,	//11시간
	        //visibleRange = 82800000,	//23시간
	        lastRecord;
		
		me.startTime = Math.floor(Ext.Date.add(new Date(), Ext.Date.HOUR, -(24-1)) / second) * second;
		//me.startTime = Math.floor(Ext.Date.add(new Date(), Ext.Date.HOUR, -11) / second) * second;
		//me.startTime = Math.floor(Ext.Date.add(new Date(), Ext.Date.HOUR, -23) / second) * second;
		xAxis.setMinimum(me.startTime);
		xAxis.setMaximum(me.startTime + visibleRange);
		
		if (count > 0) {
			if (Ext.Date.format(new Date(), 'i') % 10 > 2) return true;
		}
    	//var dataStore = Ext.create('Ext.data.Store', {
    	cni.app.dashBoardGraphStore = Ext.create('Ext.data.Store', {
	   	    proxy: {
	   	    	type: 'ajax',
	   	        url: '/dashboard/getRealTimeGraphList.ax',
	   	        reader: {
	   	        	type: 'json',
	   	            rootProperty: 'data' 
	   	        }
		   	    /*,extraParams: {
		   	    	grp_cd: Ext.getCmp('dashboardGraphPanel').config.grp_cd,
		   	    	item_cd: Ext.getCmp('dashboardGraphPanel').config.item_cd
		        }*/
	   	    },
	   	    autoLoad: true,
	   	    listeners: {
	   	    	beforeload: function(obj, records, successful, operation, eOpts) {
	   	    		obj.proxy.extraParams = {
	   	    			grp_cd: me.getView().config.grp_cd,
	   	    			region_cd: me.getView().config.region_cd,
	   	    			item_cd: me.getView().config.item_cd,
	   			   	    //x_axis_length: cni.app.dashBoardGraphTimeAxisLength
	   					x_axis_length: "'24'"
	   				};
	   	    	},
	   	    	load: function(obj, records, successful, operation, eOpts) {
	   	    		//Ext.getCmp('dashboardGraphPanel').setTitle('트랜드그래프 ('+cni.app.dashBoardGraphItemNM+' 시간자료)');
	   	    		//Ext.getCmp('dashboardGraphPanel').setTitle('트랜드그래프 ('+cni.app.dashBoardGraphItemNM+(cni.app.tmsType=='S'?' 30분자료)':' 시간자료)'));
	   	    		var max_value = 0;
	   	    		for (i = 0, len = records.length; i < len; ++i) {
	   	    			//records[i].set('msr_dt', Math.floor(Ext.Date.parse(records[i].get('msr_dt'), "Y-m-d H:i") / second) * second);
	   	    			records[i].set('DSP_DT', Ext.Date.parse(records[i].get('DSP_DT'), "Y-m-d H:i"));
	   	    			
	   	    			if (max_value < Number(records[i].get('METRIC1'))) max_value = Number(records[i].get('METRIC1'));
	   	    			if (max_value < Number(records[i].get('METRIC2'))) max_value = Number(records[i].get('METRIC2'));
	   	    			if (max_value < Number(records[i].get('METRIC3'))) max_value = Number(records[i].get('METRIC3'));
	   	    			if (max_value < Number(records[i].get('METRIC4'))) max_value = Number(records[i].get('METRIC4'));
	   	    			if (max_value < Number(records[i].get('METRIC5'))) max_value = Number(records[i].get('METRIC5'));
	   	    			if (max_value < Number(records[i].get('METRIC6'))) max_value = Number(records[i].get('METRIC6'));
	   	    			if (max_value < Number(records[i].get('METRIC7'))) max_value = Number(records[i].get('METRIC7'));
	   	    			if (max_value < Number(records[i].get('METRIC8'))) max_value = Number(records[i].get('METRIC8'));
	   	    			if (max_value < Number(records[i].get('METRIC9'))) max_value = Number(records[i].get('METRIC9'));
	   	    			if (max_value < Number(records[i].get('METRIC10'))) max_value = Number(records[i].get('METRIC10'));
	   	    			if (max_value < Number(records[i].get('METRIC11'))) max_value = Number(records[i].get('METRIC11'));
	   	    			if (max_value < Number(records[i].get('METRIC12'))) max_value = Number(records[i].get('METRIC12'));
	   	    			if (max_value < Number(records[i].get('METRIC13'))) max_value = Number(records[i].get('METRIC13'));
	   	    			if (max_value < Number(records[i].get('METRIC14'))) max_value = Number(records[i].get('METRIC14'));
	   	    			if (max_value < Number(records[i].get('METRIC15'))) max_value = Number(records[i].get('METRIC15'));
	   	    			if (max_value < Number(records[i].get('METRIC16'))) max_value = Number(records[i].get('METRIC16'));
	   	    			if (max_value < Number(records[i].get('METRIC17'))) max_value = Number(records[i].get('METRIC17'));
	   	    			if (max_value < Number(records[i].get('METRIC18'))) max_value = Number(records[i].get('METRIC18'));
	   	    			if (max_value < Number(records[i].get('METRIC19'))) max_value = Number(records[i].get('METRIC19'));
	   	    			if (max_value < Number(records[i].get('METRIC20'))) max_value = Number(records[i].get('METRIC20'));
	   	    			
	   	    		}
	   	    		if (me.getView().config.item_cd == 'SO2' || me.getView().config.item_cd == 'O3b' || me.getView().config.item_cd == 'NO2')
	   	    			max_value = max_value + 0.002;
	   	    		else if (me.getView().config.item_cd == 'PMb' || me.getView().config.item_cd == 'PM2')
	   	    			max_value = max_value + 2;
	   	    		else 
	   	    			max_value = max_value + 0.1;
	   	    		
	   	    		yAxis.setMaximum(max_value);

	   	    		if (count > 0) {
	   	    			lastRecord = store.getAt(count - 1);
	   	    		}
	   	    		
	   	    		store.removeAll();	
	   	    		for (i = 0, len = records.length; i < len; ++i) {
	   	    			store.add(records[i]);
	   	    			
	   	    			/*if (lastRecord != null) {
	   	    				if (lastRecord.get('msr_dt') == records[i].get('msr_dt')) {
	   	    					store.removeAt(count - 1);
	   	    					store.add(records[i]);
	   	    				} else if (lastRecord.get('msr_dt') < records[i].get('msr_dt')) {
	   	    					store.removeAt(0);
	   	    					store.add(records[i]);
	   	    				}
	   	    				
	   	    				if (Ext.Date.format(lastRecord.get('msr_dt'), 'Y-m-d H:i') == Ext.Date.format(records[i].get('Y-m-d msr_dt'), 'H:i')) {
	   	    					store.removeAt(count - 1);
	   	    					store.add(records[i]);
	   	    				} else if (lastRecord.get('msr_dt') < records[i].get('msr_dt')) {
	   	    					store.removeAt(0);
	   	    					store.add(records[i]);
	   	    				}
	   	    			} else {
	   	    				store.add(records[i]);
	   	    			}*/
	   	    		}
	   	    	}
	   	    }
   	 	});
    },
    
    onTimeChartDestroy: function () {
    	if (this.timeChartTask) {
    		Ext.TaskManager.stop(this.timeChartTask);
        }
        /*if (this.realTimeGraphTask) {
            Ext.TaskManager.stop(this.realTimeGraphTask);
        }*/
    },
    
    onPreview: function () {
        if (Ext.isIE8) {
            Ext.Msg.alert('Unsupported Operation', 'This operation requires a newer version of Internet Explorer.');
            return;
        }
        var chart = this.lookupReference('real_time_graph');
        chart.preview();
    }
});