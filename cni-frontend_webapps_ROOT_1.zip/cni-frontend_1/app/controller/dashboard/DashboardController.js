Ext.define('cni.controller.dashboard.DashboardController', {
	extend: 'Ext.app.ViewController',
    alias: 'controller.dashboard.dashboardController',
    
    fnAjaxCall: function(obj) {
    	
    	Ext.Ajax.request({
    		url : '/dashboard/getStatus.ax',
    		method : 'POST',
    		params: {
    			item_cd: cni.app.dashboardItem
    		},
    		success : function(res){
    			var result = Ext.decode(res.responseText);           
    			if (result['code'] == 200) {
    				obj.down('#btn1').setText(
    						'<p style="font-weight:bold; font-size:medium;">'+cni.app.dashboardItemNM+'</P>'
    						+'<p style="font-weight:bold; font-size:medium;">'+result['CAI_NM']+'('+result['CAI_VL']+')</P>');
    				obj.down('#btn2').setText(
    						'<p style="font-weight:bold; font-size:medium;">'+'교정중 : '+result['ST1']+'건'+'</P>'
                			+'<p style="font-weight:bold; font-size:medium;">'+'동작불량 : '+result['ST2']+'건'+'</P>');
    				obj.down('#btn3').setText(
    						'<p style="font-weight:bold; font-size:medium;">'+'전원단절 : '+result['ST4']+'건'+'</P>'
                			+'<p style="font-weight:bold; font-size:medium;">'+'보수중 : '+result['ST8']+'건'+'</P>');
    				obj.down('#btn4').setText(
    						'<p style="font-weight:bold; font-size:medium;">'+'기준초과 : '+result['OVER_YN']+'건'+'</P>'
                			+'<p style="font-weight:bold; font-size:medium;">'+'나쁨 : '+result['LEVEL_C']+'건'+'</P>'
                			+'<p style="font-weight:bold; font-size:medium;">'+'매우나쁨 : '+result['LEVEL_D']+'건'+'</P>');
    				obj.down('#btn5').setText(
    						'<p style="font-weight:bold; font-size:medium;">'+'주의보 : '+result['WARNING_C']+'건'+'</P>'
                			+'<p style="font-weight:bold; font-size:medium;">'+'경보 : '+result['WARNING_D']+'건'+'</P>'
                			+'<p style="font-weight:bold; font-size:medium;">'+'중대경보 : '+result['WARNING_E']+'건'+'</P>');
    			}
    		}
    	});
    	
    }
});