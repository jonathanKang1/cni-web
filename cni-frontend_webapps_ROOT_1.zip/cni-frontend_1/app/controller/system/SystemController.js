Ext.define('cni.controller.system.SystemController', {
	extend: 'Ext.app.ViewController',
    alias: 'controller.system.systemController',
    
    /*측정소관리*/
    /*측정소관리:측정소등록*/
    fnTmsRegster : function (btn) {
		Ext.widget('tmsDetailWindow', {
			selectedRecord: '',
			myParentStore: Ext.StoreManager.lookup('comm.dataStore')
		});
		return true;
    },
    /*측정소관리:측정소수정*/
    fnRowDblClick : function (obj, record, element, rowIndex, e, eOpts) {
		Ext.widget('tmsDetailWindow', {
			selectedRecord: record,
			myParentStore: obj.getStore('comm.dataStore')
		});
		return true;
    },
    
    /*측정소관리:측정소항목등록*/
    fnTmsItemReg : function (btn) {
		if (cni.app.clickRecord) { 
			Ext.widget('tmsItemWindow', {
				selectedRecord: cni.app.clickRecord,
				selectedTmsCD: btn.up('tmsPanel').down('#selected_tms_cd'),
				selectedTmsNM: btn.up('tmsPanel').down('#selected_tms_nm')
			});
			
			return true;
		} else {
			Ext.Msg.alert('정보', '측정소를 선택하세요');
			return false;
		}
    },
    /*측정소관리:측정소항목등록*/
    fnTmsItemReg2 : function (obj) {
		if (cni.app.clickRecord) { 
			var view = this.getView();
			Ext.widget('tmsItemWindow', {
				selectedRecord: cni.app.clickRecord,
				selectedTmsCD: view.down('#selected_tms_cd'),
				selectedTmsNM: view.down('#selected_tms_nm')
			});
			
			return true;
		} else {
			Ext.Msg.alert('정보', '측정소를 선택하세요');
			return false;
		}
    },
    
    
    /*사용자관리*/
    /*사용자관리:사용자등록*/
    fnUserRegster : function (btn) {

		Ext.widget('userDetailWindow', {
			job_cd: 'I',
			selectedRecord: '',
			myParentStore: btn.up('userPanel').getStore('system.dataStore')
		});
		return true;
    },
    
    /*사용자관리:사용자권한등록*/
    fnRoleReg : function (btn) {
		if (btn.up('userPanel').down('#selected_user_id').getValue()) { 
			Ext.widget('userRoleWindow', {
				selectedUserId: btn.up('userPanel').down('#selected_user_id'),
				selectedUserName: btn.up('userPanel').down('#selected_user_nm')
			});
			return true;
		} else {
			Ext.Msg.alert('정보', '사용자를 선택하세요');
			return false;
		}
    },
    
    /*사용자관리:사용자 측정소 등록*/
    fnTmsReg : function (btn) {
		if (btn.up('userPanel').down('#selected_user_id').getValue()) { 
			Ext.widget('userTmsWindow', {
				selectedUserId: btn.up('userPanel').down('#selected_user_id'),
				selectedUserName: btn.up('userPanel').down('#selected_user_nm')
			});
			return true;
		} else {
			Ext.Msg.alert('정보', '사용자를 선택하세요');
			return false;
		}
    },
    
    /*사용자관리:사용자정보수정*/
    fnUserUpdate : function (obj, record, element, rowIndex, e, eOpts) {
		Ext.widget('userDetailWindow', {
			selectedRecord: record,
			myParentStore: obj.up('userPanel').getStore('comm.dataStore')
		});
		return true;
    },
    
    /*사용자관리:사용자정보검색*/
    fnUserSearch : function (btn) {
		var vGrid = btn.up('userPanel'); 
		vGrid.getStore('comm.dataStore').proxy.extraParams = {
			search_key: vGrid.down("#searchKey").getValue(), 
			search_txt: vGrid.down("#searchText").getValue()
		};
		vGrid.getStore('comm.dataStore').reload();
    },
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*fnRowClick : function (obj, record, element, rowIndex, e, eOpts) {
		obj.up('tmsPanel').setSelectedRecord(record);
    },
    
    
    fnSearch : function (btn) {
		var vGrid = btn.up('tmsPanel'); 
		//btn.up('grid').getStore('userStore').proxy.extraParams = {
		vGrid.getStore('userStore').proxy.extraParams = {
			//search_key: Ext.getCmp('search_key').value, 
			//search_txt: Ext.getCmp('search_txt').value
			search_key: vGrid.down("#searchKey").getValue(), 
			search_txt: vGrid.down("#searchText").getValue()
		};
		vGrid.getStore('userStore').reload();
    },
    
    fnConvertYNImage: function (value) {
    	if (value == 'Y') {
        	value = '<img src="/images/hmenu-unlock.png" border="0" alt="사용">';
        } else {
        	value = '<img src="/images/hmenu-lock.png" border="0" alt="미사용">';
        }
        return value;
    },
    
    fnRemoveClick: function (view, recIndex, cellIndex, item, e, record) {
        record.drop();
    }*/
});