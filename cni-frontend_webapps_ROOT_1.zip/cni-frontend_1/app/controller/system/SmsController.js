Ext.define('cni.controller.system.SmsController', {
	extend: 'Ext.app.ViewController',
    alias: 'controller.system.smsController',
    
    /**
     * 우측상단 세팅아이콘 클릭
     */
    fnSmsConfigSetting : function(btn) {
    	var me = this;
    	var view = me.getView();
    	Ext.widget('smsConfigWindow');
		return true;
    },
    
    fnSmsConditionSetting : function(btn) {
    	var me = this;
    	var view = me.getView();
    	Ext.widget('smsConditionWindow');
		return true;
    },
    
    /**
     * 수신자등록버튼 클릭
     */    
    fnReceiver : function (btn) {
		//SMS환경설정정보 등록 확인
		Ext.Ajax.request({
    		url : '/system/getSmsConfig.ax',
    		method : 'POST',
    		success : function(res){
    			var result = Ext.decode(res.responseText); 
    			if (result['code'] == '200') {
    				Ext.widget('smsDetailWindow', {
    					selectedRecord: '',
    					myParentStore: btn.up('smsUserPanel').getStore('system.userStore')
    				});
    			} else {
    				//SMS환경설정정보가 미등록상태인 경우
    				Ext.Msg.confirm('확인', 'SMS환경정보가 등록되어 있지 않습니다.<br/>환경정보를 등록 하시겠습니까?', function (id, value) {
    					if (id === 'yes') {
    						Ext.widget('smsConfigWindow');
    					}
    				});
    			}
    		}
    	});
		return true;
    },
    
    /**
     * 수신자측정소등록 클릭
     */
    fnTmsReg : function (btn) {
			if (btn.up('smsUserPanel').down('#selected_receive_nm').getValue() && btn.up('smsUserPanel').down('#selected_receive_num').getValue()) { 
				Ext.widget('smsUserTmsWindow', {
					selected_receive_nm: btn.up('smsUserPanel').down('#selected_receive_nm'),
					selected_receive_num: btn.up('smsUserPanel').down('#selected_receive_num')
				});
				return true;
			} else {
				Ext.Msg.alert('정보', '수신자를 선택하세요');
				return false;
			}
    },
    
    /**
     * 수신자 정보 수정 (그리드 더블클릭)
     */
    fnRowDblClick : function (obj, record, element, rowIndex, e, eOpts) {
		//Ext.Msg.alert('알림', record.get('receive_nm'));
		Ext.widget('smsDetailWindow', {
			selectedRecord: record,
			myParentStore: obj.up('smsUserPanel').getStore('comm.listStore')
		});
		return true;
    },

    /**
     * 이름, 전화번호 검색
     */
    fnSearch : function (btn) {
    	var vGrid = btn.up('smsUserPanel'); 
		vGrid.getStore('smsStore').proxy.extraParams = {
			search_key: vGrid.down("#searchKey").getValue(), 
			search_txt: vGrid.down("#searchText").getValue()
		};
		vGrid.getStore('userStore').reload();
    },
    
    fnSendListSearch : function (btn) {
    	var view = this.getView();
    	var vGrid = btn.up('smsSendListPanel');
    	
    	if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -6)) {
			Ext.Msg.alert('알림', '조회 기간은 6개월을 초과할 수 없습니다.');
			return false;
		};
		
		vGrid.getStore('comm.listStore').proxy.extraParams = {
			search_key: vGrid.down("#s_key").getValue(), 
			search_txt: vGrid.down("#s_txt").getValue(),
			s_date: view.down("#s_date").getValue(),
			e_date: view.down("#e_date").getValue()
		};
		vGrid.getStore('comm.listStore').reload();
    },
    
    fnNumValidator : function(input_value) {
    	if(/[^0-9]/g.test(input_value)) {
    		input_value = input_value.replace(/[^0-9]/g,'');
    		return true;
    	} else {
    		return false;
    	}
    }
});