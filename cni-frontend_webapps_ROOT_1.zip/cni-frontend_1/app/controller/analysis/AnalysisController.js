Ext.define('cni.controller.analysis.AnalysisController', {
	extend: 'Ext.app.ViewController',
    alias: 'controller.analysis.analysisController',
     
    fnTimeSearch : function (btn) {
    	var view = this.getView();
    	
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (Ext.Date.format(view.down("#s_date").getValue(),'Ymd') <= Ext.Date.format(Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3),'Ymd')) {
			Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};
		
		view.down('#data_grid').getStore('comm.listStore').load();
    },
    fnTimeExcelDown : function (obj) {
       	var view = this.getView();

		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (Ext.Date.format(view.down("#s_date").getValue(),'Ymd') <= Ext.Date.format(Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3),'Ymd')) {
			Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};
		
		document.frm.action = '/analysis/getTimeExcelReport.do';
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value =  Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.item_cd.value =  view.down("#item_cd").getValue();
		document.frm.item_nm.value =  view.down("#item_cd").getRawValue();
		document.frm.submit();
		
    },
    fnTimePDFDown : function (obj) {
       	var view = this.getView();

		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (Ext.Date.format(view.down("#s_date").getValue(),'Ymd') <= Ext.Date.format(Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3),'Ymd')) {
			Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};
		
		document.frm.action = '/analysis/getTimePDFReport.do';
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value =  Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.item_cd.value =  view.down("#item_cd").getValue();
		document.frm.item_nm.value =  view.down("#item_cd").getRawValue();
		document.frm.submit();
		
    },
        
    fnDaySearch : function (btn) {
    	var view = this.getView();
    	
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (Ext.Date.format(view.down("#s_date").getValue(),'Ymd') <= Ext.Date.format(Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3),'Ymd')) {
			Ext.Msg.alert('알림', '날짜자료 조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};
		
		//view.down('#data_grid').getStore('comm.dataStore').load();
		view.down('#data_grid').getStore('comm.listStore').load();
    },
    fnDayExcelDown : function (obj) {
       	var view = this.getView();

		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (Ext.Date.format(view.down("#s_date").getValue(),'Ymd') <= Ext.Date.format(Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3),'Ymd')) {
			Ext.Msg.alert('알림', '날짜자료 조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};
		
		document.frm.action = '/analysis/getDayExcelReport.do';
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value =  Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.item_cd.value =  view.down("#item_cd").getValue();
		document.frm.item_nm.value =  view.down("#item_cd").getRawValue();
		document.frm.submit();
		
    },
    fnDayPDFDown : function (obj) {
       	var view = this.getView();

		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (Ext.Date.format(view.down("#s_date").getValue(),'Ymd') <= Ext.Date.format(Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3),'Ymd')) {
			Ext.Msg.alert('알림', '날짜자료 조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};
		
		document.frm.action = '/analysis/getDayPDFReport.do';
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value =  Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.item_cd.value =  view.down("#item_cd").getValue();
		document.frm.item_nm.value =  view.down("#item_cd").getRawValue();
		document.frm.submit();
		
    },
    
    fnWeekSearch : function (btn) {
    	var view = this.getView();
    	
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (Ext.Date.format(view.down("#s_date").getValue(),'Ymd') <= Ext.Date.format(Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3),'Ymd')) {
			Ext.Msg.alert('알림', '주간자료 조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};
		
		view.down('#data_grid').getStore('comm.listStore').load();
    },
    fnWeekExcelDown : function (obj) {
       	var view = this.getView();

		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (Ext.Date.format(view.down("#s_date").getValue(),'Ymd') <= Ext.Date.format(Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3),'Ymd')) {
			Ext.Msg.alert('알림', '주간자료 조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};
		
		document.frm.action = '/analysis/getWeekExcelReport.do';
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value =  Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.item_cd.value =  view.down("#item_cd").getValue();
		document.frm.item_nm.value =  view.down("#item_cd").getRawValue();
		document.frm.submit();
		
    },
    fnWeekPDFDown : function (obj) {
       	var view = this.getView();

		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (Ext.Date.format(view.down("#s_date").getValue(),'Ymd') <= Ext.Date.format(Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3),'Ymd')) {
			Ext.Msg.alert('알림', '주간자료 조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};
		
		document.frm.action = '/analysis/getWeekPDFReport.do';
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value =  Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.item_cd.value =  view.down("#item_cd").getValue();
		document.frm.item_nm.value =  view.down("#item_cd").getRawValue();
		document.frm.submit();
		
    },
    fnMonthSearch : function (btn) {
    	var view = this.getView();
    	
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Ymd') <= Ext.Date.format(Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -12), 'Ymd')) {
			Ext.Msg.alert('알림', '월자료 조회 기간은 12개월을 초과할 수 없습니다.');
			return false;
		};
		
		view.down('#data_grid').getStore('comm.listStore').load();
    },
    fnMonthExcelDown : function (obj) {
       	var view = this.getView();

		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Ymd') <= Ext.Date.format(Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -12), 'Ymd')) {
			Ext.Msg.alert('알림', '월자료 조회 기간은 12개월을 초과할 수 없습니다.');
			return false;
		};
		
		document.frm.action = '/analysis/getMonthExcelReport.do';
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value =  Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.item_cd.value =  view.down("#item_cd").getValue();
		document.frm.item_nm.value =  view.down("#item_cd").getRawValue();
		document.frm.submit();
		
    },
    fnMonthPDFDown : function (obj) {
       	var view = this.getView();

		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Ymd') <= Ext.Date.format(Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -12), 'Ymd')) {
			Ext.Msg.alert('알림', '월자료 조회 기간은 12개월을 초과할 수 없습니다.');
			return false;
		};
		
		document.frm.action = '/analysis/getMonthPDFReport.do';
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value =  Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.item_cd.value =  view.down("#item_cd").getValue();
		document.frm.item_nm.value =  view.down("#item_cd").getRawValue();
		document.frm.submit();
		
    }
    
});