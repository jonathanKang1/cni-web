Ext.define('cni.controller.management.FinalController', {
	extend: 'Ext.app.ViewController',
    alias: 'controller.management.finalController',

    fnDataSearch: function (btn) {
    	var view = this.getView();
    	var s_date = view.down("#s_year").getValue() +''+ (view.down("#s_month").getValue() < 10 ? '0'+view.down("#s_month").getValue() : view.down("#s_month").getValue());
    	var e_date = view.down("#e_year").getValue() +''+ (view.down("#e_month").getValue() < 10 ? '0'+view.down("#e_month").getValue() : view.down("#e_month").getValue());

		if (s_date > e_date) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		}; 
		view.down('#data_grid').getStore().load();
    },

    
    fnYearDataSearch: function (btn) {
    	var view = this.getView();
    	var s_date = view.down("#s_date").getValue();
    	var e_date = view.down("#e_date").getValue();

    	if (view.down("#tms_cd").getValue() == null) {
			Ext.Msg.alert('정보', '필수항목이 선택되지 않았습니다.')
			return false;
		};
		
		if (s_date > e_date) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		view.down('#edit_grid').getStore().load();
    },
    
    fnConfirmDataSearch: function (btn) {
    	var view = this.getView();
    	var s_date = view.down("#s_year").getValue() +''+ (view.down("#s_month").getValue() < 10 ? '0'+view.down("#s_month").getValue() : view.down("#s_month").getValue())+'01';
    	var e_date = view.down("#e_year").getValue() +''+ (view.down("#e_month").getValue() < 10 ? '0'+view.down("#e_month").getValue() : view.down("#e_month").getValue())+'31';
    	var ee_date = view.down("#e_year").getValue() +''+ (view.down("#e_month").getValue() < 10 ? '0'+view.down("#e_month").getValue() : view.down("#e_month").getValue())+'01';

    	if (view.down("#region_cd").getValue() == null || view.down("#tms_cd").getValue() == null) {
			Ext.Msg.alert('정보', '필수항목이 선택되지 않았습니다.')
			return false;
		};
		
		if (s_date > e_date) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		}; 
		if (view.down("#data_type").getValue() == 'D' && (Ext.Date.format(Ext.Date.parse(s_date,'Ymd'), 'Ym') < Ext.Date.format(Ext.Date.add(Ext.Date.parse(ee_date,'Ymd'), Ext.Date.MONTH, -5), 'Ym'))) {
			Ext.Msg.alert('알림', '자료 조회 기간은 6개월을 초과할 수 없습니다.');
			return false;
		};
		if (view.down("#data_type").getValue() == 'M' && (Ext.Date.format(Ext.Date.parse(s_date,'Ymd'), 'Ym') <= Ext.Date.format(Ext.Date.add(Ext.Date.parse(ee_date,'Ymd'), Ext.Date.YEAR, -1), 'Ym'))) {
			Ext.Msg.alert('알림', '자료 조회 기간은 1년을 초과할 수 없습니다.');
			return false;
		};
		
		view.down('#data_grid').getStore().load();
    },
    
    fnConfirmExcelDown : function (obj) {
       	var view = this.getView();

       	var s_date = view.down("#s_year").getValue() +''+ (view.down("#s_month").getValue() < 10 ? '0'+view.down("#s_month").getValue() : view.down("#s_month").getValue())+'01';
       	var e_date = view.down("#e_year").getValue() +''+ (view.down("#e_month").getValue() < 10 ? '0'+view.down("#e_month").getValue() : view.down("#e_month").getValue())+'31';
       	var ee_date = view.down("#e_year").getValue() +''+ (view.down("#e_month").getValue() < 10 ? '0'+view.down("#e_month").getValue() : view.down("#e_month").getValue())+'01';

       	//Ext.Date.parse(s_date,'Ymd')
       	if (Ext.Date.parse(s_date,'Ymd') > Ext.Date.parse(e_date,'Ymd')) {
		//if (Ext.Date.format(s_date, 'Ymd') > Ext.Date.format(e_date, 'Ymd')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		
		if (view.down("#data_type").getValue() == 'D' && (Ext.Date.format(Ext.Date.parse(s_date,'Ymd'), 'Ym') < Ext.Date.format(Ext.Date.add(Ext.Date.parse(ee_date,'Ymd'), Ext.Date.MONTH, -5), 'Ym'))) {
			Ext.Msg.alert('알림', '자료 조회 기간은 6개월을 초과할 수 없습니다.');
			return false;
		};
		if (view.down("#data_type").getValue() == 'M' && (Ext.Date.format(Ext.Date.parse(s_date,'Ymd'), 'Ym') <= Ext.Date.format(Ext.Date.add(Ext.Date.parse(ee_date,'Ymd'), Ext.Date.YEAR, -1), 'Ym'))) {
			Ext.Msg.alert('알림', '자료 조회 기간은 1년을 초과할 수 없습니다.');
			return false;
		};
		
		document.frm.action = '/analysis/getConfirmExcelReport.do';
		document.frm.net_cd.value = view.down("#net_cd").getValue();
		document.frm.region_cd.value = view.down("#region_cd").getValue();
		document.frm.region_nm.value = view.down("#region_cd").getRawValue();
		document.frm.tms_cd.value = view.down("#tms_cd").getValue();
		document.frm.tms_nm.value = view.down("#tms_cd").getRawValue();
		document.frm.data_type.value = view.down("#data_type").getValue();
		document.frm.s_date.value = s_date;
		document.frm.e_date.value = e_date;
		document.frm.submit();
		
    },
    fnConfirmPDFDown : function (obj) {
       	var view = this.getView();

       	var s_date = view.down("#s_year").getValue() +''+ (view.down("#s_month").getValue() < 10 ? '0'+view.down("#s_month").getValue() : view.down("#s_month").getValue())+'01';
       	var e_date = view.down("#e_year").getValue() +''+ (view.down("#e_month").getValue() < 10 ? '0'+view.down("#e_month").getValue() : view.down("#e_month").getValue())+'31';
       	var ee_date = view.down("#e_year").getValue() +''+ (view.down("#e_month").getValue() < 10 ? '0'+view.down("#e_month").getValue() : view.down("#e_month").getValue())+'01';

       	//Ext.Date.parse(s_date,'Ymd')
       	if (Ext.Date.parse(s_date,'Ymd') > Ext.Date.parse(e_date,'Ymd')) {
		//if (Ext.Date.format(s_date, 'Ymd') > Ext.Date.format(e_date, 'Ymd')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		
		if (view.down("#data_type").getValue() == 'D' && (Ext.Date.format(Ext.Date.parse(s_date,'Ymd'), 'Ym') < Ext.Date.format(Ext.Date.add(Ext.Date.parse(ee_date,'Ymd'), Ext.Date.MONTH, -5), 'Ym'))) {
			Ext.Msg.alert('알림', '자료 조회 기간은 6개월을 초과할 수 없습니다.');
			return false;
		};
		if (view.down("#data_type").getValue() == 'M' && (Ext.Date.format(Ext.Date.parse(s_date,'Ymd'), 'Ym') <= Ext.Date.format(Ext.Date.add(Ext.Date.parse(ee_date,'Ymd'), Ext.Date.YEAR, -1), 'Ym'))) {
			Ext.Msg.alert('알림', '자료 조회 기간은 1년을 초과할 수 없습니다.');
			return false;
		};
		
		document.frm.action = '/analysis/getConfirmPDFReport.do';
		document.frm.net_cd.value = view.down("#net_cd").getValue();
		document.frm.region_cd.value = view.down("#region_cd").getValue();
		document.frm.region_nm.value = view.down("#region_cd").getRawValue();
		document.frm.tms_cd.value = view.down("#tms_cd").getValue();
		document.frm.tms_nm.value = view.down("#tms_cd").getRawValue();
		document.frm.data_type.value = view.down("#data_type").getValue();
		document.frm.s_date.value = s_date;
		document.frm.e_date.value = e_date;
		document.frm.submit();
		
    }

});