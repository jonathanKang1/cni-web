Ext.define('cni.controller.data.DataController', {
	extend: 'Ext.app.ViewController',
    alias: 'controller.data.dataController',

    fnDataSearch : function (btn) {  
    	var view = this.getView();
    	
		//if (view.down("#selected_tms").getValue() == null || view.down("#selected_items").text == '' || view.down("#selected_states").text == '') { 
    	if (view.down("#tms_cd").getValue() == null) {
    	//if (view.down("#tms_cd").getValue() == null || view.down("#msr_st_nms").text == '') {
			Ext.Msg.alert('정보', '필수항목이 선택되지 않았습니다.')
			return false;
		};
		
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		
		if (view.down("#data_type")) {
			if (view.down("#data_type").getValue() == 'H') {
				if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
					Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
					return false;
				};
			} else {
				/*if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -1)) {
					Ext.Msg.alert('알림', '5분자료 조회 기간은 1개월을 초과할 수 없습니다.');
					return false;
				};*/
				if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.DAY, -7)) {
					Ext.Msg.alert('알림', '5분자료 조회 기간은 1주일을 초과할 수 없습니다.');
					return false;
				};
			}
		}

		view.down('#data_grid').getStore().load();
    },
    /*자료조회 - PDF*/
    fnPDFDown : function (obj) {
    	var view = this.getView();

       	if (view.down("#tms_cd").getValue() == null) {
			Ext.Msg.alert('정보', '필수항목이 선택되지 않았습니다.')
			return false;
		}
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (view.down("#data_type").getValue() == 'H') {
			if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
				Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
				return false;
			};
		} else {
			if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -1)) {
				Ext.Msg.alert('알림', '5분자료 조회 기간은 1개월을 초과할 수 없습니다.');
				return false;	
			};
		}

		document.frm.action = '/data/getPDFList.do';
		document.frm.region_cd.value = view.down("#region_cd").getValue(),
		document.frm.region_nm.value = view.down("#region_cd").getRawValue(),
		document.frm.tms_cd.value = view.down("#tms_cd").getValue(),
		document.frm.tms_nm.value = view.down('#tms_cd').getRawValue(),
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value = Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.data_type.value = view.down("#data_type").getValue();
		document.frm.data_type_nm.value = view.down("#data_type").getRawValue(),
		document.frm.item_nms.value = view.down("#item_nms").text;
		document.frm.status_nms.value = view.down("#status_nms").text;
		document.frm.submit();
    },
    /*자료조회 - 엑셀*/
    fnExcelDown : function (btn) {
       	var view = this.getView();
          
		//if (view.down("#selected_tms").getValue() == null || view.down("#selected_items").text == '' || view.down("#selected_states").text == '') { 
       	//if (view.down("#tms_cd").getValue() == null || view.down("#msr_st_mns").text == '') {
       	if (view.down("#tms_cd").getValue() == null) {
			Ext.Msg.alert('정보', '필수항목이 선택되지 않았습니다.')
			return false;
		}
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (view.down("#data_type").getValue() == 'H') {
			if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
				Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
				return false;
			};
		} else {
			if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -1)) {
				Ext.Msg.alert('알림', '5분자료 조회 기간은 1개월을 초과할 수 없습니다.');
				return false;	
			};
		}
		
		/* 다운로드 안됨
		view.getForm().submit({
			url: '/data/getExcelList.do',
            params: {
            	region_cd: view.down("#region_cd").getValue(),
            	region_nm: view.down("#region_cd").getRawValue(),
            	tms_cd: view.down("#tms_cd").getValue(),
            	tms_nm: view.down('#tms_cd').getRawValue(),
    			//s_date: Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d'),
    			s_date: view.down("#s_date").getValue(),
    			e_date: view.down("#e_date").getValue(),
    			data_type: view.down("#data_type").getValue(),
    			data_type_nm: view.down("#data_type").getRawValue(),
    			item_nms: view.down("#item_nms").text,
    			status_nms: view.down("#status_nms").text
            }
        });*/
		
		document.frm.action = '/data/getExcelList.do';
		document.frm.region_cd.value = view.down("#region_cd").getValue(),
		document.frm.region_nm.value = view.down("#region_cd").getRawValue(),
		document.frm.tms_cd.value = view.down("#tms_cd").getValue(),
		document.frm.tms_nm.value = view.down('#tms_cd').getRawValue(),
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value = Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.data_type.value = view.down("#data_type").getValue();
		document.frm.data_type_nm.value = view.down("#data_type").getRawValue(),
		document.frm.item_nms.value = view.down("#item_nms").text;
		document.frm.status_nms.value = view.down("#status_nms").text;
		document.frm.submit();
		
		//var frm = document.forms['frm'];
		/*frm.action = '/data/getExcelList.do';
		var input = document.createElement('input');
		input.type = 'text';
        input.name = 's_date';
		input.valu = view.down("#s_date").getValue();
		frm.submit();*/
		
		// error
		/*Ext.create('Ext.form.action.Submit', {
			url: '/data/getExcelList.do',
            params: {
            	tms_cd: view.down("#tms_cd").getValue(),
    			s_date: Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d'),
    			e_date: Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d'),
    			data_type: view.down("#data_type").getValue(),
    			item_cd: view.down("#item_cd").getValue()
    		},
    		success: false
		}).run();*/
		
		/*Ext.Ajax.request({
    		url : '/data/getExcelList.do',
    		method : 'POST',
    		params : {
    			tms_cd: view.down("#tms_cd").getValue(),
    			s_date: view.down("#s_date").getValue(),
    			e_date: view.down("#e_date").getValue(),
    			data_type: view.down("#data_type").getValue(),
    			item_cd: view.down("#item_cd").getValue()
    		},
    		success : function(res){
    			var result = Ext.decode(res.responseText);
    			if(result['code'] == 200) {
    				console.log('>> result["msg"] = '+result['msg']);
   				
    			} else {
    				Ext.Msg.alert("알림",result['msg']);
    				return;
    			}
    		}
    	})*/
    	
    },
    /*자료조회2 - 엑셀*/
    fnExcelDown2 : function (btn) {
       	var view = this.getView();
          
       	if (view.down("#tms_cd").getValue() == null) {
			Ext.Msg.alert('정보', '필수항목이 선택되지 않았습니다.')
			return false;
		}
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (view.down("#data_type").getValue() == 'H') {
			if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
				Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
				return false;
			};
		} else {
			if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -1)) {
				Ext.Msg.alert('알림', '5분자료 조회 기간은 1개월을 초과할 수 없습니다.');
				return false;	
			};
		}
		
		document.frm.action = '/data/getExcelList2.do';
		document.frm.region_cd.value = view.down("#region_cd").getValue(),
		document.frm.region_nm.value = view.down("#region_cd").getRawValue(),
		document.frm.tms_cd.value = view.down("#tms_cd").getValue(),
		document.frm.tms_nm.value = view.down('#tms_cd').getRawValue(),
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value = Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.data_type.value = view.down("#data_type").getValue();
		document.frm.data_type_nm.value = view.down("#data_type").getRawValue(),
		document.frm.item_nms.value = view.down("#item_nms").text;
		document.frm.status_nms.value = view.down("#status_nms").text;
		document.frm.submit();
    },
    /* 자료조회 - 항목선택 */
    fnSelectItem: function (item) {
    	var item_nms = Ext.getCmp('dataPanel').down('#item_nms').text;
    	if (item_nms.indexOf(':'+item.text) > -1)
    		item_nms = item_nms.replace(':'+item.text, '');
    	else 
    		item_nms += ':'+item.text;
    	Ext.getCmp('dataPanel').down('#item_nms').setText(item_nms);
    },
    /* 자료조회 - 상태선택 */
    fnSelectState: function (item) {
    	var status_nms = Ext.getCmp('dataPanel').down('#status_nms').text;
    	if (status_nms.indexOf(item.text) > -1)
    		status_nms = status_nms.replace(item.text+':', '');
    	else 
    		status_nms += item.text+':';
    	Ext.getCmp('dataPanel').down('#status_nms').setText(status_nms);
    },
    
    /*경보이력조회*/
    fnWarningSearch : function (btn) {
    	var view = this.getView();
    	
		//if (view.down("#selected_tms").getValue() == null || view.down("#selected_items").text == '' || view.down("#selected_states").text == '') { 
    	if (view.down("#tms_cd").getValue() == null) {
    	//if (view.down("#tms_cd").getValue() == null || view.down("#msr_st_nms").text == '') {
			Ext.Msg.alert('정보', '필수항목이 선택되지 않았습니다.')
			return false;
		};
		
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		
		if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
			Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};


		view.down('#data_grid').getStore('data.dataStore').load();
    },
    /* 자료조회 - 미수신자료검색 */
    fnNoReceiveSearch : function (btn) {  
    	var view = this.getView();
    	view.down('#data_grid').getStore().load();
    },
    /* 자료조회 - 미수신자료 항목선택 */
    fnNoReceiveItem: function (item) {
    	var item_nms = Ext.getCmp('receivePanel').down('#item_nms').text;
    	if (item_nms.indexOf(':'+item.text) > -1)
    		item_nms = item_nms.replace(':'+item.text, '');
    	else 
    		item_nms += ':'+item.text;
    	Ext.getCmp('receivePanel').down('#item_nms').setText(item_nms);
    },
    /*자료조회 - 미수신자료 엑셀*/
    fnNoReceiveExcel : function (btn) {
       	var view = this.getView();
       
		document.frm.action = '/data/getNoReceiveExcel.do';
		document.frm.net_cd.value = view.down("#net_cd").getValue(),
		document.frm.net_nm.value = view.down("#net_cd").getRawValue(),
		document.frm.region_cd.value = view.down("#region_cd").getValue(),
		document.frm.region_nm.value = view.down("#region_cd").getRawValue(),
		document.frm.tms_cd.value = view.down("#tms_cd").getValue(),
		document.frm.tms_nm.value = view.down('#tms_cd').getRawValue(),
		document.frm.data_type.value = view.down("#data_type").getValue();
		document.frm.data_type_nm.value = view.down("#data_type").getRawValue(),
		document.frm.item_nms.value = view.down("#item_nms").text;
		document.frm.submit();
    },
    /*경보이력조회 - PDF*/
    fnWarningPDFDown : function (obj) {
    	var view = this.getView();

       	if (view.down("#tms_cd").getValue() == null) {
			Ext.Msg.alert('정보', '필수항목이 선택되지 않았습니다.')
			return false;
		}
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
			Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};

		document.frm.action = '/data/getWarningPDFList.do';
		document.frm.region_cd.value = view.down("#region_cd").getValue(),
		document.frm.region_nm.value = view.down("#region_cd").getRawValue(),
		document.frm.tms_cd.value = view.down("#tms_cd").getValue(),
		document.frm.tms_nm.value = view.down('#tms_cd').getRawValue(),
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value = Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.item_nms.value = view.down("#item_nms").text;
		document.frm.submit();
    },
    /*경보이력조회 - 엑셀 */
    fnWarningExcelDown : function (btn) {
       	var view = this.getView();
          
		//if (view.down("#selected_tms").getValue() == null || view.down("#selected_items").text == '' || view.down("#selected_states").text == '') { 
       	//if (view.down("#tms_cd").getValue() == null || view.down("#msr_st_mns").text == '') {
       	if (view.down("#tms_cd").getValue() == null) {
			Ext.Msg.alert('정보', '필수항목이 선택되지 않았습니다.')
			return false;
		}
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
			Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};

		document.frm.action = '/data/getWarningExcelList.do';
		document.frm.region_cd.value = view.down("#region_cd").getValue(),
		document.frm.region_nm.value = view.down("#region_cd").getRawValue(),
		document.frm.tms_cd.value = view.down("#tms_cd").getValue(),
		document.frm.tms_nm.value = view.down('#tms_cd').getRawValue(),
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value = Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.item_nms.value = view.down("#item_nms").text;
		document.frm.submit();
    },
    /*그래프조회*/
    fnGraphSearch: function() {
    	//var view = Ext.getCmp('itemGraphPanel');
    	var view = this.getView();
    	/*if (!fnCheckDatePeriod(view.down("#data_type").getValue(), view.down("#s_date").getValue(), view.down("#e_date").getValue()))
    		return false;*/
    	if (!fnCheckDatePeriod('H', view.down("#s_date").getValue(), view.down("#e_date").getValue()))
    		return false;
    	
    	var chart = this.lookupReference('item_graph').setSprites({
            type: 'text',
            text: view.down('#tms_cd').getRawValue()+'('+view.down('#item_cd').getRawValue()+') 측정소 시간자료 그래프',
            font: '20px Arial',
            x: 100, 
            y: 30  
    	});
    	
    	Ext.StoreManager.lookup('comm.dataStore').load();
    },
    onAxisLabelRender: function (axis, label, layoutContext) { // only render interger values
        //return Math.abs(layoutContext.renderer(label) % 1) < 1e-5 ? Math.round(label) : '';
    	return layoutContext.renderer(label);
    },
    onBarSeriesTooltipRender: function (tooltip, record, item) {
    	if (record.get('AI_VL'))
    		tooltip.setHtml('대기환경지수 : '+record.get('AI_VL')+' ('+record.get('AI_LV_NM')+')');
    	else 
    		tooltip.setHtml('');
    },
    onLineSeriesTooltipRender: function (tooltip, record, item) {
    	if (record.get('MSR_VL'))
    		tooltip.setHtml('측정값 : '+record.get('MSR_VL')+record.get('ITEM_UNIT')+' ('+record.get('LEVEL_NM')+')');
    	else 
    		tooltip.setHtml('');
    },
    onPreview: function () {
        if (Ext.isIE8) {
            Ext.Msg.alert('Unsupported Operation', 'This operation requires a newer version of Internet Explorer.');
            return;
        }
        var chart = this.lookupReference('item_graph');
        chart.preview();
    },
    onDownload: function() {
        if (Ext.isIE8) {
            Ext.Msg.alert('알림', '최신버전의 브라우져가 필요 합니다.');
            return;
        }
        var chart = this.lookupReference('item_graph');
        if (Ext.os.is.Desktop) {
            chart.download({
                filename: 'chart'
            });
        } else {
            chart.preview();
        }
    },
    
    /* 이상자료관리 - 항목선택 */
    fnMgrSelectItem: function (item) {
    	var item_nms = Ext.getCmp('managementPanel').down('#item_nms').text;
    	if (item_nms.indexOf(':'+item.text) > -1)
    		item_nms = item_nms.replace(':'+item.text, '');
    	else 
    		item_nms += ':'+item.text;
    	Ext.getCmp('managementPanel').down('#item_nms').setText(item_nms);
    },
    /* 이상자료- 상태선택 */
    fnMgrSelectState: function (item) {
    	var status_nms = Ext.getCmp('managementPanel').down('#status_nms').text;
    	if (status_nms.indexOf(item.text) > -1)
    		status_nms = status_nms.replace(item.text+':', '');
    	else 
    		status_nms += item.text+':';
    	Ext.getCmp('managementPanel').down('#status_nms').setText(status_nms);
    },
    /*이상자료 - PDF*/
    fnMgrPDFDown : function (obj) {
    	var view = this.getView();

       	if (view.down("#tms_cd").getValue() == null) {
			Ext.Msg.alert('정보', '필수항목이 선택되지 않았습니다.')
			return false;
		}
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
				Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
				return false;
		};
		
		document.frm.action = '/management/getAbnormalPDFList.do';
		document.frm.net_cd.value = view.down("#net_cd").getValue(),
		document.frm.region_cd.value = view.down("#region_cd").getValue(),
		document.frm.region_nm.value = view.down("#region_cd").getRawValue(),
		document.frm.tms_cd.value = view.down("#tms_cd").getValue(),
		document.frm.tms_nm.value = view.down('#tms_cd').getRawValue(),
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value = Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.data_type.value = 'H';
		document.frm.data_type_nm.value = '시간자료';
		document.frm.item_nms.value = view.down("#item_nms").text;
		document.frm.status_nms.value = view.down("#status_nms").text;
		document.frm.submit();
    },
    /*이상자료 - 엑셀*/
    fnMgrExcelDown : function (btn) {
       	var view = this.getView();
          
       	if (view.down("#tms_cd").getValue() == null) {
			Ext.Msg.alert('정보', '필수항목이 선택되지 않았습니다.')
			return false;
		}
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
			Ext.Msg.alert('알림', '시간자료 조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};
		
		document.frm.action = '/management/getAbnormalExcelList.do';
		document.frm.net_cd.value = view.down("#net_cd").getValue(),
		document.frm.region_cd.value = view.down("#region_cd").getValue(),
		document.frm.region_nm.value = view.down("#region_cd").getRawValue(),
		document.frm.tms_cd.value = view.down("#tms_cd").getValue(),
		document.frm.tms_nm.value = view.down('#tms_cd').getRawValue(),
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value = Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.data_type.value = 'H';
		document.frm.data_type_nm.value = '시간자료';
		document.frm.item_nms.value = view.down("#item_nms").text;
		document.frm.status_nms.value = view.down("#status_nms").text;
		document.frm.submit();    	
    },
    
    
    
    
    
    
    onAxisRangeChange: function (axis, range) {
    	var chart = axis.getChart(),
            store = chart.getStore(),
            over_vl = '';
            over_vl_unit = '';
    	    
        store.each(function (rec) {
       		over_vl = rec.get('over_vl')==''?over_vl:rec.get('over_vl');
           	over_vl_unit = rec.get('over_vl_unit')==''?over_vl_unit:rec.get('over_vl_unit');
        });
        axis.setLimits({
        	value: over_vl,
        	line: {
        		title: {
        			text: over_vl==''?'':'기준초과선 : '+over_vl_unit
        		},
        		lineDash: [2,2]
        	}
        });
    },
    onSeriesTooltipRender: function (tooltip, record, ctx) {
        tooltip.setHtml(record.get('dsp_dt') + ': ' + record.get(ctx.field));
    },
    onItemHighlightChange: function (chart, newHighlightItem, oldHighlightItem) {
        //this.setSeriesLineWidth(newHighlightItem, 4);
        //this.setSeriesLineWidth(oldHighlightItem, 2);
    },
    onTimeChartDestroy: function () {
    	/*if (this.timeChartTask) {
    		Ext.TaskManager.stop(this.timeChartTask);
        }*/
    },
    
    
    fnCompareDataSearch : function (btn) {  
    	var view = this.getView();
    	
    	if (view.down("#tms_cd").getValue() == null) {
			Ext.Msg.alert('정보', '필수항목이 선택되지 않았습니다.')
			return false;
		};
		
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		

		if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
			Ext.Msg.alert('알림', '조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};
	
		view.down('grid').getStore('data.listStore').load();
		//view.down('compare_graph').getStore('data.dataStore').load();
		Ext.StoreManager.lookup('comm.dataStore').load();
    },
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*dtro*/
    
    
    //realMonitorPanel
    fnRealMonitorSetting: function () {
    	Ext.widget("realMonitorConfigWindow");
    },
    fnTmsMonitorSetting: function () {
    	Ext.widget("tmsMonitorConfigWindow", {
    			monitorId: this.getView().getId()
    	});
    },
    /*fnSelectItem: function (item) {
    	var selectedItems = Ext.getCmp('dataPanel').down('#selected_items').text;
    	if (selectedItems.indexOf(item.text) > -1)
    		selectedItems = selectedItems.replace(item.text+':', '');
    	else 
    		selectedItems += item.text+':';
    	Ext.getCmp('dataPanel').down('#selected_items').setText(selectedItems);
    	
    	console.log('>> fnSelectItem : item.text = '+selectedItems);
    	
    	//this.groupingFeature[item.checked ? 'expand' : 'collapse'](item.text, {
        //    highlight: true
        //});
    },*/
    /*fnSelectOvered: function (item) {
    	var selectedItems = Ext.getCmp('dataPanel').down('#selected_overed').text;
    	if (selectedItems.indexOf(item.getValue()) > -1)
    		selectedItems = selectedItems.replace(item.getValue()+':', '');
    	else 
    		selectedItems += item.getValue()+':';
    	Ext.getCmp('dataPanel').down('#selected_overed').setText(selectedItems);
    	
    	console.log('>> fnSelectOvered : item.getValue() = '+selectedItems);

    },*/
    
    /*fnGroupChange: function (store, grouper) {
    	console.log('>> fnGroupChange');
        var me = this,
            groupingFeature = me.groupingFeature,
            groupBy = grouper ? grouper.getProperty() : '',
            itemsBtn = me.lookup('itemsBtn'),
            vm = me.getViewModel(),
            groups, items, menu,
            len, i;

        me.groupBy = groupBy;

        if (vm) {
            vm.set({
                groupBy: groupBy
            });
        }

        if (groupBy) {
            menu = itemsBtn.menu;

            if (itemsBtn.groupBy !== groupBy) {
                itemsBtn.groupBy = groupBy;
                groups = store.getGroups();
                items = [];

                groups.each(function (group) {
                    items.push({
                        xtype: 'menucheckitem',
                        text: group.getGroupKey(),
                        handler: 'onToggleGroup'
                    });
                });

                menu.removeAll(true);
                if (items.length) {
                    menu.add(items);
                }
            }

            items = menu.items.items;
            for (i = 0, len = items.length; i < len; ++i) {
                items[i].setChecked(groupingFeature.isExpanded(items[i].text));
            }
        }
    },*/
    
    /* 비교그래프*/
    /* PDF*/
    fnComparePDFDown : function (obj) {
    	var view = this.getView();

       	if (view.down("#tms_cd").getValue() == null || view.down("#tms_cd_2").getValue() == null) {
			Ext.Msg.alert('정보', '필수항목이 선택되지 않았습니다.')
			return false;
		}
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
			Ext.Msg.alert('알림', '조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};

		document.frm.action = '/data/getComparePDFList.do';
		document.frm.region_cd.value = view.down("#region_cd").getValue();
		document.frm.region_nm.value = view.down("#region_cd").getRawValue();
		document.frm.tms_cd.value = view.down("#tms_cd").getValue();
		document.frm.tms_nm.value = view.down('#tms_cd').getRawValue();
		document.frm.region_cd_2.value = view.down("#region_cd_2").getValue();
		document.frm.region_nm_2.value = view.down("#region_cd_2").getRawValue();
		document.frm.tms_cd_2.value = view.down("#tms_cd_2").getValue();
		document.frm.tms_nm_2.value = view.down('#tms_cd_2').getRawValue();
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value = Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.item_cd.value = view.down("#item_cd").getValue();
		document.frm.item_nm.value = view.down("#item_cd").getRawValue();
		document.frm.submit();
    },
    /*자료비교 - 엑셀*/
    fnCompareExcelDown : function (btn) {
       	var view = this.getView();
          
       	if (view.down("#tms_cd").getValue() == null || view.down("#tms_cd_2").getValue() == null) {
			Ext.Msg.alert('정보', '필수항목이 선택되지 않았습니다.')
			return false;
		}
		if (Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d') > Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d')) {
			Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
			return false;
		};
		if (view.down("#s_date").getValue() < Ext.Date.add(view.down('#e_date').getValue(), Ext.Date.MONTH, -3)) {
			Ext.Msg.alert('알림', '조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};
		
		document.frm.action = '/data/getCompareExcelList.do';
		document.frm.region_cd.value = view.down("#region_cd").getValue();
		document.frm.region_nm.value = view.down("#region_cd").getRawValue();
		document.frm.tms_cd.value = view.down("#tms_cd").getValue();
		document.frm.tms_nm.value = view.down('#tms_cd').getRawValue();
		document.frm.region_cd_2.value = view.down("#region_cd_2").getValue();
		document.frm.region_nm_2.value = view.down("#region_cd_2").getRawValue();
		document.frm.tms_cd_2.value = view.down("#tms_cd_2").getValue();
		document.frm.tms_nm_2.value = view.down('#tms_cd_2').getRawValue();
		document.frm.s_date.value = Ext.Date.format(view.down("#s_date").getValue(), 'Y-m-d');
		document.frm.e_date.value = Ext.Date.format(view.down("#e_date").getValue(), 'Y-m-d');
		document.frm.item_cd.value = view.down("#item_cd").getValue();
		document.frm.item_nm.value = view.down("#item_cd").getRawValue();
		document.frm.submit();
    },
    onCompareGraphPreview: function () {
        if (Ext.isIE8) {
            Ext.Msg.alert('Unsupported Operation', 'This operation requires a newer version of Internet Explorer.');
            return;
        }
        var chart = this.lookupReference('compare_graph');
        chart.preview();
    },
    onCompareGraphDownload: function() {
        if (Ext.isIE8) {
            Ext.Msg.alert('알림', '최신버전의 브라우져가 필요 합니다.');
            return;
        }
        var chart = this.lookupReference('compare_graph');
        if (Ext.os.is.Desktop) {
            chart.download({
                filename: 'compare_graph'
            });
        } else {
            chart.preview();
        }
    },
});