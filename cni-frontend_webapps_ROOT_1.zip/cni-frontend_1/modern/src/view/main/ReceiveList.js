Ext.define('cni.view.main.ReceiveList', {
    extend: 'Ext.grid.Grid',
    xtype: 'receiveList',
    
    requires: [
        'cni.store.comm.ListStore'
    ],

    id: 'receiveList',
    title: '마을대기측정망 관제시스템',
    
    columns: [
    	{ text: '측정소', dataIndex: 'REGION_TMS_NM', align: 'center', flex: 3 },
    	{ text : '최종수신', dataIndex : 'DSP_DT', align: 'center', flex : 2,
    		renderer: function(value, record, dataIndex, cell) {
    			if (record.get('DSP_DT') == '미수신') {
                	cell.setStyle('color: red;');
                } else {
                	cell.setStyle('color: black;');
                }
                return value;
            }
    	}
    ],
    
    store: {
    	type: 'comm.listStore',
    	sortOnLoad : false,
    	autoLoad: false,
    	listeners: {
    		beforeload: function(obj, records, successful, operation, eOpts) {
    			obj.getProxy().setUrl('/m/getReceiveList.ax');
    		}
    	}
    },
    
    listeners: {
    	activate: function (newActiveItem, me, oldActiveItem, eOpts) {
    		//console.log('receiveList activate =', me.getId());
    		//최초 1회
    		//console.log('list activate');
    		//console.log('=='+me.down('#toolbar').down('#fieldset').down('#selectfield').getOptions().length);

    	},
    	painted: function (me) {
    		//탭클릭시
        	console.log('receiveList painted =', me.getId());
        	//if (!receiveListStore) 
        		//receiveListStore.load();
        	Ext.StoreManager.lookup('comm.listStore').load();
        },
        //select: 'onItemSelected'
    	select: function (me, record, eOpts) {
    		/*Ext.toast('측정시간: '+record.get('dsp_dt')+'<br/>'
    				+'항목: '+record.get('item_nm')+'<br/>'
    				+'측정값: '+record.get('msr_vl')+'<br/>'
    				+'상태: '+record.get('status_nm'));*/
    	},
    	itemtab: function (me, index, target, record, e, eOpts) {
    		//console.log('receiveList itemtab =', me.getId());
    	}
    }
});
