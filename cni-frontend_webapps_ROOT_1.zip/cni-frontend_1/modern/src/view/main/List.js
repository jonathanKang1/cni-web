var tmsListStore = null;
Ext.define('cni.view.main.List', {
    extend: 'Ext.grid.Grid',
    xtype: 'mainlist',
    id: 'mainList',
    
    requires: [
        'cni.store.comm.DataStore',
        'cni.store.comm.ListStore'
    ],
    
    title: '마을대기측정망 관제시스템',
    
    items: [{
        docked: 'bottom',
        xtype: 'toolbar',
        itemId: 'toolbar',
        shadow: false,
        items: [{
            xtype: 'fieldset',
            itemId: 'fieldset',
            width: '100%',
            items: [{
                xtype: 'selectfield',
                itemId: 'selectfield',
                listeners: {
                	change: function(selectfield, newValue, oldValue, eOpts) {
                		cni.app.tmsCD = selectfield.getValue();
                		Ext.StoreManager.lookup('comm.dataStore').load();
                	}
                }
            }]
        }]
    }],
    
    columns: [
    	{ text: '시간', dataIndex: 'DSP_DT', align: 'center', flex: 3 },
    	{ text : '항목', dataIndex : 'ITEM_NM', align: 'center', flex : 3},
    	{ text : '측정값', dataIndex : 'MSR_VL', align: 'center', flex : 2,
    		renderer: function(value, record, dataIndex, cell) {
	    		var status_cd = record.get('STATUS_CD');
	    			if (status_cd == 0) {
	                	cell.setStyle('color: black;');
	                } else if (status_cd == 1) {
	                	cell.setStyle('color: orange;');
	                	value = record.get('STATUS_NM');
	                } else if (status_cd == 2) {
	                	cell.setStyle('color: gray;');
	                	value = record.get('STATUS_NM');
	                } else if (status_cd == 4) {
	                	cell.setStyle('color: red;');
	                	value = record.get('STATUS_NM');
	                } else if (status_cd == 8) {
	                	cell.setStyle('color: orange;');
	                	value = record.get('STATUS_NM');
	                } else {
	                	cell.setStyle('color: gray;');
	                }
	                return value;
            }
    	}
    ],
    
    store: {
    	type: 'comm.dataStore',
    	sortOnLoad : false,
    	autoLoad: false,
    	listeners: {
    		beforeload: function(obj, records, successful, operation, eOpts) {
    			obj.getProxy().setUrl('/m/getDataOneday.ax');
    			obj.proxy.extraParams = {
    					data_type: 'H',
    					platform_type: 'M',
    					tms_cd: cni.app.tmsCD
    			};
    		} 
    	}
    },
    
    listeners: {
    	activate: function (newActiveItem, me, oldActiveItem, eOpts) {

    		var myTmsArr;
    		tmsListStore = Ext.create('Ext.data.Store', {
    			proxy: {
    		         type: 'ajax',
    		         url: '/comm/getUseTmsList.ax',
    		         reader: {
    		             type: 'json',
    		             rootProperty: 'data' 
    		         },
    		         extraParams: {
    		        	 platform_type: 'M'
	 		        }
    		     },
    		     autoLoad: false,
    		     listeners: {
    		    	 load: function(obj, records, successful, operation, eOpts) {
    		    		 if (records) {
	    		    		 var myTmsArr = [];
	    		    		 obj.each(function (rec) {
	    		    			 myTmsArr.push({value: rec.get('TMS_CD'), text:rec.get('REGION_TMS_NM')});
	    		    		 });
	
	    		    		 me.down('#toolbar').down('#fieldset').down('#selectfield').setOptions(myTmsArr, true);
    		    		 }
    		    	 }
    		     }
    		});
    	},
    	painted: function (me) {
    		//탭클릭시
       		tmsListStore.load();
        },
    	select: function (me, record, eOpts) {
    		if (!record.get('ITEM_NM')) return false;
    		
    		Ext.toast('측정시간: '+record.get('DSP_DT')+'<br/>'
				+'항목: '+record.get('ITEM_NM')+'<br/>'
				+'측정값: '+record.get('MSR_VL')+record.get('ITEM_UNIT')+'<br/>'
				+'상태: '+record.get('STATUS_NM')
    		);
    	}
    }
});
