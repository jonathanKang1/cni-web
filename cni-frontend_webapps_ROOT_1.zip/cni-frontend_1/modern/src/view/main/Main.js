Ext.define('cni.view.main.Main', {
    extend: 'Ext.tab.Panel',
	xtype: 'app-main',

    requires: [
        'Ext.MessageBox',
        'cni.view.main.MLoginPanel',
        'cni.view.main.List',
        'cni.view.main.ReceiveList'
    ],

    id: 'main',
    fullscreen: true,
    defaults: {
        tab: {
            iconAlign: 'top'
        },
        styleHtmlContent: true
    },

    tabBarPosition: 'bottom',
    //activeItem: 1,

    items: [{
        title: 'Login',
        id: 'loginTab',
        itemId: 'loginTab',
        iconCls: 'x-fa fa-user',
        layout: 'fit',
        items: [{
            xtype: 'mLoginPanel'
        }]
    },{
        title: '측정현황',
        id: 'listTab',
        itemId: 'listTab',
        iconCls: 'x-fa fa-list-ul',
        layout: 'fit',
        items: [{
            xtype: 'mainlist'
        }],
        tab: {
            listeners: {
                tap: function() {
                	if (cni.app.mLoginYN == 'Y') {
            			//Ext.StoreManager.lookup('comm.dataStore').load();
            		}	
                }
            }
        }
    },{
        title: '수신현황',
        id: 'receiveTab',
        itemId: 'receiveTab',
        iconCls: 'x-fa fa-desktop',
        layout: 'fit',
        items: [{
            xtype: 'receiveList'
        }],
        tab: {
            listeners: {
                tap: function() {
                	if (cni.app.mLoginYN == 'Y') {
            			//Ext.StoreManager.lookup('comm.dataStore').load();
            		}	
                }
            }
        }
    }],
    listeners: {
    	activate: function (newActiveItem, me, oldActiveItem, eOpts) {
        	console.log('app-main activate');
        	//me.getActiveItem().setActiveItem(1);
        	//console.log(me.getActiveItem().down('#loginPanel').getId());
        	Ext.Ajax.request({
	    		url: '/system/getLoginInfo.ax',
	    		method: 'POST',
	    		waitMsg: 'login...',
	    		success : function(res){
	    			var result = Ext.decode(res.responseText);
	    			if(result['code'] == 200) {
	    				try {
	    					cni.app.mLoginYN = 'Y';
	    					me.getActiveItem().setActiveItem(1)
	    					return true;
	    				} catch (err) {
	    		    		console.log('>> LoginController Message  : '+err.message);
	    		    		return true;
	    		    	}
	    				
	    			} else {
	    				cni.app.mLoginYN = 'N';
	    				Ext.toast(result['msg']);
	    				return false;
	    			}
	    		}
	    	});
    	},
    	painted: function (element, eOpts) {
        	//console.log('painted');
        },
        beforeactiveItemchange: function (sender, value, oldValue, eOpts) {
        	//console.log('beforeactiveItemchange = '+ value.getId());
        },
        activeItemchange: function (sender, value, oldValue, eOpts) {
        	//console.log('app-main activeItemchange = '+ value.getId());
        	
    		if ((!cni.app.mLoginYN || cni.app.mLoginYN == 'N') && value.getId() == 'listTab') {
    			Ext.toast('로그인이 필요합니다.');
    			//로그인탭으로 이동
    			sender.setActiveItem(0);
    			return false;
    		}
    		if (cni.app.mLoginYN == 'Y' && value.getId() == 'listTab') {
    			//console.log('app-main cni.app.mLoginYN = '+ cni.app.mLoginYN);
    			//Ext.StoreManager.lookup('comm.dataStore').load();
    			
    		}	
    		if (cni.app.mLoginYN == 'Y' && value.getId() == 'loginTab') {
    			Ext.Msg.confirm('알림','로그아웃 하시겠습니까?', function(btn) {
        			if (btn=='yes') {
        				Ext.Ajax.request({
        		    		url : '/system/logout.ax',
        		    		method : 'POST',
        		    		success : function(res){
        		    			var result = Ext.decode(res.responseText);
        		    			if(result['code'] == 200) {
        		    				cni.app.mLoginYN = 'N';
        		    				Ext.toast('로그아웃 되었습니다.');
        		    			}
        		    			else {
        		    				Ext.toast(result['msg']);
        		    				return;
        		    			}
        		    		},
        		    		callback: function(options, success, response) {
        		    		},
        		    		failure : function(){
        		    		}
        		    	});
        			} else {
        				sender.setActiveItem(1);
        			}
        		});
    		}
    	}
    }
});
