package egovframework.dooill.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import egovframework.dooill.cmmn.EgovOthersExcepHndlr;

public class SessionCheckInterceptor extends HandlerInterceptorAdapter {

	private static final Logger LOGGER = LoggerFactory.getLogger(EgovOthersExcepHndlr.class);
	
	private WebApplicationContext webApplicationContext = null;
	private DataSource dataSource =  null;
	//private Connection connection = null;
	
	
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
			throws Exception {
		// TODO Auto-generated method stub
		
	}
	
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		LOGGER.debug(">>> SessionCheckInterceptor.SessionCheckInterceptor()");
		
		//LOGGER.debug(">>> Session Check Message : RequestDomain = " + request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort());
		//LOGGER.debug(">>> Session Check Message : RequestURI = " + request.getRequestURI());
		//LOGGER.debug(">>> Session Check Message : RequestURL = " + request.getRequestURL());
		//LOGGER.debug(">>> Session Check Message : NEW Session ? = " + (request.getSession(true).isNew()?"true":"false"));
		
		
		//LOGGER.debug(">>> Client IP = " + getRemoteAddr(request));
		//LOGGER.debug(">>> Client Browser = " + getUserAgent(request));
		//LOGGER.debug(">>> Client Browser = " + request.getHeader("User-Agent"));
		
		// DB Test
		// 방문기록 IP, Browser, session, RequestURL, hit, reg_dt
		// 날짜별  IP, Browser, session, RequestURL이 같으면 업데이트 hit++
		// 날짜별  IP, Browser, session이 다른 합계 : 방문자수
		// 날짜별, RequestURL별  IP, Browser, session, RequestURL hit합계 : 페이지뷰
		//getConnection(request, "");
		
		/*API요청은 허용함*/
		if (request.getRequestURI().indexOf("/api/data") > -1) {
			return true;
		}
		
		
		if (request.getRequestURI().indexOf("/fail.ax") > -1
				|| request.getRequestURI().indexOf("/system/getLoginInfo.ax") > -1
				|| request.getRequestURI().indexOf("/system/logout.ax") > -1
				|| request.getRequestURI().indexOf("/cni") > -1
				) {
			
			if (request.getRequestURI().indexOf("/cni") > -1 && request.getRequestURI().indexOf(".ax") < 0) {
				//System.out.println(request.getRequestURI());
				//System.out.println(request.getSession(true).getId());
				//System.out.println(getRemoteAddr(request));
				//System.out.println(getUserAgent(request));
				//System.out.println(request.getHeader("User-Agent"));
				
				//방문기록 저장
				//getConnection(request, "insert into visit_list (uri, ip, user_agent, session_id) values ('" + request.getRequestURI()+ "', '"+ getRemoteAddr(request) + "', '" + getUserAgent(request) + "', '" + request.getSession(true).getId() + "')");
				setVisitLog(request, "insert into visit_list (uri, ip, user_agent, session_id) values ('" + request.getRequestURI()+ "', '"+ getRemoteAddr(request) + "', '" + getUserAgent(request) + "', '" + request.getSession(true).getId() + "')");
			}
			
			return true;
		}
		
		if (request.getSession(true).isNew() 
				|| request.getSession().getAttribute("LOGIN_TF") == null
				|| !(boolean)request.getSession().getAttribute("LOGIN_TF")) {
			LOGGER.debug(">>> Session Check Message : New Session or Do not Login!");
			response.sendRedirect("/fail.ax");
			return false;
		}

		return true;
	}
	
	public static String getRemoteAddr(HttpServletRequest request) {
        String ip = null;
        ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.length() ==  0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("Proxy-Client-IP"); 
        } 
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("WL-Proxy-Client-IP"); 
        } 
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("HTTP_CLIENT_IP"); 
        } 
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("HTTP_X_FORWARDED_FOR"); 
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("X-Real-IP"); 
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("X-RealIP"); 
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getHeader("REMOTE_ADDR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
            ip = request.getRemoteAddr(); 
        }
        return ip;
    }
	
	public static String getUserAgent(HttpServletRequest request) {
		String browserInfo = request.getHeader("User-Agent"); // 사용자 User-Agent 값 얻기
		System.out.println("browserInfo = "+ browserInfo);
		if (browserInfo != null) {
			
			if (browserInfo.indexOf("Mobile") > -1) {
				browserInfo = "Mobile";
			/*if (browserInfo.indexOf("iPhone") > -1 && browserInfo.indexOf("Mobile") > -1) {
				browserInfo = "iPhone";
			} else if (browserInfo.indexOf("Android") > -1 && browserInfo.indexOf("Mobile") > -1) {
				browserInfo = "Android";*/
			} else if (browserInfo.indexOf("Trident") > -1) {
				browserInfo = "MSIE";
			} else if (browserInfo.indexOf("Edg") > -1) {
				browserInfo = "Edge";
			} else if (browserInfo.indexOf("Firefox") > -1) {
				browserInfo = "Firefox";
			} else if (browserInfo.indexOf("Opera") > -1 || browserInfo.indexOf("OPR") > -1) {
				browserInfo = "Opera";
			} else if (browserInfo.indexOf("Mac") > -1 && browserInfo.indexOf("Apple") > -1) {
				browserInfo = "Safari";
			} else if (browserInfo.indexOf("Chrome") > -1) {
				browserInfo = "Chrome";
			} else {
				browserInfo = "unknown";
			}
		}
        return browserInfo;
	}
	
	public void setVisitLog(HttpServletRequest request, String query) throws Exception {	
		Connection connection = null;
		PreparedStatement pstmt = null;
		
		try {
			if (webApplicationContext == null) 
				webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(request.getSession().getServletContext());
			
			if (dataSource == null) 
				dataSource = (DataSource)webApplicationContext.getBean("dataSource");
			
			connection = dataSource.getConnection();
			
			pstmt = connection.prepareStatement(query);
			
			pstmt.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("[setVisitLog Exception] "+e.toString());
			e.printStackTrace();
		} finally {
	        if (pstmt != null) try { pstmt.close(); } catch(Exception e) {}
	        if (connection != null) try { connection.close(); } catch(Exception e) {}
        }
	}
	
	public void getConnection(HttpServletRequest request, String query) throws Exception {	
		List list = null;
		HashMap map = null;
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData  resultSetMetaData  = null;
		
		int sz = 0;
		try {
			//Context initContext = new InitialContext();
			//Context envContext = (Context)initContext.lookup("java:/comp/env");
			//if (envContext == null) envContext = initContext;
			//DataSource ds = (DataSource)envContext.lookup(dbms);
			if (webApplicationContext == null)
				webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(request.getSession().getServletContext());
	    	//context.getBean("dataSource");
			
			if (dataSource == null)
				dataSource = (DataSource)webApplicationContext.getBean("dataSource");
			
			if (connection == null)
				connection = dataSource.getConnection();
	
			//query = "select * from user_info";
			pstmt = connection.prepareStatement(query);
			if (query.toLowerCase().trim().indexOf("select") == 0 ) {
			
				rs = pstmt.executeQuery();
				resultSetMetaData = rs.getMetaData();
				sz = resultSetMetaData.getColumnCount();
				
				map = new HashMap();
				list = new ArrayList();
				for (int i=1; i<=sz; i++) {
					map.put(i, resultSetMetaData.getColumnName(i));
					System.out.print(resultSetMetaData.getColumnName(i) + ", ");
				}
				System.out.println("");
				
				list.add(map);
				while(rs.next()){
					map = new HashMap();
					for (int i=1; i<=sz; i++) {
						map.put(i, rs.getString(i));
						System.out.println(rs.getString(i) + ", ");
					}
					list.add(map);
				} 
			} else {
				pstmt.executeUpdate();
			}
		} catch (Exception e) {
			System.out.println("[getConnection Exception] "+e.toString());
			e.printStackTrace();
		} finally {
			//return conn; 
			if (rs != null) try { rs.close(); } catch(Exception e) {}
	        if (pstmt != null) try { pstmt.close(); } catch(Exception e) {}
	        if (connection != null) try { connection.close(); } catch(Exception e) {}
        }
	}
}
