package egovframework.dooill.util;

public class SystemConfigInitializer {

	public SystemConfigInitializer() {
		/*To do Init method !*/ 
		
	}

}
