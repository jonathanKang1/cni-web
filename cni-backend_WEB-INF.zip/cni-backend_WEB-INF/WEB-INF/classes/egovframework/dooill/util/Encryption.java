package egovframework.dooill.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Encryption {

	/**
     * MD5를 이용하여 String객체를 해쉬화 한다(VChar 32) 패스워드용 (복호화 불가능 고로 비교할때 해쉬화해서 비교할것)
     * @param str
     * @return stringBuffer.toString()
     * @throws NoSuchAlgorithmException
     */
    public static String makeHash(String str) throws NoSuchAlgorithmException{
        byte[] byteArray = null;
        byteArray = MessageDigest.getInstance("MD5").digest(str.getBytes());
       
        StringBuffer stringBuffer = new StringBuffer();  
        for (int i = 0; i < byteArray.length; i++) { 
            stringBuffer.append(Integer.toString((byteArray[i] & 0xf0) >> 4, 16)); 
            stringBuffer.append(Integer.toString(byteArray[i] & 0x0f, 16)); 
        }
        return stringBuffer.toString();
    }
}
