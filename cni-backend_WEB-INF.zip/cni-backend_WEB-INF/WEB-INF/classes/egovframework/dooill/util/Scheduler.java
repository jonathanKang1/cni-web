package egovframework.dooill.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import egovframework.dooill.cmmn.EgovOthersExcepHndlr;
import egovframework.dooill.service.EgovService;
import egovframework.dooill.service.MessageVO;

@Component
public class Scheduler {

	private static final Logger LOGGER = LoggerFactory.getLogger(EgovOthersExcepHndlr.class);
	
	/** EgovService */
	@Resource(name = "egovService")
	private EgovService egovService;

	public void Sceduler () {
		LOGGER.debug("Method = Sceduler.Sceduler()");
	}
	
	/*시도별 실시간 측정정보 조회 - 매시 15분에 시간자료 제공 - 사용안함*/
	//@Scheduled(cron = "10 17,47 * * * *") // 초 분 시 일 월 요일
	public void getApiTmslist2() {
		LOGGER.warn("Method = Scheduler.getApiTmslist2()");
		
		try {
			String tms_cd, tms_nm, dsp_dt, msr_dt, item_cd, api_cd = "";
			HashMap<String, Object> resultMap = new HashMap<String, Object>();
			
			if (System.getProperty("API_KEY") == null || System.getProperty("API_KEY").equals("")) { 
				List systemConfigList = egovService.selectQueryForList("getSystemConfigList");
				for (int x=0; x<systemConfigList.size(); x++) {
					resultMap = (HashMap)systemConfigList.get(x);
					
					if (resultMap.get("KEY") != null && resultMap.get("KEY").toString().equals("API_KEY")) {
						System.setProperty("API_KEY", resultMap.get("VAL") == null ? "" : resultMap.get("VAL").toString());
					}
				}
			}
			
			if (!System.getProperty("API_KEY").equals("")) {
			
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmm");
				Calendar cal = Calendar.getInstance();
				
				List apiTmsItem = egovService.selectQueryForList("getApiTmsItem");
				
				URL url = null;
	            HttpURLConnection conn = null;
	            BufferedReader bufferedReader;
	            StringBuilder stringBuilder;
	            String line;
	            InputSource inputSource;
	            DocumentBuilderFactory documentBuilderFactory;
	            DocumentBuilder documentBuilder;
	            Document document;
	            XPathFactory xpathFactory;
	            XPath xpath;
	            XPathExpression xPathExpression;
	            NodeList nodeList;
	            List sortedNodeList, apiItemList;
	            HashMap<String, Object> nodeMap, apiItemMap;
					
				//측정소에 해당하는 API호출 (구)
				StringBuilder urlBuilder = new StringBuilder("http://openapi.airkorea.or.kr/openapi/services/rest/ArpltnInforInqireSvc/getCtprvnRltmMesureDnsty"); /*URL*/
				urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "="+ System.getProperty("API_KEY")); /*Service Key*/
	            urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("50", "UTF-8")); /*한 페이지 결과 수 12시간*/
	            urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*페이지 번호*/
	            urlBuilder.append("&" + URLEncoder.encode("sidoName","UTF-8") + "=" + URLEncoder.encode("충남", "UTF-8")); /*측정소 이름*/
	            urlBuilder.append("&" + URLEncoder.encode("ver","UTF-8") + "=" + URLEncoder.encode("1.3", "UTF-8")); 
	            /**
	             * - 버전을 포함하지 않고 호출할 경우 : PM2.5 데이터가 포함되지 않은 원래 오퍼레이션 결과 표출.
	             * - 버전 1.0을 호출할 경우 : PM2.5 데이터가 포함된 결과 표출.
	             * - 버전 1.1을 호출할 경우 : PM10, PM2.5 24시간 예측이동 평균데이터가 포함된 결과 표출.
	             * - 버전 1.2을 호출할 경우 : 측정망 정보 데이터가 포함된 결과 표출.
	             * - 버전 1.3을 호출할 경우 : PM10, PM2.5 1시간 등급 자료가 포함된 결과 표출
	            */
	
	            url = new URL(urlBuilder.toString());
	            conn = (HttpURLConnection) url.openConnection();
	            conn.setRequestMethod("GET");
	            conn.setRequestProperty("Content-type", "application/json; charset=utf-8");
	            
	            //응답코드가 정상인경우 XML파싱
	            
	            LOGGER.debug("Response code: " + conn.getResponseCode());
	            if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
	            	bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
	            	stringBuilder = new StringBuilder();
		            while ((line = bufferedReader.readLine()) != null) {
		            	stringBuilder.append(line.replace("\t", ""));
		            }
		            bufferedReader.close();
		            conn.disconnect();
		            LOGGER.debug(">> stringBuilder.toString() = "+stringBuilder.toString());    //test
		            
		            inputSource = new InputSource(new StringReader(stringBuilder.toString()));
		            documentBuilderFactory = DocumentBuilderFactory.newInstance();
		            
		            documentBuilderFactory.setNamespaceAware(true);
		            documentBuilder = documentBuilderFactory.newDocumentBuilder();
		            document = documentBuilder.parse(inputSource);
		            
		            xpathFactory = XPathFactory.newInstance();
		            xpath = xpathFactory.newXPath();
		            xPathExpression = xpath.compile("//items/item");
		            nodeList = (NodeList)xPathExpression.evaluate(document, XPathConstants.NODESET);
		            nodeMap = new HashMap<String, Object>();
		            for (int i=0; i<nodeList.getLength(); i++) {
		                NodeList child = nodeList.item(i).getChildNodes();
		                nodeMap = new HashMap<String, Object>();
		                for (int j=0; j<child.getLength(); j++) {
		                    Node node = child.item(j);
		                    if (node.getNodeName().equals("#text")) continue; 
		                    
		                    //매일 24:00 자료를 명일 00:00 자료로 입력
		                    if (node.getNodeName().equals("dataTime")) {
		                    	//nodeMap.put("api_dt", node.getTextContent());
		                    	 
		                    	dsp_dt = simpleDateFormat.format(new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(node.getTextContent()));
		                    	nodeMap.put("dsp_dt", dsp_dt);
		        				
		        				cal.setTime(simpleDateFormat.parse(dsp_dt));
		        				cal.add(Calendar.HOUR, -1);
		        				msr_dt = simpleDateFormat.format(cal.getTime());
		        				nodeMap.put("msr_dt", msr_dt);
		                    	
		                    } else {
		                    	nodeMap.put(node.getNodeName(), node.getTextContent());
		                    }
		                    
		                    //LOGGER.debug(">> item = "+node.getNodeName()+", value = "+node.getTextContent());
		                }
		                
		                for (int x=0; x < apiTmsItem.size(); x++) {
							resultMap = (HashMap)apiTmsItem.get(x);
							tms_cd = resultMap.get("TMS_CD").toString();
							tms_nm = resultMap.get("TMS_NM").toString();
							
							if (nodeMap.get("stationName").toString().equals(tms_nm)) {
								resultMap.put("MSR_DT", nodeMap.get("msr_dt").toString());
								resultMap.put("DSP_DT", nodeMap.get("dsp_dt").toString());
								resultMap.put("MSR_VL", nodeMap.get(resultMap.get("API_CD").toString()).toString());
								
								if (nodeMap.get(resultMap.get("API_CD").toString()).toString().equals("-")) {
									resultMap.put("STATUS_CD", "8");
								} else {
									resultMap.put("STATUS_CD", "0");
								}
								
								LOGGER.debug(">> item = "+resultMap.get("TMS_NM").toString()
										+", "+resultMap.get("ITEM_CD").toString()
										+", "+resultMap.get("MSR_DT").toString()
										+", "+resultMap.get("MSR_VL").toString()
										+", "+resultMap.get("STATUS_CD").toString()
										+", "+resultMap.get("DSP_DT").toString());
								
								egovService.insertQuery("setApiItem", resultMap);
			                }
		                }
		            }
	            }
			}

		} catch (Exception e) {
			LOGGER.warn("Exception = Scheduler.getApiTmslist2() Error!");
			LOGGER.warn(e.toString());
			e.printStackTrace();
		}
	}
	
	/*시도별 실시간 측정정보 조회(2021 신규) - 매시 15분 내외  시간자료 제공*/
	@Scheduled(cron = "10 12,15,18,25 * * * *") // 초 분 시 일 월 요일     20250102 임시주석(운영서버 연결)
	public void getApiTmslistNew() {
		LOGGER.warn("Method = Scheduler.getApiTmslistNew()");
		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmm");
		//System.currentTimeMillis();
		//Date date = new Date();
		Calendar cal = Calendar.getInstance();
		//cal.setTime(date);
		
		try {
			//API Key 조회
			HashMap<String, Object> resultMap = new HashMap<String, Object>();
			
			if (System.getProperty("API_KEY") == null || System.getProperty("API_KEY").equals("")) { 
				List systemConfigList = egovService.selectQueryForList("getSystemConfigList");
				for (int x=0; x<systemConfigList.size(); x++) {
					resultMap = (HashMap)systemConfigList.get(x);
					
					if (resultMap.get("KEY") != null && resultMap.get("KEY").toString().equals("API_KEY")) {
						System.setProperty("API_KEY", resultMap.get("VAL") == null ? "qhII6rLWRaNL957rm9irttWr%2FbtbOcYJwqiyq2whjxUxH0CJOjWZIxGfxrTs3UX67yXZ2jHDcjr6wT3YP19ZIw%3D%3D" : resultMap.get("VAL").toString());
					}
				}
			}
			
			//CleanAir 측정소 및 측정소별 항목 조회
			List apiTmsItem = egovService.selectQueryForList("getApiTmsItem");
			if (apiTmsItem == null || apiTmsItem.size() < 1) return;
			
			// Airkorea API 호출
			StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/B552584/ArpltnInforInqireSvc/getCtprvnRltmMesureDnsty"); /*URL*/
			urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "="+ System.getProperty("API_KEY")); /*Service Key*/
			urlBuilder.append("&" + URLEncoder.encode("returnType","UTF-8") + "=" + URLEncoder.encode("json", "UTF-8")); /*응답형식*/
            urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("50", "UTF-8")); /*한 페이지 결과 수 12시간*/
            urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*페이지 번호*/
            urlBuilder.append("&" + URLEncoder.encode("sidoName","UTF-8") + "=" + URLEncoder.encode("충남", "UTF-8")); /*측정소 이름*/
            urlBuilder.append("&" + URLEncoder.encode("ver","UTF-8") + "=" + URLEncoder.encode("1.3", "UTF-8")); 
            LOGGER.debug("call url = "+urlBuilder.toString());
			
            URL url = new URL(urlBuilder.toString());
	        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	        
	        //추가 (운정적용 2021.10.08)
	        conn.setConnectTimeout(1000*30);
	        conn.setReadTimeout(1000*30);

	        conn.setRequestMethod("GET");
	        conn.setRequestProperty("Content-type", "application/json");
	        LOGGER.warn("Response code: " + conn.getResponseCode());
		
	        BufferedReader rd;
	        if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
	            rd = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
	        } else {
	            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream(), "UTF-8"));
	        }
		
	        StringBuilder stringBuilder = new StringBuilder();
	        String line;
	        while ((line = rd.readLine()) != null) {
	        	stringBuilder.append(line.replace("\t", ""));
	        	LOGGER.debug("line = "+line);
	        }
	        rd.close();
	        conn.disconnect();
	        LOGGER.debug(stringBuilder.toString());
	        
	        /* JSON 응답 처리 */
	        JSONObject jObject = new JSONObject(stringBuilder.toString());
	        JSONArray jArray = jObject.getJSONObject("response").getJSONObject("body").getJSONArray("items");
	        HashMap<String, Object> receiveMap = new HashMap<String, Object>();
	        
	        String stationName, dataTime, msrTime, so2Value, coValue, o3Value, no2Value, pm10Value, pm25Value, msrFlag;
	        //String msrGrade, msrGrade1h, khaiValue, khaiGrade;
	        String tms_cd, tms_nm;
	        
	        //에어코리아 측정소 정보들  
	        for (int i = 0; i < jArray.length(); i++) {
	            JSONObject obj = jArray.getJSONObject(i);
	            LOGGER.debug("obj : " + obj);
	            
	            if (obj.isNull("dataTime")) continue;
	            if (obj.isNull("stationName")) continue;
	            
	            stationName = obj.getString("stationName");
	            dataTime = simpleDateFormat.format(new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(obj.getString("dataTime")));
	            cal.setTime(simpleDateFormat.parse(dataTime));
				cal.add(Calendar.HOUR, -1);
				msrTime = simpleDateFormat.format(cal.getTime());
	            so2Value = obj.isNull("so2Value")?"-":obj.getString("so2Value");
	            coValue = obj.isNull("coValue")?"-":obj.getString("coValue");
	            o3Value = obj.isNull("o3Value")?"-":obj.getString("o3Value");
	            no2Value = obj.isNull("no2Value")?"-":obj.getString("no2Value");
	            pm10Value = obj.isNull("pm10Value")?"-":obj.getString("pm10Value");
	            pm25Value = obj.isNull("pm25Value")?"-":obj.getString("pm25Value");
	            //khaiValue = obj.isNull("khaiValue")?"-":obj.getString("khaiValue");
	            //khaiGrade = obj.isNull("khaiGrade")?"-":obj.getString("khaiGrade");
	            
	            // 클린에어 측정소 정보들 (에어코리아 측정소 정보와 비교하여 DB입력
	            for (int x=0; x < apiTmsItem.size(); x++) {
	            	resultMap = (HashMap)apiTmsItem.get(x);
					tms_cd = resultMap.get("TMS_CD").toString();
					tms_nm = resultMap.get("TMS_NM").toString();
					msrFlag = resultMap.get("API_CD").toString().replaceAll("Value", "Flag");
					//msrGrade = resultMap.get("API_CD").toString().replaceAll("Value", "Grade");
					//msrGrade1h = resultMap.get("API_CD").toString().replaceAll("Value", "Grade1h");
					
					if (stationName.toString().equals(tms_nm)) {
						resultMap.put("MSR_DT", msrTime);
						resultMap.put("DSP_DT", dataTime);
						resultMap.put("MSR_VL", obj.getString(resultMap.get("API_CD").toString()));
						
						if (obj.isNull(msrFlag)) resultMap.put("STATUS_CD", "0");
						else if (obj.getString(msrFlag).equals("점검및교정")) resultMap.put("STATUS_CD", "1");	//교정중
						else if (obj.getString(msrFlag).equals("자료이상")) resultMap.put("STATUS_CD", "2");	//동작불량
						else if (obj.getString(msrFlag).equals("통신장애")) resultMap.put("STATUS_CD", "4");	//전원단절
						else if (obj.getString(msrFlag).equals("장비점검")) resultMap.put("STATUS_CD", "8");	//보수중
						else resultMap.put("STATUS_CD", "8");
						
						/*if (obj.isNull(msrGrade)) resultMap.put("LEVEL_CD", "-");
						else if (obj.getString(msrGrade).equals("1")) resultMap.put("LEVEL_CD", "A");
						else if (obj.getString(msrGrade).equals("2")) resultMap.put("LEVEL_CD", "B");
						else if (obj.getString(msrGrade).equals("3")) resultMap.put("LEVEL_CD", "C");
						else if (obj.getString(msrGrade).equals("4")) resultMap.put("LEVEL_CD", "D");
						else resultMap.put("LEVEL_CD", "D");
						
						if (obj.isNull(msrGrade1h)) resultMap.put("LEVEL_1H_CD", "-");
						else if (obj.getString(msrGrade1h).equals("1")) resultMap.put("LEVEL_1H_CD", "A");
						else if (obj.getString(msrGrade1h).equals("2")) resultMap.put("LEVEL_1H_CD", "B");
						else if (obj.getString(msrGrade1h).equals("3")) resultMap.put("LEVEL_1H_CD", "C");
						else if (obj.getString(msrGrade1h).equals("4")) resultMap.put("LEVEL_1H_CD", "D");
						else resultMap.put("LEVEL_1H_CD", "D");*/
						
						LOGGER.debug("TMS_CD : " + resultMap.get("TMS_CD").toString());
						LOGGER.debug("TMS_NM : " + resultMap.get("TMS_NM").toString());
						LOGGER.debug("MSR_DT : " + resultMap.get("MSR_DT").toString());
						LOGGER.debug("DSP_DT : " + resultMap.get("DSP_DT").toString());
						LOGGER.debug("ITEM_CD : " + resultMap.get("ITEM_CD").toString());
						LOGGER.debug("MSR_VL : " + resultMap.get("MSR_VL").toString());
						LOGGER.debug("STATUS_CD : " + resultMap.get("STATUS_CD").toString());
						LOGGER.debug("==========================");
						
						egovService.insertQuery("setApiItem", resultMap);
					}
	            }
	        }
            
		} catch (java.net.SocketTimeoutException e) {
			LOGGER.warn("Exception = Scheduler.getApiTmslistNew() Error! : SocketTimeoutException");
			LOGGER.debug(e.toString());
			e.printStackTrace();
		} catch (java.io.IOException e) {
			LOGGER.warn("Exception = Scheduler.getApiTmslistNew() Error! : IOException");
			LOGGER.debug(e.toString());
			e.printStackTrace();
		} catch (Exception e) {
			LOGGER.warn("Exception = Scheduler.getApiTmslistNew() Error!");
			LOGGER.debug(e.toString());
			e.printStackTrace();
		} 
	}
	
	/*대기환경지수, 8식간, 24시간 평균계산*/
	@Scheduled(cron = "20 12,15,18,25 * * * *") // 초 분 시 일 월 요일	20250102 임시주석
	public void callProc() {
		LOGGER.warn("Method = Scheduler.callProc()");
		try {
			egovService.selectQueryForObject("calcCAI");
		} catch (Exception e) {
			LOGGER.warn("Exception = Scheduler.callProc() Error!");
			LOGGER.warn(e.toString());
			e.printStackTrace();
		} 
	}
	
	/* 충남도 기상정보API - 매시40분에 시간자료  서비스 */
	@Scheduled(cron = "15 40,50 * * * *") // 초 분 시 일 월 요일	20250102 임시주석
	public void callWeatherAPI() {
		LOGGER.warn("Method = Scheduler.callWeatherAPI()");
		try {
			
			HashMap<String, Object> resultMap = new HashMap<String, Object>();
			
			if (System.getProperty("API_KEY") == null || System.getProperty("API_KEY").equals("")) { 
				List systemConfigList = egovService.selectQueryForList("getSystemConfigList");
				for (int x=0; x<systemConfigList.size(); x++) {
					resultMap = (HashMap)systemConfigList.get(x);
					
					if (resultMap.get("KEY") != null && resultMap.get("KEY").toString().equals("API_KEY")) {
						System.setProperty("API_KEY", resultMap.get("VAL") == null ? "qhII6rLWRaNL957rm9irttWr%2FbtbOcYJwqiyq2whjxUxH0CJOjWZIxGfxrTs3UX67yXZ2jHDcjr6wT3YP19ZIw%3D%3D" : resultMap.get("VAL").toString());
					}
				}
			}
			
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmm");
			System.currentTimeMillis();
					
			Date date = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			
			String yyyyMMdd = simpleDateFormat.format(date);
			String HH = yyyyMMdd.substring(8,10); 
			
			//자료요청시간이 매시 40분 이전이면 1시간 이전자료를 요청 (매시40분에 시간자료  서비스)
			if (yyyyMMdd.compareTo(yyyyMMdd.substring(0,8)+HH+"40") < 0) {
				cal.add(Calendar.HOUR, -1);
				yyyyMMdd = simpleDateFormat.format(cal.getTime());
				HH = yyyyMMdd.substring(8,10); 
			}
			yyyyMMdd = yyyyMMdd.substring(0,8);
			
			//(구API 기상청_동네예보 조회서비스)
			//StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/1360000/VilageFcstInfoService/getUltraSrtNcst"); /*URL*/
			//(신API 기상청_단기예보 조회서비스:초단기실황조회)
			StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst"); /*URL*/
	        urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "="+ System.getProperty("API_KEY")); /*Service Key*/
	        urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*페이지번호*/
	        urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("10", "UTF-8")); /*한 페이지 결과 수*/
	        urlBuilder.append("&" + URLEncoder.encode("dataType","UTF-8") + "=" + URLEncoder.encode("JSON", "UTF-8")); /*요청자료형식(XML/JSON)Default: XML*/
	        urlBuilder.append("&" + URLEncoder.encode("base_date","UTF-8") + "=" + URLEncoder.encode(yyyyMMdd, "UTF-8")); /*15년 12월 1일 발표*/
	        urlBuilder.append("&" + URLEncoder.encode("base_time","UTF-8") + "=" + URLEncoder.encode(HH+"00", "UTF-8")); /*06시 발표(정시단위)*/
	        urlBuilder.append("&" + URLEncoder.encode("nx","UTF-8") + "=" + URLEncoder.encode("68", "UTF-8")); /*예보지점의 X 좌표값*/
	        urlBuilder.append("&" + URLEncoder.encode("ny","UTF-8") + "=" + URLEncoder.encode("100", "UTF-8")); /*예보지점 Y 좌표*/
	        URL url = new URL(urlBuilder.toString());
	        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	        
	        //추가 (운정적용 2021.10.08)
	        conn.setConnectTimeout(1000*30);
	        conn.setReadTimeout(1000*30);
	        
	        conn.setRequestMethod("GET");
	        conn.setRequestProperty("Content-type", "application/json");
	        LOGGER.debug("weatherAPI Response code = "+conn.getResponseCode());
	        BufferedReader rd;
	        if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
	            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	        } else {
	            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
	        }
	        
	        StringBuilder stringBuilder = new StringBuilder();
	        String line;
	        while ((line = rd.readLine()) != null) {
	        	stringBuilder.append(line.replace("\t", ""));
	        }
	        rd.close();
	        conn.disconnect();
	        LOGGER.debug("weatherAPI result = "+stringBuilder.toString());
	        
	        /* JSON 응답인 경우 */
	        JSONObject jObject = new JSONObject(stringBuilder.toString());
	        JSONArray jArray = jObject.getJSONObject("response").getJSONObject("body").getJSONObject("items").getJSONArray("item");
	        for (int i = 0; i < jArray.length(); i++) {
	            JSONObject obj = jArray.getJSONObject(i);
	            
	            String baseDate = obj.getString("baseDate");
	            String baseTime = obj.getString("baseTime");
	            String category = obj.getString("category");
	            String obsrValue = obj.getString("obsrValue");
	            //System.out.println("baseDate(" + i + "): " + baseDate);
	            //System.out.println("baseTime(" + i + "): " + baseTime);
	            //System.out.println("category(" + i + "): " + category);
	            //System.out.println("obsrValue(" + i + "): " + obsrValue);
	            //System.out.println();
	            
	            resultMap = new HashMap<String, Object>();
	            resultMap.put("msr_dt", baseDate+baseTime);
	            resultMap.put("item_cd", category);
	            resultMap.put("msr_vl", obsrValue);
	            
	            egovService.insertQuery("setWeatherList", resultMap);
	        }
	        
	        /* XML 응답인 경우
	        InputSource inputSource;
            DocumentBuilderFactory documentBuilderFactory;
            DocumentBuilder documentBuilder;
            Document document;
            XPathFactory xpathFactory;
            XPath xpath;
            XPathExpression xPathExpression;
            NodeList nodeList;
            List sortedNodeList, apiItemList;
            HashMap<String, Object> nodeMap, apiItemMap;
            
            inputSource = new InputSource(new StringReader(stringBuilder.toString()));
            documentBuilderFactory = DocumentBuilderFactory.newInstance();
            
            documentBuilderFactory.setNamespaceAware(true);
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
            document = documentBuilder.parse(inputSource);
	        
            xpathFactory = XPathFactory.newInstance();
            xpath = xpathFactory.newXPath();
            xPathExpression = xpath.compile("//items/item");
            nodeList = (NodeList)xPathExpression.evaluate(document, XPathConstants.NODESET);
            nodeMap = new HashMap<String, Object>();
            
            for (int i=0; i<nodeList.getLength(); i++) {
            	NodeList child = nodeList.item(i).getChildNodes();
                nodeMap = new HashMap<String, Object>();
                for (int j=0; j<child.getLength(); j++) {
                    Node node = child.item(j);
                    LOGGER.debug(">>>>>>> node.getNodeName() = "+node.getNodeName());
                    LOGGER.debug(">>>>>>> node.getTextContent() = "+node.getTextContent());
                }
            }*/
            
		} catch (Exception e) {
			LOGGER.warn("Exception = Scheduler.callWeatherAPI() Error!");
			LOGGER.warn(e.toString());
			e.printStackTrace();
		} 
	}
	
	/*충남연구원 SMS발송 : 서비스 신청시 주석제거 필요*/
	//@Scheduled(cron = "30 5,12,15,18,25 * * * *") // 초 분 시 일 월 요일	20250102 임시주석
	public void doSendSMS() {
		LOGGER.warn("Method = Scheduler.doSendSMS()");
		
		List smsConfigList = null;
		List receiveList = null;
		
		HashMap<String, Object> smsConfigMap = new HashMap<String, Object>();
		HashMap<String, Object> receiveMap = new HashMap<String, Object>();
		HashMap<String, Object> tempMap = new HashMap<String, Object>();
		
		List sendWarningList = null;
		List sendUserList = null;
		HashMap<String, Object> sendWarningMap = new HashMap<String, Object>();
		HashMap<String, Object> sendUserMap = new HashMap<String, Object>();
		
		try {
			//환경조회
			smsConfigList = egovService.selectQueryForList("getSmsConfig");
			for (int x=0; x<smsConfigList.size(); x++) {
				smsConfigMap = (HashMap)smsConfigList.get(x);
				if (smsConfigMap.get("SERVICE_ID") == null || smsConfigMap.get("SERVICE_ID").toString().equals("")  
						|| smsConfigMap.get("SEND_NUM") == null || smsConfigMap.get("SEND_NUM").toString().equals("")
						|| smsConfigMap.get("SERVICE_KEY") == null || smsConfigMap.get("SERVICE_KEY").toString().equals("")
						|| smsConfigMap.get("TESTMODE_YN") == null || smsConfigMap.get("TESTMODE_YN").toString().equals(""))
					break;
				
				//발송대상조회 (1시간 이전 시간자료중 경보/주의보/바쁨/매우나쁨등의 설정값에 따라 발송재상자와 경보메세지를 조회
				receiveList = egovService.selectQueryForList("getSmsReceiveList");
				if (receiveList != null) {
					for (int i=0; i<receiveList.size(); i++) {
						receiveMap = (HashMap)receiveList.get(i);
						receiveMap.get("TMS_CD");
						receiveMap.get("ITEM_CD");
						receiveMap.get("W_CD");
						receiveMap.get("ISSUE_DT");
						receiveMap.get("SEND_MSG");
						receiveMap.get("RECEIVE_NUM");

						//전송여부조회 (발송목록에서 조회되면 비전송)
						//if (egovService.selectQueryForList("getSmsResulList", sendWarningMap).size() > 0) continue;
						
						final String encodingType = "utf-8";
						final String boundary = "____boundary____";
					
						/******************** 인증정보 ********************/
						Map<String, String> sms = new HashMap<String, String>();
						String sms_url = "https://apis.aligo.in/send/"; // 전송요청 URL
						sms.put("user_id", smsConfigMap.get("SERVICE_ID").toString()); // SMS 아이디
						sms.put("key", smsConfigMap.get("SERVICE_KEY").toString()); //인증키
						sms.put("sender", smsConfigMap.get("SEND_NUM").toString()); // 발신번호
						sms.put("testmode_yn", smsConfigMap.get("TESTMODE_YN").toString()); // Y 인경우 실제문자 전송X , 자동취소(환불) 처리
						
						/******************** 전송정보 ********************/
						sms.put("title", "[경보알림]"); //  LMS, MMS 제목 (미입력시 본문중 44Byte 또는 엔터 구분자 첫라인)
						sms.put("msg", receiveMap.get("SEND_MSG").toString()); // 메세지 내용
						sms.put("receiver", receiveMap.get("RECEIVE_NUM").toString()); // 수신번호
						//sms.put("destination", "01111111111|담당자,01111111112|홍길동"); // 수신인 %고객명% 치환
						//sms.put("rdate", ""); // 예약일자 - 20161004 : 2016-10-04일기준
						//sms.put("rtime", ""); // 예약시간 - 1930 : 오후 7시30분
												
						String image = "";
						//image = "/tmp/pic_57f358af08cf7_sms_.jpg"; // MMS 이미지 파일 위치
						
						MultipartEntityBuilder builder = MultipartEntityBuilder.create();
						
						builder.setBoundary(boundary);
						builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
						builder.setCharset(Charset.forName(encodingType));
						
						for(Iterator<String> k = sms.keySet().iterator(); k.hasNext();){
							String key = k.next();
							builder.addTextBody(key, sms.get(key)
									, ContentType.create("Multipart/related", encodingType));
						}
						
						/*File imageFile = new File(image);
						if(image!=null && image.length()>0 && imageFile.exists()){
					
							builder.addPart("image",
									new FileBody(imageFile, ContentType.create("application/octet-stream"),
											URLEncoder.encode(imageFile.getName(), encodingType)));
						}*/
						
						HttpEntity entity = builder.build();
						
						CloseableHttpClient client = HttpClients.createDefault();
						HttpPost post = new HttpPost(sms_url);
						post.setEntity(entity);
						
						HttpResponse res = client.execute(post);
						
						String result = "";
						if(res != null){
							BufferedReader in = new BufferedReader(new InputStreamReader(res.getEntity().getContent(), encodingType));
							String buffer = null;
							while((buffer = in.readLine())!=null){
								result += buffer;
							}
							in.close();
						}
						LOGGER.debug("result = "+result);
					    
						/*String string = result;
						byte[] utf8 = string.getBytes("UTF-8");
						string = new String(utf8, "UTF-8");
						LOGGER.debug("result2 = "+ string);
						
						string = "\ubcf4\uc720\uac74\uc218\uac00 \ubd80\uc871\ud569\ub2c8\ub2e41.";
						utf8 = string.getBytes("UTF-8");
						string = new String(utf8, "UTF-8");
						LOGGER.debug("string = "+ string);*/
						
						String[] result_arr = result.replace("{",  "").replace("}",  "").replace("\"",  "").split(",");
						String[] result_msg = {"",""};
						for (int l=0; l<result_arr.length; l++) {
							result_msg = result_arr[l].split(":");
							receiveMap.put(result_msg[0], StringEscapeUtils.unescapeJava(result_msg[1])); 
						}
						
						//발송결과 저장
						try {
							egovService.insertQuery("setSmsresultList", receiveMap);
						} catch (Exception exception) {
							LOGGER.warn("Exception = 발송결과 입력 오류!");
							LOGGER.debug(exception.toString());
							exception.printStackTrace();
						}
						
					}
				}
			}
		} catch (Exception e) {
			LOGGER.warn("Exception = Scheduler.doSendSMS() Error!");
			LOGGER.warn(e.toString());
			e.printStackTrace();
		}
	}
	
	/*측정소별 실시간 측정정보 조회 : 사용안함*/
	//@Scheduled(cron = "10 0,10 10-21 * * *") // 초 분 시 일 월 요일
	public void getApiTmslist() {
		LOGGER.warn("Method = Scheduler.getApiTmslist()");
		
		try {
			String tms_cd, tms_nm, dsp_dt, msr_dt, item_cd, api_cd = "";
			HashMap<String, Object> resultMap = new HashMap<String, Object>();
			
			if (System.getProperty("API_KEY") == null || System.getProperty("API_KEY").equals("")) { 
				List systemConfigList = egovService.selectQueryForList("getSystemConfigList");
				for (int x=0; x<systemConfigList.size(); x++) {
					resultMap = (HashMap)systemConfigList.get(x);
					
					if (resultMap.get("KEY") != null && resultMap.get("KEY").toString().equals("API_KEY")) {
						System.setProperty("API_KEY", resultMap.get("VAL") == null ? "" : resultMap.get("VAL").toString());
					}
				}
			}
			
			if (!System.getProperty("API_KEY").equals("")) {
			
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmm");
				Calendar cal = Calendar.getInstance();
				
				List apiTmsList = egovService.selectQueryForList("getApiTmslist");
				//lastTimeList = egovService.selectQueryForList("getLastTimeList");
				
				URL url = null;
	            HttpURLConnection conn = null;
	            BufferedReader bufferedReader;
	            StringBuilder stringBuilder;
	            String line;
	            InputSource inputSource;
	            DocumentBuilderFactory documentBuilderFactory;
	            DocumentBuilder documentBuilder;
	            Document document;
	            XPathFactory xpathFactory;
	            XPath xpath;
	            XPathExpression xPathExpression;
	            NodeList nodeList;
	            List sortedNodeList, apiItemList;
	            HashMap<String, Object> nodeMap, apiItemMap;
	            
				//API를 이용하여 데이터를 받아오는 측정소 목록
				for (int x=0; x<apiTmsList.size(); x++) {
					resultMap = (HashMap)apiTmsList.get(x);
					tms_cd = resultMap.get("TMS_CD").toString();
					tms_nm = resultMap.get("TMS_NM").toString();
					
					LOGGER.debug("stationName = " + tms_nm);
					
					
					//측정소에 해당하는 API호출
					StringBuilder urlBuilder = new StringBuilder("http://openapi.airkorea.or.kr/openapi/services/rest/ArpltnInforInqireSvc/getMsrstnAcctoRltmMesureDnsty"); /*URL*/
					urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "="+ System.getProperty("API_KEY")); /*Service Key*/
					
		            urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("24", "UTF-8")); /*한 페이지 결과 수 12시간*/
		            urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*페이지 번호*/
		            urlBuilder.append("&" + URLEncoder.encode("stationName","UTF-8") + "=" + URLEncoder.encode(tms_nm, "UTF-8")); /*측정소 이름*/
		            urlBuilder.append("&" + URLEncoder.encode("dataTerm","UTF-8") + "=" + URLEncoder.encode("DAILY", "UTF-8")); /*요청 데이터기간 (하루 : DAILY, 한달 : MONTH, 3달 : 3MONTH)*/
		            urlBuilder.append("&" + URLEncoder.encode("ver","UTF-8") + "=" + URLEncoder.encode("1.3", "UTF-8")); 
		            /**
		             * - 버전을 포함하지 않고 호출할 경우 : PM2.5 데이터가 포함되지 않은 원래 오퍼레이션 결과 표출.
		             * - 버전 1.0을 호출할 경우 : PM2.5 데이터가 포함된 결과 표출.
		             * - 버전 1.1을 호출할 경우 : PM10, PM2.5 24시간 예측이동 평균데이터가 포함된 결과 표출.
		             * - 버전 1.2을 호출할 경우 : 측정망 정보 데이터가 포함된 결과 표출.
		             * - 버전 1.3을 호출할 경우 : PM10, PM2.5 1시간 등급 자료가 포함된 결과 표출
		            */
		
		            url = new URL(urlBuilder.toString());
		            conn = (HttpURLConnection) url.openConnection();
		            conn.setRequestMethod("GET");
		            conn.setRequestProperty("Content-type", "application/json; charset=utf-8");
		            
		            //응답코드가 정상인경우 XML파싱
		            
		            LOGGER.debug("Response code: " + conn.getResponseCode());
		            if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
		            	bufferedReader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
		            } else {
		                //bufferedReader = new BufferedReader(new InputStreamReader(conn.getErrorStream(), "UTF-8"));
		            	continue;
		            }
		
		            stringBuilder = new StringBuilder();
		            while ((line = bufferedReader.readLine()) != null) {
		            	stringBuilder.append(line.replace("\t", ""));
		            }
		            bufferedReader.close();
		            conn.disconnect();
		            LOGGER.debug(">> stringBuilder.toString() = "+stringBuilder.toString());    //test 
		            
		            inputSource = new InputSource(new StringReader(stringBuilder.toString()));
		            documentBuilderFactory = DocumentBuilderFactory.newInstance();
		            
		            documentBuilderFactory.setNamespaceAware(true);
		            documentBuilder = documentBuilderFactory.newDocumentBuilder();
		            document = documentBuilder.parse(inputSource);
		            
		            xpathFactory = XPathFactory.newInstance();
		            xpath = xpathFactory.newXPath();
		            xPathExpression = xpath.compile("//items/item");
		            nodeList = (NodeList)xPathExpression.evaluate(document, XPathConstants.NODESET);
		            
		            //node List를 시간 오름차순으로 소트하기위한 ArrayList 생성
		            nodeMap = new HashMap<String, Object>();
		            sortedNodeList = new ArrayList();
		            for (int i=0; i<nodeList.getLength(); i++) {
		                NodeList child = nodeList.item(i).getChildNodes();
		                nodeMap = new HashMap<String, Object>();
		                for (int j=0; j<child.getLength(); j++) {
		                    Node node = child.item(j);
		                    if (node.getNodeName().equals("#text")) continue; 
		                    
		                    //매일 24:00 자료를 명일 00:00 자료로 입력
		                    if (node.getNodeName().equals("dataTime")) {
		                    	//nodeMap.put("api_dt", node.getTextContent());
		                    	 
		                    	dsp_dt = simpleDateFormat.format(new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(node.getTextContent()));
		                    	nodeMap.put("dsp_dt", dsp_dt);
		        				
		        				cal.setTime(simpleDateFormat.parse(dsp_dt));
		        				cal.add(Calendar.HOUR, -1);
		        				msr_dt = simpleDateFormat.format(cal.getTime());
		        				nodeMap.put("msr_dt", msr_dt);
		                    	
		                    } else {
		                    	nodeMap.put(node.getNodeName(), node.getTextContent());
		                    }
		                    
		                    LOGGER.debug(">> item = "+node.getNodeName()+", value = "+node.getTextContent());
		                }
		                sortedNodeList.add(nodeMap);
		            }
	
		            //ArrayList를 소트 
		            HashMap<String, Object> tempMap = new HashMap<String, Object>();
		            for (int i=0; i<sortedNodeList.size()-1; i++) {
		            	for (int j=i+1; j<sortedNodeList.size(); j++) {
		            		if (((HashMap)sortedNodeList.get(i)).get("msr_dt").toString().compareTo(((HashMap)sortedNodeList.get(j)).get("msr_dt").toString()) > 0) {
		            			tempMap = new HashMap<String, Object>();
		            			tempMap = (HashMap)sortedNodeList.get(i);
		            			sortedNodeList.set(i, (HashMap)sortedNodeList.get(j));
		            			sortedNodeList.set(j, tempMap);
		            		}
		            	}
		            }
		            
		            //소트한 자료를 DB자료와 측정시간 비교하여 새로운 자료만 DB에 입력
		            LOGGER.debug("============================================= Start Insert");    //test 
		            HashMap<String, Object> lastTimeMap;
		            HashMap<String, Object> noReceiveTimeMap;
		            apiItemList = egovService.selectQueryForList("getApiItemList", tms_cd);
	            	
		            for (int i=0; i<sortedNodeList.size(); i++) {
		            	msr_dt = ((HashMap)sortedNodeList.get(i)).get("msr_dt").toString();
		            	
		            	for (int k=0; k<apiItemList.size(); k++) {
		            		apiItemMap = (HashMap)apiItemList.get(k);
		            		api_cd = apiItemMap.get("API_CD").toString();
		            		if (((HashMap)sortedNodeList.get(i)).get(api_cd) != null) {
		            			if (msr_dt.compareTo(apiItemMap.get("MSR_DT").toString()) > 0) {
		            				apiItemMap.put("MSR_DT", msr_dt);
		            				apiItemMap.put("MSR_VL", ((HashMap)sortedNodeList.get(i)).get(api_cd).toString());
		            				apiItemMap.put("STATUS_CD", apiItemMap.get("MSR_VL").toString().equals("-")?"4":"0");
		            				apiItemMap.put("OVER_YN", "N");
		            				apiItemMap.put("LEVEL_CD", ((HashMap)sortedNodeList.get(i)).get(api_cd.replaceAll("Value", "Grade")).toString());
		            				
		            				if (api_cd.indexOf("PM") > -1)
		            						apiItemMap.put("AVG_24", ((HashMap)sortedNodeList.get(i)).get(api_cd.replaceAll("Value", "Value24")).toString());
		            				else
		            					apiItemMap.put("AVG_24", "");
		            				
		            				apiItemMap.put("DSP_DT", ((HashMap)sortedNodeList.get(i)).get("dsp_dt").toString());
		            				
		            				LOGGER.debug(">> tms_cd : "+apiItemMap.get("TMS_CD").toString()+", "
		            						+ "item_cd : " + apiItemMap.get("ITEM_CD").toString()+", "
		            						+ "msr_dt : " + apiItemMap.get("MSR_DT").toString()+", "
		            						+ "msr_vl : " + apiItemMap.get("MSR_VL").toString()+", "
		            						+ "status_cd : " + apiItemMap.get("STATUS_CD").toString()+", "
		            						+ "over_yn : " + apiItemMap.get("OVER_YN").toString()+", "
		            						+ "level_cd : " + apiItemMap.get("LEVEL_CD").toString()+", "
		            						+ "avg_24 : " + apiItemMap.get("AVG_24").toString()+", "
		            						+ "dsp_dt : " + apiItemMap.get("DSP_DT").toString());
		            				
		            				egovService.insertQuery("setApiItem", apiItemMap);
		            			}
		            		}
		            	}
		            }
		            LOGGER.debug("============================================= End Insert");    //test
				}
			}
		} catch (Exception e) {
			LOGGER.warn("Exception = Scheduler.getApiTmslist() Error!");
			LOGGER.warn(e.toString());
            e.printStackTrace();
		}
	}
	
	//사용안함
	//@Scheduled(cron = "20 0/5 * * * *") // 초 분 시 일 월 요일  5분간격
	public void readThingPlug() throws Exception {
		LOGGER.warn("Method = readThingPlug()");
		
		try {
			URL url = new URL("https://thingplugpf.sktiot.com:9443/0100421000000631/v1_0/remoteCSE-00000631d02544fffef39b24/container-LoRa/latest");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("X-M2M-RI", "00000631d02544fffef39b24");
			conn.setRequestProperty("X-M2M-Origin", "00000631d02544fffef39b24");
			conn.setRequestProperty("ukey", "T3ZMdGZ1YTM5OWRXa3p5anE1ZkxrN3lNcnJpVWxucDJUenhnR2pNUnZqbTJrWEgrV1N6REVlMHU5UEgyRE14Ng==");
			//conn.setRequestProperty("Accept", "application/json");
            
            //응답코드가 정상인경우 XML파싱
            BufferedReader rd = null;
            LOGGER.debug("Response code: " + conn.getResponseCode());
            if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
                rd = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            } else {
                //자료요청에 대한 응답 Error
            	return;
            	
            }
            
            StringBuilder sb = new StringBuilder();
            if (rd != null) {
	            
	            String line;
	            while ((line = rd.readLine()) != null) {
	                sb.append(line.replace("\t", ""));
	            }
	            rd.close();
	            LOGGER.debug(sb.toString()); /* test */
            }
            conn.disconnect();
            
            
            DocumentBuilderFactory objDocumentBuilderFactory = null;
            DocumentBuilder objDocumentBuilder = null;
            Document doc = null;

            try{

                objDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
                objDocumentBuilder = objDocumentBuilderFactory.newDocumentBuilder();

                doc = objDocumentBuilder.parse(new InputSource(new StringReader(sb.toString())));
                
                Element root = doc.getDocumentElement(); //root 구하기
                NodeList childeren = root.getChildNodes(); // 자식 노드 목록 get
                for(int i = 0; i < childeren.getLength(); i++){
        			Node node = childeren.item(i);
        			if(node.getNodeType() == Node.ELEMENT_NODE) {
        				if (node.getNodeName().equals("con")) { 
        					System.out.println(node.getNodeName() + ":" + node.getTextContent());
        					
        					String hexString = node.getTextContent();
        					//TOOD : 1차 전문 검사 - 전문이 CR(0d)로 끝나는지 여부
        					if (hexString.substring(hexString.length()-2).equals("0d")) {

        						sb.setLength(0);
	        					String str = "";
	        				    for (int j = 4; j < hexString.length(); j += 2) {
	        				        str = hexString.substring(j, j + 2);
	        				        sb.append((char) Integer.parseInt(str, 16));
	        				    }
	        				    
	        				    if (getChecksumResult(sb.toString())) {
	        				    	LOGGER.debug(">> parsing and insert");
	        				    }       				    
        				            				    
	        				    /*String asciiString = sb.toString(); 
	        				    LOGGER.debug(">> sb.toString() = " + asciiString);
	        				    LOGGER.debug(">> sb.toString() = " + asciiString.substring(0, asciiString.length()-4));
	        				    
	        				    byte[] buffers = asciiString.substring(0, asciiString.length()-4).getBytes();
	        				    for (int j = 1; j < buffers.length; j++) {
	        				    	buffers[0] += buffers[j]; 
	        				    }
	        				    
	        				    sb.setLength(0);
	        				    sb.append((char) Integer.parseInt(Integer.toHexString(((buffers[0] & 0xf0) >>> 4) + 0x30), 16));
	        				    sb.append((char) Integer.parseInt(Integer.toHexString((buffers[0] & 0x0f) + 0x30), 16));
	        				    
	        				    if (asciiString.substring(asciiString.length()-3, asciiString.length()-1).equals(sb.toString())) {
	        				    	LOGGER.debug(">> Checksum2 compare OK");
	        				    } else {
	        				    	LOGGER.debug(">> Checksum2 different");
	        				    }
	        				    
	        				    System.out.println((char) Integer.parseInt(Integer.toHexString(((buffers[0] & 0xf0) >>> 4) + 0x30), 16));
	        				    System.out.println((char) Integer.parseInt(Integer.toHexString((buffers[0] & 0x0f) + 0x30), 16));
	        				    
	        				    //10진값
	        				    System.out.println(((buffers[0] & 0xf0) >>> 4) + 0x30);
	        				    System.out.println((buffers[0] & 0x0f) + 0x30);
	        				    
	        				    //16진값
	        				    System.out.println(Integer.toHexString(((buffers[0] & 0xf0) >>> 4) + 0x30));
	        				    System.out.println(Integer.toHexString((buffers[0] & 0x0f) + 0x30));
	        				    
	        				    //16진 문자
	        				    System.out.println((char) Integer.parseInt(Integer.toHexString(((buffers[0] & 0xf0) >>> 4) + 0x30), 16));
	        				    System.out.println((char) Integer.parseInt(Integer.toHexString((buffers[0] & 0x0f) + 0x30), 16));*/
        					
        					} else {
        						//TOOD : 1차 전문 검사 - 전문이 CR(0d)로 끝나지 않음
        						
        					}
        				} else {
        					//System.out.println(node.getNodeName());
        				}
        			} else if(node.getNodeType() == Node.TEXT_NODE) {
        				System.out.println(node.getNodeName() + ":" + node.getTextContent());
        			}
        			
                }

            }catch(Exception ex){
                throw ex;
            }
		} catch (Exception e) {
			LOGGER.warn("Exception = Scheduler.readThingPlug() Error!");
			LOGGER.warn(e.toString());
			e.printStackTrace();
		}
	}

	/*통신전문 체크썸 오류여부*/
	public boolean getChecksumResult (String data) throws Exception {
		boolean TF = false;
		
		LOGGER.debug(">> sb.toString() = " + data);
	    LOGGER.debug(">> sb.toString() = " + data.substring(0, data.length()-4));
	    
	    String orgChecksum = data.substring(data.length()-3, data.length()-1);
	    String orgString = data.substring(0, data.length()-4);
	    
	    byte[] bytes = orgString.getBytes();
	    for (int j = 1; j < bytes.length; j++) {
	    	bytes[0] += bytes[j]; 
	    }
	    
	    String cmpChecksum = (char)Integer.parseInt(Integer.toHexString(((bytes[0] & 0xf0) >>> 4) + 0x30), 16) + "" +
	    					 (char) Integer.parseInt(Integer.toHexString((bytes[0] & 0x0f) + 0x30), 16);
	    
	    if (orgChecksum.equals(cmpChecksum)) {
	    	if (insertMessage(orgString)) {
	    		TF = true;
	    	}
	    } else {
	    	LOGGER.debug(">> Error Message : The Checksum is invalid! (orgChecksum:"+orgChecksum+", cmpChecksum:"+cmpChecksum+")");
	    }
		
		return TF;
	}
	
	public boolean insertMessage (String message) throws Exception {
		//TODO : Message Parsing and DB Insert
		boolean TF = false;
		int idx = 0;
		
		MessageVO messageVO = new MessageVO();
		
		messageVO.setReport_id(message.substring(idx, idx+=4));
		
		messageVO.setTms_cd(message.substring(idx, idx+=6));
		
		messageVO.setFacility_no(message.substring(idx, idx+=3));
		
		messageVO.setDcd_cd(message.substring(idx, idx+=1));
		
		int item_cnt = Integer.parseInt(message.substring(idx, idx+=2));
		
		messageVO.setMsr_dt(message.substring(idx, idx+=12));
		
		if (message.length() == (item_cnt * 11 + idx)) {

			for (int i = 0; i < item_cnt; i++) {
				messageVO.setItem_cd(message.substring(idx, idx+=3));
				
				messageVO.setMsr_vl(message.substring(idx, idx+=7).trim());
				
				messageVO.setStatus_cd(message.substring(idx, idx+=1));
				
				/*if (messageVO.getReport_id().equals("RD05"))
					egovService.insertMessage("egovDAO.insertMinuteMessage", messageVO);
				else
					egovService.insertMessage("egovDAO.insertHalfHourMessage", messageVO);*/
		    }
			TF = true;
		} else {
			LOGGER.debug(">> Error Message : The message length is invalid! (message.length = "+message.length()+", calcLength = )"+(item_cnt * 11 + idx));
			
		}
		
		return TF;
	}
	
	/*마울대기측정망(CleanAirOpenAPI) : 테스트 CNI API test용 */
	//@Scheduled(cron = "10 0/5 * * * *") // 초 분 시 일 월 요일
	public void getCleanAirAPITest() {
		LOGGER.warn("Method = Scheduler.getCleanAirAPITest()");
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
			//System.currentTimeMillis();
					
			Date date = new Date();
			Calendar cal = Calendar.getInstance();
			cal.setTime(date);
			
			StringBuilder urlBuilder = new StringBuilder("http://192.168.10.14/api/data/getApiRealTimeData.ax"); /*URL*/
			urlBuilder.append("?" + URLEncoder.encode("key","UTF-8") + "=c53ef29fae5c1bd3ac7fc824166fab2b"); /*Service Key*/
			
            
            LOGGER.debug("call url = "+urlBuilder.toString());
            
	        URL url = new URL(urlBuilder.toString());
	        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	        conn.setRequestMethod("GET");
	        conn.setRequestProperty("Content-type", "application/json");
	        LOGGER.debug("Response code: " + conn.getResponseCode());
	        
	        BufferedReader rd;
	        if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
	            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	        } else {
	            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
	        }
	        
	        StringBuilder stringBuilder = new StringBuilder();
	        String line;
	        while ((line = rd.readLine()) != null) {
	        	stringBuilder.append(line.replace("\t", ""));
	        }
	        rd.close();
	        conn.disconnect();
	        LOGGER.debug(stringBuilder.toString());
	        
	        /* JSON 응답인 경우 */
	        JSONObject jObject = new JSONObject(stringBuilder.toString());
	        JSONArray jArray = jObject.getJSONArray("item");
	        for (int i = 0; i < jArray.length(); i++) {
	            JSONObject obj = jArray.getJSONObject(i);
	            
	            //LOGGER.debug("obj : " + obj);
	            LOGGER.debug("DSP_DT : " + simpleDateFormat.format(new SimpleDateFormat("yyyyMMddHHmm").parse(obj.getString("DSP_DT"))));
	            LOGGER.debug("TMS_NM : " + obj.getString("TMS_NM"));
	            LOGGER.debug("ITEM_NM : " + obj.getString("ITEM_NM"));
	            LOGGER.debug("MSR_VL : " + obj.getString("MSR_VL"));
	            LOGGER.debug("STATUS_NM : " + obj.getString("STATUS_NM"));
	        }

		} catch (Exception e) {
			LOGGER.warn("Exception = Scheduler.getCleanAirAPITest() Error!");
			LOGGER.warn(e.toString());
			e.printStackTrace();
		} 
	}
}

	
