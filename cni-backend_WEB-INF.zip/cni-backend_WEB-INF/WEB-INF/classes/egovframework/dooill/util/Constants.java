package egovframework.dooill.util;

/**
 * @Class Name : Constants.java
 * @Description : 
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 *
 * @author Shin D.Y
 * @since 2020. 10.18
 * @version 1.0
 * @see
 *
 *  Copyright (C) by MOPAS All right reserved.
 */
public class Constants {
    
    public final static String[][] NET_ARRAY = {{"국가대기", "A"}, {"마을대기", "C"}};
    public final static String[][] ITEM_ARRAY = {{"PM2.5", "PM2", "㎍/㎥", "0"}, {"PM10", "PMb", "㎍/㎥", "0"}, {"오존", "O3b", "ppm", "3"}, {"이산화질소", "NO2", "ppm", "3"}, {"일산화질소", "COb", "1"}, {"아황산가스", "SO2", "ppm", "3"}};
    public final static String[] ITEM_PM_ARRAY = {"PM2", "PMb", "O3b"};
    public final static String[][] ITEM_PM_ARRAY2 = {{"PM2.5", "PM2"}, {"PM10", "PMb"}};
    public final static String[][] ITEM_ARRAY2 = {{"PM2.5", "PM2"}, {"PM10", "PMb"}, {"O3", "O3b"}};
    public final static Integer PAGE_SIZE = 10;

	/**
	 * jsp 기본 폴더명
	 * @author admin
	 *
	 */
	public enum VIEW_APP {
		// 대기 데이터 테이블명
	    NAME("cni"),
        DOWNLOAD("downloadView"),
	    CHART_IMAGE("chartImageView");
        
        public String value;
        
        VIEW_APP(String val) {
            this.value = val;
        }
        
        public String toString() {
            return value;
        }
	}
}
