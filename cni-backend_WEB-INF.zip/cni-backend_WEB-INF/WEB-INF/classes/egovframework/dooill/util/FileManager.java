package egovframework.dooill.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

public class FileManager {

	private MultipartFile fileupload;
	public MultipartFile getFileupload() {
	    return fileupload;
	}
	public void setFileupload(MultipartFile fileupload) {
	    this.fileupload = fileupload;
	}
	
		
	
	public boolean doDownload(HttpServletRequest request, HttpServletResponse response, String downDir) {

		boolean downloadTF = false;
		String filePath = "D://data";
		
		/*String orgFileName = request.getParameter("orgFileName");
		String downFileName = request.getParameter("downFileName");
		downFileName = downFileName.substring(downFileName.lastIndexOf("\\")+1);
		downFileName = downFileName.substring(downFileName.lastIndexOf("/")+1);*/
		
		String orgFileName = "ListExampleLandscape1.pdf";
		String downFileName = "ListExampleLandscape1.pdf";
		downDir = "201811";
		
		FileInputStream filestream = null;
		OutputStream outStream = null;
		try {
			//System.out.println("S = "+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new java.util.Date()));
			//파일 객체를 스트림으로 불러온다. 
			System.out.println(">>> File = "+filePath + File.separator + "files" +File.separator + downDir +File.separator + downFileName);
			
			File downFile = new File(filePath + File.separator + "files" +File.separator + downDir +File.separator + downFileName);
			filestream = new FileInputStream(downFile); 
			
			// 응답 스트림 객체를 생성한다. 
			orgFileName = new String(orgFileName.getBytes("euc-kr"),"8859_1");
			response.setHeader("Content-Disposition","attachment; filename="+orgFileName);
			outStream = response.getOutputStream(); 
			
			byte[] buffer = new byte[1024];            
			int readBytes;            
			while ((readBytes = filestream.read(buffer)) != -1) {                
				// 응답 스트림에 파일 바이트 배열을 쓴다.
				outStream.write(buffer, 0, readBytes);            
			}
			downloadTF = true;
			filestream.close();
			outStream.close(); 
		} catch (Exception e) {
			e.printStackTrace(); 
		} finally {            
			try {                
				if (filestream != null) filestream.close();                
				if (outStream != null) outStream.close();                
			} catch (IOException e) {                
				e.printStackTrace();            
			}        
		}
		return downloadTF;

	}

}
