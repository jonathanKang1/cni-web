package egovframework.dooill.web;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.fontbox.ttf.TrueTypeCollection;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.PDPageContentStream.AppendMode;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.documentinterchange.taggedpdf.PDTableAttributeObject;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFCell;
import org.apache.poi.xssf.streaming.SXSSFRow;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;
import org.springmodules.validation.commons.DefaultBeanValidator;

import be.quodlibet.boxable.BaseTable;
import be.quodlibet.boxable.Cell;
import be.quodlibet.boxable.HorizontalAlignment;
import be.quodlibet.boxable.Row;
import be.quodlibet.boxable.VerticalAlignment;
import be.quodlibet.boxable.utils.PDStreamUtils;
import egovframework.dooill.cmmn.EgovOthersExcepHndlr;
import egovframework.dooill.service.BoardDefaultVO;
import egovframework.dooill.service.BoardVO;
import egovframework.dooill.service.EgovService;
import egovframework.dooill.util.Encryption;
import egovframework.rte.fdl.property.EgovPropertyService;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/**
 * @Class Name : EgovSampleController.java
 * @Description : EgovSample Controller Class
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2009.03.16           최초생성
 *
 * @author 개발프레임웍크 실행환경 개발팀
 * @since 2009. 03.16
 * @version 1.0
 * @see
 *
 *  Copyright (C) by MOPAS All right reserved.
 */

@Controller
public class EgovController {

	private static final Logger LOGGER = LoggerFactory.getLogger(EgovOthersExcepHndlr.class);
	
	/** EgovService */
	@Resource(name = "egovService")
	private EgovService egovService;

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/** Validator */
	@Resource(name = "beanValidator")
	protected DefaultBeanValidator beanValidator;
	
	@Value("${FILE_PATH}") 
	private String filePath;

	/* 서버기동시 자동실행 */
	/*@PostConstruct
	public void init() {
		try {
			LOGGER.debug("filePath = " + filePath);
		} catch (Exception e) {
			LOGGER.warn(e.toString());
			e.printStackTrace();
		} finally {
			
		}
    }*/
	
	/*cni 공통메서드*/
	/*공통 : 연도콤보 2020년부터 현재년도까지 */
	@RequestMapping(value="/comm/getyearList.ax")
	public Map<String,Object> getyearList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getyearList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		List resultList = egovService.selectQueryForList("getyearList");
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "등록자료가 없습니다.");
		}
		return resultMap;
	}
	/*공통 : 시군 목록 (use_yn = Y)*/
	@RequestMapping(value="/comm/getUseRegionList.ax")
	public Map<String,Object> getUseRegionList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getUseRegionList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		List<?> resultList = egovService.selectQueryForList("getUseRegionList", requestMap);
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
			resultMap.put("data", resultList);
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "등록자료가 없습니다.");
		}
		return resultMap;
	}
	/*공통 : 측정소 목록 (use_yn = Y)*/
	@RequestMapping(value="/comm/getUseTmsList.ax")
	public Map<String,Object> getUseTmsList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getUseTmsList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (requestMap.get("user_id") == null)
			requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());

		if (requestMap.get("platform_type") == null)
			requestMap.put("platform_type", "C");
		
		String sql_id = "getUseTmsList";
		if (requestMap.get("platform_type").toString().equals("M")) {
			sql_id = "getMUseTmsList";
		} 
		List<?> resultList = egovService.selectQueryForList(sql_id, requestMap);
	
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
			resultMap.put("data", resultList);
		} else {
			resultMap.put("code", 404);
			//resultMap.put("msg", "등록자료가 없습니다.");
		}
		return resultMap;
	}
	/*공통 : 측정항목정보 목록 (use_yn = Y)*/
	@RequestMapping(value="/comm/getItemList.ax")
	public Map<String,Object> getItemList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getItemList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		List<?> resultList = egovService.selectQueryForList("getItemList", requestMap);
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
			resultMap.put("data", resultList);
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "등록자료가 없습니다.");
		}
		return resultMap;
	}
	/*공통 : 측정소별측정항목정보 목록 (use_yn = Y)*/
	@RequestMapping(value="/comm/getUseItemList.ax")
	public Map<String,Object> getUseItemList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getUseItemList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		List<?> resultList = egovService.selectQueryForList("getUseItemList", requestMap);
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
			resultMap.put("data", resultList);
		} else {
			resultMap.put("code", 404);
			//resultMap.put("msg", "등록자료가 없습니다.");
		}
		return resultMap;
	}
	/*공통 : 측정기상태정보 목록 (use_yn = Y)*/
	@RequestMapping(value="/comm/getUseStatusList.ax")
	public Map<String,Object> getUseStatusList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getUseStatusList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		List<?> resultList = egovService.selectQueryForList("getUseStatusList", requestMap);
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
			resultMap.put("data", resultList);
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "등록자료가 없습니다.");
		}
		return resultMap;
	}

/*cni 대시보드*/	
	/* 대시보드>지도 : 통합대기환경 지도 */
	@RequestMapping(value="/dashboard/getDashboardNowMapList.ax", method=RequestMethod.POST)
	public Map<String,Object> getDashboardNowMapList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getDashboardNowMapList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		//requestMap.put("item_cd", System.getProperty("DASHBOARD_ITEM")==null?"PM2":System.getProperty("DASHBOARD_ITEM"));
		//requestMap.put("data_type", request.getSession().getAttribute("MONITOR_DATA_TYPE").toString());
		//requestMap.put("user_id", requestMap.get("user_id")==null?request.getSession().getAttribute("USER_ID").toString():requestMap.get("user_id").toString());
		
		List resultList = egovService.selectQueryForList("getDashboardNowMapList", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "측정자료가 없습니다.");
		}
		return resultMap;
	}
	/* 대시보드>뉴 그래프 24 */
	@RequestMapping(value="/dashboard/getDashboardGraphList.ax", method=RequestMethod.POST)
	public Map<String,Object> getDashboardGraphList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getDashboardGraphList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		List resultList = egovService.selectQueryForList("getDashboardGraphList", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "측정자료가 없습니다.");
		}
		return resultMap;
	}
	/* 대시보드>뉴 레이더차트 시리즈 */
	@RequestMapping(value="/dashboard/getDashboardRadarChartSeries.ax", method=RequestMethod.POST)
	public Map<String,Object> getDashboardRadarChartSeries(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getDasgetDashboardRadarChartSerieshboardNowMapList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		List resultList = egovService.selectQueryForList("getDashboardRadarChartSeries", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "측정자료가 없습니다.");
		}
		return resultMap;
	}
	/* 대시보드 : 지도 - 지역(시군구)별 통합대기환경 */
	@RequestMapping(value="/dashboard/getDashboardMapRegionList.ax", method=RequestMethod.POST)
	public Map<String,Object> getDashboardMapRegionList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getDashboardMapRegionList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		//requestMap.put("item_cd", System.getProperty("DASHBOARD_ITEM")==null?"PM2":System.getProperty("DASHBOARD_ITEM"));
		//requestMap.put("data_type", request.getSession().getAttribute("MONITOR_DATA_TYPE").toString());
		if (requestMap.get("user_id") == null)
			requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		List resultList = egovService.selectQueryForList("getDashboardMapRegionList", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "측정자료가 없습니다.");
		}
		return resultMap;
	}
	/* 대시보드 : 지역측정소 CAI 그래프 */
	@RequestMapping(value="/dashboard/getCAIRealTimeGraphList.ax")
	public Map<String,Object> getCAIRealTimeGraphList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getCAIRealTimeGraphList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (requestMap.get("user_id") == null)
			requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		List resultList = egovService.selectQueryForList("getCAIRealTimeGraphList", requestMap);

		resultMap.put("data", resultList);
		resultMap.put("code", 200);
		return resultMap;
	}
	/* 대시보드 : 목록 - 지역별 측정소별 통합대기환경 */
	@RequestMapping(value="/dashboard/getDashboardRegionTMSList.ax", method=RequestMethod.POST)
	public Map<String,Object> getDashboardRegionTMSList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getDashboardRegionTMSList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		egovService.selectQueryForObject("calcCAI");
		
		if (requestMap.get("user_id") == null)
			requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		List resultList = egovService.selectQueryForList("getDashboardRegionTMSList", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {   
			resultMap.put("code", 404);
			resultMap.put("msg", "측정자료가 없습니다.");
		}
		return resultMap;
	}
	/* 대시보드 : 목록 - 측정소 통합대기환경 24시간 리스트 */
	@RequestMapping(value="/dashboard/getDashboardRegionTMS24List.ax", method=RequestMethod.POST)
	public Map<String,Object> getDashboardRegionTMS24List(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getDashboardRegionTMS24List()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		List resultList = egovService.selectQueryForList("getDashboardRegionTMS24List", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "측정자료가 없습니다.");
		}
		return resultMap;
	}
	/* 대시보드 : 측정소 통합대기환경 환경설정 */
	@RequestMapping(value="/dashboard/setUserConfig.ax")
	public Map<String,Object> setUserConfig(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.setUserConfig()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		if (requestMap.get("user_id") == null)
			requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
			try {
				//writeProperties(request);
				
				if (requestMap.get("sound_yn") != null && requestMap.get("sound_yn").toString().equals("on")) requestMap.put("sound_yn", "Y");
				else requestMap.put("sound_yn", "N");
				if (requestMap.get("alert_yn") != null && requestMap.get("alert_yn").toString().equals("on")) requestMap.put("alert_yn", "Y");
				else requestMap.put("alert_yn", "N");
				
				//사용자정보 업데이트
				egovService.updateQuery("setUserConfig", requestMap);

				request.getSession().setAttribute("SOUND_YN", requestMap.get("sound_yn").toString());
				request.getSession().setAttribute("ALERT_YN", requestMap.get("alert_yn").toString());
				request.getSession().setAttribute("S_TM", requestMap.get("s_tm").toString());
				request.getSession().setAttribute("E_TM", requestMap.get("e_tm").toString());
				request.getSession().setAttribute("DASHBOARD_ITEM", requestMap.get("dashboard_item").toString());
				request.getSession().setAttribute("DASHBOARD_ITEM_NM", requestMap.get("dashboard_item_nm").toString());
				
				resultMap.put("code", 200);
			} catch (Exception e) {
				resultMap.put("code", 500);
				resultMap.put("msg", "모니터링 환경설정에 실패하였습니다.");
				e.printStackTrace();
			}
		//}
		
		return resultMap;
	}
	/* 대시보드 : 지도 - 지역별측정소 및 측정자료 */
	@RequestMapping(value="/dashboard/getDashboardMapTmsList.ax", method=RequestMethod.POST)
	public Map<String,Object> getDashboardMapTmsList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getDashboardMapTmsList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		//requestMap.put("item_cd", System.getProperty("DASHBOARD_ITEM")==null?"PM2":System.getProperty("DASHBOARD_ITEM"));
		//requestMap.put("data_type", request.getSession().getAttribute("MONITOR_DATA_TYPE").toString());
		//requestMap.put("user_id", requestMap.get("user_id")==null?request.getSession().getAttribute("USER_ID").toString():requestMap.get("user_id").toString());
		
		List resultList = egovService.selectQueryForList("getDashboardMapTmsList", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "측정자료가 없습니다.");
		}
		return resultMap;
	}
	/* 대시보드 : 지역상세 그래프 */
	@RequestMapping(value="/dashboard/getRealTimeGraphList.ax")
	public Map<String,Object> getRealTimeGraphList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getRealTimeGraphList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("user_id", request.getSession().getAttribute("USER_ID")==null?"":request.getSession().getAttribute("USER_ID").toString());
		List resultList = egovService.selectQueryForList("getRealTimeGraphList", requestMap);

		resultMap.put("data", resultList);
		resultMap.put("code", 200);
		return resultMap;
	}
	/* 대시보드 : 지역상세 리스트 */
	@RequestMapping(value="/dashboard/getRegionTmsData.ax")
	public Map<String,Object> getRegionTmsData(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getRegionTmsData()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		requestMap.put("item_cd", System.getProperty("DASHBOARD_ITEM")==null?"PM2":System.getProperty("DASHBOARD_ITEM"));
		//requestMap.put("data_type", request.getSession().getAttribute("MONITOR_DATA_TYPE").toString());
		requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		
		List resultList = egovService.selectQueryForList("getRegionTmsData", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "측정자료가 없습니다.");
		}
		return resultMap;
	}
	/* 대시보드 : 현황 */
	@RequestMapping(value="/dashboard/getStatus.ax")
	public Map<String,Object> getStatus(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getStatus()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		requestMap.put("item_cd", requestMap.get("item_cd")==null?(System.getProperty("DASHBOARD_ITEM")==null?"CAI":System.getProperty("DASHBOARD_ITEM")):requestMap.get("item_cd").toString());
		
		try {
			resultMap = (HashMap)egovService.selectQueryForObject("getStatus", requestMap);
			if (resultMap == null) {
				resultMap.put("code", 404);
				resultMap.put("msg", "조회자료가 없습니다.");
			} else {
				resultMap.put("code", 200);
			}
		} catch (Exception e) {
			resultMap.put("code", 500);
			resultMap.put("msg", "자료조회에 오류가 발생하였습니다.");
			e.printStackTrace();
		}
		return resultMap;
	}
	
/*cni 자료조회*/	
	/*자료조회 : 측정자료조회*/
	@RequestMapping(value="/data/getDataList.ax")
	public Map<String,Object> getDataList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getDataList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));

		if (requestMap.get("data_type")==null) {
			requestMap.put("data_type", "H");
		}
		
		if (requestMap.get("item_nms") != null) {
			String[] tempArr = requestMap.get("item_nms").toString().split(":");
			String item_nms = "'empty'";
			for (String temp : tempArr ){
				item_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("item_nms", item_nms);
		}
		if (requestMap.get("status_nms") != null) {
			String[] tempArr = requestMap.get("status_nms").toString().split(":");
			String status_nms = "'empty'";
			for (String temp : tempArr ){
				status_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("status_nms", status_nms);
		}
		
		List<?> resultList = egovService.selectQueryForList("getDataList", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	/*자료조회 : 측정자료 엑셀다운*/
	@RequestMapping(value = "/data/getExcelList.do")
	public ModelAndView getExcelList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getExcelList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		//HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		/*SimpleDateFormat df1 = new SimpleDateFormat("E M d y HH:mm:ss z");
		Date date = df1.parse(requestMap.get("s_date").toString());
		SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");
		LOGGER.debug(">>>>>>>> "+df2.format(date));*/
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		
		if (requestMap.get("item_nms") != null) {
			String[] tempArr = requestMap.get("item_nms").toString().split(":");
			String item_nms = "'empty'";
			for (String temp : tempArr ){
				item_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("item_nms", item_nms);
		}
		if (requestMap.get("status_nms") != null) {
			String[] tempArr = requestMap.get("status_nms").toString().split(":");
			String status_nms = "'empty'";
			for (String temp : tempArr ){
				status_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("status_nms", status_nms);
		}
		
		List<?> resultList = egovService.selectQueryForList("getDataList", requestMap);
		
		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("report/listExcelDown");// setViewName() 메서드를 이용하여 뷰 이름을 지정	
		mv.getModel().put("list", resultList);
		mv.getModel().put("region_nm", requestMap.get("region_nm").toString());
		mv.getModel().put("tms_nm", requestMap.get("tms_nm").toString());
		mv.getModel().put("data_type_nm", requestMap.get("data_type_nm").toString());
		mv.getModel().put("term", "기간: "+sd+" ~ "+ed);
		
		return mv;
	}
	/*자료조회 : 측정자료 PDF다운*/
	@RequestMapping(value = "/data/getPDFList.do")
	public void getPDFList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getPDFList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		
		if (requestMap.get("item_nms") != null) {
			String[] tempArr = requestMap.get("item_nms").toString().split(":");
			String item_nms = "'empty'";
			for (String temp : tempArr ){
				item_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("item_nms", item_nms);
		}
		if (requestMap.get("status_nms") != null) {
			String[] tempArr = requestMap.get("status_nms").toString().split(":");
			String status_nms = "'empty'";
			for (String temp : tempArr ){
				status_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("status_nms", status_nms);
		}
		
		List<?> resultList = egovService.selectQueryForList("getDataList", requestMap);
		
		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		if (resultList != null && resultList.size() > 0) {
			
			float POINTS_PER_INCH = 72;
			float POINTS_PER_MM = 1 / (10 * 2.54f) * POINTS_PER_INCH;
			
			PDDocument document = new PDDocument();
			
			//PDPage page = new PDPage(PDRectangle.A4);
			//PDPage page = new PDPage(new PDRectangle(PDRectangle.A4.getHeight(), PDRectangle.A4.getWidth()));
			PDPage page = new PDPage(new PDRectangle(297 * POINTS_PER_MM, 210 * POINTS_PER_MM));
			
			//PDPageContentStream contentStream = new PDPageContentStream(document, page);
			PDRectangle rect = page.getMediaBox();
			File fontFile = new File(request.getSession().getServletContext().getRealPath("/") + File.separator + "fonts"  + File.separator + "GULIM.TTC");
			PDType0Font fontGulim = PDType0Font.load(document, new TrueTypeCollection(fontFile).getFontByName("Gulim"), true);
			
			document.addPage(page);
			
			boolean drawLines = true;
			boolean drawContent = true;
			float margin = 50;
			float yStartNewPage = page.getMediaBox().getHeight() - margin;
			float tableWidth = page.getMediaBox().getWidth() - (2 * margin);
			float bottomMargin = 50;
			float topMargin = page.getMediaBox().getHeight() - margin;
			
			BaseTable table = new BaseTable(yStartNewPage, topMargin, bottomMargin, tableWidth, margin, document, page, drawLines, drawContent);
			
			Row<PDPage> headerRow = null;
			Cell<PDPage> cell = null;
			
			headerRow = table.createRow(50);
			cell = headerRow.createCell(100, "측정자료 리포트");
			cell.setFont(fontGulim);
			cell.setFontSize(20);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "지역명: "+requestMap.get("region_nm").toString());
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "측정소명: "+requestMap.get("tms_nm").toString());
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "조회기간: "+sd+" ~ "+ed);
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setTopBorderStyle(null);
			cell.setLeftBorderStyle(null);
			cell.setRightBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(14, "측정시간");
			cell.setFont(fontGulim);
			cell.setFontSize(12);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "측정항목");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "측정값");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "측정상태");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "등급");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "기준초과");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(10, "8h 평균");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(10, "24h 평균");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);

			cell = headerRow.createCell(11, "대기환경지수");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			table.addHeaderRow(headerRow);
			
			Row<PDPage> row = null;
			for (int i=0; i<resultList.size(); i++) {
				resultMap = (HashMap)resultList.get(i);
				//dsp_dt, item_nm, msr_vl, msr_vl_unit, status_nm
				row = table.createRow(20);
				
				cell = row.createCell(14, resultMap.get("DSP_DT").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(11, resultMap.get("ITEM_NM")==null?"-":resultMap.get("ITEM_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(11, (resultMap.get("MSR_VL")==null?"-":resultMap.get("MSR_VL").toString())+(resultMap.get("ITEM_UNIT")==null?"-":resultMap.get("ITEM_UNIT").toString()));
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(11, resultMap.get("STATUS_NM")==null?"-":resultMap.get("STATUS_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(11, resultMap.get("LEVEL_NM")==null?"-":resultMap.get("LEVEL_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(11, resultMap.get("OVER_NM")==null?"-":resultMap.get("OVER_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(10, resultMap.get("AVG_08")==null?"-":resultMap.get("AVG_08").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(10, resultMap.get("AVG_24")==null?"-":resultMap.get("AVG_24").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(11, (resultMap.get("AI_VL")==null?"-":resultMap.get("AI_VL").toString())+" ("+(resultMap.get("AI_LV_NM")==null?"-":resultMap.get("AI_LV_NM").toString())+")");
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
			}
			table.draw();
			//contentStream.close();
			//System.out.println("document.getNumberOfPages() = "+document.getNumberOfPages());
			
			//PDImageXObject pdImage = PDImageXObject.createFromFile(request.getSession().getServletContext().getRealPath("/")+File.separator+"images"+File.separator+"BBP8xP3.jpg", document);
			
			for (int i = 0; i < document.getNumberOfPages(); i++) {
				/*PDPageContentStream footercontentStream = new PDPageContentStream(document, document.getPage(i), AppendMode.APPEND, true);
				footercontentStream.beginText();
				footercontentStream.setFont(fontGulim, 10);
				footercontentStream.newLineAtOffset((document.getPage(i).getMediaBox().getWidth() / 2 - 20), 30);
				footercontentStream.showText("- "+String.valueOf(i + 1)+" / "+document.getNumberOfPages()+" -");
				footercontentStream.endText();
				footercontentStream.close();*/
				
				String company_name = System.getProperty("COMPANY_NAME")==null?"두일테크":System.getProperty("COMPANY_NAME");
				PDPageContentStream contentStream = new PDPageContentStream(document, document.getPage(i), AppendMode.APPEND, true);
				//PDStreamUtils.write(PDPageContentStream stream, String text, PDFont font, float fontSize, float x, float y, Color color)
				PDStreamUtils.write(contentStream, company_name, fontGulim, 10, 50, document.getPage(i).getMediaBox().getHeight()-30, new Color(102, 102, 102));
				PDStreamUtils.write(contentStream, "- "+String.valueOf(i + 1)+" / "+document.getNumberOfPages()+" -", fontGulim, 10, document.getPage(i).getMediaBox().getWidth() / 2 - 20, 30, new Color(102, 102, 102));
				
	            contentStream.close();
	        }
			
			response.setHeader("Content-Type", "application/force-download");
			response.addHeader("Content-Disposition","attachment; filename=DataReport.pdf");
			document.save(response.getOutputStream());
			document.close();
		}
	}
	/*자료조회 : 측정자료조회2*/
	@RequestMapping(value="/data/getData2List.ax")
	public Map<String,Object> getData2List(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getData2List()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));

		if (requestMap.get("data_type")==null) {
			requestMap.put("data_type", "H");
		}
		
		if (requestMap.get("item_nms") != null) {
			String[] tempArr = requestMap.get("item_nms").toString().split(":");
			String item_nms = "'empty'";
			for (String temp : tempArr ){
				item_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("item_nms", item_nms);
		}
		if (requestMap.get("status_nms") != null) {
			String[] tempArr = requestMap.get("status_nms").toString().split(":");
			String status_nms = "'empty'";
			for (String temp : tempArr ){
				status_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("status_nms", status_nms);
		}
		
		List<?> resultList = egovService.selectQueryForList("getData2List", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	/*자료조회 : 측정자료 엑셀다운*/
	@RequestMapping(value = "/data/getExcelList2.do")
	public ModelAndView getExcelList2(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getExcelList2()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		
		if (requestMap.get("item_nms") != null) {
			String[] tempArr = requestMap.get("item_nms").toString().split(":");
			String item_nms = "'empty'";
			for (String temp : tempArr ){
				item_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("item_nms", item_nms);
		}
		if (requestMap.get("status_nms") != null) {
			String[] tempArr = requestMap.get("status_nms").toString().split(":");
			String status_nms = "'empty'";
			for (String temp : tempArr ){
				status_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("status_nms", status_nms);
		}
		
		List<?> resultList = egovService.selectQueryForList("getData2List", requestMap);
		
		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("report/listExcel2Down");// setViewName() 메서드를 이용하여 뷰 이름을 지정	
		mv.getModel().put("list", resultList);
		mv.getModel().put("region_nm", requestMap.get("region_nm").toString());
		mv.getModel().put("tms_nm", requestMap.get("tms_nm").toString());
		mv.getModel().put("data_type_nm", requestMap.get("data_type_nm").toString());
		mv.getModel().put("term", "기간: "+sd+" ~ "+ed);
		
		return mv;
	}
	/*자료조회 : 통합대기환경지수*/
	@RequestMapping(value="/data/getCaiData.ax")
	public Map<String,Object> getCaiData(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getCaiData()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		
		List<?> resultList = egovService.selectQueryForList("getCaiData", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	/*자료조회 : 통합대기환경지수 엑셀*/
	@RequestMapping(value="/data/getCaiDataExcel.do")
	public void getCaiDataExcel(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getCaiDataExcel()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (requestMap.get("user_id") == null) requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		
		
		List<?> resultList = egovService.selectQueryForList("getUseTmsList", requestMap);
		if (resultList != null && resultList.size() > 0) {
		
			SXSSFWorkbook wb = new SXSSFWorkbook();
			SXSSFSheet sheet = wb.createSheet("통합대기환경지수");
		
			CellStyle cellStyle = wb.createCellStyle();
			cellStyle.setAlignment(org.apache.poi.ss.usermodel.HorizontalAlignment.CENTER);
			cellStyle.setVerticalAlignment(org.apache.poi.ss.usermodel.VerticalAlignment.CENTER);
			//배경색채우기
			//cellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
			//cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			
			int cell_idx = -2;
			SXSSFRow headerRow = sheet.createRow(0);
			SXSSFCell cell = headerRow.createCell(0);
			cell.setCellStyle(cellStyle);
			cell.setCellValue("측정시간");
			//headerRow.createCell(0).setCellValue("측정시간");
			
			for (int i = 0; i < resultList.size(); i++) {
				Map<String, Object> tmsMap = (Map<String, Object>)resultList.get(i);
				cell = headerRow.createCell(cell_idx+=3);
				cell.setCellStyle(cellStyle);
				cell.setCellValue(tmsMap.get("TMS_NM").toString());
				//headerRow.createCell(cell_idx+=3).setCellValue(tmsMap.get("TMS_NM").toString());
				sheet.addMergedRegion(new CellRangeAddress(0,0,cell_idx,cell_idx+2));
			}
			headerRow = sheet.createRow(1);
			sheet.addMergedRegion(new CellRangeAddress(0,1,0,0));
			cell_idx = 1;
			for (int i = 0; i < resultList.size(); i++) {
				headerRow.createCell(cell_idx).setCellValue("오염물질");
				headerRow.getCell(cell_idx++).setCellStyle(cellStyle);
				
				headerRow.createCell(cell_idx).setCellValue("값(지수)");
				headerRow.getCell(cell_idx++).setCellStyle(cellStyle);
				
				headerRow.createCell(cell_idx).setCellValue("등급");
				headerRow.getCell(cell_idx++).setCellStyle(cellStyle);
			}

			String[] arr = null;
			resultList = egovService.selectQueryForList("getCaiData", requestMap);
			for (int i = 0; i < resultList.size(); i++) {
				SXSSFRow bodyRow = sheet.createRow(i+2);
				Map<String, Object> dataMap = (Map<String, Object>)resultList.get(i);
				bodyRow.createCell(0).setCellValue(dataMap.get("DSP_DT").toString());
				
				cell_idx = 1;
				for (int j = 1; j < 21; j++) {
					if (dataMap.get("TMS_"+j) != null) {
						arr = dataMap.get("TMS_"+j).toString().split(":");
						bodyRow.createCell(cell_idx++).setCellValue(arr[1]);
						bodyRow.createCell(cell_idx++).setCellValue(arr[2]);
						bodyRow.createCell(cell_idx++).setCellValue(arr[3]);
					} else {
						cell_idx += 3;
					}
				}
			}
			
			response.setContentType("ms-vnd/excel");
			response.setHeader("Content-Disposition", "attachment;filename=caiData.xlsx");
			OutputStream outs = response.getOutputStream();
			try {
				//wb.write(response.getOutputStream());
				wb.write(outs);
			} catch (Exception e) {
				e.getMessage();
				e.printStackTrace();
			} finally {
				if (wb != null) {
					System.out.println("wb is not null");
					wb.close();
				}
				if (outs != null) {
					System.out.println("outs is not null");
					outs.close();
				}
				response.getOutputStream().flush();            
				response.getOutputStream().close();
			}
			
		}
	}
	/*자료조회 : 경보이력조회*/
	@RequestMapping(value="/data/getWarningList.ax")
	public Map<String,Object> getWarningList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getWarningList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));

		
		if (requestMap.get("item_nms") != null) {
			String[] tempArr = requestMap.get("item_nms").toString().split(":");
			String item_nms = "'empty'";
			for (String temp : tempArr ){
				item_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("item_nms", item_nms);
		}
		
		List<?> resultList = egovService.selectQueryForList("getWarningList", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	/*자료조회 : 측정자료 엑셀다운*/
	@RequestMapping(value = "/data/getWarningExcelList.do")
	public ModelAndView getWarningExcelList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getWarningExcelList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		//HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		
		if (requestMap.get("item_nms") != null) {
			String[] tempArr = requestMap.get("item_nms").toString().split(":");
			String item_nms = "'empty'";
			for (String temp : tempArr ){
				item_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("item_nms", item_nms);
		}
		
		List<?> resultList = egovService.selectQueryForList("getWarningList", requestMap);
		
		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("report/listWarningExcelDown");// setViewName() 메서드를 이용하여 뷰 이름을 지정	
		mv.getModel().put("list", resultList);
		mv.getModel().put("term", "기간: "+sd+" ~ "+ed);
		
		return mv;
	}
	/*자료조회 : 측정자료 PDF다운*/
	@RequestMapping(value = "/data/getWarningPDFList.do")
	public void getWarningPDFList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getWarningPDFList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		
		if (requestMap.get("item_nms") != null) {
			String[] tempArr = requestMap.get("item_nms").toString().split(":");
			String item_nms = "'empty'";
			for (String temp : tempArr ){
				item_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("item_nms", item_nms);
		}
				
		List<?> resultList = egovService.selectQueryForList("getWarningList", requestMap);
		
		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		if (resultList != null && resultList.size() > 0) {
			
			PDDocument document = new PDDocument();
			
			PDPage page = new PDPage(PDRectangle.A4);
			//PDPage page = new PDPage(new PDRectangle(PDRectangle.A4.getHeight(), PDRectangle.A4.getWidth()));
			
			/* 가로출력
			float POINTS_PER_INCH = 72;
			float POINTS_PER_MM = 1 / (10 * 2.54f) * POINTS_PER_INCH;
			PDPage page = new PDPage(new PDRectangle(297 * POINTS_PER_MM, 210 * POINTS_PER_MM));*/
			
			//PDPageContentStream contentStream = new PDPageContentStream(document, page);
			PDRectangle rect = page.getMediaBox();
			File fontFile = new File(request.getSession().getServletContext().getRealPath("/") + File.separator + "fonts"  + File.separator + "GULIM.TTC");
			PDType0Font fontGulim = PDType0Font.load(document, new TrueTypeCollection(fontFile).getFontByName("Gulim"), true);
			
			document.addPage(page);
			
			boolean drawLines = true;
			boolean drawContent = true;
			float margin = 50;
			float yStartNewPage = page.getMediaBox().getHeight() - margin;
			float tableWidth = page.getMediaBox().getWidth() - (2 * margin);
			float bottomMargin = 50;
			float topMargin = page.getMediaBox().getHeight() - margin;
			
			BaseTable table = new BaseTable(yStartNewPage, topMargin, bottomMargin, tableWidth, margin, document, page, drawLines, drawContent);
			
			Row<PDPage> headerRow = null;
			Cell<PDPage> cell = null;
			
			headerRow = table.createRow(50);
			cell = headerRow.createCell(100, "경보이력 리포트");
			cell.setFont(fontGulim);
			cell.setFontSize(20);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "조회기간: "+sd+" ~ "+ed);
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setTopBorderStyle(null);
			cell.setLeftBorderStyle(null);
			cell.setRightBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(10, "지역명");
			cell.setFont(fontGulim);
			cell.setFontSize(12);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(16, "측정소");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(10, "경보항목");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(10, "측정값");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(10, "경보명");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(17, "경보일시");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(10, "해제명");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(17, "해제일시");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);

			table.addHeaderRow(headerRow);
			
			Row<PDPage> row = null;
			for (int i=0; i<resultList.size(); i++) {
				resultMap = (HashMap)resultList.get(i);
				//dsp_dt, item_nm, msr_vl, msr_vl_unit, status_nm
				row = table.createRow(20);
				
				cell = row.createCell(10, resultMap.get("REGION_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(16, resultMap.get("TMS_NM")==null?"-":resultMap.get("TMS_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(10, resultMap.get("ITEM_NM")==null?"-":resultMap.get("ITEM_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(10, (resultMap.get("MSR_VL")==null?"-":resultMap.get("MSR_VL").toString())+(resultMap.get("ITEM_UNIT")==null?"-":resultMap.get("ITEM_UNIT").toString()));
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(10, resultMap.get("WARNING_NM")==null?"-":resultMap.get("WARNING_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(17, resultMap.get("WARNING_DT")==null?"-":resultMap.get("WARNING_DT").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(10, resultMap.get("RESET_NM")==null?"-":resultMap.get("RESET_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(17, resultMap.get("RESET_DT")==null?"-":resultMap.get("RESET_DT").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);

			}
			table.draw();
			//contentStream.close();
			//System.out.println("document.getNumberOfPages() = "+document.getNumberOfPages());
			
			//PDImageXObject pdImage = PDImageXObject.createFromFile(request.getSession().getServletContext().getRealPath("/")+File.separator+"images"+File.separator+"BBP8xP3.jpg", document);
			
			for (int i = 0; i < document.getNumberOfPages(); i++) {
				/*PDPageContentStream footercontentStream = new PDPageContentStream(document, document.getPage(i), AppendMode.APPEND, true);
				footercontentStream.beginText();
				footercontentStream.setFont(fontGulim, 10);
				footercontentStream.newLineAtOffset((document.getPage(i).getMediaBox().getWidth() / 2 - 20), 30);
				footercontentStream.showText("- "+String.valueOf(i + 1)+" / "+document.getNumberOfPages()+" -");
				footercontentStream.endText();
				footercontentStream.close();*/
				
				String company_name = System.getProperty("COMPANY_NAME")==null?"두일테크":System.getProperty("COMPANY_NAME");
				PDPageContentStream contentStream = new PDPageContentStream(document, document.getPage(i), AppendMode.APPEND, true);
				//PDStreamUtils.write(PDPageContentStream stream, String text, PDFont font, float fontSize, float x, float y, Color color)
				PDStreamUtils.write(contentStream, company_name, fontGulim, 10, 50, document.getPage(i).getMediaBox().getHeight()-30, new Color(102, 102, 102));
				PDStreamUtils.write(contentStream, "- "+String.valueOf(i + 1)+" / "+document.getNumberOfPages()+" -", fontGulim, 10, document.getPage(i).getMediaBox().getWidth() / 2 - 20, 30, new Color(102, 102, 102));
				
	            contentStream.close();
	        }
			
			response.setHeader("Content-Type", "application/force-download");
			response.addHeader("Content-Disposition","attachment; filename=WarningReport.pdf");
			document.save(response.getOutputStream());
			document.close();
		}
	}
	/*자료조회 : 그래프조회*/
	@RequestMapping(value="/data/getGraphList.ax")
	public Map<String,Object> getGraphList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getGraphList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));

		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}

		/*if (requestMap.get("msr_st_nms") != null) {
			String[] tempArr = requestMap.get("msr_st_nms").toString().split(":");
			String msr_st_nms = "'empty'";
			for (String temp : tempArr ){
				msr_st_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("msr_st_nms", msr_st_nms);
		}*/
		
		List<?> resultList = egovService.selectQueryForList("getGraphList", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	/*자료조회 : 미수신조회*/
	@RequestMapping(value="/data/getNoReceiveList.ax")
	public Map<String,Object> getNoReceiveList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getNoReceiveList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		if (requestMap.get("data_type")==null) {
			requestMap.put("data_type", "H");
		}
		
		if (requestMap.get("item_nms") != null) {
			String[] tempArr = requestMap.get("item_nms").toString().split(":");
			String item_nms = "'empty'";
			for (String temp : tempArr ){
				item_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("item_nms", item_nms);
		}
		
		List<?> resultList = egovService.selectQueryForList("getNoReceiveList", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	/*자료조회 : 미수신자료 엑셀다운*/
	@RequestMapping(value = "/data/getNoReceiveExcel.do")
	public ModelAndView getNoReceiveExcel(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getNoReceiveExcel()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		//HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		/*SimpleDateFormat df1 = new SimpleDateFormat("E M d y HH:mm:ss z");
		Date date = df1.parse(requestMap.get("s_date").toString());
		SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");
		LOGGER.debug(">>>>>>>> "+df2.format(date));*/
		
		if (requestMap.get("item_nms") != null) {
			String[] tempArr = requestMap.get("item_nms").toString().split(":");
			String item_nms = "'empty'";
			for (String temp : tempArr ){
				item_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("item_nms", item_nms);
		}
		
		List<?> resultList = egovService.selectQueryForList("getNoReceiveList", requestMap);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("report/noReceiveExcel");// setViewName() 메서드를 이용하여 뷰 이름을 지정	
		mv.getModel().put("list", resultList);
		mv.getModel().put("data_type_nm", requestMap.get("data_type_nm").toString());
		
		return mv;
	}
	/*자료조회 >자료비교 : 그리드리스트 조회 */
	@RequestMapping(value="/data/getCompareDataList.ax")
	public Map<String,Object> getCompareDataList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getCompareDataList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));

		if (requestMap.get("data_type")==null) {
			requestMap.put("data_type", "H");
		}
		
		List<?> resultList = egovService.selectQueryForList("getCompareDataList", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	/*자료조회 >자료비교: 비교자료 PDF다운*/
	@RequestMapping(value = "/data/getComparePDFList.do")
	public void getComparePDFList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getComparePDFList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		
		List<?> resultList = egovService.selectQueryForList("getCompareDataList", requestMap);
		
		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		if (resultList != null && resultList.size() > 0) {
			
			//float POINTS_PER_INCH = 72;
			//float POINTS_PER_MM = 1 / (10 * 2.54f) * POINTS_PER_INCH;
			
			PDDocument document = new PDDocument();
			
			PDPage page = new PDPage(PDRectangle.A4);
			//PDPage page = new PDPage(new PDRectangle(PDRectangle.A4.getHeight(), PDRectangle.A4.getWidth()));
			//PDPage page = new PDPage(new PDRectangle(297 * POINTS_PER_MM, 210 * POINTS_PER_MM));
			
			//PDPageContentStream contentStream = new PDPageContentStream(document, page);
			PDRectangle rect = page.getMediaBox();
			File fontFile = new File(request.getSession().getServletContext().getRealPath("/") + File.separator + "fonts"  + File.separator + "GULIM.TTC");
			PDType0Font fontGulim = PDType0Font.load(document, new TrueTypeCollection(fontFile).getFontByName("Gulim"), true);
			
			document.addPage(page);
			
			boolean drawLines = true;
			boolean drawContent = true;
			float margin = 50;
			float yStartNewPage = page.getMediaBox().getHeight() - margin;
			float tableWidth = page.getMediaBox().getWidth() - (2 * margin);
			float bottomMargin = 50;
			float topMargin = page.getMediaBox().getHeight() - margin;
			
			BaseTable table = new BaseTable(yStartNewPage, topMargin, bottomMargin, tableWidth, margin, document, page, drawLines, drawContent);
			
			Row<PDPage> headerRow = null;
			Cell<PDPage> cell = null;
			
			headerRow = table.createRow(50);
			cell = headerRow.createCell(100, "비교자료 리포트");
			cell.setFont(fontGulim);
			cell.setFontSize(20);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "시군명: "+requestMap.get("region_nm").toString()+" /  측정소명: "+requestMap.get("tms_nm").toString());
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "시군명: "+requestMap.get("region_nm_2").toString()+" /  측정소명: "+requestMap.get("tms_nm_2").toString());
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "측정항목: "+requestMap.get("item_nm").toString() +" /  조회기간: "+sd+" ~ "+ed);
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setTopBorderStyle(null);
			cell.setLeftBorderStyle(null);
			cell.setRightBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(14, "측정시간");
			cell.setFont(fontGulim);
			cell.setFontSize(12);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(10, "측정값A");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(10, "측정값B");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "8h평균A");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "8h평균B");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "24h평균A");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "24h평균B");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "환경지수A");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);

			cell = headerRow.createCell(11, "환경지수B");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			table.addHeaderRow(headerRow);
			
			Row<PDPage> row = null;
			for (int i=0; i<resultList.size(); i++) {
				resultMap = (HashMap)resultList.get(i);
				//dsp_dt, item_nm, msr_vl, msr_vl_unit, status_nm
				row = table.createRow(20);
				
				cell = row.createCell(14, resultMap.get("DSP_DT").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(10, resultMap.get("MSR_VL")==null?"-":resultMap.get("MSR_VL").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(10, resultMap.get("MSR_VL_2")==null?"-":resultMap.get("MSR_VL_2").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(11, resultMap.get("AVG_08")==null?"-":resultMap.get("AVG_08").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(11, resultMap.get("AVG_08_2")==null?"-":resultMap.get("AVG_08_2").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(11, resultMap.get("AVG_24")==null?"-":resultMap.get("AVG_24").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(11, resultMap.get("AVG_24_2")==null?"-":resultMap.get("AVG_24_2").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(11, resultMap.get("AI_VL")==null?"-":resultMap.get("AI_VL").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(11, resultMap.get("AI_VL_2")==null?"-":resultMap.get("AI_VL_2").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
			}
			table.draw();
			//contentStream.close();
			//System.out.println("document.getNumberOfPages() = "+document.getNumberOfPages());
			
			//PDImageXObject pdImage = PDImageXObject.createFromFile(request.getSession().getServletContext().getRealPath("/")+File.separator+"images"+File.separator+"BBP8xP3.jpg", document);
			
			for (int i = 0; i < document.getNumberOfPages(); i++) {
				/*PDPageContentStream footercontentStream = new PDPageContentStream(document, document.getPage(i), AppendMode.APPEND, true);
				footercontentStream.beginText();
				footercontentStream.setFont(fontGulim, 10);
				footercontentStream.newLineAtOffset((document.getPage(i).getMediaBox().getWidth() / 2 - 20), 30);
				footercontentStream.showText("- "+String.valueOf(i + 1)+" / "+document.getNumberOfPages()+" -");
				footercontentStream.endText();
				footercontentStream.close();*/
				
				String company_name = System.getProperty("COMPANY_NAME")==null?"충남연구원":System.getProperty("COMPANY_NAME");
				PDPageContentStream contentStream = new PDPageContentStream(document, document.getPage(i), AppendMode.APPEND, true);
				//PDStreamUtils.write(PDPageContentStream stream, String text, PDFont font, float fontSize, float x, float y, Color color)
				PDStreamUtils.write(contentStream, company_name, fontGulim, 10, 50, document.getPage(i).getMediaBox().getHeight()-30, new Color(102, 102, 102));
				PDStreamUtils.write(contentStream, "- "+String.valueOf(i + 1)+" / "+document.getNumberOfPages()+" -", fontGulim, 10, document.getPage(i).getMediaBox().getWidth() / 2 - 20, 30, new Color(102, 102, 102));
				
	            contentStream.close();
	        }
			
			response.setHeader("Content-Type", "application/force-download");
			response.addHeader("Content-Disposition","attachment; filename=DataReport.pdf");
			document.save(response.getOutputStream());
			document.close();
		}
	}
	/*자료조회>비교 : 비교자료 엑셀다운*/
	@RequestMapping(value = "/data/getCompareExcelList.do")
	public ModelAndView getCompareExcelList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getCompareExcelList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		//HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		
		List<?> resultList = egovService.selectQueryForList("getCompareDataList", requestMap);
		
		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("report/compareExcelDown");// setViewName() 메서드를 이용하여 뷰 이름을 지정	
		mv.getModel().put("list", resultList);
		mv.getModel().put("region_nm", requestMap.get("region_nm").toString());
		mv.getModel().put("region_nm_2", requestMap.get("region_nm_2").toString());
		mv.getModel().put("tms_nm", requestMap.get("tms_nm").toString());
		mv.getModel().put("tms_nm_2", requestMap.get("tms_nm_2").toString());
		mv.getModel().put("item_nm", requestMap.get("item_nm").toString());
		mv.getModel().put("term", "기간: "+sd+" ~ "+ed);
		
		return mv;
	}
	
/*자료관리*/	
	/*  자료관리>이상자료관리 : 자료조회 */
	@RequestMapping(value="/management/getAbnormalDatas.ax")
	public Map<String,Object> getAbnormalDatas(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getAbnormalDatas()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));

		if (requestMap.get("suspicion_ratio") == null) {
			requestMap.put("suspicion_ratio", "30");
		}
		
		if (requestMap.get("same_tm") == null) {
			requestMap.put("same_tm", "5");
		}
		
		if (requestMap.get("data_type")==null) {
			requestMap.put("data_type", "H");
		}
		
		if (requestMap.get("item_nms") != null) {
			String[] tempArr = requestMap.get("item_nms").toString().split(":");
			String item_nms = "'empty'";
			for (String temp : tempArr ){
				item_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("item_nms", item_nms);
		}
		if (requestMap.get("status_nms") != null) {
			String[] tempArr = requestMap.get("status_nms").toString().split(":");
			String status_nms = "'empty'";
			for (String temp : tempArr ){
				status_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("status_nms", status_nms);
		}
		
		List<?> resultList = egovService.selectQueryForList("getAbnormalDatas", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	/* 자료관리>이상자료관리 : 등록수정 */
	@RequestMapping(value = "/management/setAbnormalDatas.ax")
	public HashMap<String, Object> setAbnormalDatas(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.setAbnormalDatas()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		requestMap.put("reg_id", request.getSession().getAttribute("USER_ID")==null?"":request.getSession().getAttribute("USER_ID").toString());
		
		String data = request.getParameter("editRecords").toString();
		if (requestMap.get("editRecords") != null) {
			try {
				JSONArray jsonArr = new JSONArray(data);
				
				for (int i=0; i<jsonArr.length(); i++){
					JSONObject returnSubject = (JSONObject)jsonArr.get(i);
					System.out.println("returnSubject : "+returnSubject.toString());
					//System.out.println("item_cd : "+returnSubject.get("ITEM_CD").toString());
					//System.out.println("msr_dt : "+returnSubject.get("MSR_DT").toString());
					//System.out.println("abnormal_yn : "+returnSubject.get("ABNORMAL_YN").toString());
					
					requestMap.put("item_cd", returnSubject.get("ITEM_CD").toString());
					requestMap.put("msr_dt", returnSubject.get("MSR_DT").toString());
					requestMap.put("abnormal_yn", returnSubject.get("ABNORMAL_YN").toString().equals("true")?"Y":"N");
					requestMap.put("abnormal_cd", returnSubject.get("ABNORMAL_CD").toString());
					
					resultMap.put("code", 200);
					
					if ((HashMap)egovService.selectQueryForObject("getConfirmDate", requestMap) != null) {
						resultMap.put("code", 404);
						resultMap.put("msg", "이미 마감처리되어 수정 할 수 없는 자료입니다.");
						break;
					}
					
					if (egovService.insertQueryAfterReturn("setAbnormalDatas", requestMap) < 1) {
						resultMap.put("code", 500);
						resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
						break;
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
				resultMap.put("code", 500);
				resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
			}
		}
		
		return resultMap;
	}
	/* 자료관리>이상자료관리 : 측정자료 엑셀다운*/
	@RequestMapping(value = "/management/getAbnormalExcelList.do")
	public ModelAndView getAbnormalExcelList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getAbnormalExcelList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		//HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		/*SimpleDateFormat df1 = new SimpleDateFormat("E M d y HH:mm:ss z");
		Date date = df1.parse(requestMap.get("s_date").toString());
		SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");
		LOGGER.debug(">>>>>>>> "+df2.format(date));*/
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		
		if (requestMap.get("item_nms") != null) {
			String[] tempArr = requestMap.get("item_nms").toString().split(":");
			String item_nms = "'empty'";
			for (String temp : tempArr ){
				item_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("item_nms", item_nms);
		}
		if (requestMap.get("status_nms") != null) {
			String[] tempArr = requestMap.get("status_nms").toString().split(":");
			String status_nms = "'empty'";
			for (String temp : tempArr ){
				status_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("status_nms", status_nms);
		}
		
		List<?> resultList = egovService.selectQueryForList("getAbnormalDatas", requestMap);
		
		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("report/abnormalExcelDown");// setViewName() 메서드를 이용하여 뷰 이름을 지정	
		mv.getModel().put("list", resultList);
		mv.getModel().put("region_nm", requestMap.get("region_nm").toString());
		mv.getModel().put("tms_nm", requestMap.get("tms_nm").toString());
		mv.getModel().put("data_type_nm", requestMap.get("data_type_nm").toString());
		mv.getModel().put("term", "기간: "+sd+" ~ "+ed);
		
		return mv;
	}
	/* 자료관리>이상자료관리 : 측정자료 PDF다운*/
	@RequestMapping(value = "/management/getAbnormalPDFList.do")
	public void getAbnormalPDFList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getAbnormalPDFList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		
		if (requestMap.get("item_nms") != null) {
			String[] tempArr = requestMap.get("item_nms").toString().split(":");
			String item_nms = "'empty'";
			for (String temp : tempArr ){
				item_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("item_nms", item_nms);
		}
		if (requestMap.get("status_nms") != null) {
			String[] tempArr = requestMap.get("status_nms").toString().split(":");
			String status_nms = "'empty'";
			for (String temp : tempArr ){
				status_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("status_nms", status_nms);
		}
		
		List<?> resultList = egovService.selectQueryForList("getAbnormalDatas", requestMap);
		
		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		if (resultList != null && resultList.size() > 0) {
			
			float POINTS_PER_INCH = 72;
			float POINTS_PER_MM = 1 / (10 * 2.54f) * POINTS_PER_INCH;
			
			PDDocument document = new PDDocument();
			
			//PDPage page = new PDPage(PDRectangle.A4);
			//PDPage page = new PDPage(new PDRectangle(PDRectangle.A4.getHeight(), PDRectangle.A4.getWidth()));
			PDPage page = new PDPage(new PDRectangle(297 * POINTS_PER_MM, 210 * POINTS_PER_MM));
			
			//PDPageContentStream contentStream = new PDPageContentStream(document, page);
			PDRectangle rect = page.getMediaBox();
			File fontFile = new File(request.getSession().getServletContext().getRealPath("/") + File.separator + "fonts"  + File.separator + "GULIM.TTC");
			PDType0Font fontGulim = PDType0Font.load(document, new TrueTypeCollection(fontFile).getFontByName("Gulim"), true);
			
			document.addPage(page);
			
			boolean drawLines = true;
			boolean drawContent = true;
			float margin = 50;
			float yStartNewPage = page.getMediaBox().getHeight() - margin;
			float tableWidth = page.getMediaBox().getWidth() - (2 * margin);
			float bottomMargin = 50;
			float topMargin = page.getMediaBox().getHeight() - margin;
			
			BaseTable table = new BaseTable(yStartNewPage, topMargin, bottomMargin, tableWidth, margin, document, page, drawLines, drawContent);
			
			Row<PDPage> headerRow = null;
			Cell<PDPage> cell = null;
			
			headerRow = table.createRow(50);
			cell = headerRow.createCell(100, "측정자료 리포트");
			cell.setFont(fontGulim);
			cell.setFontSize(20);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "지역명: "+requestMap.get("region_nm").toString());
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "측정소명: "+requestMap.get("tms_nm").toString());
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "조회기간: "+sd+" ~ "+ed);
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setTopBorderStyle(null);
			cell.setLeftBorderStyle(null);
			cell.setRightBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(11.5f, "측정시간", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(9, "측정항목", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(7.5f, "전월평균", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(7.5f, "이전시간값", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(7.5f, "측정값", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(6, "증감율", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(6, "측정상태", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(6, "등급", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(6, "기준초과", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(6, "8h 평균", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(6, "24h 평균", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setFillColor(Color.LIGHT_GRAY);

			cell = headerRow.createCell(6, "환경지수", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(6, "이상여부", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(9, "이상구분", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			table.addHeaderRow(headerRow);
			
			Row<PDPage> row = null;
			for (int i=0; i<resultList.size(); i++) {
				resultMap = (HashMap)resultList.get(i);
				
				row = table.createRow(20);
				
				cell = row.createCell(11.5f, resultMap.get("DSP_DT").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(9, resultMap.get("ITEM_NM")==null?"-":resultMap.get("ITEM_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(7.5f, (resultMap.get("BEFORE_AVG")==null?"-":resultMap.get("BEFORE_AVG").toString())+(resultMap.get("ITEM_UNIT")==null?"-":resultMap.get("ITEM_UNIT").toString()));
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(7.5f, (resultMap.get("PRE_VL")==null?"-":resultMap.get("PRE_VL").toString())+(resultMap.get("ITEM_UNIT")==null?"-":resultMap.get("ITEM_UNIT").toString()));
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(7.5f, (resultMap.get("MSR_VL")==null?"-":resultMap.get("MSR_VL").toString())+(resultMap.get("ITEM_UNIT")==null?"-":resultMap.get("ITEM_UNIT").toString()));
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(6, (resultMap.get("RATIO")==null?"-":resultMap.get("RATIO").toString())+"%");
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(6, resultMap.get("STATUS_NM")==null?"-":resultMap.get("STATUS_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(6, resultMap.get("LEVEL_NM")==null?"-":resultMap.get("LEVEL_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(6, resultMap.get("OVER_NM")==null?"-":resultMap.get("OVER_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(6, resultMap.get("AVG_08")==null?"-":resultMap.get("AVG_08").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(6, resultMap.get("AVG_24")==null?"-":resultMap.get("AVG_24").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(6, (resultMap.get("AI_VL")==null?"-":resultMap.get("AI_VL").toString())+" ("+(resultMap.get("AI_LV_NM")==null?"-":resultMap.get("AI_LV_NM").toString())+")");
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(6, (resultMap.get("ABNORMAL")==null?"":resultMap.get("ABNORMAL").toString()));
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(9, (resultMap.get("ABNORMAL_NM")==null?"":resultMap.get("ABNORMAL_NM").toString()));
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
			}
			table.draw();

			for (int i = 0; i < document.getNumberOfPages(); i++) {

				String company_name = System.getProperty("COMPANY_NAME")==null?"두일테크":System.getProperty("COMPANY_NAME");
				PDPageContentStream contentStream = new PDPageContentStream(document, document.getPage(i), AppendMode.APPEND, true);
				//PDStreamUtils.write(PDPageContentStream stream, String text, PDFont font, float fontSize, float x, float y, Color color)
				PDStreamUtils.write(contentStream, company_name, fontGulim, 10, 50, document.getPage(i).getMediaBox().getHeight()-30, new Color(102, 102, 102));
				PDStreamUtils.write(contentStream, "- "+String.valueOf(i + 1)+" / "+document.getNumberOfPages()+" -", fontGulim, 10, document.getPage(i).getMediaBox().getWidth() / 2 - 20, 30, new Color(102, 102, 102));
				
	            contentStream.close();
	        }
			
			response.setHeader("Content-Type", "application/force-download");
			response.addHeader("Content-Disposition","attachment; filename=DataReport.pdf");
			document.save(response.getOutputStream());
			document.close();
		}
	}
	/*자료관리>측정자료마감 : 월마감자료조회 */
	@RequestMapping(value="/management/getConfirmList.ax")
	public Map<String,Object> getConfirmList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getConfirmList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (requestMap.get("confirm_type") == null || requestMap.get("confirm_type").toString().equals(""))
			requestMap.put("confirm_type", "M");
		
		List<?> resultList = egovService.selectQueryForList("getConfirmList", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		
		return resultMap;
	}
	/*자료관리>측정자료마감 : 일/월 마감 */
	@RequestMapping(value="/management/setConfirmDate.ax", method=RequestMethod.POST)
	public Map<String,Object> setConfirmDate(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.setConfirmDate()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		requestMap.put("msr_mm", requestMap.get("msr_mm").toString().replaceAll("-", ""));
		requestMap.put("use_yn", "Y");
		
		resultMap.put("code", 200);
		resultMap.put("msg", "마감되었습니다.");
		
		// 측정소별 모든 측정항목에 대한 마감자료 생성 및 마감
		List tmsList = egovService.selectQueryForList("getTmsList", requestMap);
		if (tmsList != null && tmsList.size() > 0) {
			for (int x=0; x<tmsList.size(); x++) {
				requestMap.put("tms_cd", ((HashMap)tmsList.get(x)).get("TMS_CD").toString());
				
				try {
					// 일 마감자료 생성 및 입력
					egovService.deleteQuery("resetConfirmDate", requestMap);
					egovService.insertQuery("setConfirmDate", requestMap);
				} catch (Exception e) {
					e.printStackTrace();
					resultMap.put("code", 500);
					resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.(1)");
					return resultMap;
				}
				
				try {
					//월 마감자료 등록
					egovService.deleteQuery("resetConfirmMonth", requestMap);
					egovService.insertQuery("setConfirmMonth", requestMap);
					requestMap.put("confirm_type", "M");
					egovService.insertQuery("setConfirmInfo", requestMap);
				} catch (Exception e) {
					e.printStackTrace();
					resultMap.put("code", 500);
					resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.(2)");
					return resultMap;
				}
				
					// 월 마감자료 생성 및 조회
					/*List<?> resultList = egovService.selectQueryForList("getConfirmMonthList", requestMap);
					if (resultList != null && resultList.size() > 0) {
						for (int i=0; i<resultList.size(); i++) {
							try {
								//월 마감자료 등록
								egovService.insertQuery("setConfirmMonth", (HashMap)resultList.get(i));
							} catch (Exception e) {
								e.printStackTrace();
								resultMap.put("code", 500);
								resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.(2)");
								return resultMap;
							}
						}
						try {
							//마감정보 등록
							egovService.insertQuery("setConfirmInfo", requestMap);
						} catch (Exception e) {
							e.printStackTrace();
							resultMap.put("code", 500);
							resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.(3)");
							return resultMap;
						}
					}*/

			}
			
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "등록된 항목이 없습니다.");
		}

		return resultMap;
	}	
	
	/*자료관리>마감자료 연마김조회 */
	/*@RequestMapping(value="/management/getConfirmYearList.ax")
	public Map<String,Object> getConfirmYearList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getConfirmYearList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (requestMap.get("confirm_type") == null || requestMap.get("confirm_type").toString().equals(""))
			requestMap.put("confirm_type", "Y");
		
		List<?> resultList = egovService.selectQueryForList("getConfirmYearList", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		
		return resultMap;
	}*/
	
	/*자료관리>마감자료 : 년 마감자료 생성 및 등록  */
	/*@RequestMapping(value="/management/setConfirmYearDate.ax")
	public Map<String,Object> setConfirmYearDate(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.setConfirmYearDate()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("reg_id",request.getSession().getAttribute("USER_ID").toString());
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals(""))
			requestMap.put("item_cd", "PM2");
		
		if (requestMap.get("confirm_type") == null || requestMap.get("confirm_type").toString().equals(""))
			requestMap.put("confirm_type", "Y");
			
		resultMap = (HashMap)egovService.selectQueryForObject("getConfirmYearOK", requestMap);
		if (resultMap.get("ok").toString().equals("N")) {
			resultMap.put("code", 404);
			resultMap.put("msg", "월마감이 완료 되지 않아 년마감 할 수 없습니다.");
			return resultMap;
		} else {
			resultMap.put("code", 200);
			resultMap.put("msg", "마감되었습니다.");
		}
		
		// 측정소별 모든 측정항목에 대한 마감자료 생성 및 마감
		List<?> itemList = egovService.selectQueryForList("getUseItemList", requestMap);
		if (itemList != null && itemList.size() > 0) {
			for (int x=0; x<itemList.size(); x++) {
				requestMap.put("item_cd", ((HashMap)itemList.get(x)).get("item_cd").toString());
				
				// 년 마감자료 조회 
				List<?> resultList = egovService.selectQueryForList("getConfirmYearData", requestMap);
					if (resultList != null && resultList.size() > 0) {
						for (int i=0; i<resultList.size(); i++) {
							try {
								//년 마감자료 등록
								egovService.insertQuery("setConfirmYear", (HashMap)resultList.get(i));
							} catch (Exception e) {
								e.printStackTrace();
								resultMap.put("code", 500);
								resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.(2)");
								return resultMap;
							}
						}
						try {
							//마감정보 등록
							egovService.insertQuery("setConfirmInfo", requestMap);
						} catch (Exception e) {
							e.printStackTrace();
							resultMap.put("code", 500);
							resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.(3)");
							return resultMap;
						}
					} else {
					resultMap.put("code", 404);
					resultMap.put("msg", "조회자료가 없습니다");
				}
			}
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "등록된 항목이 없습니다.");
		}

		return resultMap;
	}*/
	/*자료관리>마감자료 : 마감 data 조회(일/월/년) */
	@RequestMapping(value="/management/getConfirmDataList.ax")
	public Map<String,Object> getConfirmDataList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getConfirmDataList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (requestMap.get("region_cd") == null) requestMap.put("region_cd", "ALL");
		requestMap.put("reg_id",request.getSession().getAttribute("USER_ID").toString());
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals(""))
			requestMap.put("item_cd", "PM2");
		
		if (requestMap.get("data_type").toString().equals("D")) {
			requestMap.put("table_nm", "confirm_date");
		} else if (requestMap.get("data_type").toString().equals("M")) {
			requestMap.put("table_nm", "confirm_month");
			//requestMap.put("s_date", requestMap.get("s_date").toString().substring(0, 6));
			//requestMap.put("e_date", requestMap.get("e_date").toString().substring(0, 6));
			
		} else if (requestMap.get("data_type").toString().equals("Y")) {
			requestMap.put("table_nm", "confirm_year");
			requestMap.put("s_date", requestMap.get("s_date").toString().substring(0, 4));
			requestMap.put("e_date", requestMap.get("e_date").toString().substring(0, 4));
		}
		
		/*if (requestMap.get("confirm_type") == null || requestMap.get("confirm_type").toString().equals(""))
			requestMap.put("confirm_type", "M");*/
		
		List<?> resultList = egovService.selectQueryForList("getConfirmDataList", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		
		return resultMap;
	}
	/*자료관리>마감자료 : 마감자료 엑셀다운*/
	@RequestMapping(value = "/analysis/getConfirmExcelReport.do")
	public ModelAndView getConfirmExcelReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getConfirmExcelReport()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		//HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (requestMap.get("region_cd") == null) requestMap.put("region_cd", "ALL");
		if (requestMap.get("region_nm") == null) requestMap.put("region_nm", "전체");
		if (requestMap.get("tms_cd") == null) requestMap.put("tms_cd", "ALL");
		if (requestMap.get("tms_nm") == null) requestMap.put("tms_nm", "전체");
		requestMap.put("reg_id",request.getSession().getAttribute("USER_ID").toString());
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals(""))
			requestMap.put("item_cd", "PM2");
		
		requestMap.put("s_date", requestMap.get("s_date").toString().substring(0, 6));
		requestMap.put("e_date", requestMap.get("e_date").toString().substring(0, 6));
		
		String tms_nm = requestMap.get("tms_nm") == null ? "" : requestMap.get("tms_nm").toString();
		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		//sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		//ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6);
		String data_nm = "";
		
		if (requestMap.get("data_type").toString().equals("D")) {
			requestMap.put("table_nm", "confirm_date");
			data_nm = "일마감";
		} else if (requestMap.get("data_type").toString().equals("M")) {
			requestMap.put("table_nm", "confirm_month");
			data_nm = "월마감";
		} else if (requestMap.get("data_type").toString().equals("Y")) {
			requestMap.put("table_nm", "confirm_month");
			requestMap.put("s_date", requestMap.get("s_date").toString().substring(0, 4));
			requestMap.put("e_date", requestMap.get("e_date").toString().substring(0, 4));
			data_nm = "년마감";
		}
		
		List<?> resultList = egovService.selectQueryForList("getConfirmDataList", requestMap);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/report/confirmReport");// setViewName() 메서드를 이용하여 뷰 이름을 지정한 모습		
		mv.getModel().put("list", resultList);
		mv.getModel().put("region_nm", requestMap.get("region_nm").toString());
		mv.getModel().put("tms_nm", requestMap.get("tms_nm").toString());
		mv.getModel().put("data_nm", data_nm);
		mv.getModel().put("term", "기간: "+sd+" ~ "+ed);
		
		return mv;
	}
	/*자료관리>마감자료 : PDF다운*/
	@RequestMapping(value = "/analysis/getConfirmPDFReport.do")
	public void getConfirmPDFReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getConfirmPDFReport()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (requestMap.get("region_cd") == null) requestMap.put("region_cd", "ALL");
		if (requestMap.get("region_nm") == null) requestMap.put("region_nm", "전체");
		if (requestMap.get("tms_cd") == null) requestMap.put("tms_cd", "ALL");
		if (requestMap.get("tms_nm") == null) requestMap.put("tms_nm", "전체");
		requestMap.put("reg_id",request.getSession().getAttribute("USER_ID").toString());
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals(""))
			requestMap.put("item_cd", "PM2");
		
		requestMap.put("s_date", requestMap.get("s_date").toString().substring(0, 6));
		requestMap.put("e_date", requestMap.get("e_date").toString().substring(0, 6));
		
		String tms_nm = requestMap.get("tms_nm") == null ? "" : requestMap.get("tms_nm").toString();
		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		//sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		//ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6);
		String data_nm = "";
		
		if (requestMap.get("data_type").toString().equals("D")) {
			requestMap.put("table_nm", "confirm_date");
			data_nm = "일마감";
		} else if (requestMap.get("data_type").toString().equals("M")) {
			requestMap.put("table_nm", "confirm_month");
			data_nm = "월마감";
		} else if (requestMap.get("data_type").toString().equals("Y")) {
			requestMap.put("table_nm", "confirm_month");
			requestMap.put("s_date", requestMap.get("s_date").toString().substring(0, 4));
			requestMap.put("e_date", requestMap.get("e_date").toString().substring(0, 4));
			data_nm = "년마감";
		}

		PDDocument document = new PDDocument();
		PDPage page = new PDPage(new PDRectangle(PDRectangle.A4.getHeight(), PDRectangle.A4.getWidth()));
		//PDRectangle rect = page.getMediaBox();
		File fontFile = new File(request.getSession().getServletContext().getRealPath("/") + File.separator + "fonts"  + File.separator + "GULIM.TTC");
		PDType0Font fontGulim = PDType0Font.load(document, new TrueTypeCollection(fontFile).getFontByName("Gulim"), true);

		document.addPage(page);
		
		boolean drawLines = true;
		boolean drawContent = true;
		float margin = 30;
		float yStartNewPage = page.getMediaBox().getHeight() - margin;
		float tableWidth = page.getMediaBox().getWidth() - (2 * margin);
		float bottomMargin = 50;
		float topMargin = page.getMediaBox().getHeight() - margin;
		float cellWidth = 5;
		
		BaseTable table = new BaseTable(yStartNewPage, topMargin, bottomMargin, tableWidth, margin, document, page, drawLines, drawContent);
		Row<PDPage> headerRow = null;
		Cell<PDPage> cell = null;
		PDTableAttributeObject z = new PDTableAttributeObject();
		z.setRowSpan(2);
		
		headerRow = table.createRow(50);
		cell = headerRow.createCell(100, "마감자료 리포트", HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
		cell.setFont(fontGulim);
		cell.setFontSize(20);
		//cell.setValign(VerticalAlignment.MIDDLE);
		//cell.setAlign(HorizontalAlignment.CENTER);
		cell.setBorderStyle(null);
		table.addHeaderRow(headerRow);
		
		headerRow = table.createRow(20);
		cell = headerRow.createCell(100, "시군명: "+requestMap.get("region_nm").toString()+", 측정소명: "+requestMap.get("tms_nm").toString()+", 자료구분: "+data_nm, HorizontalAlignment.RIGHT, VerticalAlignment.MIDDLE);
		cell.setFont(fontGulim);
		cell.setFontSize(10);
		//cell.setValign(VerticalAlignment.MIDDLE);
		//cell.setAlign(HorizontalAlignment.RIGHT);
		cell.setBorderStyle(null);
		table.addHeaderRow(headerRow);
		
		headerRow = table.createRow(20);
		cell = headerRow.createCell(100, "조회기간: "+sd+" ~ "+ed, HorizontalAlignment.RIGHT, VerticalAlignment.MIDDLE);
		cell.setFont(fontGulim);
		cell.setFontSize(10);
		//cell.setValign(VerticalAlignment.MIDDLE);
		//cell.setAlign(HorizontalAlignment.RIGHT);
		cell.setTopBorderStyle(null);
		cell.setLeftBorderStyle(null);
		cell.setRightBorderStyle(null);
		table.addHeaderRow(headerRow);
		
		headerRow = table.createRow(20);
		String[] header = {"시군", "측정소", "항목", "마감월(일)", "유효율<br/>(%)", "유효일수", "유효횟수<br/>(8h)", "유효건수<br/>(1h)", "평균값", "최저<br/>(1h)", "최고<br/>(1h)", "최고일시<br/>(1h)", "기준초과<br/>건(1h)", "초과율<br/>(%, 1h)", "최저<br/>(8 or 24h)", "최고<br/>(8 or 24h)", "최고일시<br/><br/>(8 or 24h)", "기준초과<br/>건<br/>(8 or 24h)", "초과율(%)<br/>(8 or 24h)", "구분"};
		for (int i=0; i<header.length; i++) {
			if (i == 10) cellWidth = 4;
			else if (i == 11) cellWidth = 6;
			else cellWidth = 5;
			
			cell = headerRow.createCell(cellWidth, header[i], HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
			cell.setFont(fontGulim);
			cell.setFontSize(6);
			cell.setFillColor(Color.LIGHT_GRAY);
		}
		table.addHeaderRow(headerRow);

		List<?> resultList = egovService.selectQueryForList("getConfirmDataList", requestMap);
		if (resultList != null && resultList.size() > 0) {
			Row<PDPage> row = null;
			String[] keys = {"REGION_NM", "TMS_NM", "ITEM_NM", "MSR_DM_FM", "VALID_RATE", "VALID_DD_CNT", "VALID_08_CNT", "VALID_CNT", "MSR_AVG", "MSR_MIN", "MSR_MAX", "MAX_DT", "OVER_CNT", "OVER_RATE", "MIN_0824_VL", "MAX_0824_VL", "MAX_0824_DT", "OVER_0824_CNT", "OVER_08224_RATE", "HOUR_TYPE"};
			for (int i=0; i<resultList.size(); i++) {
				resultMap = (HashMap)resultList.get(i);
				row = table.createRow(15);
				
				for (int j=0; j<keys.length; j++) {
					if (j == 10) cellWidth = 4;
					else if (j == 11) cellWidth = 6;
					else cellWidth = 5;
					
					cell = row.createCell(cellWidth, resultMap.get(keys[j])==null?"-":resultMap.get(keys[j]).toString(), HorizontalAlignment.CENTER, VerticalAlignment.MIDDLE);
					cell.setFont(fontGulim);
					cell.setFontSize(6);
				}
			}
		}
		table.draw();
		
		for (int i = 0; i < document.getNumberOfPages(); i++) {
			String company_name = System.getProperty("COMPANY_NAME")==null?"두일테크":System.getProperty("COMPANY_NAME");
			PDPageContentStream contentStream = new PDPageContentStream(document, document.getPage(i), AppendMode.APPEND, true);
			PDStreamUtils.write(contentStream, company_name, fontGulim, 10, 50, document.getPage(i).getMediaBox().getHeight()-30, new Color(102, 102, 102));
			PDStreamUtils.write(contentStream, "- "+String.valueOf(i + 1)+" / "+document.getNumberOfPages()+" -", fontGulim, 10, document.getPage(i).getMediaBox().getWidth() / 2 - 20, 30, new Color(102, 102, 102));
			
            contentStream.close();
        }
		
		response.setHeader("Content-Type", "application/force-download");
		response.addHeader("Content-Disposition","attachment; filename=ReceiveDataReport.pdf");
		document.save(response.getOutputStream());
		document.close();
	}
	/*자료관리>대기환경보고서 : 목록조회 */
	@RequestMapping(value = "/management/getReportList.ax")
	public Map<String,Object> getReportList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getReportList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		List<?> resultList = egovService.selectQueryForList("getReportList", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	/*자료관리>대기환경보고서 : 파일 및  확정자료 삭제 */
	@RequestMapping(value = "/management/delReportList.ax")
	public Map<String,Object> delReportList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.delReportList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("code", 500);
		resultMap.put("success", false);
		resultMap.put("msg", "요청처리에 문제가 발생하였습니다.");
		
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		try {
			egovService.deleteQuery("delReportList", requestMap);
			if (requestMap.get("rpt_type").toString().equals("F")) egovService.deleteQuery("delDataFinal", requestMap);
			
			resultMap.put("code", 200);
			resultMap.put("success", true);
			resultMap.put("msg", "삭제 되었습니다.");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultMap;
	}
	/*자료관리>대기환경보고서 : 등록(수정) */
	@RequestMapping(value="/management/setReport.ax", method = RequestMethod.POST)
	public Map<String,Object> setReport(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.setReport()");

		//request.setCharacterEncoding("utf-8");
		//response.setContentType("text/plain;charset=UTF-8");

		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		resultMap.put("code", "404");
	    resultMap.put("success", false);
	    
	    requestMap.put("reg_id", request.getSession().getAttribute("USER_ID").toString());
		//requestMap.put("title", new String(requestMap.get("title").toString().getBytes("8859_1"), "UTF-8"));
		//requestMap.put("content", new String(requestMap.get("content").toString().getBytes("8859_1"), "UTF-8"));
		if (requestMap.get("org_file_nm") != null) {
			requestMap.put("org_file_nm", new String(requestMap.get("org_file_nm").toString().getBytes("8859_1"), "UTF-8"));
		}
		if (requestMap.get("save_file_nm") != null) {
			requestMap.put("save_file_nm", new String(requestMap.get("save_file_nm").toString().getBytes("8859_1"), "UTF-8"));
		}
		//requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		//requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("use_yn", requestMap.get("use_yn")==null?"N":requestMap.get("use_yn").toString());
		
		String orgFileName = ""; 
 		String saveFileName = "";
		MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest)request;
		MultipartFile file = multipartHttpServletRequest.getFile( "fileupload" );
		//String filePath = request.getSession().getServletContext().getRealPath("/") + File.separator + "files";
		filePath = filePath==null?"D://files":(filePath.equals("")?"D://files":filePath);
		File dir = new File(filePath);
		if (!dir.isDirectory()) {
			dir.mkdirs();
		}
		if (file != null && !file.getOriginalFilename().equals("")) {
			orgFileName = new String(file.getOriginalFilename().getBytes("8859_1"), "UTF-8");
			orgFileName = orgFileName.trim().replaceAll(" ", "");
			if (orgFileName != null && !orgFileName.equals("") && file.getSize() > 0 && orgFileName.lastIndexOf('.') > 0) {
				String file_extension = orgFileName.substring(orgFileName.lastIndexOf('.')+1);
				if (!file_extension.toLowerCase().equals("exe") 
						&& !file_extension.toLowerCase().equals("com") 
						&& !file_extension.toLowerCase().equals("bat")
						&& !file_extension.toLowerCase().equals("sh")) {
					saveFileName = requestMap.get("rpt_type").toString()+"_"+System.currentTimeMillis()+"."+file_extension.toLowerCase();
					File f = new File(filePath + File.separator + saveFileName);
					file.transferTo(f);
					resultMap.put("code", "200");
					resultMap.put("success", true);
					resultMap.put("msg", "저장되었습니다.");
					resultMap.put("file_nm", saveFileName);
					
					requestMap.put("org_file_nm", orgFileName);
					requestMap.put("save_file_nm", saveFileName);

				} else {
					resultMap.put("msg", "실행파일은 업로드 할 수 없습니다.");
				}
			} else {
				resultMap.put("msg", "잘못된 형식의 파일 입니다.");
			}	
		}
		try {
			int cnt = egovService.insertQueryAfterReturn("setReport", requestMap);
			LOGGER.debug("cnt = "+cnt);
			if (cnt < 1) {
				resultMap.put("code", "500");
				resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
			} else {
				resultMap.put("code", "200");
	            resultMap.put("success", true);
				resultMap.put("msg", resultMap.get("msg") == null ? "저장되었습니다." : resultMap.get("msg").toString());  
			}
		} catch (Exception e) {
			e.printStackTrace();
			resultMap.put("code", "500");
			resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
		}
		LOGGER.debug("resultMap = "+resultMap);
		return resultMap;
	}
	/*자료관리>대기환경보고서 : 첨부파일 다운로드 */
	@RequestMapping(value="/management/getReportFile.do")
	public void getReportFile(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getReportFile()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (requestMap.get("rpt_type")==null || requestMap.get("yyyy")==null || requestMap.get("org_file_nm")==null)
			return;
		
		resultMap = (HashMap)egovService.selectQueryForObject("getReportFile", requestMap);
		
		boolean downloadTF = false;
		String orgFileName = resultMap.get("ORG_FILE_NM").toString();
		String saveFileName = resultMap.get("SAVE_FILE_NM").toString();
		FileInputStream filestream = null;
		OutputStream outStream = null;
		
		try {
			//File downFile = new File(request.getSession().getServletContext().getRealPath("/") + File.separator + "files" + File.separator + saveFileName);
			//String filePath = "D://files";
			filePath = filePath==null?"D://files":(filePath.equals("")?"D://files":filePath);
			File downFile = new File(filePath + File.separator + saveFileName);
			filestream = new FileInputStream(downFile); 
			
			orgFileName = new String(orgFileName.getBytes("UTF-8"),"8859_1");
			response.setHeader("Content-Disposition","attachment; filename="+orgFileName);
			outStream = response.getOutputStream(); 
			
			byte[] buffer = new byte[1024];            
			int readBytes;            
			while ((readBytes = filestream.read(buffer)) != -1) {                
				// 응답 스트림에 파일 바이트 배열을 쓴다.
				outStream.write(buffer, 0, readBytes);            
			}
			downloadTF = true;
			filestream.close();
			outStream.close(); 
		} catch (Exception e) {
			e.printStackTrace(); 
		} finally {            
			try {                
				if (filestream != null) filestream.close();                
				if (outStream != null) outStream.close();                
			} catch (IOException e) {                
				e.printStackTrace();            
			}        
		}
		
	}
	/*자료관리>대기환경보고서:확정자료-등록(수정) */
	@RequestMapping(value="/management/setReportFinal.ax", method = RequestMethod.POST)
	public Map<String,Object> setReportFinal(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.setReportFinal()");

		//request.setCharacterEncoding("utf-8");
		//response.setContentType("text/plain;charset=UTF-8");

		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		resultMap.put("code", "200");
		resultMap.put("success", true);
		resultMap.put("msg", "저장되었습니다.");
	    
	    requestMap.put("reg_id", request.getSession().getAttribute("USER_ID").toString());
		//requestMap.put("title", new String(requestMap.get("title").toString().getBytes("8859_1"), "UTF-8"));
		//requestMap.put("content", new String(requestMap.get("content").toString().getBytes("8859_1"), "UTF-8"));
		if (requestMap.get("org_file_nm") != null) {
			requestMap.put("org_file_nm", new String(requestMap.get("org_file_nm").toString().getBytes("8859_1"), "UTF-8"));
		}
		if (requestMap.get("save_file_nm") != null) {
			requestMap.put("save_file_nm", new String(requestMap.get("save_file_nm").toString().getBytes("8859_1"), "UTF-8"));
		}
		//requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		//requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("use_yn", requestMap.get("use_yn")==null?"N":requestMap.get("use_yn").toString());
		
		String orgFileName = ""; 
 		String saveFileName = "";
 	    Workbook workbook = null;
		
 	    MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest)request;
		MultipartFile file = multipartHttpServletRequest.getFile( "fileupload" );
		//String filePath = request.getSession().getServletContext().getRealPath("/") + File.separator + "files";
		filePath = filePath==null?"D://files":(filePath.equals("")?"D://files":filePath);
		File dir = new File(filePath);
		if (!dir.isDirectory()) {dir.mkdirs();}
		
		try {
			if (file != null && !file.getOriginalFilename().equals("")) {
				orgFileName = new String(file.getOriginalFilename().getBytes("8859_1"), "UTF-8");
				orgFileName = orgFileName.trim().replaceAll(" ", "");
				if (orgFileName != null && !orgFileName.equals("") && file.getSize() > 0 && orgFileName.lastIndexOf('.') > 0) {
					LOGGER.warn("upload File Name = "+orgFileName);
					
					String file_extension = FilenameUtils.getExtension(orgFileName).toLowerCase();
					// 엑셀 97 - 2003 까지는 HSSF(xls),  엑셀 2007 이상은 XSSF(xlsx)
		            if (file_extension.equals("xls")) {
		            	workbook = new HSSFWorkbook(file.getInputStream());
		            } else if (file_extension.equals("xlsx")) {
		                workbook = new XSSFWorkbook(file.getInputStream());
		            } else {
		            	resultMap.put("code", "400");
						resultMap.put("success", true);
						resultMap.put("msg", "엑셀파일형식이 아닙니다.");
						
						return resultMap;
		            }
		            
					//파일읽기 및 DB입력
		            String tms_nm = "";
		            String[] tms_nms = new String[100];
		            String[] item_nms = new String[]{"pmb","pm2","o3b","no2","so2","cob"};
		            List mapList = new ArrayList();
					HashMap map;
		            Sheet worksheet = null;
		            int LastCellNum = 0;
		            int numberOfSheets = workbook.getNumberOfSheets();
		            for (int x=0; x<numberOfSheets ; x++) {
		            	LOGGER.warn("Sheet["+ x +"]'s name is " + workbook.getSheetName(x));
		                //엑셀파일에서 시트 불러오기
		                worksheet = workbook.getSheetAt(x);
		                
			            // getPhysicalNumberOfRow 는 행의 갯수를 불러오는 매소드
			            //LOGGER.warn("worksheet.getLastRowNum()="+worksheet.getLastRowNum());
			            //LOGGER.warn("worksheet.getPhysicalNumberOfRows()="+worksheet.getPhysicalNumberOfRows());
			            for (int i = 0; i < worksheet.getPhysicalNumberOfRows(); i++) {
			            	// i번째 행 정보 가져오기
			                org.apache.poi.ss.usermodel.Row row = worksheet.getRow(i);
			                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.KOREAN);
			                
			                tms_nm = "";
			                mapList = new ArrayList();
			                
			                if (row == null) continue;
			                
			                //빈 셀은 카운트 안함
		                	//System.out.println("row.getPhysicalNumberOfCells()="+row.getPhysicalNumberOfCells());
		                	//빈 셀 포함 카운트
		                	//System.out.println("row.getLastCellNum()="+row.getLastCellNum());
			                if (i == 1) LastCellNum = row.getLastCellNum();
			                if (LastCellNum < row.getLastCellNum()) LastCellNum = row.getLastCellNum();
			                
		                	for (int j = 0; j < LastCellNum; j++) {
		                		// i번째 행의 j번째 셀 정보 가져오기
		                    	org.apache.poi.ss.usermodel.Cell cell = row.getCell(j);
		                    	String value = "";
		                        
		                    	if (cell != null) {
		                            // 타입별로 내용 읽기
		                        	switch (cell.getCellType()) {
		                        		case FORMULA:
		                        			//수식
		                        			//value = cell.getCellFormula();
		                        			//수식결과값
		                        			value = cell.getNumericCellValue() + "";
		                        			break;
		                        		case NUMERIC:
		                        			//if (HSSFDateUtil.isCellDateFormatted(cell)) { // 숫자- 날짜 타입이다.  deprecated
		                        			if (DateUtil.isCellDateFormatted(cell)) { // 숫자- 날짜 타입이다.
		                        				value = formatter.format(cell.getDateCellValue());
		                        			} else {
		                        				double numericCellValue = cell.getNumericCellValue();
		                        				value = String.valueOf(numericCellValue);
		                        				if (numericCellValue == Math.rint(numericCellValue)) {
		                        					value = String.valueOf((int) numericCellValue);
		                        				} else {
		                        					value = String.valueOf(Math.round(numericCellValue * 1000) / 1000.0);
		                        				}
		                        			}
		                        			break;
		                        		case STRING:
		                        			value = cell.getStringCellValue() + "";
		                        			break;
		                        		case BLANK:
		                        			value = "";
		                        			break;
		                        		case ERROR:
		                        			//System.out.println(cell.getErrorCellValue());
		                        			value = "";
		                        			break;
		                        		default:
		                        			value = cell.getStringCellValue();
		                        			break;
		                        	} 	                        	
		                        } else {
		                        	value = "";
		                        }
		                    	//System.out.println(i+","+j+"="+value);
		                        	
		                    	if (i == 0 && Math.floorMod(j,6) == 1) {
		                    		tms_nms[Math.floorDiv(j,6)] = value;
		                    	} else if (i > 1) {
		                    		if (j == 0) {
		                    			if (value.isEmpty()) break;
		                    			value = value.replaceAll("-", "").replaceAll(":", "").replaceAll(" ", "");
		                    			if (value.length() != 12) break; 
		                    			requestMap.put("msr_dt", value);
		                    			//requestMap.put("msr_yy", value.substring(0, 4));
		                    			//requestMap.put("msr_mm", value.substring(4, 6));
		                    			
		                    		} else {
		                    			requestMap.put(item_nms[Math.floorMod(j,6)==0?5:Math.floorMod(j,6)-1], value);
		                    		}
		                    	}
		                    	if (i > 1 && j > 0 && Math.floorMod(j,6) == 0) {
		                    		requestMap.put("tms_nm", tms_nms[Math.floorDiv(j,6)-1]);

		                    		/*for (String key : requestMap.keySet()) {
		                    			System.out.println(String.format("키 : %s, 값 : %s", key, requestMap.get(key)));
		                    		}*/
		                    		//egovService.insertQuery("setDataFinal", requestMap);
		                    		
		                    		map = new HashMap();
		                    		for (String key : requestMap.keySet()) {
		                    			if ("tms_nm,msr_dt,pmb,pm2,o3b,no2,so2,cob,use_yn".contains(key))
		                    				map.put(key, requestMap.get(key));
	                    			}
		                    		mapList.add(map);
		                    	}
		                	}	// end column
		                	if (mapList.size() > 0) egovService.insertBatchHashMap("setDataFinal", mapList);
			            }	// end row
					} // end Sheet
		            workbook.close();
		            
		            //파일저장
		            saveFileName = "F"+"_"+System.currentTimeMillis()+"."+file_extension.toLowerCase();
					File f = new File(filePath + File.separator + saveFileName);
					file.transferTo(f);
					
					resultMap.put("file_nm", saveFileName);
					requestMap.put("org_file_nm", orgFileName);
					requestMap.put("save_file_nm", saveFileName);
		            
				} else {
					resultMap.put("msg", "잘못된 형식의 파일 입니다.");
				}
			}
		} catch (Exception e) {
			LOGGER.warn("파일 처리에 문제가 발생하였습니다.");
			LOGGER.warn(e.getMessage());
			e.printStackTrace(); 
			
			if (workbook != null) workbook.close(); 
			resultMap.put("code", "500");
			resultMap.put("success", false);
			resultMap.put("msg", "파일 처리에 문제가 발생하였습니다.");
			egovService.deleteQuery("delDataFinal", requestMap);
			egovService.deleteQuery("delReportList", requestMap);
		}
		try {
			for( String key : requestMap.keySet() ){
				//LOGGER.debug(String.format("키 : %s, 값 : %s", key, requestMap.get(key)));
			}
			if (!resultMap.get("code").toString().equals("500")) {	
				int cnt = egovService.insertQueryAfterReturn("setReport", requestMap);

				if (cnt < 1) {
					resultMap.put("code", "400");
					resultMap.put("success", true);
					resultMap.put("msg", "파일등록에 문제가 발생하엿습니다.");
				} else {
					egovService.updateQuery("updateDataFinal", requestMap);
					resultMap.put("code", "200");
		            resultMap.put("success", true);
					resultMap.put("msg", resultMap.get("msg") == null ? "저장되었습니다." : resultMap.get("msg").toString());  
				}
			}
		} catch (Exception e) {
			LOGGER.warn("파일 등록에 문제가 발생하였습니다.");
			LOGGER.warn(e.getMessage());
			e.printStackTrace(); 
			resultMap.put("code", "500");
			resultMap.put("success", false);
			resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
		}

		LOGGER.debug("resultMap = "+resultMap);
		return resultMap;
	}
	
	
/*분석통계*/	
	/*분석통계>시간자료 : 시간평균 자료(사용자 측정소) */
	@RequestMapping(value="/analysis/getTimeList.ax")
	public Map<String,Object> getTimeList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getTimeList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}
		
		List<?> resultList = egovService.selectQueryForList("getTimeList", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	/*분석통계>시간평균 : 엑셀다운*/
	@RequestMapping(value = "/analysis/getTimeExcelReport.do")
	public ModelAndView getTimeExcelReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getTimeExcelReport()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		//HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}

		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		List<?> resultList = egovService.selectQueryForList("getTimeList", requestMap);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/report/timeAnalysisReport");// setViewName() 메서드를 이용하여 뷰 이름을 지정한 모습		
		mv.getModel().put("list", resultList);
		mv.getModel().put("item_nm", requestMap.get("item_nm").toString());
		mv.getModel().put("term", "기간: "+sd+" ~ "+ed);
		
		return mv;
	}
	/*분석통계>시간평균 : PDF다운*/
	@RequestMapping(value = "/analysis/getTimePDFReport.do")
	public void getTimePDFReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getTimePDFReport()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}

		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		List<?> resultList = egovService.selectQueryForList("getTimeList", requestMap);
		if (resultList != null && resultList.size() > 0) {
			
			PDDocument document = new PDDocument();
			PDPage page = new PDPage(new PDRectangle(PDRectangle.A4.getHeight(), PDRectangle.A4.getWidth()));
			PDRectangle rect = page.getMediaBox();
			File fontFile = new File(request.getSession().getServletContext().getRealPath("/") + File.separator + "fonts"  + File.separator + "GULIM.TTC");
			PDType0Font fontGulim = PDType0Font.load(document, new TrueTypeCollection(fontFile).getFontByName("Gulim"), true);
			
			document.addPage(page);
			
			boolean drawLines = true;
			boolean drawContent = true;
			float margin = 30;
			float yStartNewPage = page.getMediaBox().getHeight() - margin;
			float tableWidth = page.getMediaBox().getWidth() - (2 * margin);
			float bottomMargin = 50;
			float topMargin = page.getMediaBox().getHeight() - margin;
			
			BaseTable table = new BaseTable(yStartNewPage, topMargin, bottomMargin, tableWidth, margin, document, page, drawLines, drawContent);
			
			Row<PDPage> headerRow = null;
			Cell<PDPage> cell = null;
			
			headerRow = table.createRow(50);
			cell = headerRow.createCell(100, requestMap.get("item_nm").toString()+" 시간평균 리포트");
			cell.setFont(fontGulim);
			cell.setFontSize(20);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "조회기간: "+sd+" ~ "+ed);
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setTopBorderStyle(null);
			cell.setLeftBorderStyle(null);
			cell.setRightBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(7, "시군");
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(6.6f, "측정소");
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			String title = "";
			for (int i=0; i<24; i++) {
				if (i<10) {
					title = "0"+i+"시";
				} else {
					title = i+"시";
				}
				cell = headerRow.createCell(3.6f, title);
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setValign(VerticalAlignment.MIDDLE);
				cell.setAlign(HorizontalAlignment.CENTER);
				cell.setFillColor(Color.LIGHT_GRAY);
			}
			table.addHeaderRow(headerRow);
			
			Row<PDPage> row = null;
			for (int i=0; i<resultList.size(); i++) {
				resultMap = (HashMap)resultList.get(i);
				row = table.createRow(20);
				
				cell = row.createCell(7, resultMap.get("REGION_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(6.6f, resultMap.get("TMS_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				String key = "";
				for (int j=0; j<24; j++) {
					if (j<10) {
						key = "H0"+j;
					} else {
						key = "H"+j;
					}
					cell = row.createCell(3.6f, resultMap.get(key)==null?"-":resultMap.get(key).toString());
					cell.setFont(fontGulim);
					cell.setFontSize(6);
					cell.setAlign(HorizontalAlignment.CENTER);
				}
			}
			table.draw();
			
			for (int i = 0; i < document.getNumberOfPages(); i++) {
				String company_name = System.getProperty("COMPANY_NAME")==null?"두일테크":System.getProperty("COMPANY_NAME");
				PDPageContentStream contentStream = new PDPageContentStream(document, document.getPage(i), AppendMode.APPEND, true);
				//PDStreamUtils.write(PDPageContentStream stream, String text, PDFont font, float fontSize, float x, float y, Color color)
				PDStreamUtils.write(contentStream, company_name, fontGulim, 10, 50, document.getPage(i).getMediaBox().getHeight()-30, new Color(102, 102, 102));
				PDStreamUtils.write(contentStream, "- "+String.valueOf(i + 1)+" / "+document.getNumberOfPages()+" -", fontGulim, 10, document.getPage(i).getMediaBox().getWidth() / 2 - 20, 30, new Color(102, 102, 102));
				
	            contentStream.close();
	        }
			
			response.setHeader("Content-Type", "application/force-download");
			response.addHeader("Content-Disposition","attachment; filename=DayAverageReport.pdf");
			document.save(response.getOutputStream());
			document.close();
		}
	}
	/*분석통계>요일평균 : 자료(사용자 측정소) */
	@RequestMapping(value="/analysis/getWeekList.ax")
	public Map<String,Object> getWeekList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getWeekList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}
		
		List<?> resultList = egovService.selectQueryForList("getWeekList", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	/*분석통계>요일평균 : 엑셀다운*/
	@RequestMapping(value = "/analysis/getWeekExcelReport.do")
	public ModelAndView getWeekExcelReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getWeekExcelReport()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		//HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}

		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		List<?> resultList = egovService.selectQueryForList("getWeekList", requestMap);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/report/weekAnalysisReport");// setViewName() 메서드를 이용하여 뷰 이름을 지정한 모습		
		mv.getModel().put("list", resultList);
		mv.getModel().put("item_nm", requestMap.get("item_nm").toString());
		mv.getModel().put("term", "기간: "+sd+" ~ "+ed);
		
		return mv;
	}
	/*분석통계>요일평균 : PDF다운*/
	@RequestMapping(value = "/analysis/getWeekPDFReport.do")
	public void getWeekPDFReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getWeekPDFReport()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}

		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		List<?> resultList = egovService.selectQueryForList("getWeekList", requestMap);
		if (resultList != null && resultList.size() > 0) {
			
			PDDocument document = new PDDocument();
			PDPage page = new PDPage(new PDRectangle(PDRectangle.A4.getHeight(), PDRectangle.A4.getWidth()));
			PDRectangle rect = page.getMediaBox();
			File fontFile = new File(request.getSession().getServletContext().getRealPath("/") + File.separator + "fonts"  + File.separator + "GULIM.TTC");
			PDType0Font fontGulim = PDType0Font.load(document, new TrueTypeCollection(fontFile).getFontByName("Gulim"), true);
			
			document.addPage(page);
			
			boolean drawLines = true;
			boolean drawContent = true;
			float margin = 30;
			float yStartNewPage = page.getMediaBox().getHeight() - margin;
			float tableWidth = page.getMediaBox().getWidth() - (2 * margin);
			float bottomMargin = 50;
			float topMargin = page.getMediaBox().getHeight() - margin;
			
			BaseTable table = new BaseTable(yStartNewPage, topMargin, bottomMargin, tableWidth, margin, document, page, drawLines, drawContent);
			
			Row<PDPage> headerRow = null;
			Cell<PDPage> cell = null;
			
			headerRow = table.createRow(50);
			cell = headerRow.createCell(100, requestMap.get("item_nm").toString()+ " 요일평균 리포트");
			cell.setFont(fontGulim);
			cell.setFontSize(20);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "조회기간: "+sd+" ~ "+ed);
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setTopBorderStyle(null);
			cell.setLeftBorderStyle(null);
			cell.setRightBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(12, "시군");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "측정소");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "월요일");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "화요일");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);

			cell = headerRow.createCell(11, "수요일");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "목요일");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "금요일");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "토요일");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(11, "일요일");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			table.addHeaderRow(headerRow);
			
			Row<PDPage> row = null;
			for (int i=0; i<resultList.size(); i++) {
				resultMap = (HashMap)resultList.get(i);
				row = table.createRow(20);
				
				cell = row.createCell(12, resultMap.get("REGION_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(11, resultMap.get("TMS_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(10);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				String key = "";
				for (int j=0; j<7; j++) {
					key = "W"+j;
					cell = row.createCell(11, resultMap.get(key)==null?"-":resultMap.get(key).toString());
					cell.setFont(fontGulim);
					cell.setFontSize(10);
					cell.setAlign(HorizontalAlignment.CENTER);
				}
			}
			table.draw();
			
			for (int i = 0; i < document.getNumberOfPages(); i++) {
				String company_name = System.getProperty("COMPANY_NAME")==null?"두일테크":System.getProperty("COMPANY_NAME");
				PDPageContentStream contentStream = new PDPageContentStream(document, document.getPage(i), AppendMode.APPEND, true);
				//PDStreamUtils.write(PDPageContentStream stream, String text, PDFont font, float fontSize, float x, float y, Color color)
				PDStreamUtils.write(contentStream, company_name, fontGulim, 10, 50, document.getPage(i).getMediaBox().getHeight()-30, new Color(102, 102, 102));
				PDStreamUtils.write(contentStream, "- "+String.valueOf(i + 1)+" / "+document.getNumberOfPages()+" -", fontGulim, 10, document.getPage(i).getMediaBox().getWidth() / 2 - 20, 30, new Color(102, 102, 102));
				
	            contentStream.close();
	        }
			
			response.setHeader("Content-Type", "application/force-download");
			response.addHeader("Content-Disposition","attachment; filename=WeekAverageReport.pdf");
			document.save(response.getOutputStream());
			document.close();
		}
	}
	/*분석통계>일자별 평균 : 자료(사용자 측정소) */
	@RequestMapping(value="/analysis/getDayList.ax")
	public Map<String,Object> getDayList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getDayList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}
		
		List<?> resultList = egovService.selectQueryForList("getDayList", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	/*분석통계>일자별 평균 : 엑셀다운*/
	@RequestMapping(value = "/analysis/getDayExcelReport.do")
	public ModelAndView getDayExcelReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getDayExcelReport()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		//HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}

		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		List<?> resultList = egovService.selectQueryForList("getDayList", requestMap);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/report/dayAnalysisReport");// setViewName() 메서드를 이용하여 뷰 이름을 지정한 모습		
		mv.getModel().put("list", resultList);
		mv.getModel().put("item_nm", requestMap.get("item_nm").toString());
		mv.getModel().put("term", "기간: "+sd+" ~ "+ed);
		
		return mv;
	}
	/*분석통계>일자별 평균 : PDF다운*/
	@RequestMapping(value = "/analysis/getDayPDFReport.do")
	public void getDayPDFReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getDayPDFReport()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}

		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		List<?> resultList = egovService.selectQueryForList("getDayList", requestMap);
		if (resultList != null && resultList.size() > 0) {
			
			PDDocument document = new PDDocument();
			PDPage page = new PDPage(new PDRectangle(PDRectangle.A4.getHeight(), PDRectangle.A4.getWidth()));
			PDRectangle rect = page.getMediaBox();
			File fontFile = new File(request.getSession().getServletContext().getRealPath("/") + File.separator + "fonts"  + File.separator + "GULIM.TTC");
			PDType0Font fontGulim = PDType0Font.load(document, new TrueTypeCollection(fontFile).getFontByName("Gulim"), true);
			
			document.addPage(page);
			
			boolean drawLines = true;
			boolean drawContent = true;
			float margin = 30;
			float yStartNewPage = page.getMediaBox().getHeight() - margin;
			float tableWidth = page.getMediaBox().getWidth() - (2 * margin);
			float bottomMargin = 50;
			float topMargin = page.getMediaBox().getHeight() - margin;
			
			BaseTable table = new BaseTable(yStartNewPage, topMargin, bottomMargin, tableWidth, margin, document, page, drawLines, drawContent);
			
			Row<PDPage> headerRow = null;
			Cell<PDPage> cell = null;
			
			headerRow = table.createRow(50);
			cell = headerRow.createCell(100, requestMap.get("item_nm").toString()+ " 일일평균 리포트");
			cell.setFont(fontGulim);
			cell.setFontSize(20);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "조회기간: "+sd+" ~ "+ed);
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setTopBorderStyle(null);
			cell.setLeftBorderStyle(null);
			cell.setRightBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(6.6f, "시군");
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(6.6f, "측정소");
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			for (int i=1; i<32; i++) {
				cell = headerRow.createCell(2.8f, i+"일");
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setValign(VerticalAlignment.MIDDLE);
				cell.setAlign(HorizontalAlignment.CENTER);
				cell.setFillColor(Color.LIGHT_GRAY);
			}
			table.addHeaderRow(headerRow);
			
			Row<PDPage> row = null;
			for (int i=0; i<resultList.size(); i++) {
				resultMap = (HashMap)resultList.get(i);
				row = table.createRow(20);
				
				cell = row.createCell(6.6f, resultMap.get("REGION_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(6.6f, resultMap.get("TMS_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				String key = "";
				for (int j=1; j<32; j++) {
					if (j<10) {
						key = "D0"+j;
					} else {
						key = "D"+j;
					}
					cell = row.createCell(2.8f, resultMap.get(key)==null?"-":resultMap.get(key).toString());
					cell.setFont(fontGulim);
					cell.setFontSize(6);
					cell.setAlign(HorizontalAlignment.CENTER);
				}
			}
			table.draw();
			
			for (int i = 0; i < document.getNumberOfPages(); i++) {
				String company_name = System.getProperty("COMPANY_NAME")==null?"두일테크":System.getProperty("COMPANY_NAME");
				PDPageContentStream contentStream = new PDPageContentStream(document, document.getPage(i), AppendMode.APPEND, true);
				//PDStreamUtils.write(PDPageContentStream stream, String text, PDFont font, float fontSize, float x, float y, Color color)
				PDStreamUtils.write(contentStream, company_name, fontGulim, 10, 50, document.getPage(i).getMediaBox().getHeight()-30, new Color(102, 102, 102));
				PDStreamUtils.write(contentStream, "- "+String.valueOf(i + 1)+" / "+document.getNumberOfPages()+" -", fontGulim, 10, document.getPage(i).getMediaBox().getWidth() / 2 - 20, 30, new Color(102, 102, 102));
				
	            contentStream.close();
	        }
			
			response.setHeader("Content-Type", "application/force-download");
			response.addHeader("Content-Disposition","attachment; filename=DayAverageReport.pdf");
			document.save(response.getOutputStream());
			document.close();
		}
	}
	/*분석통계>월별 평균 : 자료(사용자 측정소) */
	@RequestMapping(value="/analysis/getMonthList.ax")
	public Map<String,Object> getMonthList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getMonthList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}
		
		List<?> resultList = egovService.selectQueryForList("getMonthList", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	/*분석통계>월별 평균 : 엑셀다운*/
	@RequestMapping(value = "/analysis/getMonthExcelReport.do")
	public ModelAndView getMonthExcelReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getMonthExcelReport()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		//HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}

		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		List<?> resultList = egovService.selectQueryForList("getMonthList", requestMap);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/report/monthAnalysisReport");// setViewName() 메서드를 이용하여 뷰 이름을 지정한 모습		
		mv.getModel().put("list", resultList);
		mv.getModel().put("item_nm", requestMap.get("item_nm").toString());
		mv.getModel().put("term", "기간: "+sd+" ~ "+ed);
		
		return mv;
	}
	/*분석통계>월별 평균 : PDF다운*/
	@RequestMapping(value = "/analysis/getMonthPDFReport.do")
	public void getMonthPDFReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getMonthPDFReport()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}

		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		List<?> resultList = egovService.selectQueryForList("getMonthList", requestMap);
		if (resultList != null && resultList.size() > 0) {
			
			PDDocument document = new PDDocument();
			PDPage page = new PDPage(new PDRectangle(PDRectangle.A4.getHeight(), PDRectangle.A4.getWidth()));
			PDRectangle rect = page.getMediaBox();
			File fontFile = new File(request.getSession().getServletContext().getRealPath("/") + File.separator + "fonts"  + File.separator + "GULIM.TTC");
			PDType0Font fontGulim = PDType0Font.load(document, new TrueTypeCollection(fontFile).getFontByName("Gulim"), true);
			
			document.addPage(page);
			
			boolean drawLines = true;
			boolean drawContent = true;
			float margin = 30;
			float yStartNewPage = page.getMediaBox().getHeight() - margin;
			float tableWidth = page.getMediaBox().getWidth() - (2 * margin);
			float bottomMargin = 50;
			float topMargin = page.getMediaBox().getHeight() - margin;
			
			BaseTable table = new BaseTable(yStartNewPage, topMargin, bottomMargin, tableWidth, margin, document, page, drawLines, drawContent);
			
			Row<PDPage> headerRow = null;
			Cell<PDPage> cell = null;
			
			headerRow = table.createRow(50);
			cell = headerRow.createCell(100, requestMap.get("item_nm").toString()+ " 월평균 리포트");
			cell.setFont(fontGulim);
			cell.setFontSize(20);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "조회기간: "+sd+" ~ "+ed);
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setTopBorderStyle(null);
			cell.setLeftBorderStyle(null);
			cell.setRightBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(9.2f, "시군");
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(9.2f, "측정소");
			cell.setFont(fontGulim);
			cell.setFontSize(8);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			for (int i=1; i<13; i++) {
				cell = headerRow.createCell(6.8f, i+"월");
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setValign(VerticalAlignment.MIDDLE);
				cell.setAlign(HorizontalAlignment.CENTER);
				cell.setFillColor(Color.LIGHT_GRAY);
			}
			table.addHeaderRow(headerRow);
			
			Row<PDPage> row = null;
			for (int i=0; i<resultList.size(); i++) {
				resultMap = (HashMap)resultList.get(i);
				row = table.createRow(20);
				
				cell = row.createCell(9.2f, resultMap.get("REGION_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				cell = row.createCell(9.2f, resultMap.get("TMS_NM").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				String key = "";
				for (int j=1; j<13; j++) {
					if (j<10) {
						key = "M0"+j;
					} else {
						key = "M"+j;
					}
					cell = row.createCell(6.8f, resultMap.get(key)==null?"-":resultMap.get(key).toString());
					cell.setFont(fontGulim);
					cell.setFontSize(8);
					cell.setAlign(HorizontalAlignment.CENTER);
				}
			}
			table.draw();
			
			for (int i = 0; i < document.getNumberOfPages(); i++) {
				String company_name = System.getProperty("COMPANY_NAME")==null?"두일테크":System.getProperty("COMPANY_NAME");
				PDPageContentStream contentStream = new PDPageContentStream(document, document.getPage(i), AppendMode.APPEND, true);
				//PDStreamUtils.write(PDPageContentStream stream, String text, PDFont font, float fontSize, float x, float y, Color color)
				PDStreamUtils.write(contentStream, company_name, fontGulim, 10, 50, document.getPage(i).getMediaBox().getHeight()-30, new Color(102, 102, 102));
				PDStreamUtils.write(contentStream, "- "+String.valueOf(i + 1)+" / "+document.getNumberOfPages()+" -", fontGulim, 10, document.getPage(i).getMediaBox().getWidth() / 2 - 20, 30, new Color(102, 102, 102));
				
	            contentStream.close();
	        }
			
			response.setHeader("Content-Type", "application/force-download");
			response.addHeader("Content-Disposition","attachment; filename=MonthAverageReport.pdf");
			document.save(response.getOutputStream());
			document.close();
		}
	}
	
/*cni system*/
	/*시스템관리>측정소관리 : 전체TMS정보*/
	@RequestMapping(value="/system/getTmsList.ax")
	public Map<String,Object> getTmsList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getTmsList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		List resultList = egovService.selectQueryForList("getTmsList", requestMap);

		/*HashMap<String, Object> defaultMap = new HashMap<String, Object>();
		defaultMap.put("order_seq", 0);
		defaultMap.put("tms_nm", "전체");
		defaultMap.put("tms_id", "ALL");
		resultList.add(defaultMap);*/
		
		resultMap.put("data", resultList);
		return resultMap;
	}
	/*측정소 정보 등록 / 수정*/
	@RequestMapping(value = "/system/setTmsInfo.ax")
	public HashMap<String, Object> setTmsInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.setTmsInfo()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("reg_id",request.getSession().getAttribute("USER_ID").toString());
		
		if (requestMap.get("use_yn") != null && requestMap.get("use_yn").toString().equals("on")) requestMap.put("use_yn", "Y");
		else requestMap.put("use_yn", "N");
		
		try {
			String work_cd = requestMap.get("work_cd").toString();
			if (work_cd.equals("I") && egovService.selectQueryForObject("getTmsInfo", requestMap) != null) 
				work_cd = "X";
				
			if (!work_cd.equals("X")) {
				egovService.insertQuery("setTmsInfo", requestMap);
				
				/* 측정소별 측정항목 자동등록
				if (work_cd.equals("I")) {
					egovService.insertQuery("setTmsItemInfo", requestMap);
				}*/
				
				resultMap.put("code", 200);
			} else {
				resultMap.put("code", 300);
				resultMap.put("msg", "측정소ID는 중복될수 없습니다.");
			}
		} catch (Exception e) {
			resultMap.put("code", 500);
			resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
			e.printStackTrace();
		}
		
		return resultMap;
	}
	/* 측정소별 항목 조회 */
	@RequestMapping(value="/system/getTmsItemList.ax")
	public Map<String,Object> getTmsItemList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getTmsItemList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		List resultList = egovService.selectQueryForList("getTmsItemList", requestMap);
		String[] tms_items = new String[resultList.size()];
		for (int i=0; i<resultList.size(); i++) {
			resultMap = (HashMap)resultList.get(i);
			tms_items[i] = ((HashMap)resultList.get(i)).get("ITEM_CD").toString();
		}
		resultMap.put("items", tms_items);
		
		return resultMap;
	}
	/* 측정소별 항목등록 */
	@RequestMapping(value="/system/setTmsItem.ax")
	public Map<String,Object> setTmsItem(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.setTmsItem()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		resultMap.put("code", "404");
		resultMap.put("success", false);
		resultMap.put("msg", "항목등록에 오류가발생하였습니다.");
		
		if (requestMap.get("tms_cd") != null) {
			//기존항목 지우기
			egovService.deleteQuery("resetTmsItems", requestMap);
			
			String tms_cd = requestMap.get("tms_cd").toString();
			String[] tms_items = requestMap.get("tms_item_menus").toString().split(",");
			List mapList = new ArrayList();
			HashMap map;
			for (int i=0; i<tms_items.length; i++) {
				map = new HashMap();
				map.put("tms_cd", tms_cd);
				map.put("item_cd", tms_items[i]);
				map.put("order_seq", i);
				mapList.add(map);
			}
			
			try {
				egovService.insertBatchHashMap("setTmsItems", mapList);
				resultMap.put("success", true);
				resultMap.put("code", "200");
				resultMap.put("msg", "측정항목이 등록되었습니다.");
			} catch (Exception e) {
				resultMap.put("code", 500);
				resultMap.put("msg", "항목등록 중 오류가발생하였습니다.");
				e.printStackTrace();
			}
		}
		
		/*if (requestMap.get("params") != null) {
			//기존항목 지우기
			egovService.deleteQuery("resetTmsItems", requestMap);
			requestMap.put("reg_id",request.getSession().getAttribute("USER_ID").toString());
			
			List mapList = new ArrayList();
			HashMap map;
			String tms_cd = requestMap.get("tms_cd").toString();
			String[] tms_items = requestMap.get("params").toString().replaceAll("tms_item_menus=", "").split(",");
			for (int i=0; i<tms_items.length; i++) {
				map = new HashMap();
				map.put("tms_cd", tms_cd);
				map.put("item_cd", tms_items[i]);
				map.put("order_seq", i);
				mapList.add(map);
			}
			int i = egovService.insertBatchHashMap("setTmsItems", mapList);
			resultMap.put("code", "200");
			resultMap.put("msg", "측정항목이 등록되었습니다.");
		}*/  

		return resultMap;
	}

	/*시스템관리>사용자관리:사용자목록조회*/
	@RequestMapping(value="/system/getUserList.ax")
	public Map<String,Object> getUserList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getUserList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		//requestMap.put("admin_yn", request.getSession().getAttribute("ADMIN_YN").toString());
		
		String sqlMapID = "getUserList";
		List<?> resultList = null;
		if (requestMap.get("search_txt") == null) {
			resultList = egovService.selectQueryForList(sqlMapID, requestMap);
		} else {
			resultList = egovService.selectQueryForList(sqlMapID, requestMap);
		}
		/*for (int i=0; i<resultList.size(); i++) {
			resultMap = (HashMap)resultList.get(i);
		}*/
		resultMap.put("code", 200);
		resultMap.put("msg", "정상");
		resultMap.put("data", resultList);
		return resultMap;
	}	
	
	/*시스템관리>사용자관리:사용자정보등록수정*/
	@RequestMapping(value = "/system/setUserInfo.ax", method = RequestMethod.POST)
	public HashMap<String, Object> setUserInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.setUserInfo()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (requestMap.get("job_cd") == null) requestMap.put("job_cd", "C");
		if (requestMap.get("sms_yn") == null) requestMap.put("sms_yn", "N");
		
		//로그인사용자 비밀번호 변경
		if (requestMap.get("job_cd").toString().equals("C") && requestMap.get("user_id") == null) {
			requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
			resultMap = (HashMap<String, Object>)egovService.selectQueryForObject("getLoginInfo", requestMap);
			
			if (resultMap != null) {
				if (!Encryption.makeHash(requestMap.get("user_pw").toString()).equals(resultMap.get("USER_PW").toString())) {
					resultMap.put("code", 400);
					resultMap.put("msg", "현재비밀번호를 확인하세요!");
					return resultMap;
				}
				
			} else {
				resultMap.put("code", 500);
				resultMap.put("msg", "사용자정보를 찾을수 없습니다.<br />다시 로그인 하시기 바랍니다.");
				return resultMap;
			}
			
			try {
				requestMap.put("confirm_pw", Encryption.makeHash(requestMap.get("confirm_pw").toString()));
				if (egovService.updateQueryAfterReturn("setUserPassword", requestMap) > 0) {
					resultMap.put("code", 200);
					resultMap.put("msg", "Y");
				} else {
					LOGGER.warn("Exception at EgovController.setUserInfo() setUserPassword Faile!");
					resultMap.put("code", 500);
					resultMap.put("msg", "비밀번호 변경이 실패 하였습니다.");
				}
			} catch (Exception e) {
				resultMap.put("code", 500);
				resultMap.put("msg", "비밀번호 변경이 실패 하였습니다.");
				e.printStackTrace();
			}
			return resultMap;
		}
		
		//사용자 정보 등록 / 수정
		if (requestMap.get("admin_yn") != null && requestMap.get("admin_yn").toString().equals("on")) requestMap.put("admin_yn", "Y");
		else requestMap.put("admin_yn", "N");
		
		if (requestMap.get("use_yn") != null && requestMap.get("use_yn").toString().equals("on")) requestMap.put("use_yn", "Y");
		else requestMap.put("use_yn", "N");
		
		requestMap.put("reg_id",request.getSession().getAttribute("USER_ID").toString());
		
		try {
			if (requestMap.get("confirm_pw") != null) requestMap.put("confirm_pw", Encryption.makeHash(requestMap.get("confirm_pw").toString()));
			egovService.insertQuery("setUserInfo", requestMap);
			
			if (requestMap.get("job_cd").toString().equals("I")) {
				 requestMap.put("s_tm", "09");
				 requestMap.put("e_tm", "18");
				 requestMap.put("sound_yn", "Y");
				 requestMap.put("alert_yn", "Y");
				egovService.insertQuery("setUserConfig", requestMap);
			}
			
			resultMap.put("code", 200);
			resultMap.put("msg", "Y");
		} catch (Exception e) {
			resultMap.put("code", 500);
			resultMap.put("msg", "중복ID 또는 저장에 실패하였습니다.");
			e.printStackTrace();
		}
		return resultMap;
	}
	
	/* 시스템전체 메뉴 조회 */
	@RequestMapping(value="/system/getMenuList.ax")
	public Map<String,Object> getMenuList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getMenuList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		//requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		
		List resultList = egovService.selectQueryForList("getMenuList", requestMap);

		resultMap.put("data", resultList);
		return resultMap;
	}
	/* 사용자 권한(메뉴) 정보 조회 */
	@RequestMapping(value="/system/getUserRoleList.ax")
	public Map<String,Object> getUserRoleList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getUserRoleList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		List resultList = egovService.selectQueryForList("getUserRoleList", requestMap);
		String[] user_roles = new String[resultList.size()];
		for (int i=0; i<resultList.size(); i++) {
			resultMap = (HashMap)resultList.get(i);
			user_roles[i] = ((HashMap)resultList.get(i)).get("MENU_ID").toString();
		}
		
		//String[] roles = {"statusPanel","userPanel","dataPanel"};
		resultMap.put("roles", user_roles);
		
		return resultMap;
	}
	/* 시스템관리>사용자관리:사용자 권한(메뉴) 저장*/
	@RequestMapping(value="/system/setUserRoles.ax")
	public Map<String,Object> setUserRoles(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.setUserRoles()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		resultMap.put("code", "404");
		resultMap.put("success", false);
		resultMap.put("msg", "저장할 정보가 없거나 저장에 실패 하였습니다.");
		
		if (requestMap.get("user_id") != null) {
			//기존권한 지우기
			egovService.deleteQuery("resetUserRoles", requestMap);
			
			String user_id = requestMap.get("user_id").toString();
			String reg_id = request.getSession().getAttribute("USER_ID").toString();
			String[] user_roles = requestMap.get("user_role_menus").toString().split(",");
			List mapList = new ArrayList();
			HashMap map;
			for (int i=0; i<user_roles.length; i++) {
				map = new HashMap();
				map.put("user_id", user_id);
				map.put("menu_id", user_roles[i]);
				map.put("reg_id", reg_id);
				mapList.add(map);
			}
			
			try {
				egovService.insertBatchHashMap("setUserRoles", mapList);
				resultMap.put("code", "200");
				resultMap.put("success", true);
				resultMap.put("msg", "사용자 권한이 등록되었습니다.");
			} catch (Exception e) {
				resultMap.put("code", 500);
				resultMap.put("msg", "권힌등록 중 오류가발생하였습니다.");
				e.printStackTrace();
			}
		}
		
		/*if (requestMap.get("params") != null) {
			egovService.deleteQuery("resetUserRoles", requestMap);
			requestMap.put("reg_id",request.getSession().getAttribute("USER_ID").toString());
			
			String[] user_roles = requestMap.get("params").toString().replaceAll("user_role_menus=", "").split(",");
			
			List mapList = new ArrayList();
			HashMap map;
			String user_id = requestMap.get("user_id").toString();
			String reg_id = request.getSession().getAttribute("USER_ID").toString();
			for (int i=0; i<user_roles.length; i++) {
				map = new HashMap();
				map.put("user_id", user_id);
				map.put("menu_id", user_roles[i]);
				map.put("reg_id", reg_id);
				mapList.add(map);	
			}
			int i = egovService.insertBatchHashMap("setUserRoles", mapList);
			resultMap.put("code", "200");
			resultMap.put("success", true);
			resultMap.put("msg", "사용자 권한 정보가 등록(수정) 되었습니다.");
		}*/
		LOGGER.debug("resultMap = "+resultMap);
		return resultMap;
	}
	/*시스템관리>사용자관리:사용자 측정소 목록 조회*/
	@RequestMapping(value="/system/getUserTmsList.ax")
	public Map<String,Object> getUserTmsList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getUserTmsList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		if (requestMap.get("user_id") == null)
			requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		
		List resultList = egovService.selectQueryForList("getUserTmsList", requestMap);
		String[] user_tms = new String[resultList.size()];
		for (int i=0; i<resultList.size(); i++) {
			resultMap = (HashMap)resultList.get(i);
			user_tms[i] = ((HashMap)resultList.get(i)).get("TMS_CD").toString();
		}
		
		//String[] roles = {"statusPanel","userPanel","dataPanel"};
		resultMap.put("user_tms", user_tms);
		
		return resultMap;
	}
	/* 시스템관리>사용자관리:사용자 측정소 저장*/
	@RequestMapping(value="/system/setUserTms.ax")
	public Map<String,Object> setUserTms(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.setUserTms()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		String reg_id = request.getSession().getAttribute("USER_ID").toString();
		
		resultMap.put("code", "404");
		resultMap.put("success", false);
		resultMap.put("msg", "저장할 정보가 없거나 저장에 실패 하였습니다.");
		
		/*if (requestMap.get("params") != null) {
			//기존 측정소 지우기
			egovService.deleteQuery("resetUserTms", requestMap);
			String user_id = requestMap.get("user_id").toString(); 
			String[] user_tms_list = requestMap.get("params").toString().replaceAll("user_tms_list=", "").split(",");
			List mapList = new ArrayList();
			HashMap map;
			for (int i=0; i<user_tms_list.length; i++) {
				map = new HashMap();
				map.put("user_id", user_id);
				map.put("tms_cd", user_tms_list[i]);
				map.put("reg_id", reg_id);
				map.put("order_seq", i);
			    mapList.add(map);
			}
			int i = egovService.insertBatchHashMap("setUserTms", mapList);
			resultMap.put("code", "200");
			resultMap.put("success", true);
			resultMap.put("msg", "측정소("+i+"개) 정보가 등록(수정) 되었습니다.");
		}*/  

		if (requestMap.get("user_id") != null) {
			//기존 측정소 지우기
			egovService.deleteQuery("resetUserTms", requestMap);
			
			String user_id = requestMap.get("user_id").toString();
			String[] user_tms_list = requestMap.get("user_tms_list").toString().split(",");
			List mapList = new ArrayList();
			HashMap map;
			for (int i=0; i<user_tms_list.length; i++) {
				map = new HashMap();
				map.put("user_id", user_id);
				map.put("tms_cd", user_tms_list[i]);
				map.put("reg_id", reg_id);
				map.put("order_seq", i);
			    mapList.add(map);
			}
			
			try {
				egovService.insertBatchHashMap("setUserTms", mapList);
				resultMap.put("code", "200");
				resultMap.put("success", true);
				resultMap.put("msg", "사용자 측정소정보가 등록(수정) 되었습니다.");
			} catch (Exception e) {
				resultMap.put("code", 500);
				resultMap.put("msg", "측정소등록 중 오류가발생하였습니다.");
				e.printStackTrace();
			}
		}
		return resultMap;
	}
	/* 시스템관리>로그인*/
	@RequestMapping(value = "/system/getLoginInfo.ax", method = RequestMethod.POST) 
	public HashMap<String, Object> getLoginInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getLoginInfo()");
		//LOGGER.debug(">>> Client IP = " + SessionCheckInterceptor.getRemoteAddr(request));
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (request.getSession().getAttribute("LOGIN_TF") != null && (boolean)request.getSession().getAttribute("LOGIN_TF")) {
			resultMap.put("code", 200);
			resultMap.put("msg", request.getSession().getAttribute("USER_NM").toString() + "님 반갑습니다.");
			resultMap.put("USER_ID", request.getSession().getAttribute("USER_ID").toString());
			resultMap.put("USER_NM", request.getSession().getAttribute("USER_NM").toString());
			resultMap.put("SOUND_YN", request.getSession().getAttribute("SOUND_YN")==null?"Y":request.getSession().getAttribute("SOUND_YN").toString());
			resultMap.put("ALERT_YN", request.getSession().getAttribute("ALERT_YN")==null?"Y":request.getSession().getAttribute("ALERT_YN").toString());
			resultMap.put("S_TM", request.getSession().getAttribute("S_TM")==null?"09":request.getSession().getAttribute("S_TM").toString());
			resultMap.put("E_TM", request.getSession().getAttribute("E_TM")==null?"18":request.getSession().getAttribute("E_TM").toString());
			resultMap.put("DASHBOARD_ITEM", request.getSession().getAttribute("DASHBOARD_ITEM")==null?"CAI":request.getSession().getAttribute("DASHBOARD_ITEM").toString());
			resultMap.put("DASHBOARD_ITEM_NM", request.getSession().getAttribute("DASHBOARD_ITEM_NM")==null?"통합대기환경지수":request.getSession().getAttribute("DASHBOARD_ITEM_NM").toString());
			
		} else {
			if (requestMap.get("user_id") == null || requestMap.get("user_pw") == null) {
				resultMap.put("code", 404);
				resultMap.put("msg", "로그인이 필요합니다.");
				
			} else {
				try {
					resultMap = (HashMap)egovService.selectQueryForObject("getLoginInfo", requestMap);
					
					if (resultMap == null) {
						resultMap = new HashMap<String, Object>();
						resultMap.put("code", 404);
						resultMap.put("msg", "ID 또는 비밀번호를 확인하세요.");
					
					} else if (Encryption.makeHash(requestMap.get("user_pw").toString()).equals(resultMap.get("USER_PW").toString()) && resultMap.get("USE_YN").toString().equals("N")) {
						resultMap.put("code", 204);
						resultMap.put("msg", "사용이 중지된 ID입니다");
					
					} else if (Encryption.makeHash(requestMap.get("user_pw").toString()).equals(resultMap.get("USER_PW").toString())) {
						
						System.out.println(">>> Encryption Test = "+Encryption.makeHash(requestMap.get("user_pw").toString()));
						LOGGER.warn("*************************************************");
						LOGGER.warn("* Login info");
						LOGGER.warn("* Login ID = "+resultMap.get("USER_ID").toString());
						LOGGER.warn("* Login Time = "+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()));
						LOGGER.warn("*************************************************");
						
						resultMap.remove("USSER_PW");
						resultMap.put("code", 200);
						resultMap.put("msg", resultMap.get("USER_NM").toString()+"님 반갑습니다.");
						
						if (readProperties(request)) {
							resultMap.put("VERSION", System.getProperty("VERSION")==null?"3.0":System.getProperty("VERSION"));
							resultMap.put("COMPANY_NAME", System.getProperty("COMPANY_NAME")==null?"두일테크":System.getProperty("COMPANY_NAME"));
						}
						
						request.getSession().setAttribute("LOGIN_TF", true);
						request.getSession().setAttribute("USER_ID", resultMap.get("USER_ID").toString());
						request.getSession().setAttribute("USER_NM", resultMap.get("USER_NM").toString());
						request.getSession().setAttribute("ADMIN_YN", resultMap.get("ADMIN_YN").toString());
						request.getSession().setAttribute("SOUND_YN", resultMap.get("SOUND_YN")==null?"Y":resultMap.get("SOUND_YN").toString());
						request.getSession().setAttribute("ALERT_YN", resultMap.get("ALERT_YN")==null?"Y":resultMap.get("ALERT_YN").toString());
						request.getSession().setAttribute("S_TM", resultMap.get("S_TM")==null?"09":resultMap.get("S_TM").toString());
						request.getSession().setAttribute("E_TM", resultMap.get("E_TM")==null?"18":resultMap.get("E_TM").toString());
						request.getSession().setAttribute("DASHBOARD_ITEM", resultMap.get("DASHBOARD_ITEM")==null?"CAI":resultMap.get("DASHBOARD_ITEM").toString());
						request.getSession().setAttribute("DASHBOARD_ITEM_NM", resultMap.get("DASHBOARD_ITEM_NM")==null?"통합대기환경지수":resultMap.get("DASHBOARD_ITEM_NM").toString());
												
					} else {
						resultMap.put("code", 400);
						resultMap.put("msg", "ID 또는 비밀번호를 확인하세요");
					}
				} catch (Exception e) {
		            e.printStackTrace();
		            
		            resultMap.put("code", 400);
					resultMap.put("msg", "로그인 처리에 문제가 발생하였습니다.");
				}
			}
		}
		
		return resultMap;
	}
	/* 시스템관리>로그아웃 */
	@RequestMapping(value = "/system/logout.ax")
	public HashMap<String, Object> logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.logout()");
		
		HashMap<String, Object> requestMap = new HashMap<String, Object>();
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		request.getSession().setAttribute("LOGIN_TF", false);
		
		resultMap.put("code", 200);
		resultMap.put("msg", "로그아웃 되었습니다.");
		//request.getSession().invalidate();	
		return resultMap;
	}
	/* 시스템관리>사용자 권한 체크 Y/N*/
	@RequestMapping(value="/system/getAuthorityCheck.ax", method = RequestMethod.POST)
	public Map<String,Object> getAuthorityCheck(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getAuthorityCheck()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (request.getSession().getAttribute("USER_ID") == null) {
			resultMap.put("code", "000");
			resultMap.put("msg", "로그아웃 되었습니다.");
			return resultMap;
		}
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		
		resultMap = (HashMap)egovService.selectQueryForObject("getAuthorityCheck", requestMap);
		if (resultMap.get("AUTHORITY_YN").toString().equals("Y")) {
			if (resultMap.get("ADMIN_YN").toString().equals("Y") && !request.getSession().getAttribute("ADMIN_YN").toString().equals("Y")) {
				resultMap.put("code", 404);
				resultMap.put("msg", "권한이 없습니다.");
			} else {
				resultMap.put("code", 200);
			}
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "권한이 없습니다.");
		}

		return resultMap;
	}
	
	/*시스템관리>항목별등급관리:항목별등급정보조회*/
	@RequestMapping(value="/system/getLevelInfoList.ax")
	public Map<String,Object> getLevelInfoList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getLevelInfoList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		//requestMap.put("admin_yn", request.getSession().getAttribute("ADMIN_YN").toString());

		List resultList = egovService.selectQueryForList("getLevelInfoList", requestMap);

		resultMap.put("code", 200);
		resultMap.put("msg", "정상");
		resultMap.put("data", resultList);
		return resultMap;
	}	
	/*시스템관리>항목별등급관리:항목별등급정보등록(수정)*/
	@RequestMapping(value = "/system/setLevelInfo.ax")
	public HashMap<String, Object> setLevelInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.setLevelInfo()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		try {
			egovService.insertQuery("setLevelInfo", requestMap);
			resultMap.put("code", 200);
		} catch (Exception e) {
			resultMap.put("code", 500);
			resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
			e.printStackTrace();
		}
		
		return resultMap;
	}
	/*시스템관리>SMS:목록조회*/
	@RequestMapping(value="/system/getReceiverList.ax")
	public Map<String,Object> getReceiverList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getReceiverList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		requestMap.put("admin_yn", request.getSession().getAttribute("ADMIN_YN").toString());
		
		String sqlMapID = "getReceiverList";
		List<?> resultList = null;
		if (requestMap.get("search_txt") == null) {
			resultList = egovService.selectQueryForList(sqlMapID, requestMap);
		} else {
			resultList = egovService.selectQueryForList("getReceiverList", requestMap);
		}

		resultMap.put("data", resultList);
		return resultMap;
	}
	@RequestMapping(value="/system/getSmsConfig.ax")
	public Map<String,Object> getSmsConfig(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getSmsConfig()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		resultMap.put("code", "404");
		
		List resultList = egovService.selectQueryForList("getSmsConfig");
		if (resultList != null) {
			resultMap = (HashMap)resultList.get(0);
			resultMap.put("code", "200");
			/*resultMap.put("service_id", ((HashMap)resultList.get(0)).get("service_id").toString());
			resultMap.put("send_num", ((HashMap)resultList.get(0)).get("send_num").toString());
			resultMap.put("service_key", ((HashMap)resultList.get(0)).get("service_key").toString());
			resultMap.put("testmode_yn", ((HashMap)resultList.get(0)).get("testmode_yn").toString());*/
		}
		
		return resultMap;
	}
	@RequestMapping(value="/system/setSmsConfig.ax")
	public Map<String,Object> setSmsConfig(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.setSmsConfig()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("testmode_yn", requestMap.get("testmode_yn")==null?"N":"Y");
		
		try {
			egovService.insertQuery("setSmsConfig", requestMap);
			resultMap.put("code", "200");
		} catch (Exception e) {
			LOGGER.warn("Exception at EgovController.setSmsConfig()");
			resultMap.put("code", "500");
			resultMap.put("msg", "SMS환경정보 등록 작업에 오류가 발생하였습니다.");
			e.printStackTrace();
		}
		return resultMap;
	}
	/*SMS발송조건 조회*/
	@RequestMapping(value="/system/getSmsCondition.ax")
	public Map<String,Object> getSmsCondition(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getSmsCondition()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		HashMap<String, Object> tempMap = new HashMap<String, Object>();
		
		//requestMap.put("testmode_yn", requestMap.get("testmode_yn")==null?"N":"Y");
		
		try {
			List resultList = egovService.selectQueryForList("getSystemConfigList");
			for (int i=0; i<resultList.size(); i++) {
				tempMap = (HashMap)resultList.get(i);
				resultMap.put(tempMap.get("KEY").toString(), tempMap.get("VAL").toString());
			}
			resultMap.put("code", "200");
		} catch (Exception e) {
			LOGGER.warn("Exception at EgovController.setSmsConfig()");
			resultMap.put("code", "500");
			resultMap.put("msg", "SMS발송조건 조회에 오류가 발생하였습니다.");
			e.printStackTrace();
		}
		return resultMap;
	}
	/*SMS발송조건 등록*/
	@RequestMapping(value="/system/setSmsCondition.ax")
	public Map<String,Object> setSmsCondition(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.setSmsCondition()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		//requestMap.put("testmode_yn", requestMap.get("testmode_yn")==null?"N":"Y");
		requestMap.put("val", "Y");
		try {
			requestMap.put("key", "warning_c");
			if (requestMap.get("warning_c") == null) requestMap.put("val", "N");
			else requestMap.put("val", "Y");
			egovService.updateQueryAfterReturn("setSmsCondition", requestMap);
			
			requestMap.put("key", "warning_d");
			if (requestMap.get("warning_d") == null) requestMap.put("val", "N");
			else requestMap.put("val", "Y");
			egovService.updateQueryAfterReturn("setSmsCondition", requestMap);
			
			requestMap.put("key", "warning_e");
			if (requestMap.get("warning_e") == null) requestMap.put("val", "N");
			else requestMap.put("val", "Y");
			egovService.updateQueryAfterReturn("setSmsCondition", requestMap);
			
			requestMap.put("key", "level_c");
			if (requestMap.get("level_c") == null) requestMap.put("val", "N");
			else requestMap.put("val", "Y");
			egovService.updateQueryAfterReturn("setSmsCondition", requestMap);
			
			requestMap.put("key", "level_d");
			if (requestMap.get("level_d") == null) requestMap.put("val", "N");
			else requestMap.put("val", "Y");
			egovService.updateQueryAfterReturn("setSmsCondition", requestMap);
			
			requestMap.put("key", "over_yn");
			if (requestMap.get("over_yn") == null) requestMap.put("val", "N");
			else requestMap.put("val", "Y");
			egovService.updateQueryAfterReturn("setSmsCondition", requestMap);
			
			requestMap.put("key", "level_x");
			if (requestMap.get("level_x") == null) requestMap.put("val", "N");
			else requestMap.put("val", "Y");
			egovService.updateQueryAfterReturn("setSmsCondition", requestMap);
				
			requestMap.put("key", "level_z");
			if (requestMap.get("level_z") == null) requestMap.put("val", "N");
			else requestMap.put("val", "Y");
			egovService.updateQueryAfterReturn("setSmsCondition", requestMap);
			
			requestMap.put("key", "level_z");
			if (requestMap.get("level_z") == null) requestMap.put("val", "N");
			else requestMap.put("val", "Y");
			egovService.updateQueryAfterReturn("setSmsCondition", requestMap);
			
			requestMap.put("key", "receive_st");
			requestMap.put("val", requestMap.get("receive_st").toString());
			egovService.updateQueryAfterReturn("setSmsCondition", requestMap);
			
			requestMap.put("key", "receive_ed");
			requestMap.put("val", requestMap.get("receive_ed").toString());
			egovService.updateQueryAfterReturn("setSmsCondition", requestMap);
			
			resultMap.put("code", "200");
		} catch (Exception e) {
			LOGGER.warn("Exception at EgovController.setSmsConfig()");
			resultMap.put("code", "500");
			resultMap.put("msg", "SMS환경정보 등록 작업에 오류가 발생하였습니다.");
			e.printStackTrace();
		}
		return resultMap;
	}
	/*시스템관리>SMS:사용자 등록/수정 */
	@RequestMapping(value="/system/setReceiveInfo.ax")
	public Map<String,Object> setReceiveInfo(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.setReceiveInfo()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		if (requestMap.get("job_cd") == null) requestMap.put("job_cd", "U");
		requestMap.put("use_yn", requestMap.get("use_yn")==null?"N":"Y");
		requestMap.put("reg_id", request.getSession().getAttribute("USER_ID").toString());
		requestMap.put("search_key", "receive_num");
		requestMap.put("search_txt", requestMap.get("receive_num").toString());
		
		try {
			if (requestMap.get("del_yn") != null) {
				egovService.deleteQuery("delReceiveInfo", requestMap);
				egovService.deleteQuery("delSmsUserTms", requestMap);
			} else {
				if (requestMap.get("job_cd").toString().equals("I") && (HashMap)egovService.selectQueryForObject("getReceiverList", requestMap) != null) {
					resultMap.put("code", "400");
					resultMap.put("msg", "이미 등록 되었거나  사용할 수 없는 번호입니다.");
					return resultMap;
				}
				egovService.insertQuery("setReceiveInfo", requestMap);
			}
				resultMap.put("code", "200");
		} catch (Exception e) {
			LOGGER.warn("Exception at EgovController.setReceiveInfo()");
			resultMap.put("msg", "수신자 정보가 중복 되었거나 작업에 오류가 발생하였습니다.");
			e.printStackTrace();
		}
		
		return resultMap;
	}
	@RequestMapping(value="/system/getSmsSendList.ax")
	public Map<String,Object> getSmsSendList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getSmsSendList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		
		//requestMap.put("admin_yn", request.getSession().getAttribute("ADMIN_YN").toString());
		
		List<?> resultList = egovService.selectQueryForList("getSmsSendList", requestMap);
		
		resultMap.put("code", 200);
		resultMap.put("msg", "정상");
		resultMap.put("data", resultList);
		
		return resultMap;
	}	
	@RequestMapping(value="/system/getSmsUserTmsList.ax")
	public Map<String,Object> getSmsUserTmsList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getSmsUserTmsList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		List resultList = egovService.selectQueryForList("getSmsUserTmsList", requestMap);
		String[] user_tms = new String[resultList.size()];
		for (int i=0; i<resultList.size(); i++) {
			resultMap = (HashMap)resultList.get(i);
			user_tms[i] = ((HashMap)resultList.get(i)).get("TMS_CD").toString();
		}
		resultMap.put("tms", user_tms);
		return resultMap;
	}
	@RequestMapping(value="/system/setSmsUserTms.ax")
	public Map<String,Object> setSmsUserTms(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.setSmsUserTms()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		/*if (requestMap.get("params") != null) {
			//기존권한 지우기
			egovService.deleteQuery("resetSmsUserTms", requestMap);
			
			String[] user_tms = requestMap.get("params").toString().replaceAll("user_tms_menus=", "").split(",");
			for (int i=0; i<user_tms.length; i++) {
			    LOGGER.debug(user_tms[i]);
			    requestMap.put("tms_cd", user_tms[i]);
			    egovService.insertQuery("setSmsUserTms", requestMap);
			    requestMap.remove("tms_cd");
			}
		}*/  
		resultMap.put("code", "404");
		resultMap.put("success", false);
		resultMap.put("msg", "저장할 정보가 없거나 저장에 실패 하였습니다.");
		if (requestMap.get("receive_nm") != null && requestMap.get("receive_num") != null) {
			//기존권한 지우기
			egovService.deleteQuery("resetSmsUserTms", requestMap);
			
			String receive_nm = requestMap.get("receive_nm").toString();
			String receive_num = requestMap.get("receive_num").toString();
			String reg_id = request.getSession().getAttribute("USER_ID").toString();
			String[] user_tms = requestMap.get("user_tms_menus").toString().split(",");
			List mapList = new ArrayList();
			HashMap map;
			for (int i=0; i<user_tms.length; i++) {
				map = new HashMap();
				map.put("receive_nm", receive_nm);
				map.put("receive_num", receive_num);
				map.put("tms_cd", user_tms[i]);
				map.put("reg_id", reg_id);
				mapList.add(map);
			}
			try {
				egovService.insertBatchHashMap("setSmsUserTms", mapList);
				resultMap.put("code", "200");
				resultMap.put("success", true);
				resultMap.put("msg", "사용자 측정소가 등록(수정) 되었습니다.");
			} catch (Exception e) {
				resultMap.put("code", 500);
				resultMap.put("msg", "측정소등록 중 오류가발생하였습니다.");
				e.printStackTrace();
			}
		}
		resultMap.put("result", "Y");
		return resultMap;
	}
	
	/*시스템관리>API: 사용자정보 */
	@RequestMapping(value="/system/getApiUser.ax")
	public Map<String,Object> getApiUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getApiUser()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		
		String sqlMapID = "getReceiverList";
		List<?> resultList = egovService.selectQueryForList("getApiUser", requestMap);
		resultMap.put("data", resultList);
		
		return resultMap;
	}
	/*시스템관리>API:사용자 등록/수정 */
	@RequestMapping(value="/system/setApiUser.ax")
	public Map<String,Object> setApiUser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.setApiUser()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		if (requestMap.get("job_cd") == null) requestMap.put("job_cd", "U");
		requestMap.put("reg_id", request.getSession().getAttribute("USER_ID").toString());
		requestMap.put("s_day", requestMap.get("s_day").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_day", requestMap.get("e_day").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("use_yn", requestMap.get("use_yn")==null?"N":"Y");
		requestMap.put("search_key", "api_key");
		requestMap.put("search_txt", requestMap.get("api_key")==null?"api_key":requestMap.get("api_key").toString());
		
		try {

				if (requestMap.get("job_cd").toString().equals("I") && (HashMap)egovService.selectQueryForObject("getApiUser", requestMap) != null) {
					resultMap.put("code", "400");
					resultMap.put("msg", "사용중인 API 사용자 입니다");
					return resultMap;
				}
				if (requestMap.get("job_cd").toString().equals("I")) {
					requestMap.put("api_key", Encryption.makeHash(requestMap.get("user_tel").toString()));
				}
				egovService.insertQuery("setApiUser", requestMap);
				
				resultMap.put("code", "200");
		} catch (Exception e) {
			LOGGER.warn("Exception at EgovController.setReceiveInfo()");
			resultMap.put("msg", "수신자 정보가 중복 되었거나 작업에 오류가 발생하였습니다.");
			e.printStackTrace();
		}
		
		return resultMap;
	}
	/*시스템관리>API:요청목록조회*/
	@RequestMapping(value="/system/getApiReqList.ax")
	public Map<String,Object> getApiReqList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getApiReqList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		
		
		List<?> resultList = egovService.selectQueryForList("getApiReqList", requestMap);
		
		resultMap.put("code", 200);
		resultMap.put("msg", "정상");
		resultMap.put("data", resultList);

		return resultMap;
	}
	/*API: 실시간 측정정보 - 시간자료 */
	@RequestMapping(value="/api/data/getApiRealTimeData.ax")
	//public Map<String,Object> getApiRealTimeData(HttpServletRequest request, HttpServletResponse response)  throws Exception {
	public Map<String,Object> getApiRealTimeData(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getApiRealTimeData()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		String client_ip = request.getHeader("X-Forwarded-For");
	    if (client_ip == null) client_ip = request.getRemoteAddr();
	    requestMap.put("req_ip", client_ip);
	    requestMap.put("req_url", request.getRequestURI());
	    requestMap.put("api_key", requestMap.get("key")==null?"":requestMap.get("key").toString());
	    requestMap.put("ver_num", requestMap.get("ver")==null?"1.0":requestMap.get("ver").toString());
	    requestMap.put("check", "Y");
	    
	    try {
		    //apiKey 검증
	    	resultMap = (HashMap)egovService.selectQueryForObject("getApiUser", requestMap);
	    	if (resultMap == null) {
	    		requestMap.put("err_cd", "900");
	    		
	    		resultMap = new HashMap<String, Object>();
	    		resultMap.put("CODE", "900");
				resultMap.put("MSG", "잘못된키");
				return resultMap;
	    	}
	    	
		    //자료조회
		    List resultList = egovService.selectQueryForList("getApiRealTimeData", requestMap);
		    resultMap = new HashMap<String, Object>();
		    if (resultList==null || resultList.size() < 1) {
		    	resultMap.put("CODE", "400");
				resultMap.put("MSG", "자료없음");
				
				requestMap.put("success_yn", "Y");
				requestMap.put("err_cd", "400");
				egovService.insertQuery("setApiReqList", requestMap);
				
		    } else {
		    	resultMap.put("CODE", "200");
			    resultMap.put("ITEMS", resultList);
			    resultMap.put("MSG", "정상");
			    
			    requestMap.put("success_yn", "Y");
			    requestMap.put("err_cd", "200");
			    egovService.insertQuery("setApiReqList", requestMap);
		    }
			
	    } catch (Exception e) {
			e.printStackTrace();
			//throw new RuntimeException("Error EgovController.getLoginInfo Cause : " + e);
			resultMap = new HashMap<String, Object>();
			resultMap.put("CODE", "500");
			resultMap.put("MSG", "서비스오류");
			
			requestMap.put("success_yn", "N");
			requestMap.put("err_cd", "500");
			egovService.insertQuery("setApiReqList", requestMap);
	    } finally {
		}
		return resultMap;
		
		/*String str = "";
		JSONObject json = new JSONObject(resultMap);
		String xml = XML.toString(json);
		System.out.println("====================================================================================================");
		System.out.println(xml); 
	    
		return Response.status(Status.OK).entity(xml).build();*/
	    
	}
	/*API: 측정소별 24시간 측정정보 - 시간자료 */
	@RequestMapping(value="/api/data/getApiTmsData.ax")
	public Map<String,Object> getApiTmsData(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getApiTmsData()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		String client_ip = request.getHeader("X-Forwarded-For");
	    if (client_ip == null) client_ip = request.getRemoteAddr();
	    requestMap.put("req_ip", client_ip);
	    requestMap.put("req_url", request.getRequestURI());
	    requestMap.put("api_key", requestMap.get("key")==null?"":requestMap.get("key").toString());
	    requestMap.put("tms_cd", requestMap.get("tms_cd")==null?"":requestMap.get("tms_cd").toString());
	    requestMap.put("ver_num", requestMap.get("ver")==null?"1.0":requestMap.get("ver").toString());
	    requestMap.put("check", "Y");
	    
	    try {
		    //apiKey 검증
	    	resultMap = (HashMap)egovService.selectQueryForObject("getApiUser", requestMap);
	    	if (resultMap == null) {
	    		requestMap.put("err_cd", "900");
	    		
	    		resultMap = new HashMap<String, Object>();
	    		resultMap.put("CODE", "900");
				resultMap.put("MSG", "잘못된키");
				return resultMap;
	    	}
	    	
		    //자료조회
	    	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMddHHmm");
	    	requestMap.put("req_dt", simpleDateFormat.format(new Date(System.currentTimeMillis())).toString());
			
		    List resultList = egovService.selectQueryForList("getApiTmsData", requestMap);
		    resultMap = new HashMap<String, Object>();
		    if (resultList==null || resultList.size() < 1) {
		    	resultMap.put("CODE", "400");
				resultMap.put("MSG", "자료없음");
				
				requestMap.put("success_yn", "Y");
				requestMap.put("err_cd", "400");
				egovService.insertQuery("setApiReqList", requestMap);
				
		    } else {
		    	resultMap.put("CODE", "200");
			    resultMap.put("ITEMS", resultList);
			    resultMap.put("MSG", "정상");
			    
			    requestMap.put("success_yn", "Y");
			    requestMap.put("err_cd", "200");
			    egovService.insertQuery("setApiReqList", requestMap);
		    }
			
	    } catch (Exception e) {
			e.printStackTrace();
			//throw new RuntimeException("Error EgovController.getLoginInfo Cause : " + e);
			resultMap = new HashMap<String, Object>();
			resultMap.put("CODE", "500");
			resultMap.put("MSG", "서비스오류");
			
			requestMap.put("success_yn", "N");
			requestMap.put("err_cd", "500");
			egovService.insertQuery("setApiReqList", requestMap);
	    } finally {
		}
		return resultMap;
	}
	/*API: 측정소정보조회 */
	@RequestMapping(value="/api/data/getApiTmsInfo.ax")
	public Map<String,Object> getApiTmsInfo(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getApiTmsInfo()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		String client_ip = request.getHeader("X-Forwarded-For");
	    if (client_ip == null) client_ip = request.getRemoteAddr();
	    requestMap.put("req_ip", client_ip);
	    requestMap.put("req_url", request.getRequestURI());
	    requestMap.put("api_key", requestMap.get("key")==null?"":requestMap.get("key").toString());
	    requestMap.put("ver_num", requestMap.get("ver")==null?"1.0":requestMap.get("ver").toString());
	    requestMap.put("check", "Y");
	    
	    try {
		    //apiKey 검증
	    	resultMap = (HashMap)egovService.selectQueryForObject("getApiUser", requestMap);
	    	if (resultMap == null) {
	    		requestMap.put("err_cd", "900");
	    		
	    		resultMap = new HashMap<String, Object>();
	    		resultMap.put("CODE", "900");
				resultMap.put("MSG", "잘못된키");
				return resultMap;
	    	}
			
		    List resultList = egovService.selectQueryForList("getApiTmsInfo", requestMap);
		    resultMap = new HashMap<String, Object>();
		    if (resultList==null || resultList.size() < 1) {
		    	resultMap.put("CODE", "400");
				resultMap.put("MSG", "자료없음");
				
				requestMap.put("success_yn", "Y");
				requestMap.put("err_cd", "400");
				egovService.insertQuery("setApiReqList", requestMap);
				
		    } else {
		    	resultMap.put("CODE", "200");
			    resultMap.put("ITEMS", resultList);
			    resultMap.put("MSG", "정상");
			    
			    requestMap.put("success_yn", "Y");
			    requestMap.put("err_cd", "200");
			    egovService.insertQuery("setApiReqList", requestMap);
		    }
			
	    } catch (Exception e) {
			e.printStackTrace();
			//throw new RuntimeException("Error EgovController.getLoginInfo Cause : " + e);
			resultMap = new HashMap<String, Object>();
			resultMap.put("CODE", "500");
			resultMap.put("MSG", "서비스오류");
			
			requestMap.put("success_yn", "N");
			requestMap.put("err_cd", "500");
			egovService.insertQuery("setApiReqList", requestMap);
	    } finally {
		}
		return resultMap;
	}
	/*공지사항: 공지사항목록 */
	@RequestMapping(value="/system/getNoticeList.ax")
	public Map<String,Object> getNoticeList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getNoticeList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		
		//requestMap.put("admin_yn", request.getSession().getAttribute("ADMIN_YN").toString());
		
		List<?> resultList = egovService.selectQueryForList("getNoticeList", requestMap);
		
		resultMap.put("code", 200);
		resultMap.put("msg", "정상");
		resultMap.put("data", resultList);
		
		return resultMap;
	}	
	/*공지사항: 공지사항등록(수정) */
	@RequestMapping(value="/system/setNotice.ax", method = RequestMethod.POST)
	public Map<String,Object> setNotice(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.setNotice()");

		//request.setCharacterEncoding("utf-8");
		//response.setContentType("text/plain;charset=UTF-8");

		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		resultMap.put("code", "404");
	    resultMap.put("success", false);
	    
	    requestMap.put("reg_id", request.getSession().getAttribute("USER_ID").toString());
		requestMap.put("title", new String(requestMap.get("title").toString().getBytes("8859_1"), "UTF-8"));
		requestMap.put("content", new String(requestMap.get("content").toString().getBytes("8859_1"), "UTF-8"));
		if (requestMap.get("org_file_nm") != null) {
			requestMap.put("org_file_nm", new String(requestMap.get("org_file_nm").toString().getBytes("8859_1"), "UTF-8"));
		}
		if (requestMap.get("save_file_nm") != null) {
			requestMap.put("save_file_nm", new String(requestMap.get("save_file_nm").toString().getBytes("8859_1"), "UTF-8"));
		}
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("use_yn", requestMap.get("use_yn")==null?"N":requestMap.get("use_yn").toString());
		
		String orgFileName = ""; 
 		String saveFileName = "";
		MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest)request;
		MultipartFile file = multipartHttpServletRequest.getFile( "fileupload" );
		//String filePath = request.getSession().getServletContext().getRealPath("/") + File.separator + "files";
		filePath = filePath==null?"D://files":(filePath.equals("")?"D://files":filePath);
		File dir = new File(filePath);
		if (!dir.isDirectory()) {
			dir.mkdirs();
		}
		if (file != null && !file.getOriginalFilename().equals("")) {
			orgFileName = new String(file.getOriginalFilename().getBytes("8859_1"), "UTF-8");
			orgFileName = orgFileName.trim().replaceAll(" ", "");
			if (orgFileName != null && !orgFileName.equals("") && file.getSize() > 0 && orgFileName.lastIndexOf('.') > 0) {
				String file_extension = orgFileName.substring(orgFileName.lastIndexOf('.')+1);
				if (!file_extension.toLowerCase().equals("exe") 
						&& !file_extension.toLowerCase().equals("com") 
						&& !file_extension.toLowerCase().equals("bat")
						&& !file_extension.toLowerCase().equals("sh")) {
					saveFileName = requestMap.get("board_type").toString()+"_"+System.currentTimeMillis()+"."+file_extension.toLowerCase();
					File f = new File(filePath + File.separator + saveFileName);
					file.transferTo(f);
					resultMap.put("code", "200");
					resultMap.put("success", true);
					resultMap.put("msg", "저장되었습니다.");
					resultMap.put("file_nm", saveFileName);
					
					requestMap.put("org_file_nm", orgFileName);
					requestMap.put("save_file_nm", saveFileName);

				} else {
					resultMap.put("msg", "실행파일은 업로드 할 수 없습니다.");
				}
			} else {
				resultMap.put("msg", "잘못된 형식의 파일 입니다.");
			}	
		}
		try {
			int cnt = egovService.insertQueryAfterReturn("setNotice", requestMap);
			LOGGER.debug("cnt = "+cnt);
			if (cnt < 1) {
				resultMap.put("code", "500");
				resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
			} else {
				resultMap.put("code", "200");
	            resultMap.put("success", true);
				resultMap.put("msg", resultMap.get("msg") == null ? "저장되었습니다." : resultMap.get("msg").toString());  
			}
		} catch (Exception e) {
			e.printStackTrace();
			resultMap.put("code", "500");
			resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
		}
		LOGGER.debug("resultMap = "+resultMap);
		return resultMap;
	}
	/*공지사항: 공지사항 첨부파일 다운로드 */
	@RequestMapping(value="/system/getNoticeFile.do")
	public void getNoticeFile(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getNoticeFile()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (requestMap.get("seq")==null || requestMap.get("org_file_nm")==null)
			return;
		
		resultMap = (HashMap)egovService.selectQueryForObject("getSaveFileNM", requestMap);
		
		boolean downloadTF = false;
		String orgFileName = resultMap.get("ORG_FILE_NM").toString();
		String saveFileName = resultMap.get("SAVE_FILE_NM").toString();
		FileInputStream filestream = null;
		OutputStream outStream = null;
		
		try {
			//File downFile = new File(request.getSession().getServletContext().getRealPath("/") + File.separator + "files" + File.separator + saveFileName);
			//String filePath = "D://files";
			filePath = filePath==null?"D://files":(filePath.equals("")?"D://files":filePath);
			File downFile = new File(filePath + File.separator + saveFileName);
			filestream = new FileInputStream(downFile); 
			
			orgFileName = new String(orgFileName.getBytes("UTF-8"),"8859_1");
			response.setHeader("Content-Disposition","attachment; filename="+orgFileName);
			outStream = response.getOutputStream(); 
			
			byte[] buffer = new byte[1024];            
			int readBytes;            
			while ((readBytes = filestream.read(buffer)) != -1) {                
				// 응답 스트림에 파일 바이트 배열을 쓴다.
				outStream.write(buffer, 0, readBytes);            
			}
			downloadTF = true;
			filestream.close();
			outStream.close(); 
		} catch (Exception e) {
			e.printStackTrace(); 
		} finally {            
			try {                
				if (filestream != null) filestream.close();                
				if (outStream != null) outStream.close();                
			} catch (IOException e) {                
				e.printStackTrace();            
			}        
		}
		
	}
	
	/*방문기록: 방문기록 */
	@RequestMapping(value="/system/getVisitList.ax")
	public Map<String,Object> getVisitList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getVisitList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		
		List<?> resultList = egovService.selectQueryForList("getVisitList", requestMap);
		
		resultMap.put("code", 200);
		resultMap.put("msg", "정상");
		resultMap.put("data", resultList);
		
		return resultMap;
	}	
	/*방문기록: 방문기록 엑셀다운*/
	@RequestMapping(value = "/system/getVisitExcel.do")
	public ModelAndView getVisitExcel(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getVisitExcel()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").replaceAll("/", "").substring(0, 8));
		
		List<?> resultList = egovService.selectQueryForList("getVisitList", requestMap);
		
		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("report/visitList");// setViewName() 메서드를 이용하여 뷰 이름을 지정	
		mv.getModel().put("list", resultList);
		mv.getModel().put("content_group", requestMap.get("content_group").toString());
		mv.getModel().put("term", "기간: "+sd+" ~ "+ed);
		
		return mv;
	}
	
	/*유틸:쿼리브라우저*/
	@RequestMapping(value = "/system/getQueryBrowser.do")
	public ModelAndView getQueryBrowser(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getQueryBrowser()");
        
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/queryBrowser");		
		
		return mv;
	}
	
	/*유틸: System.properties File 읽기*/
	public boolean readProperties(HttpServletRequest request) {
		LOGGER.warn("Method = EgovController.readProperties()");
		
		boolean TF = false;
		
		Properties properties = new Properties();
		Enumeration enumeration = null;
		try {
			String key = "";
			//properties.load(getClass().getResourceAsStream("/system.properties"));
			properties.load(new FileInputStream(request.getSession().getServletContext().getRealPath("/") + File.separator + "WEB-INF" + File.separator + "system.properties"));
			enumeration = properties.propertyNames();
			while (enumeration.hasMoreElements()) {
				key = (String)enumeration.nextElement();
				System.setProperty(key, properties.getProperty(key));
				LOGGER.debug("Key = " + key + ", value = "+ properties.getProperty(key));
			}
			TF = true;
		} catch (Exception e) {
			e.printStackTrace();
			//throw new RuntimeException("Error EgovController.getLoginInfo Cause : " + e); 
		} finally {
			
		}
		return TF;
		
	}
	/*유틸 : System.properties File 쓰기*/
	public boolean writeProperties(HttpServletRequest request) {
		LOGGER.warn("Method = EgovController.writeProperties()");
		
		boolean TF = false;
		
		String filePath = request.getSession().getServletContext().getRealPath("/");
		FileOutputStream fileOutputStream;
		Properties properties = new Properties(); 
		try {
			String key = "";
			Enumeration enumeration = System.getProperties().propertyNames();
			while (enumeration.hasMoreElements()) {
				key = (String)enumeration.nextElement();
				properties.setProperty(key, System.getProperty(key));
			}
			
			fileOutputStream = new FileOutputStream(filePath + File.separator + "WEB-INF" + File.separator + "system.properties");
			String header = "This is Configuration Value! (" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())+ ")";
			properties.store(fileOutputStream, header);
			fileOutputStream.close();
			TF = true;
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Error EgovController.getLoginInfo Cause : " + e); 
		}
		
		return TF;
		
	}
	/*유틸: request 파라메터 정보 출력*/
	public HashMap<String, Object> writeRequestParam(HttpServletRequest request) throws Exception {
		
		String key = null;
		String values[] = (String[])null;
		HashMap<String, Object> requestMap = new HashMap<String, Object>();
		LOGGER.debug("=== Write Request Parameter =====================================");
		for (Enumeration em = request.getParameterNames(); em.hasMoreElements();) {
			key = em.nextElement().toString();
			values = request.getParameterValues(key);
			
			if (values == null) continue;
			if (values.length == 1 && values[0] != null && values[0].length() > 0) {
				LOGGER.debug("Key = " + key + ", value = "+ values[0]);
				requestMap.put(key, values[0]);
			}
		}
		LOGGER.debug("=================================================================");
		return requestMap;
	}
	/*세션타임아웃등*/
	@RequestMapping(value="/fail.ax")
	public Map<String,Object> fail(){
		Map<String,Object> resultMap = new HashMap<String,Object>();
		resultMap.put("code", "000");
		resultMap.put("msg", "로그인이 필요합니다.");
		return resultMap;
	}
	
	
	/*모바일*/
	/*모바일 : 자료조회*/
	@RequestMapping(value="/m/getDataOneday.ax")
	public Map<String,Object> getDataOneday(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getDataOneday()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		List<?> resultList = egovService.selectQueryForList("getDataOneday", requestMap);
		resultMap.put("data", resultList);
		if (resultList != null && resultList.size() > 0) {
			//resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	/*모바일 : 수신현황*/
	@RequestMapping(value="/m/getReceiveList.ax")
	public Map<String,Object> getReceiveList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getReceiveList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (requestMap.get("user_id") == null)
			requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		
		List<?> resultList = egovService.selectQueryForList("getReceiveList", requestMap);
		resultMap.put("data", resultList);
		if (resultList != null && resultList.size() > 0) {
			//resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		return resultMap;
	}
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/**************************************************************************************************************************/
	/**************************************************************************************************************************/
	/**************************************************************************************************************************/
	/**************************************************************************************************************************/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**************************************************************************************************************************/
	/**************************************************************************************************************************/
	/**************************************************************************************************************************/
	/**************************************************************************************************************************/
	/**************************************************************************************************************************/
	
	
	
	/*roweditingTest*/
	@RequestMapping(value = "/test/roweditingTest.ax")
	public HashMap<String, Object> roweditingTest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.roweditingTest()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		String data = request.getParameter("editRecords").toString();
		if (requestMap.get("editRecords") != null) {
			try {
				JSONArray jsonArr = new JSONArray(data);
				
				for (int i=0; i<jsonArr.length(); i++){
					JSONObject returnSubject = (JSONObject)jsonArr.get(i);
					System.out.println("region_cd : "+returnSubject.get("region_cd").toString());
					System.out.println("region_nm : "+returnSubject.get("region_nm").toString());
					
					requestMap.put("region_cd", returnSubject.get("region_cd").toString());
					requestMap.put("region_nm", returnSubject.get("region_nm").toString());
					
					/*resultMap = (HashMap)egovService.selectQueryForObject("getConfirmYN", requestMap);
					if (resultMap.get("confirm_yn").toString().equals("Y")) {
						resultMap.put("code", 404);
						resultMap.put("msg", "마감 완료로 인하여 수정할 수 없습니다.");
						break;
					} else {
						resultMap.put("code", 200);
					}
					
					if (egovService.updateQueryAfterReturn("setHourData", requestMap) < 1) {
						resultMap.put("code", 500);
						resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
						break;
					}*/
				}

			} catch (Exception e) {
				e.printStackTrace();
				resultMap.put("code", 500);
				resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
			}
		}
		
		resultMap.put("code", 200);
		resultMap.put("msg", "정상");
		
		return resultMap;
	}
	
		
	/**
	 * 대시보드>노선도
	 * @param request
	 * @param response
	 * @return resultMap
	 * @throws Exception
	 */
	@RequestMapping(value="/dashboard/getMapTmsList.ax", method=RequestMethod.POST)
	public Map<String,Object> getMapTmsList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getMapTmsList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		requestMap.put("item_cd", System.getProperty("DASHBOARD_ITEM")==null?"PM2":System.getProperty("DASHBOARD_ITEM"));
		requestMap.put("data_type", request.getSession().getAttribute("MONITOR_DATA_TYPE").toString());
		requestMap.put("user_id", requestMap.get("user_id")==null?request.getSession().getAttribute("USER_ID").toString():requestMap.get("user_id").toString());
		
		List resultList = egovService.selectQueryForList("getMapTmsList", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "측정자료가 없습니다.");
		}
		return resultMap;
	}
	/**
	 * 대시보드>노선도 윈도우
	 * @param request
	 * @param response
	 * @return resultMap
	 * @throws Exception
	 */
	@RequestMapping(value="/dashboard/getMapWindowList.ax")
	public Map<String,Object> getMapWindowList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getMapWindowList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		requestMap.put("item_cd", System.getProperty("DASHBOARD_ITEM")==null?"PM2":System.getProperty("DASHBOARD_ITEM"));
		requestMap.put("data_type", request.getSession().getAttribute("MONITOR_DATA_TYPE").toString());
		
		List resultList = egovService.selectQueryForList("getMapWindowList", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "측정자료가 없습니다.");
		}
		
		return resultMap;
	}
	
	/**
	 * 대시보드>중요역사측정목록
	 * @param request
	 * @param response
	 * @return resultMap
	 * @throws Exception
	 */
	@RequestMapping(value="/dashboard/getImportantTmsList.ax")
	public Map<String,Object> getImportantTmsList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getImportantTmsList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		requestMap.put("item_cd", System.getProperty("DASHBOARD_ITEM")==null?"PM2":System.getProperty("DASHBOARD_ITEM"));
		requestMap.put("data_type", request.getSession().getAttribute("MONITOR_DATA_TYPE").toString());
		requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		
		List resultList = egovService.selectQueryForList("getImportantTmsList", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "중요역사 측정자료가 없습니다.");
		}
		return resultMap;
	}
	
	/**
	 * 대시보드>상태발생역사목록
	 * @param request
	 * @param response
	 * @return resultMap
	 * @throws Exception
	 */
	@RequestMapping(value="/dashboard/getStatusTmsList.ax")
	public Map<String,Object> getStatusTmsList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getStatusTmsList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		requestMap.put("item_cd", System.getProperty("DASHBOARD_ITEM")==null?"PM2":System.getProperty("DASHBOARD_ITEM"));
		requestMap.put("data_type", request.getSession().getAttribute("MONITOR_DATA_TYPE").toString());
		requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		
		List resultList = egovService.selectQueryForList("getStatusTmsList", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "상태발생역사가 없습니다.");
		}
		return resultMap;
	}
	
	/**
	 * 대시보드>기준초과역사목록
	 * @param request
	 * @param response
	 * @return resultMap
	 * @throws Exception
	 */
	@RequestMapping(value="/dashboard/getOverTmsList.ax")
	public Map<String,Object> getOverTmsList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getOverTmsList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		requestMap.put("item_cd", System.getProperty("DASHBOARD_ITEM")==null?"PM2":System.getProperty("DASHBOARD_ITEM"));
		requestMap.put("data_type", request.getSession().getAttribute("MONITOR_DATA_TYPE").toString());
		requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		
		List resultList = egovService.selectQueryForList("getOverTmsList", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "기준초과역사가 없습니다.");
		}
		return resultMap;
	}
	/**
	 * 모니터링>측정자료현황
	 * @param request
	 * @param response
	 * @return resultMap
	 * @throws Exception
	 */
	@RequestMapping(value="/monitor/getMonitorList.ax")
	public Map<String,Object> getMonitorList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getMonitorList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		requestMap.put("item_cd", System.getProperty("DASHBOARD_ITEM")==null?"PM2":System.getProperty("DASHBOARD_ITEM"));
		requestMap.put("data_type", request.getSession().getAttribute("MONITOR_DATA_TYPE").toString());
		requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		
		List resultList = egovService.selectQueryForList("getMonitorList", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "측정자료가 없습니다.");
		}
		return resultMap;
	}
	
	
	
	@RequestMapping(value="/data/setSoundConfig.ax")
	public Map<String,Object> setSoundConfig(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.setSoundConfig()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		if (requestMap.get("user_id") == null)
			requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());

		if (requestMap.get("sound_yn") != null && !requestMap.get("sound_yn").toString().equals("")) {
			try {
				
				//사용자정보 업데이트
				egovService.updateQuery("setUserSoundConfig", requestMap);
				request.getSession().setAttribute("SOUND_YN", requestMap.get("sound_yn").toString());
				resultMap.put("code", 200);
			} catch (Exception e) {
				resultMap.put("code", 500);
				resultMap.put("msg", "경보음재생설정에 실패하였습니다.");
				e.printStackTrace();
			}
		}
		
		return resultMap;
	}
	
	
	
	/*@RequestMapping(value="/monitor/getMonitorData.ax")
	public Map<String,Object> getMonitorData(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getMonitorData()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		//requestMap.put("tms_cd", request.getSession().getAttribute("USER_ID").toString());
		requestMap.put("data_type", "M");
		requestMap.put("tms_cd", "000000");
		requestMap.put("facility_no", "000");
		requestMap.put("item_cd", "TMP");
		requestMap.put("s_date", "20190705");
		requestMap.put("e_date", "20190705");
		requestMap.put("status_cd", "0");
		List resultList = egovService.selectQueryForList("egovDAO.selectMonitorData", requestMap);
		resultMap.put("data", resultList);
		resultMap.put("cnt", resultList.size());
		return resultMap;
	}*/
	
	
	
	
	
	
	
	
	
	/*자료관리 : 측정자료관리*/
	@RequestMapping(value="/management/getOrgDataList.ax")
	public Map<String,Object> getOrgDataList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getOrgDataList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));

		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}
		
		if (requestMap.get("msr_st_nms") != null) {
			String[] tempArr = requestMap.get("msr_st_nms").toString().split(":");
			String msr_st_nms = "'empty'";
			for (String temp : tempArr ){
				msr_st_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("msr_st_nms", msr_st_nms);
		}
		
		List<?> resultList = egovService.selectQueryForList("getOrgDataList", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		
		return resultMap;
	}
	/*자료관리 : 측정자료관리 엑셀 다운 */
	@RequestMapping(value = "/management/getOrgDataExcelReport.do")
	public ModelAndView getOrgDataExcelReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getOrgDataExcelReport()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));

		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}
		
		if (requestMap.get("msr_st_nms") != null) {
			String[] tempArr = requestMap.get("msr_st_nms").toString().split(":");
			String msr_st_nms = "'empty'";
			for (String temp : tempArr ){
				msr_st_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("msr_st_nms", msr_st_nms);
		}
	
		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		String tms_nm = requestMap.get("tms_nm") == null ? "" : requestMap.get("tms_nm").toString();
		String data_type = requestMap.get("data_type") == null ? "H" : requestMap.get("data_type").toString();
		data_type = data_type.equals("H") ? "시간자료" : "5분자료";		
		List<?> resultList = egovService.selectQueryForList("getOrgDataList", requestMap);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("/report/receiveDataReport");// setViewName() 메서드를 이용하여 뷰 이름을 지정한 모습		
		mv.getModel().put("list", resultList);
		mv.getModel().put("tms_nm", "측정소: "+ tms_nm);
		mv.getModel().put("data_type", "자료구분: "+ data_type);
		mv.getModel().put("term", "기간: "+sd+" ~ "+ed);
		
		return mv;
	}
	/*자료관리 : 측정자료관리 PDF다운 */
	@RequestMapping(value = "/management/getOrgDataPDFReport.do")
	public void getOrgDataPDFReport(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getOrgDataPDFReport()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));

		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}
		
		if (requestMap.get("msr_st_nms") != null) {
			String[] tempArr = requestMap.get("msr_st_nms").toString().split(":");
			String msr_st_nms = "'empty'";
			for (String temp : tempArr ){
				msr_st_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("msr_st_nms", msr_st_nms);
		}
	
		String sd = requestMap.get("s_date").toString();
		String ed = requestMap.get("e_date").toString();
		sd = sd.substring(0, 4)+"-"+sd.substring(4, 6)+"-"+sd.substring(6);
		ed = ed.substring(0, 4)+"-"+ed.substring(4, 6)+"-"+ed.substring(6);
		String data_type = requestMap.get("data_type") == null ? "H" : requestMap.get("data_type").toString();
		data_type = data_type.equals("H") ? "시간자료" : "5분자료";		
		
		List<?> resultList = egovService.selectQueryForList("getOrgDataList", requestMap);
		if (resultList != null && resultList.size() > 0) {
			
			PDDocument document = new PDDocument();
			PDPage page = new PDPage(new PDRectangle(PDRectangle.A4.getHeight(), PDRectangle.A4.getWidth()));
			PDRectangle rect = page.getMediaBox();
			File fontFile = new File(request.getSession().getServletContext().getRealPath("/") + File.separator + "fonts"  + File.separator + "GULIM.TTC");
			PDType0Font fontGulim = PDType0Font.load(document, new TrueTypeCollection(fontFile).getFontByName("Gulim"), true);
			
			document.addPage(page);
			
			boolean drawLines = true;
			boolean drawContent = true;
			float margin = 30;
			float yStartNewPage = page.getMediaBox().getHeight() - margin;
			float tableWidth = page.getMediaBox().getWidth() - (2 * margin);
			float bottomMargin = 50;
			float topMargin = page.getMediaBox().getHeight() - margin;
			
			BaseTable table = new BaseTable(yStartNewPage, topMargin, bottomMargin, tableWidth, margin, document, page, drawLines, drawContent);
			
			Row<PDPage> headerRow = null;
			Cell<PDPage> cell = null;
			
			headerRow = table.createRow(50);
			cell = headerRow.createCell(100, "측정자료 리포트");
			cell.setFont(fontGulim);
			cell.setFontSize(20);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "측정소명: "+requestMap.get("tms_nm").toString()+", 자료구분: "+data_type);
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(100, "조회기간: "+sd+" ~ "+ed);
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.RIGHT);
			cell.setTopBorderStyle(null);
			cell.setLeftBorderStyle(null);
			cell.setRightBorderStyle(null);
			table.addHeaderRow(headerRow);
			
			headerRow = table.createRow(20);
			cell = headerRow.createCell(14, "측정시간");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(10, "측정항목");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(10, "측정값");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(10, "수신값");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(10, "상태표시");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(10, "기준초과");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);

			cell = headerRow.createCell(10, "등급");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(13, "수신일시");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			cell = headerRow.createCell(13, "수정일시");
			cell.setFont(fontGulim);
			cell.setFontSize(10);
			cell.setValign(VerticalAlignment.MIDDLE);
			cell.setAlign(HorizontalAlignment.CENTER);
			cell.setFillColor(Color.LIGHT_GRAY);
			
			table.addHeaderRow(headerRow);
			
			Row<PDPage> row = null;
			String[] keys = {"item_nm","msr_vl","org_vl", "msr_st_nm", "over_nm", "level_nm", "reg_dt", "udt_dt"};
			for (int i=0; i<resultList.size(); i++) {
				resultMap = (HashMap)resultList.get(i);
				row = table.createRow(20);
				
				cell = row.createCell(14, resultMap.get("dsp_dt").toString());
				cell.setFont(fontGulim);
				cell.setFontSize(8);
				cell.setAlign(HorizontalAlignment.CENTER);
				
				for (int j=0; j<keys.length; j++) {
					if ("reg_dtudt_dt".indexOf(keys[j]) > -1) {
						cell = row.createCell(13, resultMap.get(keys[j])==null?"-":resultMap.get(keys[j]).toString());
					} else {
						cell = row.createCell(10, resultMap.get(keys[j])==null?"-":resultMap.get(keys[j]).toString());
					}
					cell.setFont(fontGulim);
					cell.setFontSize(8);
					cell.setAlign(HorizontalAlignment.CENTER);
				}
			}
			table.draw();
			
			for (int i = 0; i < document.getNumberOfPages(); i++) {
				String company_name = System.getProperty("COMPANY_NAME")==null?"두일테크":System.getProperty("COMPANY_NAME");
				PDPageContentStream contentStream = new PDPageContentStream(document, document.getPage(i), AppendMode.APPEND, true);
				PDStreamUtils.write(contentStream, company_name, fontGulim, 10, 50, document.getPage(i).getMediaBox().getHeight()-30, new Color(102, 102, 102));
				PDStreamUtils.write(contentStream, "- "+String.valueOf(i + 1)+" / "+document.getNumberOfPages()+" -", fontGulim, 10, document.getPage(i).getMediaBox().getWidth() / 2 - 20, 30, new Color(102, 102, 102));
				
	            contentStream.close();
	        }
			
			response.setHeader("Content-Type", "application/force-download");
			response.addHeader("Content-Disposition","attachment; filename=ReceiveDataReport.pdf");
			document.save(response.getOutputStream());
			document.close();
		}
	}
	/*자료관리 : 수정자료 저장 */
	@RequestMapping(value="/management/setHourData.ax")
	public Map<String,Object> setHourData(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.setHourData()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("user_id",request.getSession().getAttribute("USER_ID").toString());
		if (requestMap.get("confirm_type") == null || requestMap.get("confirm_type").toString().equals(""))
			requestMap.put("confirm_type", "M");
		
		String data = request.getParameter("editRecordTemp").toString();
		
		if (requestMap.get("editRecordTemp") != null) {
			try {
				JSONArray jsonArr = new JSONArray(data);
				
				for (int i=0; i<jsonArr.length(); i++){
					JSONObject returnSubject = (JSONObject)jsonArr.get(i);
					System.out.println("tms_cd : "+returnSubject.get("tms_cd").toString());
					System.out.println("item_cd : "+returnSubject.get("item_cd").toString());
					System.out.println("msr_dt : "+returnSubject.get("msr_dt").toString());
					System.out.println("msr_vl : "+returnSubject.get("msr_vl").toString());
					
					requestMap.put("tms_cd", returnSubject.get("tms_cd").toString());
					requestMap.put("msr_dt", returnSubject.get("msr_dt").toString());
					requestMap.put("item_cd", returnSubject.get("item_cd").toString());
					requestMap.put("msr_vl", returnSubject.get("msr_vl").toString());
					
					resultMap = (HashMap)egovService.selectQueryForObject("getConfirmYN", requestMap);
					if (resultMap.get("confirm_yn").toString().equals("Y")) {
						resultMap.put("code", 404);
						resultMap.put("msg", "마감 완료로 인하여 수정할 수 없습니다.");
						break;
					} else {
						resultMap.put("code", 200);
					}
					
					if (egovService.updateQueryAfterReturn("setHourData", requestMap) < 1) {
						resultMap.put("code", 500);
						resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
						break;
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
				resultMap.put("code", 500);
				resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
			}
		}
		
		return resultMap;
	}
	
	
	/*자료관리 : 월마감 
	@RequestMapping(value="/management/setConfirmData.ax")
	public Map<String,Object> setConfirmData(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.setConfirmData()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		List<?> resultList = egovService.selectQueryForList("setConfirmData", requestMap);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("code", 200);
			resultMap.put("data", resultList);
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "조회자료가 없습니다");
		}
		
		return resultMap;
	}*/
	
	
	
	/*측정소위치정보 수정*/
	@RequestMapping(value="/system/setTmsLocation.ax")
	public Map<String,Object> setTmsLocation(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.setTmsLocation()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		String data = request.getParameter("editRecordTemp").toString();
		System.out.println(data);
		//data = data.replaceAll("\"\\{", "\\{").replaceAll("\\}\"", "\\}").replaceAll("\\", "").replaceAll("\"", "");
		System.out.println(data);
		
		if (requestMap.get("editRecordTemp") != null) {
			try {
				//requestMap.put("editRecordTemp", requestMap.get("editRecordTemp").toString().replaceAll("\"{", "{").replaceAll("}\"", "}"));
				//System.out.println(requestMap.get("editRecordTemp").toString());
				
				JSONArray jsonArr = new JSONArray(data);
				
				for (int i=0; i<jsonArr.length(); i++){
					JSONObject returnSubject = (JSONObject)jsonArr.get(i);
					/*System.out.println("tms_cd : "+returnSubject.get("tms_cd").toString());
					System.out.println("pos_x : "+returnSubject.get("pos_x").toString());
					System.out.println("pos_y : "+returnSubject.get("pos_y").toString());*/
					
					requestMap.put("tms_cd", returnSubject.get("tms_cd").toString());
					requestMap.put("pos_x", returnSubject.get("pos_x").toString());
					requestMap.put("pos_y", returnSubject.get("pos_y").toString());
					
					resultMap.put("code", 200);
					resultMap.put("msg", "수정되었습니다.");
					
					if (egovService.updateQueryAfterReturn("setTmsLocation", requestMap) < 1) {
						resultMap.put("code", 500);
						resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
						break;
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
				resultMap.put("code", 500);
				resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
			}
		}

		return resultMap;
	}
	/*노선도 파일 업로드*/
	@RequestMapping(value="/system/setTmsMapImage.ax")
	public Map<String,Object> setTmsMapImage(HttpServletRequest request)  throws Exception {
		LOGGER.warn("Method = EgovController.setTmsMapImage()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		String orgFileName = ""; 
 		String saveFileName = "";
 		
 		resultMap.put("success", false);
 		
		try {
			
			MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest)request;
			MultipartFile file = multipartHttpServletRequest.getFile( "fileupload" );
			String filePath = request.getSession().getServletContext().getRealPath("/") + File.separator + "images";
			
			LOGGER.debug("filePath = "+filePath);
			
			/*File dir = new File(filePath);
			if(!dir.isDirectory()) {
				dir.mkdirs();
			} */
			
			if (file != null) {
	 			orgFileName = file.getOriginalFilename().trim().replaceAll(" ", "");
				if (orgFileName != null && !orgFileName.equals("") && file.getSize() > 0) {
					
					String file_extension = orgFileName.substring(orgFileName.length()-3, orgFileName.length());
					if (file_extension.toLowerCase().equals("png") || file_extension.toLowerCase().equals("jpg")) {
						saveFileName = System.currentTimeMillis()+"_map."+file_extension.toLowerCase();
						File f = new File(filePath + File.separator + saveFileName);
						file.transferTo(f);
						
						requestMap.put("map_img", saveFileName);
						if (egovService.updateQueryAfterReturn("setTmsMapImage", requestMap) < 1) {
							resultMap.put("code", 500);
							resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
							resultMap.put("map_img", request.getSession().getAttribute("MAP_IMG").toString());
						} else {
							resultMap.put("success", true);
							resultMap.put("msg", "새로고침(F5) 하시기 바랍니다.");
							resultMap.put("map_img", saveFileName);
							request.getSession().setAttribute("MAP_IMG", saveFileName);
						}
					} else {
						resultMap.put("msg", "png, jpg 파일만 사용가능 합니다.");
						resultMap.put("map_img", request.getSession().getAttribute("MAP_IMG").toString());
					}
					
				} else {
					resultMap.put("msg", "잘못된 형식의 파일 입니다.");
					resultMap.put("map_img", request.getSession().getAttribute("MAP_IMG").toString());
				}
 			}
		} catch (Exception e) {
			e.printStackTrace();
			resultMap.put("code", 500);
			resultMap.put("msg", "서비스 이용에 문제가 발생하였습니다.");
		}
		return resultMap;

	}
	
	/* 시스템관리>메뉴관리 : 메뉴정보 등록, 수정 */
	@RequestMapping(value="/system/setMenuInfo.ax")
	public Map<String,Object> setMenuInfo(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.setMenuInfo()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (requestMap.get("admin_yn") != null && requestMap.get("admin_yn").toString().equals("on")) requestMap.put("admin_yn", "Y");
		else requestMap.put("admin_yn", "N");
		
		try {
			egovService.insertQuery("setMenuInfo", requestMap);
			resultMap.put("result", "Y");
		} catch (Exception e) {
			resultMap.put("result", "중복코드이거나 저장에 실패하였습니다.");
			e.printStackTrace();
		}
		return resultMap;
	}
	/* 시스템관리>기준값관리 : 기준값정보 조회 */
	@RequestMapping(value="/system/getLevelInfo.ax")
	public Map<String,Object> getLevelInfo(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getLevelInfo()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		if (requestMap.get("item_cd") == null || requestMap.get("item_cd").toString().equals("")) {
			requestMap.put("item_cd", "PM2");
		}
		
		try {
			List resultList = egovService.selectQueryForList("getLevelInfo", requestMap);
			resultMap.put("data", resultList);
			/*for (int i=0; i<resultList.size(); i++) {
				
			}*/
			resultMap.put("code", "200");
		} catch (Exception e) {
			resultMap.put("result", "중복코드이거나 저장에 실패하였습니다.");
			e.printStackTrace();
		}
		return resultMap;
	}
	
	
	/* 시스템관리>원격명령 : 원격명령이력 */
	@RequestMapping(value="/system/getRemoteCommand.ax")
	public Map<String,Object> getRemoteCommand(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getRemoteCommand()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		requestMap.put("s_date", requestMap.get("s_date").toString().replaceAll("-", "").substring(0, 8));
		requestMap.put("e_date", requestMap.get("e_date").toString().replaceAll("-", "").substring(0, 8));
		
		List resultList = egovService.selectQueryForList("getRemoteCmdHis", requestMap);

		/*HashMap<String, Object> defaultMap = new HashMap<String, Object>();
		defaultMap.put("order_seq", 0);
		defaultMap.put("tms_nm", "전체");
		defaultMap.put("tms_id", "ALL");
		resultList.add(defaultMap);*/
		
		resultMap.put("data", resultList);
		return resultMap;
	}
	/* 시스템관리>원격명령 : 원격명령요청 */
	@RequestMapping(value="/system/doRemoteCommand.ax", method = RequestMethod.POST)
	public Map<String,Object> doRemoteCommand(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.doRemoteCommand()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		String resultMsg = "";
		resultMap.put("code", 200);
		
		if (requestMap.get("reg_id") == null)
			requestMap.put("reg_id", request.getSession().getAttribute("USER_ID").toString());
		
		if (requestMap.get("tms_nms") != null && !requestMap.get("tms_nms").toString().equals("")) {
			String[] tempArr = requestMap.get("tms_nms").toString().split(":");
			String tms_nms = "'empty'";
			for (String temp : tempArr ){
				tms_nms += ",'"+temp+"'"; 
	        }
			requestMap.put("tms_nms", tms_nms);
		} else {
			resultMap.put("code", 404);
			resultMap.put("result", "명령대상 측정소를 선택하세요");
			return resultMap;
		}
		/*if (requestMap.get("remote_cmd") != null) {
			if (requestMap.get("remote_cmd").toString().equals("SETT")) {
				requestMap.put("current_date_time", new SimpleDateFormat("yyyyMMddHHmm").format(new Date()));
			}
		}*/
		if (requestMap.get("port_num") == null || requestMap.get("port_num").toString().equals("")) {
			resultMap.put("code", 404);
			resultMap.put("result", "Port를 입력하세요");
			return resultMap;
		}
		
		String remote_message = "";
		List resultList = egovService.selectQueryForList("getRemoteTmsInfo", requestMap);
		for (int x=0; x<resultList.size(); x++) {
			remote_message = "A";
			requestMap.put("tms_cd", ((HashMap)resultList.get(x)).get("tms_cd").toString());
			requestMap.put("tms_nm", ((HashMap)resultList.get(x)).get("tms_nm").toString());
			requestMap.put("tms_ip", ((HashMap)resultList.get(x)).get("tms_ip") == null ? "" : ((HashMap)resultList.get(x)).get("tms_ip").toString());
			
			remote_message += requestMap.get("tms_cd").toString();
			if ("DMPADMPFDMPH".indexOf(requestMap.get("remote_cmd").toString()) > -1) {
				remote_message += requestMap.get("remote_cmd").toString();
				remote_message += requestMap.get("s_dt").toString();
				remote_message += requestMap.get("e_dt").toString();
			} 
			else if (requestMap.get("remote_cmd").toString().equals("SETT")) { 
				remote_message += "ALLSETT";
				requestMap.put("s_dt", new SimpleDateFormat("yyyyMMddHHmm").format(new Date()));
				remote_message += requestMap.get("s_dt").toString();
			}
			else if (requestMap.get("remote_cmd").toString().equals("SETP")) {
				remote_message += "ALLSETP";
				requestMap.put("s_dt", "      "+requestMap.get("dl_pwd").toString());
				remote_message += requestMap.get("s_dt").toString();
			}
			else if (requestMap.get("remote_cmd").toString().equals("BOOT")) {
				remote_message += "ALLBOOT";
				requestMap.put("s_dt", new SimpleDateFormat("yyyyMMddHHmm").format(new Date()));
				remote_message += requestMap.get("s_dt").toString();
			} else {
				remote_message = "";
			}
			
			//원격명령전송 및 결과메세지
			LOGGER.debug(">> request_msg = " + remote_message);
			requestMap.put("request_msg", remote_message);
			requestMap.put("result_msg", doRemoteCmd(requestMap, remote_message));
			
			//원격명령전송이력등록
			egovService.insertQuery("setRemoteCmdHis", requestMap);
			
			
		}
		/*if (!resultMsg.equals("")) {
			resultMsg += "가 원격명령에 응답하지 않습니다.";
			resultMap.put("code", 500);
			resultMap.put("result", resultMsg);
		}*/
		
		return resultMap;
	}
	public String doRemoteCmd(HashMap<String, Object> requestMap, String message) {
		LOGGER.warn("Method = EgovController.doRemoteCmd()");
		
		String result_msg = "";
		if (requestMap.get("tms_ip").toString().equals("")) return "Datalogger IP is null";
		
		byte[] bytes = message.getBytes();
		char STX = 0x02, ETX = 0x03, EOT = 0x04, ENQ = 0x05, ACK = 0x06, NAK = 0x15, CR = 0x0D, chk1 = 0x00, chk2 = 0x00, sum_byte = 0x00;
		
    	for (int j = 0; j < bytes.length; j++) {
	    	sum_byte += bytes[j];
	    }
	    chk1 = (char) Integer.parseInt(Integer.toHexString(((sum_byte & 0xf0) >>> 4) + 0x30), 16);
	    chk2 = (char) Integer.parseInt(Integer.toHexString((sum_byte & 0x0f) + 0x30), 16);
	    message = Character.toString(STX)+message+Character.toString(ETX)+Character.toString(chk1)+Character.toString(chk2)+Character.toString(CR);
	    
	    Socket sock = null;
	    BufferedReader br = null;
		PrintWriter out = null;
	    try {
		    String line = null;
			sock = new Socket(InetAddress.getByName(requestMap.get("tms_ip").toString()), Integer.parseInt(requestMap.get("port_num").toString()));
			sock.setTcpNoDelay(true);
			sock.setSoTimeout(10000);
			LOGGER.debug(">> sock.toString() = "+sock.toString());
			
			br = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			out = new PrintWriter(new OutputStreamWriter(sock.getOutputStream()));
			
			out.print(message);
			out.flush();
			LOGGER.debug(">> Send message : " + message);
			int a=0;
			boolean loof = true;
			while (loof) {
				//if ((line = br.readLine()) != null) {
				if ((a = br.read()) > 0) {
					
					if ((char) Integer.parseInt(Integer.toHexString(a), 16) == ACK) {
						result_msg = "Receive message is ACK";
						break;
					}
					if ((char) Integer.parseInt(Integer.toHexString(a), 16) == NAK) {
						result_msg = "Receive message is NAK";
						break;
					}
					/*for (int i=0; i<line.length(); i++) {
						if (line.charAt(i) == ACK || line.charAt(i) == NAK) {
							if (line.charAt(i) == ACK) {
								result_msg = "Receive message is ACK";
							} else {
								result_msg = "Receive message is NAK";
							}
							
							if(out != null) {
			                    out.close();
			                    LOGGER.debug(">> out.close()");
			                }
							
			                if(br != null) {
			                    br.close();
			                    LOGGER.debug(">> br.close()");
			                }
			                
			                if(sock != null) {
			                    sock.close();
			                    LOGGER.debug(">> sock.close()");
			                }
			                
			                loof = false;
							break;
						}
					}*/
				}
			}
	    } catch (Exception e) {
	    	LOGGER.debug(">> Exception: "+e.toString());
	    	result_msg = e.toString();
	    	e.printStackTrace();
        } finally { 
        	try {
		    	if(out != null) out.close();
		    	if(br != null) br.close();
	            if(sock != null) sock.close();
	    	} catch (IOException ex) {
	    		result_msg = ex.toString();
	    		LOGGER.debug(">> IOException");
	    		ex.printStackTrace();
	    	}
        }
	    return result_msg;
	}
	
	
	

	

	
	
	/**
	 * 자료조회>측정현황
	 * @param request
	 * @param response
	 * @return resultMap
	 * @throws Exception
	 */
	@RequestMapping(value="/data/getMonitorDataList.ax")
	public Map<String,Object> getMonitorDataList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getMonitorDataList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		//requestMap.put("tms_cd", request.getSession().getAttribute("USER_ID").toString());
		requestMap.put("data_type", "M");
		requestMap.put("tms_cd", "000000");
		requestMap.put("facility_no", "000");
		requestMap.put("item_cd", "TMP");
		requestMap.put("s_date", "20190705");
		requestMap.put("e_date", "20190705");
		requestMap.put("status_cd", "0");
		List resultList = egovService.selectQueryForList("egovDAO.getMonitorDataList", requestMap);
		resultMap.put("data", resultList);
		resultMap.put("cnt", resultList.size());
		return resultMap;
	}
	
	/**
	 * 자료조회>측정소별조회
	 * @param request
	 * @param response
	 * @return resultMap
	 * @throws Exception
	 */
	@RequestMapping(value="/data/getTmsDataList.ax")
	public Map<String,Object> getTmsDataList(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getTmsDataList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		//requestMap.put("tms_cd", request.getSession().getAttribute("USER_ID").toString());
		requestMap.put("data_type", "M");
		requestMap.put("tms_cd", "000000");
		requestMap.put("facility_no", "000");
		requestMap.put("item_cd", "TMP");
		requestMap.put("s_date", "20190705");
		requestMap.put("e_date", "20190705");
		requestMap.put("status_cd", "0");
		List resultList = egovService.selectQueryForList("egovDAO.selectMsrData", requestMap);
		resultMap.put("data", resultList);
		resultMap.put("cnt", resultList.size());
		return resultMap;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*공통 : 상태정보 목록*/
	@RequestMapping(value="/comm/getStatusList.ax")
	public Map<String,Object> getStatusList(HttpServletRequest request, HttpServletResponse response) throws Exception {
		LOGGER.warn("Method = EgovController.getStatusList()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		
		//requestMap.put("user_id", request.getSession().getAttribute("USER_ID").toString());
		//requestMap.put("tms_type", request.getSession().getAttribute("TMS_TYPE").toString());
		//requestMap.put("tm_type", request.getSession().getAttribute("TM_TYPE").toString());
		
		List<?> resultList = egovService.selectQueryForList("egovDAO.getStatusList", requestMap);
		
		resultMap.put("data", resultList);
		return resultMap;
	}
	
	/**
	 * 공통>TMS Group 코드
	 * @param request
	 * @param response
	 * @return resultMap
	 * @throws Exception
	 */
	@RequestMapping(value="/comm/getLineNo.ax")
	public Map<String,Object> getLineNo(HttpServletRequest request, HttpServletResponse response)  throws Exception {
		LOGGER.warn("Method = EgovController.getLineNo()");
		
		HashMap<String, Object> requestMap = writeRequestParam(request);
		HashMap<String, Object> resultMap = new HashMap<String, Object>();

		List resultList = egovService.selectQueryForList("getLineNo", requestMap);
		resultMap.put("data", resultList);
		
		if (resultList != null && resultList.size() > 0) {
			resultMap.put("cnt", resultList.size());
		} else {
			resultMap.put("code", 404);
			resultMap.put("msg", "등록자료가 없습니다.");
		}
		return resultMap;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**************************************************************************************************************************************************************
	**************************************************************************************************************************************************************/
	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 DooillDefaultVO
	 * @param model
	 * @return "egovSampleList"
	 * @exception Exception
	 */
	@RequestMapping(value = "/egovSampleList.do")
	public String selectSampleList(@ModelAttribute("searchVO") BoardDefaultVO searchVO, ModelMap model) throws Exception {
	//public ModelAndView selectSampleList(@ModelAttribute("searchVO") DooillDefaultVO searchVO, ModelMap model, HttpServletRequest request, HttpServletResponse response) throws Exception {

		LOGGER.debug("Method = EgovDooillController.selectSampleList()");
		
		/** EgovPropertyService.sample */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing setting */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<?> sampleList = egovService.selectSampleList(searchVO);
		model.addAttribute("resultList", sampleList);

		int totCnt = egovService.selectSampleListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);

		return "egovframework/dooill/sample/egovSampleList";
		
		
		/*ModelAndView mv = new ModelAndView();
		mv.setViewName("/egovframework/dooill/sample/egovSampleList");		
		mv.getModel().put("paginationInfo", paginationInfo);
		mv.getModel().put("resultList", sampleList);
		return mv;*/
	}

	/**
	 * 글 등록 화면을 조회한다.
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "egovSampleRegister"
	 * @exception Exception
	 */
	@RequestMapping(value = "/addSample.do", method = RequestMethod.GET)
	public String addSampleView(@ModelAttribute("searchVO") BoardDefaultVO searchVO, Model model) throws Exception {
		System.out.println(">>>>>>>>>>>>>>>>>> addSample GET");
		
		model.addAttribute("boardVO", new BoardVO());
		return "egovframework/dooill/sample/egovSampleRegister";
		
		
		/*ModelAndView mv = new ModelAndView();
		mv.setViewName("egovframework/dooill/sample/egovSampleRegister");		
		mv.getModel().put("boardVO", new BoardVO());
		return mv;*/
	}

	/**
	 * 글을 등록한다.
	 * @param sampleVO - 등록할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/egovSampleList.do"
	 * @exception Exception
	 */
	@RequestMapping(value = "/addSample.do", method = RequestMethod.POST)
	public String addSample(@ModelAttribute("searchVO") BoardDefaultVO searchVO, BoardVO boardVO, BindingResult bindingResult, Model model, SessionStatus status)
			throws Exception {
		System.out.println(">>>>>>>>>>>>>>>>>> addSample POST");
		
		// Server-Side Validation
		beanValidator.validate(boardVO, bindingResult);

		if (bindingResult.hasErrors()) {
			System.out.println(">>>>>>>>>>>>>>>>>> bindingResult.hasErrors()");
			model.addAttribute("boardVO", boardVO);
			return "egovframework/dooill/sample/egovSampleRegister";
		}
		
		egovService.insertSample(boardVO);
		status.setComplete();
		return "forward:/egovSampleList.do";
	}

	/**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "egovSampleRegister"
	 * @exception Exception
	 */
	@RequestMapping("/updateSampleView.do")
	public String updateSampleView(@RequestParam("selectedId") String id, @ModelAttribute("searchVO") BoardDefaultVO searchVO, Model model) throws Exception {
		BoardVO boardVO = new BoardVO();
		boardVO.setId(id);
		// 변수명은 CoC 에 따라 sampleVO
		model.addAttribute(selectSample(boardVO, searchVO));
		return "egovframework/dooill/sample/egovSampleRegister";
	}

	/**
	 * 글을 조회한다.
	 * @param sampleVO - 조회할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return @ModelAttribute("sampleVO") - 조회한 정보
	 * @exception Exception
	 */
	public BoardVO selectSample(BoardVO boardVO, @ModelAttribute("searchVO") BoardDefaultVO searchVO) throws Exception {
		return egovService.selectSample(boardVO);
	}

	/**
	 * 글을 수정한다.
	 * @param sampleVO - 수정할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/egovSampleList.do"
	 * @exception Exception
	 */
	@RequestMapping("/updateSample.do")
	public String updateSample(@ModelAttribute("searchVO") BoardDefaultVO searchVO, BoardVO boardVO, BindingResult bindingResult, Model model, SessionStatus status)
			throws Exception {

		beanValidator.validate(boardVO, bindingResult);

		if (bindingResult.hasErrors()) {
			model.addAttribute("boardVO", boardVO);
			return "egovframework/dooill/sample/egovSampleRegister";
		}

		egovService.updateSample(boardVO);
		status.setComplete();
		return "forward:/egovSampleList.do";
	}

	/**
	 * 글을 삭제한다.
	 * @param sampleVO - 삭제할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/egovSampleList.do"
	 * @exception Exception
	 */
	@RequestMapping("/deleteSample.do")
	public String deleteSample(BoardVO boardVO, @ModelAttribute("searchVO") BoardDefaultVO searchVO, SessionStatus status) throws Exception {
		egovService.deleteSample(boardVO);
		status.setComplete();
		return "forward:/egovSampleList.do";
	}

}
