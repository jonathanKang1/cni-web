/**
 * 
 */
package egovframework.dooill.cmmn.web;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.view.AbstractView;

import sun.misc.BASE64Decoder;

/**
 * 차트 이미지 다운로드 생성
 * @author admin
 *
 */
@Component("chartImageView")
public class ChartImageView extends AbstractView {
    private static final Logger logger = LoggerFactory.getLogger(ChartImageView.class);
    
    @Value("${FILE_PATH}")
    private String UPLOAD_ROOT_PATH;
    
    @Override
    protected void renderMergedOutputModel(Map<String, Object> resultMap,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
     // tokenize the data
        String[] imgSrc = resultMap.get("imgSrc").toString().split(",");
        String imageString = imgSrc[1];

       // create a buffered image
       BufferedImage image = null;
       byte[] imageByte;

       BASE64Decoder decoder = new BASE64Decoder();
       imageByte = decoder.decodeBuffer(imageString);
       ByteArrayInputStream bis = new ByteArrayInputStream(imageByte);
       image = ImageIO.read(bis);
       bis.close();

       // write the image to a file
       String fileaName = "chartImage.png";
       File outputfile = new File(UPLOAD_ROOT_PATH + "/" + fileaName);
       ImageIO.write(image, "png", outputfile);
       
       response.setHeader("Content-Disposition", "attachment; filename=\"" + fileaName + "\";");
       response.setHeader("Content-Transfer-Encoding", "binary");
       OutputStream out = response.getOutputStream();
       FileInputStream fis = null;
       try {
           fis = new FileInputStream(outputfile);
           FileCopyUtils.copy(fis, out);
       } catch (IOException e) {
       } finally {
           if (fis != null) {
               try {
                   fis.close();
               } catch (IOException e) {
               }
           }
           
           outputfile.delete();
           out.flush();
           out.close();
        }
    }
}
