/**
 * 
 */
package egovframework.dooill.cmmn.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.view.AbstractView;

/**
 * 다운로드 생성
 * @author admin
 *
 */
@Component("downloadView")
public class DownloadView extends AbstractView {
    private static final Logger logger = LoggerFactory.getLogger(DownloadView.class);
    
    @Value("${FILE_PATH}")
    private String UPLOAD_ROOT_PATH;
    
    @Override
    protected void renderMergedOutputModel(Map<String, Object> resultMap,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        File file = null;
        String fileOriName = (String) resultMap.get("fileOriName");
        String fileName = (String) resultMap.get("fileName");
        String filePath = (String) resultMap.get("filePath");
      
        if(fileName != null && !fileName.equals("")) {
            if(StringUtils.isEmpty(filePath)) {
                logger.debug(UPLOAD_ROOT_PATH + "/" + fileName);
                file = new File(UPLOAD_ROOT_PATH + "/" + fileName);
            } else {
                logger.debug(UPLOAD_ROOT_PATH + "/" + filePath + "/" + fileName);
                file = new File(UPLOAD_ROOT_PATH + "/" + filePath + "/" + fileName);
            }
        }
        
        if(null != file) {
            logger.trace("DownloadView --> file.getPath() : " + file.getPath());
            logger.trace("DownloadView --> file.getName() : " + file.getName());
            String userAgent = request.getHeader("User-Agent");
            response.setContentLength((int)file.length());
            if(userAgent.indexOf("MSIE") > -1){
                fileName = URLEncoder.encode(fileOriName, "utf-8");
            } else if(userAgent.indexOf("Trident") > -1) {
                fileName = URLEncoder.encode(fileOriName, "utf-8");
            } else {
                fileName = new String(fileOriName.getBytes("utf-8"), "iso-8859-1");
            }
            
            String ext = (fileName.lastIndexOf(".") >= 0) ? fileName.substring(fileName.lastIndexOf(".")) : "";
            String name = (fileName.lastIndexOf(".") >= 0) ? fileName.substring(0, fileName.lastIndexOf(".")) : "";
            if (userAgent.indexOf("Android") > -1 ) {   // 사파리, 크롬일 경우
                if(".hwp".equals(ext)) {
                    response.setContentType("application/x-hwp");
                } else if(".xls".equals(ext) || ".xlsx".equals(ext)) {
                    response.setContentType("application/vnd.ms-excel");
                } else if(".ppt".equals(ext) || ".pptx".equals(ext)) {
                    response.setContentType("application/vnd.ms-powerpoint");
                } else if(".doc".equals(ext) || ".docx".equals(ext)) {
                    response.setContentType("application/msword");
                } else if(".jpg".equals(ext) || "jpge".equals(ext)) {
                    response.setContentType("image/jpeg");
                } else if(".pdf".equals(ext) ) {
                    response.setContentType("application/pdf");
                } else if(".zip".equals(ext) ) {
                    response.setContentType("application/x-zip");
                } else if(".bmp".equals(ext) ) {
                    response.setContentType("image/bmp");
                } else if(".pdf".equals(ext) ) {
                    response.setContentType("application/pdf");
                } else {
                    response.setContentType("application/octet-stream");
                }
            } else {
                response.setContentType("text/plain");
            }
            response.setHeader("Content-Disposition", "attachment; filename=\"" + (name+ext) + "\";");
            response.setHeader("Content-Transfer-Encoding", "binary");
            OutputStream out = response.getOutputStream();
            FileInputStream fis = null;
            try {
                fis = new FileInputStream(file);
                FileCopyUtils.copy(fis, out);
            } catch (IOException e) {
            } finally {
                if (fis != null) {
                    try {
                        fis.close();
                    } catch (IOException e) {
                    }
                }
            }
            out.flush();
            out.close();
        }
    }
}
