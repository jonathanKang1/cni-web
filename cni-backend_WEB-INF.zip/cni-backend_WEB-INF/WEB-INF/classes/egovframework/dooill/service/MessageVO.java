/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package egovframework.dooill.service;

/**
 * @Class Name : SampleVO.java
 * @Description : SampleVO Class
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2009.03.16           최초생성
 *
 * @author 개발프레임웍크 실행환경 개발팀
 * @since 2009. 03.16
 * @version 1.0
 * @see
 *
 *  Copyright (C) by MOPAS All right reserved.
 */
public class MessageVO extends BoardDefaultVO { 

	private static final long serialVersionUID = 2L;

	private String report_id;
	
	private String tms_cd;
	
	private String facility_no;
	
	private String dcd_cd;
	
	private String msr_dt;
	
	private String item_cd;
	
	private String msr_vl;
	
	private String status_cd;

	public String getReport_id() {
		return report_id;
	}

	public void setReport_id(String report_id) {
		this.report_id = report_id;
	}

	public String getTms_cd() {
		return tms_cd;
	}

	public void setTms_cd(String tms_cd) {
		this.tms_cd = tms_cd;
	}

	public String getFacility_no() {
		return facility_no;
	}

	public void setFacility_no(String facility_no) {
		this.facility_no = facility_no;
	}

	public String getDcd_cd() {
		return dcd_cd;
	}

	public void setDcd_cd(String dcd_cd) {
		this.dcd_cd = dcd_cd;
	}

	public String getMsr_dt() {
		return msr_dt;
	}

	public void setMsr_dt(String msr_dt) {
		this.msr_dt = msr_dt;
	}

	public String getItem_cd() {
		return item_cd;
	}

	public void setItem_cd(String item_cd) {
		this.item_cd = item_cd;
	}

	public String getMsr_vl() {
		return msr_vl;
	}

	public void setMsr_vl(String msr_vl) {
		this.msr_vl = msr_vl;
	}

	public String getStatus_cd() {
		return status_cd;
	}

	public void setStatus_cd(String status_cd) {
		this.status_cd = status_cd;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	

}
