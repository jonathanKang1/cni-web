/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package egovframework.dooill.service.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ibatis.sqlmap.client.SqlMapExecutor;

import egovframework.dooill.service.BoardDefaultVO;
import egovframework.dooill.service.BoardVO;
import egovframework.dooill.service.MessageVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.orm.ibatis.SqlMapClientCallback;

/**
 * @Class Name : EgovDAO.java
 * @Description : Egov DAO Class
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2009.03.16           최초생성
 *
 * @author 개발프레임웍크 실행환경 개발팀
 * @since 2009. 03.16
 * @version 1.0
 * @see
 *
 *  Copyright (C) by MOPAS All right reserved.
 */

@Repository("egovDAO")
public class EgovDAO extends EgovAbstractDAO {

	/**
	 * 메시지 등록
	 * @param vo - 등록할 정보가 담긴 MessageVO
	 * @exception Exception
	 */
	public void insertMessage(String sql_id, MessageVO vo) throws Exception {
		insert(sql_id, vo);
	}
	
	public Object selectQueryForObject(String mapID) throws Exception {
		return select(mapID);
	}
	public Object selectQueryForObject(String mapID, HashMap hmap) throws Exception {
		return select(mapID, hmap);
	}
	public Object selectQueryForObject(String mapID, String argument) throws Exception {
		return select(mapID, argument);
	}
	public List<?> selectQueryForList(String mapID) throws Exception {
		return list(mapID);
	}
	public List<?> selectQueryForList(String mapID, String queryKey) throws Exception {
		return list(mapID, queryKey);
	}
	public List<?> selectQueryForList(String mapID, HashMap hmap) throws Exception {
		return list(mapID, hmap);
	}
	public void updateQuery(String mapID, HashMap hmap) throws Exception {
		update(mapID, hmap);
	}
	public int updateQueryAfterReturn(String mapID, HashMap hmap) throws Exception {
		return update(mapID, hmap);
	}
	public void insertQuery(String mapID, HashMap hmap) throws Exception {
		insert(mapID, hmap);
	}
	public int insertQueryAfterReturn(String mapID, HashMap hmap) throws Exception {
		return update(mapID, hmap);
	}
	public void deleteQuery(String mapID, String value) throws Exception {
		delete(mapID, value);
	}
	public void deleteQuery(String mapID, HashMap hmap) throws Exception {
		delete(mapID, hmap);
	}
	public int insertBatchHashMap(String mapID, List mapList) throws Exception {
		@SuppressWarnings("deprecation")
		Integer result = (Integer) getSqlMapClientTemplate().execute(new SqlMapClientCallback<Object>() {
			
			@Override
			public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
				
				try {
					executor.startBatch();
					
					for (Iterator iterator = mapList.iterator(); iterator.hasNext();) {
						HashMap map = (HashMap) iterator.next();
						executor.insert(mapID, map);
					}
					
					return new Integer(executor.executeBatch());
					
				} catch (Exception e) {
					throw new SQLException(e.getMessage());
				}

			}
		});
		
		return result.intValue();
	}
	
	
	
	
	
	
	
	
	/**************************************************************************************************************/
	/**
	 * 글을 등록한다.
	 * @param vo - 등록할 정보가 담긴 DooillVO
	 * @return 등록 결과
	 * @exception Exception
	 */
	public String insertSample(BoardVO vo) throws Exception {
		return (String) insert("egovDAO.insertSample", vo);
	}

	/**
	 * 글을 수정한다.
	 * @param vo - 수정할 정보가 담긴 SampleVO
	 * @return void형
	 * @exception Exception
	 */
	public void updateSample(BoardVO vo) throws Exception {
		update("egovDAO.updateSample", vo);
	}

	/**
	 * 글을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 SampleVO
	 * @return void형
	 * @exception Exception
	 */
	public void deleteSample(BoardVO vo) throws Exception {
		delete("egovDAO.deleteSample", vo);
	}

	/**
	 * 글을 조회한다.
	 * @param vo - 조회할 정보가 담긴 SampleVO
	 * @return 조회한 글
	 * @exception Exception
	 */
	public BoardVO selectSample(BoardVO vo) throws Exception {
		return (BoardVO) select("egovDAO.selectSample", vo);
	}

	/**
	 * 글 목록을 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return 글 목록
	 * @exception Exception
	 */
	public List<?> selectSampleList(BoardDefaultVO searchVO) throws Exception {
		return list("egovDAO.selectSampleList", searchVO);
	}

	/**
	 * 글 총 갯수를 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return 글 총 갯수
	 * @exception
	 */
	public int selectDooillListTotCnt(BoardDefaultVO searchVO) {
		return (Integer) select("egovDAO.selectSampleListTotCnt", searchVO);
	}

}
