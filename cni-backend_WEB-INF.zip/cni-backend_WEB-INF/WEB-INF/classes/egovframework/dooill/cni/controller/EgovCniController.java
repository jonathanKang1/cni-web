package egovframework.dooill.cni.controller;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.support.SessionStatus;
import org.springmodules.validation.commons.DefaultBeanValidator;

import egovframework.dooill.cmmn.EgovOthersExcepHndlr;
import egovframework.dooill.cni.service.EgovCniService;
import egovframework.dooill.service.BoardDefaultVO;
import egovframework.dooill.service.BoardVO;
import egovframework.dooill.util.Constants;
import egovframework.rte.fdl.property.EgovPropertyService;

/**
 * @Class Name : EgovCivilController.java
 * @Description : 
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 *
 * @author Shin D.Y
 * @since 2020. 10.18
 * @version 1.0
 * @see
 *
 *  Copyright (C) by MOPAS All right reserved.
 */
@Controller
@RequestMapping("/cni")
public class EgovCniController {

    private static final Logger LOGGER = LoggerFactory.getLogger(EgovOthersExcepHndlr.class);
    
    /** EgovService */
    @Resource(name = "egovCniService")
    private EgovCniService egovCniService;

    /**
     * 클린에어충남이란 페이지 접근
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/intro/{urlPath:intro|network|stationInfo}.do", method = RequestMethod.GET)
    public String introView(@PathVariable("urlPath") String urlPath, Model model)
            throws Exception {
        return Constants.VIEW_APP.NAME.toString() + "/intro/" + urlPath;
    }
    
    /**
     * 실시간자료조회 페이지 접근
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/real/{urlPath:townsData|townsDataPop|citiesData|citiesDataPop|weeksInfo}.do", method = RequestMethod.GET)
    public String realView(@PathVariable("urlPath") String urlPath, HttpServletRequest request, Model model)
            throws Exception {
        
        if("townsDataPop".equals(urlPath)) {
            HashMap<String, Object> requestMap = writeRequestParam(request);
            model.addAttribute("searchTmsCode", requestMap.get("searchTmsCode"));
            model.addAttribute("searchDataType", requestMap.get("searchDataType"));
            model.addAttribute("searchFromDate", requestMap.get("searchFromDate"));
            model.addAttribute("searchFromTime", requestMap.get("searchFromTime"));
            model.addAttribute("searchToDate", requestMap.get("searchToDate"));
            model.addAttribute("searchToTime", requestMap.get("searchToTime"));
        } else if("citiesDataPop".equals(urlPath)) {
            HashMap<String, Object> requestMap = writeRequestParam(request);
            model.addAttribute("searchRegionCode", requestMap.get("searchRegionCode"));
            model.addAttribute("searchItemCode", requestMap.get("searchItemCode"));
            model.addAttribute("searchDataType", requestMap.get("searchDataType"));
            model.addAttribute("searchMonthDate", requestMap.get("searchMonthDate"));
            model.addAttribute("searchValidChiper", requestMap.get("searchValidChiper"));
            model.addAttribute("searchUnit", requestMap.get("searchUnit"));
        }
        
        return Constants.VIEW_APP.NAME.toString() + "/real/" + urlPath;
    }
    
    /**
     * 대기주의보경보 페이지 접근
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/air/{urlPath:citiesWarning|pmAction|dustAction|caiAction}.do", method = RequestMethod.GET)
    public String airView(@PathVariable("urlPath") String urlPath, Model model)
            throws Exception {
        return Constants.VIEW_APP.NAME.toString() + "/air/" + urlPath;
    }
    
    /**
     * 통계정보 페이지 접근
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/statis/{urlPath:airReport|determine|determinePop|foreignCountry}.do", method = RequestMethod.GET)
    public String statisView(@PathVariable("urlPath") String urlPath, HttpServletRequest request, Model model)
            throws Exception {
        
        if("determine".equals(urlPath)) {
        	model.addAttribute("confirmDate", this.egovCniService.selectQueryForObject("getConfirmDateInfo"));
        	//model.addAttribute("regionList", this.egovCniService.selectQueryForList("getCommUseRegionList"));
        	HashMap<String, Object> requestMap = writeRequestParam(request);
        	if (requestMap.get("searchNetCode") == null) requestMap.put("searchNetCode", "C");
        	model.addAttribute("regionList", this.egovCniService.selectQueryForList("getCommUseRegionList", requestMap));
            
        } else if("determinePop".equals(urlPath)) {
            HashMap<String, Object> requestMap = writeRequestParam(request);
            model.addAttribute("searchTmsCode", requestMap.get("searchTmsCode"));
            model.addAttribute("searchMonthDate", requestMap.get("searchMonthDate"));
        }
        
        return Constants.VIEW_APP.NAME.toString() + "/statis/" + urlPath;
    }
    
    /**
     * 배움터 페이지 접근
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/edu/{urlPath:cai|airPollution|airStandard|airOpen|dictionary}.do", method = RequestMethod.GET)
    public String eduView(@PathVariable("urlPath") String urlPath, Model model)
            throws Exception {
        return Constants.VIEW_APP.NAME.toString() + "/edu/" + urlPath;
    }
    
    /**
     * 고객지원 페이지 접근
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/custom/{urlPath:notice|noticeForm|faq|faqForm|data|dataForm}.do", method = RequestMethod.GET)
    public String customView(@PathVariable("urlPath") String urlPath, HttpServletRequest request, Model model)
            throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        model.addAttribute("searchCtgry", requestMap.get("searchCtgry"));
        model.addAttribute("searchTxt", requestMap.get("searchTxt"));
        model.addAttribute("pageNum", (requestMap.get("pageNum") == null ? 1 : requestMap.get("pageNum")));
        model.addAttribute("seq", requestMap.get("seq"));
        return Constants.VIEW_APP.NAME.toString() + "/custom/" + urlPath;
    }
    
    
    /**
     * 실시간 자료조회 데이터
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/real/{urlPath:getRealTownsData|getRealTownsCaiData|getRealCitiesTableData|getRealCitiesChartData|getRealCitisDayPopData|getRealCitisPopData|getRealForecastHourData}.ax", method = {RequestMethod.GET, RequestMethod.POST})
    public Map<String,Object> realData(@PathVariable("urlPath") String urlPath, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        
        if("getRealTownsData".equals(urlPath)) {
            // 측정자료 탭
            if("hour".equals(requestMap.get("searchDataType").toString())) {
                urlPath = "getRealTownsHourData";
            } else {
                urlPath = "getRealTownsDateData";
            }
            
        } else if("getRealTownsCaiData".equals(urlPath)) {
            // 통합대기 환경지수 탭 
            if("hour".equals(requestMap.get("searchDataType").toString())) {
                urlPath = "getRealTownsCaiHourData";
            } else {
                //urlPath = "getRealTownsDateData";
            	urlPath = "getRealTownsCaiDateData";
            }
            
        } else if("getRealCitiesTableData".equals(urlPath)) {
            // 시군별 대기정보
            if("day".equals(requestMap.get("searchDataType").toString())) {
                urlPath = "getRealCitiesTableDayData";
            } else if("7days".equals(requestMap.get("searchDataType").toString())) {
                urlPath = "getRealCities7DaysData";
            } else {
                urlPath = "getRealCitiesMonthData";
            }
            //requestMap.put("searchRegionMulti", requestMap.get("searchRegionMulti").toString().split(","));
        }
        
        resultMap.put("data", this.egovCniService.selectQueryForList(urlPath, requestMap));
        
        return resultMap;
    }
    
    /**
     * 대기 주의보/경보
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/air/{urlPath:getCitiesWarningData|getCitiesWarningYearData|getCitiesWarningRegData|getRealWeekData}.ax", method = {RequestMethod.GET, RequestMethod.POST})
    public Map<String,Object> airData(@PathVariable("urlPath") String urlPath, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        
        
        if("getCitiesWarningRegData".equals(urlPath)) {
//            List<Map<String, Object>> regionList = (List<Map<String, Object>>) this.egovCniService.selectQueryForList("getCommUseRegionList", requestMap);
//            requestMap.put("regionList", regionList);
//            resultMap.put("regionList", regionList);
            resultMap.put("data1", this.egovCniService.selectQueryForList("getCitiesWarningRegChartData", requestMap));
            //resultMap.put("data2", this.egovCniService.selectQueryForList("getCitiesWarningRegTableData", requestMap));
            
        } else {
            if("getCitiesWarningData".equals(urlPath)) {
                if(StringUtils.isEmpty(requestMap.get("searchItemCode"))) {
                    requestMap.put("searchItemArrCode", Constants.ITEM_PM_ARRAY);
                }
                resultMap.put("totalCount", this.egovCniService.selectQueryForObject("getCitiesWarningDataCnt", requestMap));
            }
            
            resultMap.put("data", this.egovCniService.selectQueryForList(urlPath, requestMap));
        }
        
        return resultMap;
    }
    
    
    /**
     * 고객지원
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/statis/{urlPath:getStatisReportData|getStatisStationListData|getStatisItemListData|getStatisCaiChartData|getStatisItemChartData}.ax", method = {RequestMethod.GET, RequestMethod.POST})
    public Map<String,Object> statisData(@PathVariable("urlPath") String urlPath, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        
        resultMap.put("data", this.egovCniService.selectQueryForList(urlPath, requestMap));
        
        return resultMap;
    }
    
    
    /**
     * 고객지원
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/custom/{urlPath:getCustomBoardListData|getCustomBoardFormData}.ax", method = {RequestMethod.GET, RequestMethod.POST})
    public Map<String,Object> customData(@PathVariable("urlPath") String urlPath, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        
        if("getCustomBoardListData".equals(urlPath)) {
            resultMap.put("totalCount", this.egovCniService.selectQueryForObject("getCustomBoardListDataCnt", requestMap));
            resultMap.put("data", this.egovCniService.selectQueryForList(urlPath, requestMap));
            
        } else if("getCustomBoardFormData".equals(urlPath)) {
            resultMap.put("subData", this.egovCniService.selectQueryForObject("getCustomBoardFormPreNextData", requestMap));
            resultMap.put("data", this.egovCniService.selectQueryForObject(urlPath, requestMap));
        }
        
        
        return resultMap;
    }
    
    
    /*유틸: request 파라메터 정보 출력*/
    public HashMap<String, Object> writeRequestParam(HttpServletRequest request) throws Exception {
        
        String key = null;
        String values[] = (String[])null;
        HashMap<String, Object> requestMap = new HashMap<String, Object>();
        LOGGER.debug("=== Write Request Parameter =====================================");
        for (Enumeration em = request.getParameterNames(); em.hasMoreElements();) {
            key = em.nextElement().toString();
            values = request.getParameterValues(key);
            
            if (values == null) continue;
            if (values.length == 1 && values[0] != null && values[0].length() > 0) {
                LOGGER.debug("Key = " + key + ", value = "+ values[0]);
                if(key.indexOf("Date") > -1) {
                    requestMap.put(key, values[0].toString().replaceAll("-", ""));
                } else if(key.indexOf("Multi") > -1) {
                    requestMap.put(key, values[0].toString().split(","));
                } else {
                    requestMap.put(key, values[0]);
                }
            }
        }
        LOGGER.debug("=================================================================");
        return requestMap;
    }
}
