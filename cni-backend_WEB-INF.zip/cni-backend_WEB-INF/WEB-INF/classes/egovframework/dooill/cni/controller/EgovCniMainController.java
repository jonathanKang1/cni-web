package egovframework.dooill.cni.controller;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.support.SessionStatus;
import org.springmodules.validation.commons.DefaultBeanValidator;

import egovframework.dooill.cmmn.EgovOthersExcepHndlr;
import egovframework.dooill.cni.service.EgovCniService;
import egovframework.dooill.service.BoardDefaultVO;
import egovframework.dooill.service.BoardVO;
import egovframework.dooill.util.Constants;
import egovframework.rte.fdl.property.EgovPropertyService;

/**
 * @Class Name : EgovCivilController.java
 * @Description : 
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 *
 * @author Shin D.Y
 * @since 2020. 10.18
 * @version 1.0
 * @see
 *
 *  Copyright (C) by MOPAS All right reserved.
 */
@Controller
@RequestMapping("/cni")
public class EgovCniMainController {

    private static final Logger LOGGER = LoggerFactory.getLogger(EgovOthersExcepHndlr.class);
    
    /** EgovService */
    @Resource(name = "egovCniService")
    private EgovCniService egovCniService;

    /**
     * 페이지 접근
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/{urlPath:mainStationPop|main}.do", method = RequestMethod.GET)
    public String view(@PathVariable("urlPath") String urlPath, HttpServletRequest request, Model model, SessionStatus status)
            throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        
        String searchTmsCode = null;
        
        if(!StringUtils.isEmpty(requestMap.get("searchTmsCode"))) {
            searchTmsCode = requestMap.get("searchTmsCode").toString();
        }
        
        if(urlPath.equals("main")) {
            searchTmsCode = "20038000"; // 기본값(아무값도 없을 때)
            if(!StringUtils.isEmpty(requestMap.get("lat")) && !StringUtils.isEmpty(requestMap.get("lng"))) {
                searchTmsCode = this.egovCniService.getNearStationCode(requestMap);
            }
        }
        
        model.addAttribute("searchTmsCode", requestMap.get("searchTmsCode"));
        model.addAttribute("searchItemCode", requestMap.get("searchItemCode"));
        
        return Constants.VIEW_APP.NAME.toString() + "/" + urlPath;
    }
    
    /**
     * 다중 데이터
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/main/{urlPath:getMapMakerList|getTmsDetailInfo|getMainBbsList}.ax", method = {RequestMethod.GET, RequestMethod.POST})
    public Map<String,Object> list(@PathVariable("urlPath") String urlPath, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        
        resultMap.put("data", this.egovCniService.selectQueryForList(urlPath, requestMap));
        
        return resultMap;
    }
    
    
    /**
     * 다중 데이터
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/main/{urlPath:getMainForecastInfo}.ax", method = {RequestMethod.GET, RequestMethod.POST})
    public Map<String,Object> info(@PathVariable("urlPath") String urlPath, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        
        System.out.println(":::: " + requestMap);
        
        resultMap.put("data", this.egovCniService.selectQueryForObject(urlPath, requestMap));
        
        if (resultMap.get("data") == null) {
        	requestMap.put("tms_cd", "");
        	resultMap.put("data", this.egovCniService.selectQueryForObject(urlPath, requestMap));
        }
        
        return resultMap;
    }
    
    
    /**
     * 팝업 데이터
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/mainPop/{urlPath:getMainPopTableData|getMainPopChartData}.ax", method = {RequestMethod.GET, RequestMethod.POST})
    public Map<String,Object> mainPopData(@PathVariable("urlPath") String urlPath, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        
        if("getMainPopTableData".equals(urlPath)) {
            resultMap.put("itemData", this.egovCniService.selectQueryForList("getCommItemList", requestMap));
        }
        
        resultMap.put("data", this.egovCniService.selectQueryForList(urlPath, requestMap));
        
        return resultMap;
    }
    
    
    /*유틸: request 파라메터 정보 출력*/
    public HashMap<String, Object> writeRequestParam(HttpServletRequest request) throws Exception {
        
        String key = null;
        String values[] = (String[])null;
        HashMap<String, Object> requestMap = new HashMap<String, Object>();
        LOGGER.debug("=== Write Request Parameter =====================================");
        for (Enumeration em = request.getParameterNames(); em.hasMoreElements();) {
            key = em.nextElement().toString();
            values = request.getParameterValues(key);
            
            if (values == null) continue;
            if (values.length == 1 && values[0] != null && values[0].length() > 0) {
                LOGGER.debug("Key = " + key + ", value = "+ values[0]);
                requestMap.put(key, values[0]);
            }
        }
        LOGGER.debug("=================================================================");
        return requestMap;
    }

    
    /**
     * 메인팝업 데이터  > kang
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/main/{urlPath:getPopup}.ax", method = {RequestMethod.GET, RequestMethod.POST})
    public Map<String,Object> getPopup(@PathVariable("urlPath") String urlPath, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        
        //System.out.println(":::: " + requestMap);
        
        resultMap.put("data", this.egovCniService.selectQueryForObject(urlPath));
        //System.out.println(":::: " + resultMap);
        
        return resultMap;
    }
    
    /**
     * 메인베너 방문자수  > kang
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/main/{urlPath:getVisitCnt}.ax", method = {RequestMethod.GET, RequestMethod.POST})
    public Map<String,Object> getVisitCnt(@PathVariable("urlPath") String urlPath, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        
        resultMap.put("data", this.egovCniService.selectQueryForObject(urlPath));
        
        return resultMap;
    }
}
