package egovframework.dooill.cni.controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import egovframework.dooill.cmmn.EgovOthersExcepHndlr;
import egovframework.dooill.cni.service.EgovCniService;
import egovframework.dooill.util.Constants;
import sun.misc.BASE64Decoder;

/**
 * @Class Name : EgovCivilController.java
 * @Description : 
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 *
 * @author Shin D.Y
 * @since 2020. 10.18
 * @version 1.0
 * @see
 *
 *  Copyright (C) by MOPAS All right reserved.
 */
@Controller
@RequestMapping("/cni/comm")
public class EgovCniCommonController {

    private static final Logger LOGGER = LoggerFactory.getLogger(EgovOthersExcepHndlr.class);
    
    /** EgovService */
    @Resource(name = "egovCniService")
    private EgovCniService egovCniService;

    /**
     * 데이터
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/{urlPath:getCommUseRegionList|getCommCodeList|getCommUseTmsList|getCommItemList|getCommLevelList}.ax", method = {RequestMethod.GET, RequestMethod.POST})
    public Map<String,Object> listData(@PathVariable("urlPath") String urlPath, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        
        resultMap.put("data", this.egovCniService.selectQueryForList(urlPath, requestMap));
        
        return resultMap;
    }
    
    
    /**
     * 데이터
     * @param model
     * @param status
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/{urlPath:getCommLevelInfo}.ax", method = {RequestMethod.GET, RequestMethod.POST})
    public Map<String,Object> infoData(@PathVariable("urlPath") String urlPath, HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        HashMap<String, Object> resultMap = new HashMap<String, Object>();
        
        if("getCommLevelInfo".equals(urlPath)) {
            urlPath = "getCommLevelList";
        }
        
        resultMap.put("data", this.egovCniService.selectQueryForObject(urlPath, requestMap));
        
        return resultMap;
    }
    
    
    /**
     * 다운로드
     * @param request
     * @param response
     * @param session
     * @param model
     * @return
     * @throws Exception 
     */
    @RequestMapping(value="/downloadFile.do", method=RequestMethod.POST)
    public String downloadFile(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        
        String fileOriName =requestMap.get("fileOriName").toString(); 
        String fileName = requestMap.get("fileName").toString();
        String path="";
        
        if(!StringUtils.isEmpty(requestMap.get("filePath"))) {
            path=requestMap.get("filePath").toString();
        }
        
        LOGGER.debug("=== fileOriName ===================================== " + fileOriName);
        LOGGER.debug("=== fileName ===================================== " + fileName);
        LOGGER.debug("=== path ===================================== " + path);
        
        if(fileName != null && fileName.length() > 0) {
            if(fileOriName != null && fileOriName.length() > 0) {
                fileOriName = fileOriName.replaceAll(" ", "_");
            } else {
                fileOriName = fileName;
            }
           
            model.addAttribute("fileOriName", fileOriName);
            model.addAttribute("fileName", fileName);
            model.addAttribute("filePath", path);
            
        } else {
            try {
                String msg = "파일이 존재하지 않습니다.";
                String script = "<script>";
                script += "alert(decodeURIComponent('"+java.net.URLEncoder.encode(msg, "utf-8")+"'));return;";
                script += "</script>";
                
                PrintWriter writer = response.getWriter();
                writer.print(script);
                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return Constants.VIEW_APP.DOWNLOAD.toString();
    }
    
    
    /**
     * 엑셀 다운로드
     * @param request
     * @param response
     * @param session
     * @param model
     * @return
     * @throws Exception 
     */
    @RequestMapping(value="/excelFile.do", method=RequestMethod.POST)
    public String excelFile(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        
        String excelName= requestMap.get("excelName").toString();
        String fileName =requestMap.get("excelName").toString() + "_template";
        String viewName = Constants.VIEW_APP.NAME.toString() + "/excelTemplate/" + fileName;
        String mapperName = "";
        if (requestMap.get("searchRegionCode") == null) requestMap.put("searchRegionCode", requestMap.get("searchRegionCode1"));
        if (requestMap.get("searchMonthDate") == null) requestMap.put("searchMonthDate", requestMap.get("searchMonthDate1"));
        
        if("stationInfo".equals(excelName)) {
            mapperName = "getCommUseTmsList";
            
        } else if("townsData".equals(excelName)) {
            if("hour".equals(requestMap.get("searchDataType").toString())) {
                mapperName = "getRealTownsHourData";
            } else {
                mapperName = "getRealTownsDateData";
            }
            
        } else if("townsCaiData".equals(excelName)) {
            if("hour".equals(requestMap.get("searchDataType").toString())) {
                mapperName = "getRealTownsCaiHourData";
            } else {
                mapperName = "getRealTownsDateData";
            }
            
        } else if("forecastData".equals(excelName)) {
            mapperName = "getRealForecastHourData";
            
        } else if("citiesData".equals(excelName)) {
            if("day".equals(requestMap.get("searchDataType").toString())) {
                mapperName = "getRealCitiesTableDayData";
            } else if("7days".equals(requestMap.get("searchDataType").toString())) {
                mapperName = "getRealCities7DaysData";
            } else {
                mapperName = "getRealCitiesMonthData";
            }
            
            model.addAttribute("regionList", this.egovCniService.selectQueryForList("getCommUseRegionList", requestMap));
            
        } else if("weeksInfo".equals(excelName)) {
            mapperName = "getRealWeekData";
            
        } else if("citiesWarning".equals(excelName)) {
            if(StringUtils.isEmpty(requestMap.get("searchItemCode"))) {
                requestMap.put("searchItemArrCode", Constants.ITEM_PM_ARRAY);
            }
            mapperName = "getCitiesWarningData";
            
        } else if("statisStation".equals(excelName)) {
            mapperName = "getStatisStationListData";
            model.addAttribute("tms_nm", this.egovCniService.selectQueryForObject("getTmsNM", requestMap));
        } else if("statisItem".equals(excelName)) {
            model.addAttribute("region", this.egovCniService.selectQueryForObject("getCommUseRegionList", requestMap));
            List<HashMap<String, Object>> stationList = (List<HashMap<String, Object>>) this.egovCniService.selectQueryForList("getCommUseTmsList", requestMap);
            model.addAttribute("item_cd", requestMap.get("searchItemCode"));
            model.addAttribute("stationList", stationList);
            mapperName = "getStatisItemListData";
        }
        
        model.addAttribute("data", this.egovCniService.selectQueryForList(mapperName, requestMap));
        model.addAttribute("excelName", excelName);
        model.addAttribute("searchDataType", requestMap.get("searchDataType"));
        
        return viewName;
    }
    
    
    
    @Value("${FILE_PATH}")
    private String UPLOAD_ROOT_PATH;
    
    /**
     * 차트 이미지 다운로드
     * @param request
     * @param response
     * @param session
     * @param model
     * @return
     * @throws Exception 
     */
    @RequestMapping(value="/chartDownloadImg.do", method=RequestMethod.POST)
    public String chartDownloadImg(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
        HashMap<String, Object> requestMap = writeRequestParam(request);
        model.addAttribute("imgSrc", requestMap.get("imgSrc").toString());
       return Constants.VIEW_APP.CHART_IMAGE.toString();
    }
    
    
    /*유틸: request 파라메터 정보 출력*/
    public HashMap<String, Object> writeRequestParam(HttpServletRequest request) throws Exception {
        
        String key = null;
        String values[] = (String[])null;
        HashMap<String, Object> requestMap = new HashMap<String, Object>();
        LOGGER.debug("=== Write Request Parameter =====================================");
        for (Enumeration em = request.getParameterNames(); em.hasMoreElements();) {
            key = em.nextElement().toString();
            values = request.getParameterValues(key);
            
            if (values == null) continue;
            if (values.length == 1 && values[0] != null && values[0].length() > 0) {
                LOGGER.debug("Key = " + key + ", value = "+ values[0]);
                if(key.indexOf("Date") > -1) {
                    requestMap.put(key, values[0].toString().replaceAll("-", ""));
                } else if(key.indexOf("Multi") > -1) {
                    requestMap.put(key, values[0].toString().split(","));
                } else {
                    requestMap.put(key, values[0]);
                }
            }
        }
        LOGGER.debug("=================================================================");
        return requestMap;
    }

}
