/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package egovframework.dooill.cni.service.impl;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.ibatis.sqlmap.client.SqlMapExecutor;

import egovframework.dooill.service.MessageVO;
import egovframework.rte.psl.dataaccess.EgovAbstractDAO;
import egovframework.rte.psl.orm.ibatis.SqlMapClientCallback;

/**
 * @Class Name : EgovCivilDAO.java
 * @Description : 
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 *
 * @author Shin D.Y
 * @since 2020. 10.18
 * @version 1.0
 * @see
 *
 *  Copyright (C) by MOPAS All right reserved.
 */

@Repository("egovCniDAO")
public class EgovCniDAO extends EgovAbstractDAO {

	/**
	 * 메시지 등록
	 * @param vo - 등록할 정보가 담긴 MessageVO
	 * @exception Exception
	 */
	public void insertMessage(String sql_id, MessageVO vo) throws Exception {
		insert(sql_id, vo);
	}
	
	public Object selectQueryForObject(String mapID) throws Exception {
		return select(mapID);
	}
	public Object selectQueryForObject(String mapID, HashMap hmap) throws Exception {
		return select(mapID, hmap);
	}
	public Object selectQueryForObject(String mapID, String argument) throws Exception {
		return select(mapID, argument);
	}
	public List<?> selectQueryForList(String mapID) throws Exception {
		return list(mapID);
	}
	public List<?> selectQueryForList(String mapID, String queryKey) throws Exception {
		return list(mapID, queryKey);
	}
	public List<?> selectQueryForList(String mapID, HashMap hmap) throws Exception {
		return list(mapID, hmap);
	}
	public void updateQuery(String mapID, HashMap hmap) throws Exception {
		update(mapID, hmap);
	}
	public int updateQueryAfterReturn(String mapID, HashMap hmap) throws Exception {
		return update(mapID, hmap);
	}
	public void insertQuery(String mapID, HashMap hmap) throws Exception {
		insert(mapID, hmap);
	}
	public int insertQueryAfterReturn(String mapID, HashMap hmap) throws Exception {
		return update(mapID, hmap);
	}
	public void deleteQuery(String mapID, String value) throws Exception {
		delete(mapID, value);
	}
	public void deleteQuery(String mapID, HashMap hmap) throws Exception {
		delete(mapID, hmap);
	}
	public int insertBatchHashMap(String mapID, List mapList) throws Exception {
		@SuppressWarnings("deprecation")
		Integer result = (Integer) getSqlMapClientTemplate().execute(new SqlMapClientCallback<Object>() {
			
			@Override
			public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
				
				try {
					executor.startBatch();
					
					for (Iterator iterator = mapList.iterator(); iterator.hasNext();) {
						HashMap map = (HashMap) iterator.next();
						executor.insert(mapID, map);
					}
					
					return new Integer(executor.executeBatch());
					
				} catch (Exception e) {
					throw new SQLException(e.getMessage());
				}

			}
		});
		
		return result.intValue();
	}
	
	

}
