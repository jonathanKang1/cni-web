/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package egovframework.dooill.cni.service;

import java.util.HashMap;
import java.util.List;

/**
 * @Class Name : EgovCivilService.java
 * @Description : 
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 *
 * @author Shin D.Y
 * @since 2020. 10.18
 * @version 1.0
 * @see
 *
 *  Copyright (C) by MOPAS All right reserved.
 */
public interface EgovCniService {

	
	Object selectQueryForObject(String mapID) throws Exception;
	
	Object selectQueryForObject(String mapID, HashMap hmap) throws Exception;
	
	Object selectQueryForObject(String mapID, String argument) throws Exception;
	
	List<?> selectQueryForList(String mapID) throws Exception;
	
	List<?> selectQueryForList(String mapID, String queryKey) throws Exception ;
	
	List<?> selectQueryForList(String mapID, HashMap hmap) throws Exception;
	
	void updateQuery(String mapID, HashMap hmap) throws Exception;
	
	int updateQueryAfterReturn(String mapID, HashMap hmap) throws Exception;
	
	void insertQuery(String mapID, HashMap hmap) throws Exception;
	
	int insertQueryAfterReturn(String mapID, HashMap hmap) throws Exception;
	
	void deleteQuery(String mapID, String value) throws Exception;
	
	void deleteQuery(String mapID, HashMap hmap) throws Exception;
	
	int insertBatchHashMap(String mapID, List mapList) throws Exception;
	
	String getNearStationCode(HashMap<String, Object> requestMap) throws Exception;
	
	
}
