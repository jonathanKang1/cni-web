/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package egovframework.dooill.cni.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import egovframework.dooill.cni.service.EgovCniService;
import egovframework.dooill.util.Constants;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;
import egovframework.rte.fdl.idgnr.EgovIdGnrService;

/**
 * @Class Name : EgovCivilServiceImpl.java
 * @Description : Sample Business Implement Class
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 *
 * @author Shin D.Y
 * @since 2020. 10.18
 * @version 1.0
 * @see
 *
 *  Copyright (C) by MOPAS All right reserved.
 */

@Service("egovCniService")
public class EgovCniServiceImpl extends EgovAbstractServiceImpl implements EgovCniService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EgovCniServiceImpl.class);

    /** SampleDAO */
    // TODO ibatis 사용
    @Resource(name = "egovCniDAO")
    private EgovCniDAO egovCniDAO;
    // TODO mybatis 사용
    //  @Resource(name="sampleMapper")
    //    private SampleMapper sampleDAO;

    /** ID Generation */
    @Resource(name = "egovIdGnrService")
    private EgovIdGnrService egovIdGnrService;

    
    @Override
    public Object selectQueryForObject(String mapID) throws Exception {
        return egovCniDAO.selectQueryForObject(mapID);
    }
    
    @Override
    public Object selectQueryForObject(String mapID, HashMap hmap) throws Exception {
        return egovCniDAO.selectQueryForObject(mapID, hmap);
    }
    
    @Override
    public Object selectQueryForObject(String mapID, String argument) throws Exception {
        return egovCniDAO.selectQueryForObject(mapID, argument);
    }
    
    @Override
    public List<?> selectQueryForList(String mapID) throws Exception {
        return egovCniDAO.selectQueryForList(mapID);
    }
    
    @Override
    public List<?> selectQueryForList(String mapID, String queryKey) throws Exception {
        return egovCniDAO.selectQueryForList(mapID, queryKey);
    }
    
    @Override
    public List<?> selectQueryForList(String mapID, HashMap hmap) throws Exception {
        
        if("getCitiesWarningData".equals(mapID) || "getCustomBoardListData".equals(mapID)) {
            Integer pageNum = hmap.get("pageNum") == null ? 1 : Integer.parseInt(hmap.get("pageNum").toString());
            Integer pageSize = Constants.PAGE_SIZE;
            hmap.put("startPage", ((pageNum-1) * pageSize) + 1);
            hmap.put("endPage", pageNum * pageSize);
            
        } else if("getRealCitisDayPopData".equals(mapID)) {
            String[] searchTimeArr = new String[24];
            String time ="";
            for(int i=0; i<=23; i++) {
                time = i < 10 ? "0"+i : ""+i;
                searchTimeArr[i] = time;
            }
            hmap.put("searchTimeArr", searchTimeArr);
            
        } else if("getMapMakerList".equals(mapID)) {
            if(!StringUtils.isEmpty(hmap.get("searchRegionCode"))) {
                String searchRegionCode = hmap.get("searchRegionCode").toString();
                if("44131".equals(searchRegionCode)){
                    // 천안시 동남부 ,천안시 서남부 합쳐야됨
                    ArrayList<String> searchRegionCodeArr = new ArrayList<String>();
                    searchRegionCodeArr.add(searchRegionCode);
                    searchRegionCodeArr.add("44133");
                    hmap.put("searchRegionCodeArr", searchRegionCodeArr);
                    hmap.put("searchRegionCode", null);
                }
                
            }
        }
        
        return egovCniDAO.selectQueryForList(mapID, hmap);
    }
    
    @Override
    public void updateQuery(String mapID, HashMap hmap) throws Exception {
        egovCniDAO.updateQuery(mapID, hmap);
    }
    
    @Override
    public int updateQueryAfterReturn(String mapID, HashMap hmap) throws Exception {
        return egovCniDAO.updateQueryAfterReturn(mapID, hmap);
    }
    
    @Override
    public void insertQuery(String mapID, HashMap hmap) throws Exception {
        egovCniDAO.insertQuery(mapID, hmap);
    }
    
    @Override
    public int insertQueryAfterReturn(String mapID, HashMap hmap) throws Exception {
        return egovCniDAO.insertQueryAfterReturn(mapID, hmap);
    }
    
    @Override
    public void deleteQuery(String mapID, HashMap hmap) throws Exception {
        egovCniDAO.deleteQuery(mapID, hmap);
    }
    
    @Override
    public void deleteQuery(String mapID, String value) throws Exception {
        egovCniDAO.deleteQuery(mapID, value);
    }
    
    @Override
    public int insertBatchHashMap(String mapID, List mapList) throws Exception {
        return egovCniDAO.insertBatchHashMap(mapID, mapList);
        
    }

    @Override
    public String getNearStationCode(HashMap<String, Object> requestMap) throws Exception {
        // TODO Auto-generated method stub
        Double paramLat = Double.parseDouble(requestMap.get("lat").toString());
        Double paramLng = Double.parseDouble(requestMap.get("lng").toString());
        List<HashMap<String, Object>> getCommUseTmsList = (List<HashMap<String, Object>>) this.selectQueryForList("getCommUseTmsList", requestMap);
        
        //HashMap<String, Object> tmsInfo = new HashMap<String, Object>();
        String tmsCode = null;
        String tmsNm = null;
        Double minValue = null;
        for(HashMap<String, Object> tmsInfo : getCommUseTmsList) {
            Double lat = Double.parseDouble(tmsInfo.get("LAT").toString());
            Double lng = Double.parseDouble(tmsInfo.get("LNG").toString());
            
            lat = paramLat - lat;
            lng = paramLng - lng;
            
            // 위도 음수 -> 양수로 변환
            if(lat < 0) {
                lat = lat * -1;
            }
            
            // 경도 음수 -> 양수로 변환
            if(lng < 0) {
                lng = lng * -1;
            }
            
            lat = Math.sqrt(lat);
            lng = Math.sqrt(lng);
            
            Double curValue = lat + lng;
            
            // 현재 최소 거리의 측정소 코드값 세팅
            if(tmsCode == null || minValue > curValue) {
                tmsCode = tmsInfo.get("TMS_CD").toString();
                tmsNm = tmsInfo.get("TMS_NM").toString();
                minValue = curValue;
            }
        }
        
        return tmsCode;
    }
    
}
