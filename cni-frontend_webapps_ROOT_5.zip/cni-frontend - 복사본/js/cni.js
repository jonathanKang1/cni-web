function fnCheckDatePeriod(data_type, s_date, e_date) {
	if (Ext.Date.format(s_date, 'Y-m-d') > Ext.Date.format(e_date, 'Y-m-d')) {
		Ext.Msg.alert('정보', '시작일이 종료일 보다 클수 없습니다.')
		return false;
	};
	
	if (data_type == 'H') {
		if (s_date < Ext.Date.add(e_date, Ext.Date.MONTH, -3)) {
			Ext.Msg.alert('알림', '자료 조회 기간은 3개월을 초과할 수 없습니다.');
			return false;
		};
	} else {
		if (s_date < Ext.Date.add(e_date, Ext.Date.DAY, -7)) {
			Ext.Msg.alert('알림', '5분자료 조회 기간은 1주일을 초과할 수 없습니다.');
			return false;
		};
	}
	return true;
}

function fnPasswdValidater(chk_pwd) {
	
	var regExp1 = /[a-z]/i;
	var regExp2 = /[0-9]/;
	var regExp3 = /[!@#\$%\^&\*]/;
	var regExp4 = /[^a-z0-9!@#\$%\^&\*]/i;
	var char_0, char_1, char_2;
	
	/* password 규칙
	*  영문, 숫자, 특수문자(!@#$%^&*) 포함
	*  9~15자  이내 이어야 하며, 
	*  동일문자의 반복 또는 연속되는 문자가 3자리 이상 불가
	*/
	
	if (chk_pwd.length < 9|| chk_pwd.length > 15) return false;
	
	/*if (regExp1.test(chk_pwd) &&
			regExp2.test(chk_pwd) &&
			regExp3.test(chk_pwd) &&
			!regExp4.test(chk_pwd)) {
		rtn_tf = true;
	}*/
	if (!regExp1.test(chk_pwd) || !regExp2.test(chk_pwd) || !regExp3.test(chk_pwd) || regExp4.test(chk_pwd)) return false;
	
	for (var i=2; i<chk_pwd.length; i++) {
		//if (i > 1) {
			char_0 = chk_pwd.charCodeAt(i-2);
			char_1 = chk_pwd.charCodeAt(i-1);
			char_2 = chk_pwd.charCodeAt(i);

			//동일문자 연속 3회 반복 체크
			/*if (char_0 == char_1 && char_1 == char_2) {
				rtn_tf = false;
				break;
			}*/
			if (char_0 == char_1 && char_1 == char_2) return false;
			
			//연속문자 3회 체크
			/*if ((char_0 - char_1 == 1 && char_1 - char_2 == 1) || (char_0 - char_1 == -1 && char_1 - char_2 == -1)) {
				rtn_tf = false;
				break;
			}*/
			if ((char_0 - char_1 == 1 && char_1 - char_2 == 1) || (char_0 - char_1 == -1 && char_1 - char_2 == -1)) return false;
		//}
	}
	
	return true;
};
