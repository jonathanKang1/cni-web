let SEARCH_FROM_DATE, SEARCH_TO_DATE;
$(function() {
    init();
    
    // 탭 이벤트
    $('input[name=tabs]').click(function() {
        $('input[name=searchTabGubun]').val($(this).val());
        if($(this).val() == 'tab1') {
            $('.sub_tab_contnets').removeClass('tab_on');
            $('#content1').addClass('tab_on');
            getTab1TabelData();
        } else if($(this).val() == 'tab2') {
            $('.sub_tab_contnets').removeClass('tab_on');
            $('#content2').addClass('tab_on');
            getTab2TabelData();
        } else if($(this).val() == 'tab3') {
            $('.sub_tab_contnets').removeClass('tab_on');
            $('#content3').addClass('tab_on');
            getTab3TabelData();
        }
    });
    
    // 검색버튼 이벤트
    $('.searchBtn').click(function() {
        if($(this).data('tab') == 'tab1') {
            getTab1TabelData();
        } else if($(this).data('tab') == 'tab2') {
            getTab2TabelData();
        } else if($(this).data('tab') == 'tab3') {
            getTab3TabelData();
        }
    });
    
    // 그래프보기 버튼 이벤트
    $('.showChartBtn').click(function() {
        let url = '/cni/real/townsDataPop.do?' + $('.sub_tab_contnets.tab_on form').serialize();
        let name = 'CHARTPOP';
        let opt = 'width=770,height=650,location=no,menubar=no,scrollbars=no,status=no,titlebar=no,toolbar=no';
        window.open(url, name, opt);
    });
    
    // 검색영역 변경 이벤트
    $('select[name=searchTmsCode]').change(function() {
        $('select[name=searchTmsCode]').val($('option:selected', this).val());
    });
    $('input[name=searchDataType]').change(function() {
        let val = $(this).val();
        
        if(val == 'hour') {
            $('select[name=searchFromTime]').show();
            $('select[name=searchToTime]').show();
        } else {
            $('select[name=searchFromTime]').hide();
            $('select[name=searchToTime]').hide();
        }
        
        $('input[name=searchDataType][value='+val+']').prop('checked', true);
    });
    $('select[name=searchFromTime]').change(function() {
        $('select[name=searchFromTime]').val($('option:selected', this).val());
    });
    $('select[name=searchToTime]').change(function() {
        $('select[name=searchToTime]').val($('option:selected', this).val());
    });
});


function init() {
    let onFromSelect = function(d, date) {
        $('input[name=searchFromDate]').val(d);
    };
    let onToSelect = function(d, date) {
        $('input[name=searchToDate]').val(d);
    };
    
    // 달력 세팅
    SEARCH_FROM_DATE = $('input[name=searchFromDate]').datepicker({autoClose: true,'onSelect' : onFromSelect}).data('datepicker');
    SEARCH_TO_DATE = $('input[name=searchToDate]').datepicker({autoClose: true,'onSelect' : onToSelect}).data('datepicker');
    SEARCH_FROM_DATE.selectDate(new Date());
    SEARCH_TO_DATE.selectDate(new Date());
    let dt = moment(new Date(), "YYYYMMDDHH").subtract(2, 'hours').toDate(); // 1시간 전
    let hour = dt.getHours() < 10 ? '0' + dt.getHours() : dt.getHours();
    $('select[name=searchToTime]').val(hour);
    
    getStationList();
    getTab1TabelData();
}

//측정소 리스트 가져오기
function getStationList() {
    $.ajax({
            url : '/cni/comm/getCommUseTmsList.ax',
            type : 'GET',
            dataType : 'json',
            async : false
    }).done(function(res) {
        let makeHtml = '';
        $.each(res.data, function(i, data) {
            makeHtml += '<option value="'+data.TMS_CD+'">'+data.TMS_NM+'</option>'; 
        });
        $('select[name=searchTmsCode]').html(makeHtml);
    });
}


function getTab1TabelData() {
    $.get(
            '/cni/real/getRealTownsData.ax',
            $('.sub_tab_contnets.tab_on form').serialize()
    ).done(function(res) {
        console.log(res);
        let dataType = $('input[name=searchDataType]:checked').val();
        let makeHtml = '';
        
        setTab1TableHead(dataType);
        
        if(dataType == 'hour') {
            $.each(res.data, function(i, data) {
                makeHtml += '<tr>';
                makeHtml += '   <th>'+data.DSP_DT+'</th>';
                makeHtml += '   <td><img src="/cni/image/grade_'+(data.PMB_LVL_CD || 'X')+'_s.png" alt="'+data.PMB_LVL_NM+'"></td>';
                makeHtml += '   <td>'+(data.PMB_MSR_VL || '-')+'</td>';
                makeHtml += '   <td><img src="/cni/image/grade_'+(data.PM2_LVL_CD || 'X')+'_s.png" alt="'+data.PM2_LVL_NM+'"></td>';
                makeHtml += '   <td>'+(data.PM2_MSR_VL || '-')+'</td>';
                makeHtml += '   <td><img src="/cni/image/grade_'+(data.O3B_LVL_CD || 'X')+'_s.png" alt="'+data.O3B_LVL_NM+'"></td>';
                makeHtml += '   <td>'+(data.O3B_MSR_VL || '-')+'</td>';
                makeHtml += '   <td><img src="/cni/image/grade_'+(data.NO2_LVL_CD || 'X')+'_s.png" alt="'+data.NO2_LVL_NM+'"></td>';
                makeHtml += '   <td>'+(data.NO2_MSR_VL || '-')+'</td>';
                makeHtml += '   <td><img src="/cni/image/grade_'+(data.COB_LVL_CD || 'X')+'_s.png" alt="'+data.COB_LVL_NM+'"></td>';
                makeHtml += '   <td>'+(data.COB_MSR_VL || '-')+'</td>';
                makeHtml += '   <td><img src="/cni/image/grade_'+(data.SO2_LVL_CD || 'X')+'_s.png" alt="'+data.SO2_LVL_NM+'"></td>';
                makeHtml += '   <td>'+(data.SO2_MSR_VL || '-')+'</td>';
                makeHtml += '</tr>';
            });
            
        } else if(dataType == 'date') {
            $.each(res.data, function(i, data) {
                makeHtml += '<tr>';
                makeHtml += '   <th>'+data.DSP_DT+'</th>';
                makeHtml += '   <td>'+isNull(data.PMB_MSR_VL, '-')+'</td>';
                makeHtml += '   <td>'+isNull(data.PM2_MSR_VL, '-')+'</td>';
                makeHtml += '   <td>'+isNull(data.O3B_MSR_VL, '-')+'</td>';
                makeHtml += '   <td>'+isNull(data.NO2_MSR_VL, '-')+'</td>';
                makeHtml += '   <td>'+isNull(data.COB_MSR_VL, '-')+'</td>';
                makeHtml += '   <td>'+isNull(data.SO2_MSR_VL, '-')+'</td>';
                
                makeHtml += '</tr>';
            });
        }
        
        $('#townsDataTable tbody').html(makeHtml);
    })
}

function setTab1TableHead(p_dataType) {
    if(p_dataType == 'hour') {
        $('#townsDataTable thead tr:eq(0) th:not(:first)').attr('colspan', 2);
        $('#townsDataTable thead tr:eq(1)').show();
        
    } else if(p_dataType == 'date') {
        $('#townsDataTable thead tr:eq(0) th:not(:first)').attr('colspan', 1);
        $('#townsDataTable thead tr:eq(1)').hide();
    }
}


function getTab2TabelData() {
    $.get(
            '/cni/real/getRealTownsCaiData.ax',
            $('.sub_tab_contnets.tab_on form').serialize()
    ).done(function(res) {
        console.log(res);
        let dataType = $('input[name=searchDataType]:checked').val();
        let makeHtml = '';
        
        setTab2TableHead(dataType);
        
        if(dataType == 'hour') {
            $.each(res.data, function(i, data) {
                makeHtml += '<tr>';
                makeHtml += '   <th>'+data.DSP_DT+'</th>';
                makeHtml += '   <td>'+(data.BAD_ITEM_NM || '')+'</td>';
                makeHtml += '   <td><img src="/cni/image/grade_'+(data.CAI_LVL_CD || 'X')+'_s.png" alt="'+data.CAI_LVL_NM+'"></td>';
                makeHtml += '   <td>'+(data.CAI_MSR_VL || '-')+'</td>';
                makeHtml += '   <td><img src="/cni/image/grade_'+(data.PMB_LVL_CD || 'X')+'_s.png" alt="'+data.PMB_LVL_NM+'"></td>';
                makeHtml += '   <td>'+(data.PMB_MSR_VL || '-')+'</td>';
                makeHtml += '   <td><img src="/cni/image/grade_'+(data.PM2_LVL_CD || 'X')+'_s.png" alt="'+data.PM2_LVL_NM+'"></td>';
                makeHtml += '   <td>'+(data.PM2_MSR_VL || '-')+'</td>';
                makeHtml += '   <td><img src="/cni/image/grade_'+(data.O3B_LVL_CD || 'X')+'_s.png" alt="'+data.O3B_LVL_NM+'"></td>';
                makeHtml += '   <td>'+(data.O3B_MSR_VL || '-')+'</td>';
                makeHtml += '   <td><img src="/cni/image/grade_'+(data.NO2_LVL_CD || 'X')+'_s.png" alt="'+data.NO2_LVL_NM+'"></td>';
                makeHtml += '   <td>'+(data.NO2_MSR_VL || '-')+'</td>';
                makeHtml += '   <td><img src="/cni/image/grade_'+(data.COB_LVL_CD || 'X')+'_s.png" alt="'+data.COB_LVL_NM+'"></td>';
                makeHtml += '   <td>'+(data.COB_MSR_VL || '-')+'</td>';
                makeHtml += '   <td><img src="/cni/image/grade_'+(data.SO2_LVL_CD || 'X')+'_s.png" alt="'+data.SO2_LVL_NM+'"></td>';
                makeHtml += '   <td>'+(data.SO2_MSR_VL || '-')+'</td>';
                makeHtml += '</tr>';
            });
            
        } else if(dataType == 'date') {
            $.each(res.data, function(i, data) {
                makeHtml += '<tr>';
                makeHtml += '   <th>'+data.DSP_DT+'</th>';
                makeHtml += '   <td>'+isNull(data.CAI_MSR_VL, '-')+'</td>';
                makeHtml += '   <td>'+isNull(data.PMB_MSR_VL, '-')+'</td>';
                makeHtml += '   <td>'+isNull(data.PM2_MSR_VL, '-')+'</td>';
                makeHtml += '   <td>'+isNull(data.O3B_MSR_VL, '-')+'</td>';
                makeHtml += '   <td>'+isNull(data.NO2_MSR_VL, '-')+'</td>';
                makeHtml += '   <td>'+isNull(data.COB_MSR_VL, '-')+'</td>';
                makeHtml += '   <td>'+isNull(data.SO2_MSR_VL, '-')+'</td>';
                makeHtml += '</tr>';
            });
        }
        
        $('#townsCaiDataTable tbody').html(makeHtml);
    })
}

function setTab2TableHead(p_dataType) {
    
    if(p_dataType == 'hour') {
        $('#townsCaiDataTable thead tr:eq(0) th:not(:first)').attr('colspan', 2);
        $('#townsCaiDataTable thead tr:eq(0) th:eq(1)').attr('colspan', 3);
        $('#townsCaiDataTable thead tr:eq(1)').show();
        
    } else if(p_dataType == 'date') {
        $('#townsCaiDataTable thead tr:eq(0) th:not(:first)').attr('colspan', 1);
        $('#townsCaiDataTable thead tr:eq(1)').hide();
    }
}


function getTab3TabelData() {
    $.get(
            '/cni/real/getRealForecastHourData.ax',
            $('.sub_tab_contnets.tab_on form').serialize()
    ).done(function(res) {
        console.log(res);
        let dataType = $('input[name=searchDataType]:checked').val();
        let makeHtml = '';
        
        $.each(res.data, function(i, data) {
            makeHtml += '<tr>';
            makeHtml += '   <th>'+data.DSP_DT+'</th>';
            makeHtml += '   <td>'+(data.TMP_MSR_VL || '-')+'</td>';
            makeHtml += '   <td>'+(data.HUM_MSR_VL || '-')+'</td>';
            makeHtml += '   <td>'+(data.DIR_MSR_VL || '-')+'</td>';
            makeHtml += '   <td>'+(data.SPD_MSR_VL || '-')+'</td>';
            makeHtml += '</tr>';
        });
        
        $('#forecastDataTable tbody').html(makeHtml);
    })
}