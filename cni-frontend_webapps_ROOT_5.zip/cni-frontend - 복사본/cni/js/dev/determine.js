let SEARCH_FROM_DATE1, SEARCH_TO_DATE1, SEARCH_FROM_DATE2, SEARCH_TO_DATE2, SEARCH_MONTH_DATE, SEARCH_MONTH_DATE1;
$(function() {
    init();
    
    // 탭 이벤트
    $('input[name=tabs]').click(function() {
        $('input[name=searchTabGubun]').val($(this).val());
        if($(this).val() == 'tab1') {
            $('.sub_tab_contnets').removeClass('tab_on');
            $('#content1').addClass('tab_on');
            getTab1TabelData();
        } else if($(this).val() == 'tab2') {
            $('.sub_tab_contnets').removeClass('tab_on');
            $('#content2').addClass('tab_on');
            $('#searchTmsCode1')[0].sumo.selectAll();
            getTab2TabelData();
        } else if($(this).val() == 'tab3') {
            $('.sub_tab_contnets').removeClass('tab_on');
            $('#content3').addClass('tab_on');
            $('#searchTmsCode2')[0].sumo.selectAll();
        }
    });
    
    // 검색버튼 이벤트
    $('.searchBtn').click(function() {
        if($(this).data('tab') == 'tab1') {
            getTab1TabelData();
        } else if($(this).data('tab') == 'tab2') {
            getTab2TabelData();
        }
    });
    
    
    // 측정망 변경 이벤트
    /*$('select[name=searchNetCode]').change(function() {
        let index = $(this).data('index');
        getStationList($('select[name=searchRegionCode]').val(), $(this).val(), index);
        $('#searchTmsCode' + index)[0].sumo.reload();
        $('#searchTmsCode' + index)[0].sumo.selectAll();
    });*/
    
    
    // 시군 변경 이벤트:측정소별확정자료
    $('select[name=searchRegionCode]').change(function() {
    	let index = $(this).data('index');
        //getStationList($(this).val(), $('select[name=searchNetCode]').val(), index);
        getStationList($(this).val(), 'C', index);
        //$('#searchTmsCode' + index)[0].sumo.reload();
        //$('#searchTmsCode' + index)[0].sumo.selectAll();
    });
    // 시군 변경 이벤트:항목별확정자료
    $('select[name=searchRegionCode1]').change(function() {
        let index = $(this).data('index');
        //getStationList($(this).val(), $('select[name=searchNetCode]').val(), index);
        getStationList($(this).val(), 'C', index);
        $('#searchTmsCode' + index)[0].sumo.reload();
        $('#searchTmsCode' + index)[0].sumo.selectAll();
    });
    
    
    // 항목별 측정소 변경 이벤트
    $('#searchTmsCode1').change(function() {
        let tmsSelElem = $('#searchTmsCode1 option:selected');
        let tmsCodeArr = [];
        
        tmsSelElem.each(function(i) {
            if($(this).val() != null && $(this).val() != '' && $(this).is(':enabled')) {
                tmsCodeArr.push($(this).val());
            }
        });
        
        $('#content2 input[name=searchMultiTmsCode]').val(tmsCodeArr.toString());
    });
    
    // 그래프보기 버튼 이벤트
    $('#showChartBtn').click(function() {
        let url = '/cni/statis/determinePop.do?' + $('#content1 form').serialize();
        let name = 'CHARTPOP2';
        let opt = 'width=770,height=650,location=no,menubar=no,scrollbars=no,status=no,titlebar=no,toolbar=no';
        window.open(url, name, opt);
    });
});

function init() {
    let dt = moment(confirmDate, 'YYYYMM').toDate();
    let endDt = new Date(confirmDate.substring(0, 4), confirmDate.substring(4, 6), 0);
    
    // 달력 세팅
    SEARCH_MONTH_DATE = $('input[name=searchMonthDate]').datepicker({autoClose: true, minView:'months', view:'months', dateFormat:'yyyy-mm' }).data('datepicker');
    SEARCH_MONTH_DATE1 = $('input[name=searchMonthDate1]').datepicker({autoClose: true, minView:'months', view:'months', dateFormat:'yyyy-mm' }).data('datepicker');
    //SEARCH_FROM_DATE1 = $('#content2 input[name=searchFromDate]').datepicker({autoClose: true}).data('datepicker');
    //SEARCH_TO_DATE1 = $('#content2 input[name=searchToDate]').datepicker({autoClose: true}).data('datepicker');
    //SEARCH_FROM_DATE2 = $('#content3 input[name=searchFromDate]').datepicker({autoClose: true}).data('datepicker');
    //SEARCH_TO_DATE2 = $('#content3 input[name=searchToDate]').datepicker({autoClose: true}).data('datepicker');
    SEARCH_MONTH_DATE.selectDate(dt);
    SEARCH_MONTH_DATE1.selectDate(dt);
    //SEARCH_FROM_DATE1.selectDate(dt);
    //SEARCH_TO_DATE1.selectDate(endDt);
    //SEARCH_FROM_DATE2.selectDate(dt);
    //SEARCH_TO_DATE2.selectDate(endDt);
    
    //getStationList();
    getStationList($('select[name=searchRegionCode]').val(), 'C', '');
    getTab1TabelData();
    
    //getStationList($('select[name=searchRegionCode]').val(), $('select[name=searchNetCode]').val());
    getStationList($('select[name=searchRegionCode1]').val(), 'C', '1');
    
    $('.multi-select-all').SumoSelect({ selectAll: true, locale : ['확인','취소','전체'], placeholder : '선택',captionFormatAllSelected : '전체선택',captionFormat : '{0}개 선택'
        ,forceCustomRendering: true
    });
}


//측정소 리스트 가져오기
function getStationList(p_region, p_net, index) {
    $.ajax({
            url : '/cni/comm/getCommUseTmsList.ax',
            data : {
                'searchRegionCode' : p_region,
                'searchNetCode' : p_net
            },
            type : 'GET',
            dataType : 'json',
            async : false
    }).done(function(res) {
        let makeHtml = '';
        $.each(res.data, function(i, data) {
            makeHtml += '<option value="'+data.TMS_CD+'">'+data.TMS_NM+'</option>'; 
        });
        
        if(p_net == null) {
            $('#content1 select[name=searchTmsCode]').html(makeHtml);
        } else {
            if(index == null) {
                $('.searchTmsCode').html(makeHtml);
            } else {
                $('#searchTmsCode' + index).html(makeHtml);
            }
        }
    });
}


function getTab1TabelData() {
	$.get(
            '/cni/statis/getStatisStationListData.ax',
            $('.sub_tab_contnets.tab_on form').serialize()
    ).done(function(res) {
        let dataType = $('input[name=searchDataType]:checked').val();
        let makeHtml = '';
        
        $.each(res.data, function(i, data) {
            makeHtml += '<tr>';
            makeHtml += '   <th>'+data.DSP_DT+'</th>';
            makeHtml += '   <td>'+isNull(data.PMB_MSR_VL, '-')+'</td>';
            makeHtml += '   <td>'+isNull(data.PM2_MSR_VL, '-')+'</td>';
            makeHtml += '   <td>'+isNull(data.O3B_MSR_VL, '-')+'</td>';
            makeHtml += '   <td>'+isNull(data.NO2_MSR_VL, '-')+'</td>';
            makeHtml += '   <td>'+isNull(data.COB_MSR_VL, '-')+'</td>';
            makeHtml += '   <td>'+isNull(data.SO2_MSR_VL, '-')+'</td>';
            makeHtml += '</tr>';
        });
        
        $('#stationDataTable tbody').html(makeHtml);
    });
}


function getTab2TabelData() {
	let elem = $('#content2');
    let tmsCodeArr = []; 
    let makeHtml = '';
    let tmsSelElem = elem.find('#searchTmsCode1 option:selected');
    
    tmsSelElem.each(function(i) {
        if($(this).val() != null && $(this).val() != '' && $(this).is(':enabled')) {
            makeHtml += '<th>'+$(this).text()+'</th>'
            tmsCodeArr.push($(this).val());
        }
    });
    
    $.get(
            '/cni/statis/getStatisItemListData.ax',
            {
                //'searchNetCode' : elem.find('select[name=searchNetCode]').val(),
            	'searchNetCode' : 'C',
                'searchItemCode' : elem.find('select[name=searchItemCode]').val(),
                'searchRegionCode' : elem.find('select[name=searchRegionCode1]').val(),
                'searchMultiTmsCode' : tmsCodeArr.toString(),
                'searchMonthDate' : elem.find('input[name=searchMonthDate1]').val()
                //'searchFromDate' : elem.find('input[name=searchFromDate]').val(),
                //'searchToDate' : elem.find('input[name=searchToDate]').val()
            }
    ).done(function(res) {
        let dataType = $('input[name=searchDataType]:checked').val();
        $('#itemSigun').text(elem.find('select[name=searchRegionCode1] option:selected').text());
        $('#itemSigun').attr('colspan', tmsSelElem.size());
        $('#itemStation').html(makeHtml);
        
        makeHtml = '';
        $.each(res.data, function(i, data) {
            makeHtml += '<tr>';
            makeHtml += '   <th>'+data.DSP_DAY+'</th>';
            $.each(tmsCodeArr, function(j, code) {
                //makeHtml += '   <td>'+isNull(data['R'+code], '-')+'</td>';
            	makeHtml += '   <td>'+isNull(data["'"+code+"'"], '-')+'</td>';
            });
            makeHtml += '</tr>';
        });
        
        $('#itemDataTable tbody').html(makeHtml);
    })
}


function getTab3TabelData() {
    $.get(
            '/cni/statis/getRealForecastHourData.ax',
            $('.sub_tab_contnets.tab_on form').serialize()
    ).done(function(res) {
        let dataType = $('input[name=searchDataType]:checked').val();
        let makeHtml = '';
        
        $.each(res.data, function(i, data) {
            makeHtml += '<tr>';
            makeHtml += '   <th>'+data.DSP_DT+'</th>';
            makeHtml += '   <td>'+(data.TMP_MSR_VL || '-')+'</td>';
            makeHtml += '   <td>'+(data.HUM_MSR_VL || '-')+'</td>';
            makeHtml += '   <td>'+(data.DIR_MSR_VL || '-')+'</td>';
            makeHtml += '   <td>'+(data.SPD_MSR_VL || '-')+'</td>';
            makeHtml += '</tr>';
        });
        
        $('#forecastDataTable tbody').html(makeHtml);
    })
}