let SEARCH_FROM_DATE, SEARCH_TO_DATE;
let DATA1, DATA2, DATA3, DATA4, DATA5, DATA6, DATA7;
let CHART1, CHART2, CHART3, CHART4, CHART5, CHART6, CHART7;

$(function() {
    init();
    
    // 검색버튼 이벤트
    $('#searchBtn').click(function() {
        dataInit();
        getCaiChartData();
        getItemChartData();
    });
});

function init() {
    let dt = moment(searchMonthDate, 'YYYYMM').toDate();
    
    // 달력 세팅
    SEARCH_MONTH_DATE = $('input[name=searchMonthDate]').datepicker({autoClose: true, minView:'months', view:'months', dateFormat:'yyyy-mm' }).data('datepicker');
    SEARCH_MONTH_DATE.selectDate(moment(dt, 'YYYY-MM').toDate());
    
    dataInit();
    google.charts.load('current', {packages: ['corechart', 'line']});
    getCaiChartData();
    getItemChartData();
};


// 차트 데이터 초기화
function dataInit() {
    DATA1 = [['날짜', '좋음', '보통', '약간나쁨', '좋음']]
    , DATA2 = [['날짜', 'PM10', '']]
    , DATA3 = [['날짜', 'PM2.5', '']]
    , DATA4 = [['날짜', '오존', '']]
    , DATA5 = [['날짜', '이산화질소', '']]
    , DATA6 = [['날짜', '일산화탄소', '']]
    , DATA7 = [['날짜', '아황산가스', '']];
}


// 데이터 가져오기
function getCaiChartData() {
    console.log($('#searchForm').serialize());
    $.get(
            '/cni/statis/getStatisCaiChartData.ax'
            ,$('#searchForm').serialize()
    ).done(function(res) {
        console.log(res);
        let flag = false;
        $.each(res.data, function(i, data) {
            let arr1 = [];
            
            arr1.push(data.MSR_DD);
            arr1.push(parseFloat(data.CAI_LVL1_CNT) || 0);
            arr1.push(parseFloat(data.CAI_LVL2_CNT) || 0);
            arr1.push(parseFloat(data.CAI_LVL3_CNT) || 0);
            arr1.push(parseFloat(data.CAI_LVL4_CNT) || 0);
            
            DATA1.push(arr1);
            
            if(data.CAI_LVL1_CNT || data.CAI_LVL2_CNT || data.CAI_LVL3_CNT || data.CAI_LVL4_CNT){
                flag = true;
            }
        });
        
        if(!flag) {
            options1.vAxis.viewWindow.max = 10;
            options1.vAxis.viewWindow.min = 0;
        } else {
            options1.vAxis.viewWindow = {min:0};
        }
        
        google.charts.setOnLoadCallback(drawLine1);
    })
}


// 데이터 가져오기
let flag2 = false, flag3 = false, flag4 = false, flag5 = false, flag6 = false, flag7 = false;
function getItemChartData() {
    console.log($('#searchForm').serialize());
    $.get(
            '/cni/statis/getStatisItemChartData.ax',
            $('#searchForm').serialize()
    ).done(function(res) {
        console.log(res);
        flag2 = false, flag3 = false, flag4 = false, flag5 = false, flag6 = false, flag7 = false;
        
        $.each(res.data, function(i, data) {
            let arr2 = [];
            let arr3 = [];
            let arr4 = [];
            let arr5 = [];
            let arr6 = [];
            let arr7 = [];
            
            if(i == 0) {
                $('#chart_area_pmb .ind span').text(setBaseline(parseFloat(data.PMB_LVL_VL)));
                $('#chart_area_pm2 .ind span').text(setBaseline(parseFloat(data.PM2_LVL_VL)));
                $('#chart_area_o3b .ind span').text(setBaseline(parseFloat(data.O3B_LVL_VL)));
                $('#chart_area_no2 .ind span').text(setBaseline(parseFloat(data.NO2_LVL_VL)));
                $('#chart_area_cob .ind span').text(setBaseline(parseFloat(data.COB_LVL_VL)));
                $('#chart_area_so2 .ind span').text(setBaseline(parseFloat(data.SO2_LVL_VL)));
            }
            
            arr2.push(data.MSR_DD);
            arr2.push(parseFloat(data.PMB_MSR_AVG) || 0);
            arr2.push(setBaseline(parseFloat(data.PMB_LVL_VL)));
            
            if(data.PMB_MSR_AVG){
                flag2 = true;
            }
            
            arr3.push(data.MSR_DD);
            arr3.push(parseFloat(data.PM2_MSR_AVG) || 0);
            arr3.push(setBaseline(parseFloat(data.PM2_LVL_VL)));
            
            if(data.PM2_MSR_AVG){
                flag3 = true;
            }
            
            arr4.push(data.MSR_DD);
            arr4.push(parseFloat(data.O3B_MSR_AVG) || 0);
            arr4.push(setBaseline(parseFloat(data.O3B_LVL_VL)));
            
            if(data.O3B_MSR_AVG){
                flag4 = true;
            }
            
            arr5.push(data.MSR_DD);
            arr5.push(parseFloat(data.NO2_MSR_AVG) || 0);
            arr5.push(setBaseline(parseFloat(data.NO2_LVL_VL)));
            
            if(data.NO2_MSR_AVG){
                flag5 = true;
            }
            
            arr6.push(data.MSR_DD);
            arr6.push(parseFloat(data.COB_MSR_AVG) || 0);
            arr6.push(setBaseline(parseFloat(data.COB_LVL_VL)));
            
            if(data.COB_MSR_AVG){
                flag6 = true;
            }
            
            arr7.push(data.MSR_DD);
            arr7.push(parseFloat(data.SO2_MSR_AVG) || 0);
            arr7.push(setBaseline(parseFloat(data.SO2_LVL_VL)));
            
            if(data.SO2_MSR_AVG){
                flag7 = true;
            }
            
            DATA2.push(arr2);
            DATA3.push(arr3);
            DATA4.push(arr4);
            DATA5.push(arr5);
            DATA6.push(arr6);
            DATA7.push(arr7);
        });
        
        google.charts.setOnLoadCallback(drawLine2);
        google.charts.setOnLoadCallback(drawLine3);
        google.charts.setOnLoadCallback(drawLine4);
        google.charts.setOnLoadCallback(drawLine5);
        google.charts.setOnLoadCallback(drawLine6);
        google.charts.setOnLoadCallback(drawLine7);
    });
}

// 차트 그리기 옵션
var options1 = {
    legend: 'none', // { position: 'bottom' },
    chartArea: {'width': '75%', 'height': '75%'},
    vAxis: {
        minValue: 0,
        viewWindow: {min:0},
    },
    animation:{
        duration: 1000,
        easing: 'out',
        startup: true
    },
    colors: ['#006cb1', '#65b24b', '#d5b60e', '#e94045']
};
var options2 = {
        curveType: 'function',
        legend: 'none', // { position: 'bottom' },
        series: {2: {
            type: "steppedArea", 
            color: '#AA0000', 
            visibleInLegend: false, 
            areaOpacity: 0}
        },
        chartArea: {'width': '85%', 'height': '75%'},
        vAxis: {
            minValue: 0,
            viewWindow: {min:0},
        },
        hAxis: {
            showTextEvery : 5
        },
        animation:{
            duration: 1000,
            easing: 'out',
            startup: true
        },
};

function drawLine1() {
    var data = google.visualization.arrayToDataTable(DATA1);
    CHART1 = new google.visualization.ColumnChart(document.getElementById('chart1'));
    CHART1.draw(data, options1);
}
function drawLine2() {
    options2.vAxis.viewWindow = {min:0};
    if(!flag2) {
        options2.vAxis.viewWindow.max = 10;
        options2.vAxis.viewWindow.min = 0;
    }
    
    var data = google.visualization.arrayToDataTable(DATA2);
    CHART2 = new google.visualization.LineChart(document.getElementById('chart2'));
    CHART2.draw(data, options2);
}
function drawLine3() {
    options2.vAxis.viewWindow = {min:0};
    if(!flag3) {
        options2.vAxis.viewWindow.max = 10;
        options2.vAxis.viewWindow.min = 0;
    }
    var data = google.visualization.arrayToDataTable(DATA3);
    CHART3 = new google.visualization.LineChart(document.getElementById('chart3'));
    CHART3.draw(data, options2);
}
function drawLine4() {
    options2.vAxis.viewWindow = {min:0};
    if(!flag4) {
        options2.vAxis.viewWindow.max = 0.0001;
        options2.vAxis.viewWindow.min = 0;
    }
    var data = google.visualization.arrayToDataTable(DATA4);
    CHART4 = new google.visualization.LineChart(document.getElementById('chart4'));
    CHART4.draw(data, options2);
}
function drawLine5() {
    options2.vAxis.viewWindow = {min:0};
    if(!flag5) {
        options2.vAxis.viewWindow.max = 0.0001;
        options2.vAxis.viewWindow.min = 0;
    }
    var data = google.visualization.arrayToDataTable(DATA5);
    CHART5 = new google.visualization.LineChart(document.getElementById('chart5'));
    CHART5.draw(data, options2);
}
function drawLine6() {
    options2.vAxis.viewWindow = {min:0};
    if(!flag6) {
        options2.vAxis.viewWindow.max = 0.0001;
        options2.vAxis.viewWindow.min = 0;
    }
    var data = google.visualization.arrayToDataTable(DATA6);
    CHART6 = new google.visualization.LineChart(document.getElementById('chart6'));
    CHART6.draw(data, options2);
}
function drawLine7() {
    options2.vAxis.viewWindow = {min:0};
    if(!flag7) {
        options2.vAxis.viewWindow.max = 0.0001;
        options2.vAxis.viewWindow.min = 0;
    }
    var data = google.visualization.arrayToDataTable(DATA7);
    CHART7 = new google.visualization.LineChart(document.getElementById('chart7'));
    CHART7.draw(data, options2);
}

