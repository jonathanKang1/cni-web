let SEARCH_FROM_DATE, SEARCH_TO_DATE;
$(function() {
    init();
    
    // 검색버튼 이벤트
    $('.searchBtn').click(function() {
        getTableData();
    });
});


function init() {
    // 달력 표시하지 않을 주
    var disabledDays = [0,2,3,4,5,6];
    let onRenderCell = function (date, cellType) {
        if (cellType == 'day') {
            var day = date.getDay(),
                isDisabled = disabledDays.indexOf(day) != -1;
            return {
                disabled: isDisabled
            }
        }
    }
    
    // 달력 세팅
    SEARCH_FROM_DATE = $('input[name=searchFromDate]').datepicker({autoClose: true, onRenderCell:onRenderCell}).data('datepicker');
    SEARCH_FROM_DATE.selectDate(getMonday(new Date()));
    
    getRegionList();
    getTableData()
}


//월요일 날짜 가져오기
function getMonday(d) {
    d = new Date(d);
    var day = d.getDay(),
        diff = d.getDate() - day + (day == 0 ? -6:1); // adjust when day is sunday
    return new Date(d.setDate(diff));
}


//시,군 정보 가져오기
function getRegionList() {
    $.ajax({
        url : '/cni/comm/getCommUseRegionList.ax',
        type : 'GET',
        dataType : 'json',
        async : false
    }).done(function(res) {
        console.log(res);
        let makeHtml = '<option value="">전체</option>';
        $.each(res.data, function(i, data) {
            makeHtml += '<option value="'+data.REGION_CD+'">'+data.REGION_NM+'</option>'; 
        });
        $('select[name=searchRegionCode]').html(makeHtml);
    });
}


function getTableData() {
    $.get(
            '/cni/air/getRealWeekData.ax',
            {
                'searchRegionCode' : $('select[name=searchRegionCode]').val(),
                'searchFromDate' : $('input[name=searchFromDate]').val(),
            }
    ).done(function(res) {
        console.log(res);
        let makeHtml = '';
        
        $.each(res.data, function(i, data) {
            makeHtml += '<tr>';
            makeHtml += '   <th>'+data.TMS_NM+'</th>';
            
            if(data.CAI_LV_VL == '-')
                makeHtml += '   <td>'+(data.CAI_MSR_VL || '-')+'</td>';
            else 
                makeHtml += '   <td><img src="/cni/image/grade_'+data.CAI_LV_VL+'_s.png"> '+(data.CAI_MSR_VL || '-')+'</td>';
            
            if(data.CAI_PRE_LV_VL == '-')
                makeHtml += '   <td>'+(data.CAI_PRE_MSR_VL || '-')+'</td>';
            else
                makeHtml += '   <td><img src="/cni/image/grade_'+data.CAI_PRE_LV_VL+'_s.png"> '+(data.CAI_PRE_MSR_VL || '-')+'</td>';
                    
            if(data.PMB_LV_VL == '-')
                makeHtml += '   <td>'+(data.PMB_MSR_VL || '-')+'</td>';
            else
                makeHtml += '   <td><img src="/cni/image/grade_'+data.PMB_LV_VL+'_s.png"> '+(data.PMB_MSR_VL || '-')+'</td>';
                    
            if(data.PMB_PRE_LV_VL == '-')
                makeHtml += '   <td>'+(data.PMB_PRE_MSR_VL || '-')+'</td>';
            else
                makeHtml += '   <td><img src="/cni/image/grade_'+data.PMB_PRE_LV_VL+'_s.png"> '+(data.PMB_PRE_MSR_VL || '-')+'</td>';
            
            if(data.PM2_LV_VL == '-')
                makeHtml += '   <td>'+(data.PM2_MSR_VL || '-')+'</td>';
            else
                makeHtml += '   <td><img src="/cni/image/grade_'+data.PM2_LV_VL+'_s.png"> '+(data.PM2_MSR_VL || '-')+'</td>';
            
            if(data.PM2_PRE_LV_VL == '-')
                makeHtml += '   <td>'+(data.PM2_PRE_MSR_VL || '-')+'</td>';
            else
                makeHtml += '   <td><img src="/cni/image/grade_'+data.PM2_PRE_LV_VL+'_s.png"> '+(data.PM2_PRE_MSR_VL || '-')+'</td>';
            
            if(data.O3B_LV_VL == '-')
                makeHtml += '   <td>'+(data.O3B_MSR_VL || '-')+'</td>';
            else
                makeHtml += '   <td><img src="/cni/image/grade_'+data.O3B_LV_VL+'_s.png"> '+(data.O3B_MSR_VL || '-')+'</td>';
            
            if(data.O3B_PRE_LV_VL == '-')
                makeHtml += '   <td>'+(data.O3B_PRE_MSR_VL || '-')+'</td>';
            else
                makeHtml += '   <td><img src="/cni/image/grade_'+data.O3B_PRE_LV_VL+'_s.png"> '+(data.O3B_PRE_MSR_VL || '-')+'</td>';
            
            if(data.NO2_LV_VL == '-')
                makeHtml += '   <td>'+(data.NO2_MSR_VL || '-')+'</td>';
            else
                makeHtml += '   <td><img src="/cni/image/grade_'+data.NO2_LV_VL+'_s.png"> '+(data.NO2_MSR_VL || '-')+'</td>';
            
            if(data.NO2_PRE_LV_VL == '-')
                makeHtml += '   <td>'+(data.NO2_PRE_MSR_VL || '-')+'</td>';
            else
                makeHtml += '   <td><img src="/cni/image/grade_'+data.NO2_PRE_LV_VL+'_s.png"> '+(data.NO2_PRE_MSR_VL || '-')+'</td>';
            
            if(data.COB_LV_VL == '-')
                makeHtml += '   <td>'+(data.COB_MSR_VL || '-')+'</td>';
            else
                makeHtml += '   <td><img src="/cni/image/grade_'+data.COB_LV_VL+'_s.png"> '+(data.COB_MSR_VL || '-')+'</td>';
            
            if(data.COB_PRE_LV_VL == '-')
                makeHtml += '   <td>'+(data.COB_PRE_MSR_VL || '-')+'</td>';
            else
                makeHtml += '   <td><img src="/cni/image/grade_'+data.COB_PRE_LV_VL+'_s.png"> '+(data.COB_PRE_MSR_VL || '-')+'</td>';
            
            if(data.SO2_LV_VL == '-')
                makeHtml += '   <td>'+(data.SO2_MSR_VL || '-')+'</td>';
            else
                makeHtml += '   <td><img src="/cni/image/grade_'+data.SO2_LV_VL+'_s.png"> '+(data.SO2_MSR_VL || '-')+'</td>';
            
            if(data.SO2_PRE_LV_VL == '-')
                makeHtml += '   <td>'+(data.SO2_PRE_MSR_VL || '-')+'</td>';
            else
                makeHtml += '   <td><img src="/cni/image/grade_'+data.SO2_PRE_LV_VL+'_s.png"> '+(data.SO2_PRE_MSR_VL || '-')+'</td>';
            
            makeHtml += '</tr>';
        });
        
        $('#weekDataTable tbody').html(makeHtml);
    });
}

