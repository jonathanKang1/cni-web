let SEARCH_FROM_DATE1, SEARCH_TO_DATE1, SEARCH_FROM_DATE2, SEARCH_TO_DATE2, SEARCH_MONTH_DATE;
$(function() {
    init();
    
    // 검색버튼 이벤트
    $(document).on('click', '.air_download', function() {
        let frm = $('#fileForm');
        frm.find('input[name=fileName]').val($(this).data('name'));
        frm.find('input[name=fileOriName]').val($(this).data('ori'));
        frm.attr('action', '/cni/comm/downloadFile.do');
        frm.attr('method', 'post');
        frm.submit();
    });
});

function init() {
    getReportData({'searchType' : 'Y'});
    getReportData({'searchType' : 'Q'});
    getReportData({'searchType' : 'M'});
}

// 데이터 가져오기
function getReportData(p_param) {
    $.get(
            '/cni/statis/getStatisReportData.ax',
            p_param
    ).done(function(res) {
        //console.log(res);
        if(p_param.searchType == 'Y') {
            setYearTable(res.data);
        } else if(p_param.searchType == 'Q') {
        	setQuarterTable(res.data);
        } else {
            setMonthTable(res.data);
        }
        
    });
}


// 연보 테이블 세팅
function setYearTable(p_data) {
    let makeHtml = '';
    let len = p_data.length;
    let max = 4;
    
    if(len == 0) {
        makeHtml = '<tr><td colspan="5">정보가 존재하지 않습니다.</td></tr>'
    } else {
        $.each(p_data, function(i, data) {
            if(i%max == 0) {
                makeHtml += '<tr>';
            }
            makeHtml += '<td>'+data.YYYY+'년<br/><a href="#" class="air_download" alt="'+data.YYYY+' 연보" title="'+data.YYYY+' 연보 다운로드" data-ori="'+data.ORG_FILE_NM+'" data-name="'+data.SAVE_FILE_NM+'"></a></td>';
            
            // 마지막에 나머지 빈칸 공란으로 채우기
            if(i == (len - 1)) {
                for(var j=0; j<max-(len%max); j++) {
                    makeHtml += '<td></td>';
                }
            }
            
            if(i%max == (max-1)) {
                makeHtml += '</tr>';
            }
        });
    }
    
    $('#yearTable tbody').html(makeHtml);
}

//분기 테이블 세팅
function setQuarterTable(p_data) {
    let makeHtml = '';
    let len = p_data.length;
    let max = 4;
    let td_cnt = 0;
    
    if(len == 0) {
        makeHtml = '<tr><td colspan="12">정보가 존재하지 않습니다.</td></tr>'
    } else {
        let prvYear;
        $.each(p_data, function(i, data) {
        	
        	//연도가 변경되는 경우 td 채우기
        	if(prvYear != null && data.YYYY != prvYear) {
        		for(var j=0; j<(max-td_cnt); j++) {
                    makeHtml += '<td></td>';
                }
        		makeHtml += '</tr>';
        		td_cnt = 0;
            }
        	
        	if(prvYear == null || data.YYYY != prvYear) {
                makeHtml += '<tr><th colspan="4">'+data.YYYY+'</th></tr><tr>';
                prvYear = data.YYYY;
            }
            
            /*if(i%max == 0) {
                makeHtml += '<tr>';
            }*/
            
            makeHtml += '<td>'+data.MM+'분기<br/><a href="#" class="air_download" alt="'+data.MM+' 연보" title="'+data.MM+' 분기보고서 다운로드" data-ori="'+data.ORG_FILE_NM+'" data-name="'+data.SAVE_FILE_NM+'"></a></td>';
            td_cnt ++;
            
            // 마지막에 나머지 td 채우기
            if(i == (len - 1)) {
            	for(var j=0; j<(max-td_cnt); j++) {
                    makeHtml += '<td></td>';
                }
        		makeHtml += '</tr>';
            }
            
            // 마지막에 나머지 빈칸 공란으로 채우기
            /*if(i == (len - 1)) {
                for(var j=0; j<max-(len%max); j++) {
                    makeHtml += '<td></td>';
                }
            }
            
            if(i%max == (max-1)) {
                makeHtml += '</tr>';
            }*/
        });
    }

    $('#quarterTable tbody').html(makeHtml);
}
// 월보 테이블 세팅
function setMonthTable(p_data) {
    let makeHtml = '';
    let len = p_data.length;
    let max = 12;
    let td_cnt = 0;
    
    if(len == 0) {
        makeHtml = '<tr><td colspan="12">정보가 존재하지 않습니다.</td></tr>'
    } else {
        let prvYear;
        $.each(p_data, function(i, data) {

        	//연도가 변경되는 경우 td 채우기
        	if(prvYear != null && data.YYYY != prvYear) {
        		for(var j=0; j<(max-td_cnt); j++) {
                    makeHtml += '<td></td>';
                }
        		makeHtml += '</tr>';
        		td_cnt = 0;
            }
        	
        	if(prvYear == null || data.YYYY != prvYear) {
                makeHtml += '<tr><th colspan="12">'+data.YYYY+'</th></tr><tr>';
                prvYear = data.YYYY;
            }
            
            /*if(i%max == 0) {
                makeHtml += '<tr>';
            }*/
            
            makeHtml += '<td>'+data.MM+'월<br/><a href="#" class="air_download" alt="'+data.MM+' 연보" title="'+data.MM+' 월보 다운로드" data-ori="'+data.ORG_FILE_NM+'" data-name="'+data.SAVE_FILE_NM+'"></a></td>';
            td_cnt ++;
            
            // 마지막에 나머지 td 채우기
            if(i == (len - 1)) {
            	for(var j=0; j<(max-td_cnt); j++) {
                    makeHtml += '<td></td>';
                }
        		makeHtml += '</tr>';
            }
            
            // 마지막에 나머지 빈칸 공란으로 채우기
            /*if(i == (len - 1)) {
                for(var j=0; j<max-(len%max); j++) {
                    makeHtml += '<td></td>';
                }
            }
            
            if(i%max == (max-1)) {
                makeHtml += '</tr>';
            }*/
        });
    }
    
    $('#monthTable tbody').html(makeHtml);
}