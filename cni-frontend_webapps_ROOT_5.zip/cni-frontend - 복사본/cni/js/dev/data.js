let href = location.href;
$(function() {
    init();
    
    // 검색 버튼 이벤트
    $('#searchBtn').click(function() {
        getBoardListData();
    });
    
    // 상세보기 버튼 이벤트
    $(document).on('click', '.goFormBtn', function() {
        $('input[name=seq]').val($(this).data('seq'));
        
        let frm = $('#searchForm');
        frm.attr('action', '/cni/custom/dataForm.do');
        frm.submit();
    });
    
    // 검색 버튼 이벤트
    $('#goListBtn').click(function() {
        let frm = $('#searchForm');
        frm.attr('action', '/cni/custom/data.do');
        frm.submit();
    });
    
    
    // 검색 버튼 이벤트
    $(document).on('click', '.goViewBtn', function() {
        $('input[name=seq]').val($(this).data('seq'));
        
        let frm = $('#searchForm');
        frm.attr('action', '/cni/custom/dataForm.do');
        frm.submit();
    });
    
    // 파일 다운로드 버튼 이벤트
    $(document).on('click', '.downloadFile', function() {
        let frm = $('#fileForm');
        
        frm.find('input[name=fileName]').val($(this).data('name'));
        frm.find('input[name=fileOriName]').val($(this).data('ori'));
        
        frm.attr('action', '/cni/comm/downloadFile.do');
        frm.attr('method', 'post');
        frm.submit();
    });
});

// 초기화
function init() {
    if(href.indexOf('dataForm') > -1) {
        getBoardFormData()
    } else {
        getBoardListData()
    }
}


// 리스트 데이터
function getBoardListData(p_pageNum) {
    let pageNum = $('input[name=pageNum]').val() || 1;
    pageNum = p_pageNum || pageNum;
    
    $.get(
            '/cni/custom/getCustomBoardListData.ax',
            $('#searchForm').serialize()
    ).done(function(res) {
        console.log(res);
        let makeHtml = '';
        let totalCount = res.totalCount.CNT;
        let no = totalCount - (pageNum - 1) * PAGE_SIZE;
        
        if(res.data.length == 0) {
            makeHtml = '<tr><td colspan="5">목록이 존재하지 않습니다.</td></td>';
        }
        
        $.each(res.data, function(i, data) {
            makeHtml += '<tr>';
            makeHtml += '   <td>'+no+'</td>';
            if(data.IS_NEW == 'Y') {
                /*makeHtml += '   <td><a href="javascript:;" class="goFormBtn" data-seq="'+data.SEQ+'">'+data.TITLE+'</a><img src="/cni/image/sub/new.png"></td>';*/
                makeHtml += '   <td><a href="javascript:;" class="goFormBtn" data-seq="'+data.SEQ+'">'+data.TITLE+'</a></td>';
            } else {
                makeHtml += '   <td><a href="javascript:;" class="goFormBtn" data-seq="'+data.SEQ+'">'+data.TITLE+'</a></td>';
                
            }
            if(data.ORG_FILE_NM) {
                makeHtml += '   <td><img src="/cni/image/sub/file.png" alt="파일"></td>';
            } else {
                makeHtml += '   <td></td>';
            }
            makeHtml += '   <td>'+data.USER_NM+'</td>';
            //makeHtml += '   <td>'+data.DT+'</td>';
            //makeHtml += '   <td></td>';
            makeHtml += '</tr>';
            
            no--;
        });
        
        let opt = {
                frm : "searchForm",
                attrId : 'divPageNavigator',
                pageNum : $('input[name=pageNum]').val(),
                pageSize : PAGE_SIZE,
                totalCount : totalCount,
        };
        setPagingNavigator(opt);
        
        $('#bbsTable tbody').html(makeHtml);
    });
}


// 상세보기 데이터
function getBoardFormData(pageNum) {
    $.get(
            '/cni/custom/getCustomBoardFormData.ax',
            $('#searchForm').serialize()
    ).done(function(res) {
        console.log(res);
        let data = res.data;
        let subData = res.subData;
        
        $('#title').html(data.TITLE);
        $('#author').html(data.USER_NM);
        //$('#regDate').html(data.DT);
        //$('#cnt').html(0);
        $('#cont').html((data.CONTENT || '').replace(/\r\n/g, '<br>'));
        
        if(data.SAVE_FILE_NM) {
            $('#attachFile').show();
            $('#attachFile a').html(data.ORG_FILE_NM);
            $('#attachFile a').data('name', data.SAVE_FILE_NM);
            $('#attachFile a').data('ori', data.ORG_FILE_NM);
        }
        
        if(subData.PRE_SEQ) {
            $('#prevBtn').html('<a href="javascript:;" class="goViewBtn" data-seq="'+subData.PRE_SEQ+'">' + subData.PRE_TITLE + '</a>');
        } else {
            $('#prevBtn').html(subData.PRE_TITLE);
        }
        
        if(subData.NEXT_SEQ) {
            $('#nextBtn').html('<a href="javascript:;" class="goViewBtn" data-seq="'+subData.NEXT_SEQ+'">' + subData.NEXT_TITLE + '</a>');
        } else {
            $('#nextBtn').html(subData.NEXT_TITLE);
        }
    });
}


/**
 * 리스트 페이징 생성
 * @param option {frm, attrId, pageNum, totalCount, pageSize, visible}
 */
function setPagingNavigator(p_opt) {
    let opt = p_opt || {};
    var frm = opt.frm || 'searchForm',
        attrId = opt.attrId || 'divPageNavigator', 
        pageNum = opt.pageNum || 1, 
        pageSize = opt.pageSize || 10, 
        totalCount = opt.totalCount || 0, 
        visible = opt.visible || false;
    
    // 페이징 생성
    var oPageNavigator = new PageNavigator(
            document.getElementById(attrId), 
            function(pageNum) {
                $('input[name=pageNum]').val(pageNum);
                getBoardListData(pageNum);
            },
            { 
                firstVisible:visible
                , lastVisible:visible
                , prevClassName : 'prev'
                , nextClassName : 'next' 
                , currentClassName: "on"
                , currentNodeType:"A"
                , prevTags:"&lt;&lt;"
                , nextTags:"&gt;&gt;"
            }
    );
    
    oPageNavigator.show(pageNum, Math.ceil(totalCount/pageSize), 5);
}