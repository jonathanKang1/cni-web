let SEARCH_FROM_DATE, SEARCH_TO_DATE;
let DATA1 = [['날짜', '시간평균']];
let CHART;

$(function() {
    init();
});

function init() {
    setVisibleDiv();
    // 구글 차트 생성
    google.charts.load('current', {packages: ['corechart', 'line']});
    getData();
};

// 자료 구분에 따른 영역 visible
function setVisibleDiv() {
    $('.content_section').not('#section_' + searchDataType).remove();
    $('#section_' + searchDataType).show();
}

// 자료 구분에 따른 데이터 가져오기
function getData() {
    if(searchDataType == 'day') {
        getTabelData1();
    } else {
        getTabelData();
    }
}

// 당일 데이터 가져오기
function getTabelData1() {
    $.ajax({
        url : '/cni/real/getRealCitisDayPopData.ax',
        data : {
            searchDataType : searchDataType,
            searchRegionCode : searchRegionCode,
            searchItemCode : searchItemCode,
            searchMonthDate : searchMonthDate,
            searchValidChiper : searchValidChiper,
        },
        type : 'GET',
        dataType : 'json',
        async : false
    }).done(function(res) {
        console.log(res);
        let flag = false;
        let makeHtml = '';
        for(var i=0; i<res.data.length; i++) {
            let data = res.data[i];
            makeHtml += '<tr>';
            makeHtml += '   <th>'+data.TMS_NM+'</th>';
            makeHtml += '   <th>'+(data.AVG_MSR_VL || '-')+'</th>';
            makeHtml += '   <th>'+(data.MAX_MSR_VL || '-')+'</th>';
            makeHtml += '   <th>'+(data.MIN_MSR_VL || '-')+'</th>';
            
            if(i < 2) {
                for(var j=0; j<24; j++) {
                    let name = j<10 ? '0'+j : j;
                    makeHtml += '   <th>'+(data['D' + name] || '-')+'</th>';
                }
                
                if(i == 1) {
                    for(var j=0; j<24; j++) {
                        let arr = [];
                        let name = j<10 ? '0'+j : j;
                        arr.push((j+1) + '시');
                        arr.push(data['D' + name] || 0);
                        DATA1.push(arr);
                        
                        if(data['D' + name]){
                            flag = true;
                        }
                    }
                }
                
            } else {
                for(var j=0; j<24; j++) {
                    let name = j<10 ? '0'+j : j;
                    makeHtml += '   <td>'+(data['D' + name] || '-')+'</td>';
                }
                
            }
            makeHtml += '</tr>';
        }
        
        if(!flag) {
            options.vAxis.viewWindow.max = 10;
            options.vAxis.viewWindow.min = 0;
        } else {
            options.vAxis.viewWindow = {min:0};
        }
        
        $('#citiesDataTable tbody').html(makeHtml);
        google.charts.setOnLoadCallback(drawChart); // 차트;
    });
}

// 차트그리기
var options = {
        legend: { position: 'bottom' },
        chartArea: {'width': '90%', 'height': '50%'},
        vAxis: {
            title: searchUnit,
            minValue: 0,
            viewWindow: {min:0}
        },
        hAxis: {textStyle: {fontSize:10},
        },
        animation:{
            duration: 1000,
            easing: 'out',
            startup: true
        },
};
function drawChart() {
    var data = google.visualization.arrayToDataTable(DATA1);
    CHART = new google.visualization.LineChart(document.getElementById('chart1'));
    CHART.draw(data, options);
}


// 7일간 데이터 가져오기
function getTabelData() {
    let searchMultiDays = getDateArr();
    
    $.ajax({
        url : '/cni/real/getRealCitisPopData.ax',
        data : {
            'searchDataType' : searchDataType,
            'searchRegionCode' : searchRegionCode,
            'searchItemCode' : searchItemCode,
            'searchValidChiper' : searchValidChiper,
            'searchMonthDate' : searchMonthDate,
            'searchMultiDays' : searchMultiDays.toString(),
        },
        type : 'GET',
        dataType : 'json',
        async : false
    }).done(function(res) {
        console.log(res);
        let makeHtml = '';
        
        makeHtml += '   <th>지점</th>';
        $.each(searchMultiDays, function(j, dt) {
            makeHtml += '   <th>'+(dt.substring(0,4)+'-'+dt.substring(4,6)+'-'+dt.substring(6,8))+'</th>';
        });
        $('#cities'+searchDataType+'DataTable thead tr').html(makeHtml);
        
        makeHtml = '';
        for(var i=0; i<res.data.length; i++) {
            let data = res.data[i];
            makeHtml += '<tr>';
            makeHtml += '   <th>'+data.TMS_NM+'</th>';
            
            $.each(searchMultiDays, function(j, dt) {
                makeHtml += '   <td>'+(data['D' + dt] || '-')+'</td>';
            });
            
            makeHtml += '</tr>';
        }
        
        $('#cities'+searchDataType+'DataTable tbody').html(makeHtml);
    });
}


// 날짜 세팅
function getDateArr() {
    let returnArr = [];
    
    if(searchDataType == '7days') {
        for(let i=6; i>=0; i--) {
            returnArr.push(moment().subtract(i, 'day').format('YYYYMMDD'));
        }
        
    } else {
        let lastDay = moment('202011', 'YYYYMM').endOf('month').format('D')
        for(let i=lastDay; i>=0; i--) {
            returnArr.push(moment().subtract(i, 'day').format('YYYYMMDD'));
        }
    }
    return returnArr;
}