let SEARCH_FROM_DATE, SEARCH_TO_DATE;

$(function() {
    init();
	google.charts.load('current', {packages: ['corechart', 'bar', 'line']});
	google.charts.setOnLoadCallback(drawColumn);
	google.charts.setOnLoadCallback(drawLine);
});

function init() {
    // 달력 세팅
    SEARCH_FROM_DATE = $('#searchFromDate').datepicker({autoClose: true}).data('datepicker');
    SEARCH_TO_DATE = $('#searchToDate').datepicker({autoClose: true}).data('datepicker');
    SEARCH_FROM_DATE.selectDate(new Date());
    SEARCH_TO_DATE.selectDate(new Date());
    let dt = moment(new Date(), "YYYYMMDDHH").subtract(2, 'hours').toDate(); // 1시간 전
    let hour = dt.getHours();
    $('#searchToTime').val(hour);
};

function drawColumn() {
	var redCross = '#ff0000';
	var blueCross = '#0000ff';
    var data = new google.visualization.arrayToDataTable([
    	['측정소', '수치',  {'role': 'style'}, ''],
    	['서울', 12, redCross, 10],
    	['인천', 11, null, 10],
    	['경기', 10, null, 10],
    	['경기2', 10, null, 10],
    	['경기3', 10, null, 10],
    	['경기4', 10, null, 10],
    ]);

    var options = {
      colors : ['#33bb33'],
      legend : 'none', // { position: 'bottom' }
      series: {1: {
          type: "steppedArea", 
          color: '#AA0000', 
          visibleInLegend: false, 
          areaOpacity: 0}
      },
      vAxis: {
        title: 'cm',
       	minValue: 0
      },
      animation:{
          duration: 1000,
          easing: 'out',
          startup: true
      },
    };

    var chart = new google.visualization.ColumnChart(document.getElementById('chart1'));
    chart.draw(data, options);
    
}


function drawLine() {
	var data = google.visualization.arrayToDataTable([
        ['Year', 'Sales', ''],
        ['2004',  1000, 1000],
        ['2005',  1170, 1000],
        ['2006',  660,  1000],
        ['2007',  1030, 1000]
    ]);

    var options = {
        curveType: 'function',
        legend: 'none', // { position: 'bottom' },
        series: {2: {
            type: "steppedArea", 
            color: '#AA0000', 
            visibleInLegend: false, 
            areaOpacity: 0}
        },
        chartArea: {'width': '75%', 'height': '75%'},
        animation:{
            duration: 1000,
            easing: 'out',
            startup: true
        },
    };

      var chart = new google.visualization.LineChart(document.getElementById('chart2'));
      chart.draw(data, options);
}

    
    