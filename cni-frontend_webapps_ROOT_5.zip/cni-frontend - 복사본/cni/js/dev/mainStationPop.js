let CHART_DATA = [], ITEM_NM, UNIT, CHART;

$(function() {
    init();
});


// 기본 세팅
function init() {
    getMainPopTableData();
}


// 측정소/측정항목 상세 데이터
function getMainPopTableData() {
    $.get(
            '/cni/mainPop/getMainPopTableData.ax'
            ,{
                'searchTmsCode' : searchTmsCode,
                'searchItemCode' : searchItemCode
            }
    ).done(function(res) {
        console.log(res);
        let unit = res.itemData[0].UNIT;
        
        ITEM_NM = res.itemData[0].ITEM_NM;
        UNIT = unit;
        
        getMainPopChartData(unit);
        
        if(res.data.length > 0) {
            let data = res.data[0];
            let gradeBgTxt = getGradeColorTxt(data.LEVEL_CD);
            $('#value').addClass(gradeBgTxt);
            $('#value p').text(unit);
            $('#value span').text(data.MSR_VL || '-');
            $('#stationNm').text(data.TMS_NM);
            $('#address').text(data.ADDR);
            $('#valueAll').text((data.MSR_VL || '-') + unit + '(1시간), ' + (data.AVG_24 || '-') + unit + '(24시간)');
        }
    });
}

// 측정소/측정항목 차트 데이터
function getMainPopChartData(p_unit) {
    $.get(
            '/cni/mainPop/getMainPopChartData.ax'
            ,{
                'searchTmsCode' : searchTmsCode,
                'searchItemCode' : searchItemCode
            }
    ).done(function(res) {
        console.log(res);
        let flag = false;
        CHART_DATA.push(['날짜', ITEM_NM,  {'role': 'style'}]);
        if(res.data.length > 0) {
            $.each(res.data, function(i, data) {
                let arr = [];
                arr.push(data.DSP_DT);
                arr.push(convertNumber(data.MSR_VL));
                arr.push(getGradeColorCode(data.LEVEL_CD));
                CHART_DATA.push(arr);
                
                if(data.MSR_VL){
                    flag = true;
                }
            });
        }
        
        if(!flag) {
            options.vAxis.viewWindow.max = 10;
            options.vAxis.viewWindow.min = 0;
        } else {
            options.vAxis.viewWindow = {min:0};
        }
        
        google.charts.load('current', {packages: ['corechart', 'bar']});
        google.charts.setOnLoadCallback(drawColumn);
    });
}

// 컬럼 차트 세팅
var options = {
    colors : ['#ffffff'],
    legend : {
        position: 'bottom',
    },
    vAxis: {
      title: UNIT,
      format: 'decimal',
      minValue: 0,
      viewWindow: {min:0},
    },
    chartArea: {
        top: 15,
        height: '55%',
        width:'80%'
  },
    hAxis: {
        showTextEvery : 3
    },
    animation:{
        duration: 1000,
        easing: 'out',
        startup: true
    },
  };
function drawColumn() {
    var data = new google.visualization.arrayToDataTable(CHART_DATA);
    CHART = new google.visualization.ColumnChart(document.getElementById('chart_div'));
    CHART.draw(data, options);
}


