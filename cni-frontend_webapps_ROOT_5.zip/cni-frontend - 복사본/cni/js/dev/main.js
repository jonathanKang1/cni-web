let TMS_COOKIE = $.cookie('TMS_COOKIE_CODE');
let DEFAULT_TMS = isEmpty(TMS_COOKIE) ? '20038000' : ''+TMS_COOKIE; // 측정소(인주면 또는 쿠키값) 기본값
let SUBMAP_ID = '' // 서브 지도 ID 값 

$(function() {
    init();
    
    // 측정항목 선택 버튼 이벤트
    $('.tabItembtn').click(function() {
        $('.tabItembtn').removeClass('current-demo');
        $(this).addClass('current-demo');
        $('#itemTxt').text($(this).text());
        getMapMakerList();
        if(SUBMAP_ID != ''){
           getMapDetailMakerList(SUBMAP_ID);
        }
        getLevelList();
    });
    
    // 지도 마커 선택 버튼 이벤트
    $(document).on('click', '.marker', function() {
        let regionCd = $(this).data('regioncd');
        let tmsCd = $(this).data('tmscd');
        let tmsNm = $(this).data('tmsnm');
        
        getTmsDetailInfo(regionCd, tmsCd, tmsNm);
        
        if($('.tabItembtn.current-demo').data('item') != 'CAI') {
            openStationPop(tmsCd);
        }
    });
    
    // 지도 마커 마우스오버 이벤트
    $(document).on('mouseover', '.marker', function(e) {
        let val = $(this).data('val');
        let tmsNm = $(this).data('tmsnm');
        let markerType = $(this).data('marker');
        let unit = $('.tabItembtn.current-demo').data('unit') || '';
        let xPos = $(this).css('left');
        let yPos = $(this).css('top');
        
        let mapPopupElem = $('#mapPopup'+markerType);
        mapPopupElem.find('#mapPopName').text(tmsNm);
        mapPopupElem.find('#mapPopVal').text(val);
        mapPopupElem.find('#mapPopUnit').text(unit);
        mapPopupElem.css({'left' : parseInt(xPos) + 30, 'top' : yPos});
        mapPopupElem.show();
    });
    
    // 지도 마커 마우스아웃 이벤트
    $(document).on('mouseout', '.marker', function(e) {
        $('.marker-map-popup').hide();
    });
    
    // 측정망구분 선택 버튼 이벤트
    $('.tabNetBtn').click(function() {
        let elem = $(this);
        let value = elem.data('val');
        let flag = elem.hasClass('category-select_on');
        
        // 'A'는 민간대기를 제외한 측정망
        if(value == 'A') {
            if(flag) {
                $('.markerA').hide();
                $('.markerB').hide();
                $('.markerD').hide();
                elem.removeClass('category-select_on');
            } else {
                $('.markerA').show();
                $('.markerB').show();
                $('.markerD').show();
                elem.addClass('category-select_on');
            }
        } else {
            if(flag) {
                $('.markerC').hide();
                elem.removeClass('category-select_on');
            } else {
                $('.markerC').show();
                elem.addClass('category-select_on');
            }
        }
    });
    
    // 농도범위 선택 버튼 이벤트
    $(document).on('click', '.tabLevelBtn', function() {
        let value = $(this).data('val');
        let flag = $(this).data('flag');
        
        if(flag) {
            $('.markerLevel' + value).hide();
            $(this).data('flag', false);
        } else {
            $('.markerLevel' + value).show();
            $(this).data('flag', true);
        }
    });
    
    // 시군변경 이벤트
    $('#regionSel').change(function() {
        getTmsList($('option:selected', this).val());
    });
    
    // 측정소변경 이벤트
    $('#tmsSel').change(function() {
        let val = $('option:selected', this).val();
        let txt = $('option:selected', this).text();
        if(!isEmpty(val)) {
            $.cookie('TMS_COOKIE_CODE' , val, { expires : 365});
            getTmsDetailInfo($('#regionSel').val(), val, txt);
            DEFAULT_TMS = val;
        }
        getMainForecastInfo(val);
    });
    
    // 상세지도에서 뒤로(메인지도) 가기 이벤트
    $('#showMainMap').click(function() {
        visibleMap(true);
        SUBMAP_ID = '';
    });
});

// GPL License 고지 kang
function licensePopup() {
	let url = '/licensePopup.html';
    let name = 'GPL 3.0 License';
    let left = Math.ceil(( window.screen.width - 750 )/2);
    let top = Math.ceil(( window.screen.height - 700 )/2); 
    let opt = 'width=750,height=680,top='+top+',left='+left+',directories=no,location=no,menubar=no,scrollbars=no,status=no,titlebar=no,toolbar=no';
    window.open(url, name, opt);
}

// 맵 선택시 세부 지도로 이동
function setSubMap(evt,id){
    document.getElementById("sub_map_object").src = "/cni/image/detail/"+evt+".png";
    visibleMap(false);
    getMapDetailMakerList(id);
}

/**
 * 메인 지도 시각여부
 * @param flag
 * @returns
 */
function visibleMap(flag) {
    if(flag) {
        $('#sub_map_object').attr('src',''); // 서브 맵 초기화
        $('#sub_map .marker').remove(); // 서브 맵 마커 삭제
        $('.sub_map_table').hide(); // 서브 맵 하위행정구역 hide
        $('#sub_map').hide();
        $('#map').show();
    } else {
        $('#map').hide();
        $('#sub_map').show();
    }
}


// 기본 세팅
function init() {
    getMainForecastInfo();
    getMapMakerList();
    getTmsDetailInfo();
    getRegionList();
    getMainBbsList();
    getLevelList();
    getPopup();		//kang
    getVisitCnt();	//kang
}


// 측정소 선택에 따른 날씨 가져오기 2021.03.10
function getMainForecastInfo(p_tmsCd) {
    let tmsCd = p_tmsCd;
    
    if(isEmpty(p_tmsCd)) {
        tmsCd = TMS_COOKIE ? TMS_COOKIE : DEFAULT_TMS;
    }
    
    $.get(
            '/cni/main/getMainForecastInfo.ax'
            ,{'tms_cd' : tmsCd}
    ).done(function(res) {
        let data = res.data;
        // console.log(data);
        if(data != null) {
            $('#wDate').text(data.DSP_DT);
            $('#wTemp').text(data.TIH_VL);
            $('#wHum').text(data.REH_VL);
            $('#wVec').text(data.VEC_VL);
            $('#wWsd').text(data.WSD_VL);
        }
    });
}


// 지도 마커 리스트
function getMapMakerList() {
    $.get(
            '/cni/main/getMapMakerList.ax'
            ,{'searchItemCode' : $('.tabItembtn.current-demo').data('item')}
    ).done(function(res) {
        //console.log(res);
        
        $('#map > span').remove();
        
        let netAFlag = $('.tabNetBtn').eq(0).hasClass('category-select_on');
        let netBFlag = $('.tabNetBtn').eq(1).hasClass('category-select_on');
        let makeHtml = '';
        $.each(res.data, function(i, data) {
            let regionCd = data.REGION_CD;
            let tmsCd = data.TMS_CD;
            let tmsNm = data.TMS_NM;
            let level = data.LEVEL_CD;
            let netCd = data.NET_CD;
            let val = data.MSR_VL;
            let unit = data.UNIT;
            let xPos = data.XPOS;
            let yPos = data.YPOS;
            let makeAttData='';
            let style = 'top:'+yPos+'px;left: '+xPos+'px;';
            
            makeAttData += 'data-tmscd='+tmsCd + ' ';
            makeAttData += 'data-tmsnm='+tmsNm + ' ';
            makeAttData += 'data-val='+val + ' ';
            makeAttData += 'data-unit='+unit + ' ';
            makeAttData += 'data-tmscd='+tmsCd + ' ';
            makeAttData += 'data-regioncd='+regionCd + ' ';
            makeAttData += 'data-marker=1';
            
            // 측정망 구분에 따른 시각여부
            if((!netBFlag && netCd == 'C') || (!netAFlag && (netCd == 'A' || netCd == 'B' || netCd == 'D') )) {
                style += 'display:none;';
            }
            
            if(level == null || level == '-') {
                makeHtml += '<span class="map_marker marker markerLevelX marker'+netCd+'" style="'+style+'" '+makeAttData+'><img src="/cni/image/map_markerX.png"></span>';
                // makeHtml += '<span class="marker markerLevelX marker'+netCd+'" style="top:'+yPos+'px;left: '+xPos+'px;" '+makeAttData+'><img src="/images/cni/point_X.png" /></span>';
            } else {
                makeHtml += '<span class="map_marker marker markerLevel'+level+' marker'+netCd+'" style="'+style+'" '+makeAttData+'><img src="/cni/image/map_marker'+level+'.png"></span>';
                // makeHtml += '<span class="marker markerLevel'+level+' marker'+netCd+'" style="top:'+yPos+'px;left: '+xPos+'px;" '+makeAttData+'><img src="/images/cni/point_'+level+'.png" /></span>';
            }
        });
        
        $('#map').prepend(makeHtml);
        setCookieTms();
    });
}

// 지도 마커 리스트
function getMapDetailMakerList(regionCode) {
    SUBMAP_ID = regionCode
    $.get(
            '/cni/main/getMapMakerList.ax'
            ,{'searchItemCode' : $('.tabItembtn.current-demo').data('item'),'searchRegionCode' : regionCode}
    ).done(function(res) {
        //console.log(res);
        
        $('#sub_map > span').remove();
        
        let netAFlag = $('.tabNetBtn').eq(0).hasClass('category-select_on');
        let netBFlag = $('.tabNetBtn').eq(1).hasClass('category-select_on');
        let makeHtml = '';
        $.each(res.data, function(i, data) {
            let regionCd = data.REGION_CD;
            let tmsCd = data.TMS_CD;
            let tmsNm = data.TMS_NM;
            let level = data.LEVEL_CD;
            let netCd = data.NET_CD;
            let val = data.MSR_VL;
            let unit = data.UNIT;
            let xPos = data.XPOS_DETAIL;
            let yPos = data.YPOS_DETAIL;
            let makeAttData='';
            let style = 'top:'+yPos+'px;left: '+xPos+'px;';
            
            makeAttData += 'data-tmscd='+tmsCd + ' ';
            makeAttData += 'data-tmsnm='+tmsNm + ' ';
            makeAttData += 'data-val='+val + ' ';
            makeAttData += 'data-unit='+unit + ' ';
            makeAttData += 'data-tmscd='+tmsCd + ' ';
            makeAttData += 'data-regioncd='+regionCd + ' ';
            makeAttData += 'data-marker=2';
            
            // 측정망 구분에 따른 시각여부
            if((!netBFlag && netCd == 'C') || (!netAFlag && (netCd == 'A' || netCd == 'B' || netCd == 'D') )) {
                style += 'display:none;';
            }
            
            if(level == null || level == '-') {
                makeHtml += '<span class="map_marker marker markerLevelX marker'+netCd+'" style="'+style+'" '+makeAttData+'><img src="/cni/image/map_markerX.png"></span>';
            } else {
                makeHtml += '<span class="map_marker marker markerLevel'+level+' marker'+netCd+'" style="'+style+'" '+makeAttData+'><img src="/cni/image/map_marker'+level+'.png"></span>';
            }
        });
        
        // 천안시 행정구역 상세 설명 테이블 visible
        if(regionCode == '44131') {
            $('.sub_map_table').show();
        } else {
            $('.sub_map_table').hide();
        }
        
        $('#sub_map').prepend(makeHtml);
        setCookieTms();
    });
}


function setCookieTms() {
    $('.map_marker').each(function() {
        if($(this).data('tmscd') == DEFAULT_TMS) {
            $('.vi_02_box_wrap .vi_02_title').text($(this).data('tmsnm'));
            return false;
        }
    })
    
}


// 측정소 대기 상세 정보
function getTmsDetailInfo(p_regioncd, p_tmscd, p_tmsnm) {
    let paramTmscd = isEmpty(p_tmscd) ? DEFAULT_TMS : p_tmscd;
    
    //console.log(paramTmscd);
    
    $.get(
            '/cni/main/getTmsDetailInfo.ax'
            ,{
                'searchTmsCode' : paramTmscd
            }
    ).done(function(res) {
        //console.log(res);
        
        let makeHtml = '';
        
        if(res.data.length > 0) {
            $.each(res.data, function(i, data) {
                let elem = $('#detail' + data.ITEM_CD);
                let txtColor = getGradeColorTxt(data.LEVEL_CD);
                
                // 초미세와 미세먼지는 24시도 있음
                if(data.ITEM_CD.indexOf('PM') > -1) {
                    elem.find('.hour').text(data.MSR_VL + '(1h)' || '-');
                    elem.find('.hourGradeImg').attr('src', RS_IMG_PATH + 'grade_' + data.LEVEL_CD + '.png');
                    elem.find('.hourGradeImg').attr('alt', data.CODE_NM);
                    elem.find('.hour24').text(data.AVG_24 + '(24h)' || '-');
                    elem.find('.hour24GradeImg').attr('src', RS_IMG_PATH + 'grade_' + data.LEVEL_CD + '.png');
                    elem.find('.hour24GradeImg').attr('alt', data.CODE_NM);
                } else {
                    elem.find('.hour').text(data.MSR_VL || '-');
                    elem.find('.hourGradeImg').attr('src', RS_IMG_PATH + 'grade_' + data.LEVEL_CD + '.png');
                    elem.find('.hourGradeImg').attr('alt', data.CODE_NM);
                }
            });
            
        } else {
            $('.hour').text('-');
            $('.hourGradeImg').attr('src', RS_IMG_PATH + 'grade_X.png');
            $('.hourGradeImg').attr('alt', '점검중');
            $('.hour24').text('-');
            $('.hour24GradeImg').attr('src', RS_IMG_PATH + 'grade_X.png');
            $('.hour24GradeImg').attr('alt', '점검중');
        }
        
        if(!isEmpty(p_tmsnm)) {
            $('.vi_02_box_wrap .vi_02_title').text(p_tmsnm);
        }
        
        $('.vi_02_box_wrap .time').text(getCurrentTime());
    });
}


// 현재시간 가져오기
function getCurrentTime() {
    let dt = moment(new Date(), "YYYYMMDDHH").toDate(); // 2시간 전
    let y = dt.getFullYear() < 10 ? '0' + dt.getFullYear() : dt.getFullYear();
    let m = (dt.getMonth()+1) < 10 ? '0' + (dt.getMonth()+1) : (dt.getMonth()+1);
    let d = dt.getDate() < 10 ? '0' + dt.getDate() : dt.getDate();
    let h = dt.getHours() < 10 ? '0' + dt.getHours() : dt.getHours();
    return y + '년 ' + m + '월 ' + d + '일 ' + h + '시';
}


function openStationPop(p_tmsCd) {
    let url = '/cni/mainStationPop.do?searchTmsCode='+p_tmsCd+'&searchItemCode='+$('.tabItembtn.current-demo').data('item');
    let name = 'CNIMAINPOP';
    let opt = 'width=519,height=450,location=no,menubar=no,scrollbars=no,status=no,titlebar=no,toolbar=no';
    window.open(url, name, opt);
}


// 공지/경보 가져오기
function getMainBbsList() {
    $.get(
            '/cni/main/getMainBbsList.ax'
    ).done(function(res) {
        //console.log(res);
        $('#bbs').empty();
        
        let makeHtml = '';
        $.each(res.data, function(i, data) {
            let title = (data.TITLE || '').length > 16 ? data.TITLE.substring(0, 16) + '....' : data.TITLE;
            
            if(i < 2) {
                if(data.ID != null) {
                    let href = '/cni/custom/noticeForm.do';
                    makeHtml += '<li>';
                    makeHtml += '   <p class="board_tit"><img src="/cni/image/news01_icon.png" class="s_img">'+data.TYPE_NAME+'</p>';
                    makeHtml += '   <a href="'+href+'?seq=' + data.ID + '" class="tit elps_01 text_hover">'+data.DT+ ' ' + title + '</a>';
                    makeHtml += '   <p class="board_more"><a href="/cni/custom/notice.do">더보기</a></p>';
                    makeHtml += '</li>';
                } else {
                    let href = '/cni/air/citiesWarning.do';
                    makeHtml += '<li>';
                    makeHtml += '   <p class="board_tit"><img src="/cni/image/news02_icon.png" class="s_img">'+data.TYPE_NAME+'</p>';
                    makeHtml += '   <a href="'+href+'" class="tit elps_01 text_hover">'+data.DT+ ' ' + title + '</a>';
                    makeHtml += '   <p class="board_more"><a href="'+href+'">더보기</a></p>';
                    makeHtml += '</li>';
                }
            }
        });
        
        $('#bbs').html(makeHtml);
    });
}

// 시,군 정보 가져오기
function getRegionList() {
    $.get(
            '/cni/comm/getCommCodeList.ax'
            ,{'parent_id':'REGION_CD'}
    ).done(function(res) {
        //console.log(res);
        let makeHtml = '<option value="">시,군 선택</option>';
        $.each(res.data, function(i, data) {
            makeHtml += '<option value="'+data.CODE_ID+'">' + data.CODE_NM + '</option>' ;
        });
        
        $('#regionSel').html(makeHtml);
    });
}

// 측정소 리스트 가져오기
function getTmsList(p_region) {
    $.get(
            '/cni/comm/getCommUseTmsList.ax'
            ,{'searchRegionCode':p_region}
    ).done(function(res) {
        //console.log(res);
        let makeHtml = '<option value="">측정소 선택</option>';
        $.each(res.data, function(i, data) {
            makeHtml += '<option value="'+data.TMS_CD+'">' + data.TMS_NM + '</option>' ;
        });
        
        $('#tmsSel').html(makeHtml);
    });
}

// 측정항목 등급 가져오기
function getLevelList() {
    $.get(
            '/cni/comm/getCommLevelList.ax'
            ,{'searchItemCode':$('.tabItembtn.current-demo').data('item')}
    ).done(function(res) {
        //console.log(res);
        let makeHtml = '';
        $.each(res.data, function(i, data) {
            if(data.LEVEL_CD != 'D') {
                $('#level' + data.LEVEL_CD).find('span').text(data.L_VL + '~' + data.H_VL);
            } else {
                $('#level' + data.LEVEL_CD).find('span').text(data.L_VL + '~');
            }
            //makeHtml += '<div class="tabLevelBtn" id="level'+data.LEVEL_CD+'" data-val="'+data.LEVEL_CD+'" data-flag="true">' ;
            //makeHtml += '    <img src="/images/cni/point_'+data.LEVEL_CD+'.png" />' ;
            //makeHtml += '    <span>'+data.CODE_NM+'</span><span>'+data.L_VL+'</span> ~ <span>'+data.H_VL+'</span>' ;
            //makeHtml += '</div>' ;
        });
        
        $('#level').html(makeHtml);
    });
}

//신규팝업가져오기 > kang
function getPopup() {
	cookiedata = document.cookie; 
	$.get(
		'/cni/main/getPopup.ax'
    ).done(function(res) {
    	//console.log(res);
    	if (res && res.data && res.data.TITLE && res.data.CONTENT) {
    		if ( cookiedata.indexOf(res.data.TITLE+"=done") < 0 ) {
	    		Ext.getCmp('id_popupWindow').setTitle(res.data.TITLE);
		    	Ext.getCmp('id_contnet').setValue(res.data.CONTENT);
		    	Ext.getCmp('id_popupWindow').show();
	    	}
    	}
    });
}

//방문자수가져오기 > kang
function getVisitCnt() {
	$.get(
          '/cni/main/getVisitCnt.ax'
    ).done(function(res) {
    	if (res && res.data) {
    	 	$('#dayVisitCnt').text('Today : '+res.data.DAY_VISIT_CNT+' 명');
    		$('#totVisitCnt').text('Total : '+res.data.TOT_VISIT_CNT+' 명');
    	}
    });
}