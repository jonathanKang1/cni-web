let SEARCH_FROM_DATE;
let CHART_DATA;
let CHART_DATA2;
let CHART_DATA3;
let CHART_DATA4;
let ITEM_LEVEL = 0;
let ITEM_CHANGE_FLAG = false;
let popupParam;
let CHART;

$(function() {
    init();
    
    // 측정항목 변경 이벤트
    $('select[name=searchItemCode]').change(function() {
        ITEM_CHANGE_FLAG = true;
    });
    
    // 검색버튼 이벤트
    $('#searchBtn').click(function() {
        let searchDataType = $('input[name=searchDataType]:checked').val();
        setScreen(searchDataType);
        setDateTime();
        
        if(ITEM_CHANGE_FLAG) {
            getItemLevelInfo();
        }
        
        ITEM_CHANGE_FLAG = false;
        
        if(searchDataType == 'day') {
            getTabelData();
            // getStationData(); // 20201127 삭제요청(기능개발 완료)
            
        } else if(searchDataType == '7days') {
            getTabelData();
            
        } else if(searchDataType == 'month') {
            getTabelData();
        }
    });
    
    // 시군 클릭 시 팝업이벤트
    $(document).on('click', '.tmsPop', function() {
        console.log(popupParam);
        let url = '/cni/real/citiesDataPop.do' + popupParam + '&searchRegionCode=' + $(this).data('region');
        let name = 'TABLEPOP';
        let opt = 'width=1280,height=750,location=no,menubar=no,scrollbars=no,status=no,titlebar=no,toolbar=no';
        window.open(url, name, opt);
    });
    
});


function init() {
    // 달력 세팅
    //SEARCH_FROM_DATE = $('input[name=searchFromDate]').datepicker({autoClose: true}).data('datepicker');
    //SEARCH_FROM_DATE.selectDate(new Date());
    
    google.charts.load('current', {packages: ['corechart', 'bar']});
    
    getItemLevelInfo();
    setDateTime();
    getRegionList();
    setScreen();
    getTabelData();
    //getStationData(); // 20201127 삭제요청(기능개발 완료)
}

//시군 리스트 가져오기
let REGION_CD_ARR = [];
let REGION_ARR = [];
function getRegionList() {
    $.ajax({
        url : '/cni/comm/getCommUseRegionList.ax',
        type : 'GET',
        dataType : 'json',
        async : false
    }).done(function(res) {
        REGION_ARR = res.data;
        
//        let makeHtml = '';
//        $.each(res.data, function(i, data) {
//            makeHtml += '<option value="'+data.REGION_CD+'">'+data.REGION_NM+'</option>'; 
//        });
//        $('select[name=searchRegionCode]').html(makeHtml);
        
        makeHtml = '<th>&nbsp;</th>';
        $.each(REGION_ARR, function(i, data) {
            let nm = data.REGION_NM;
            REGION_CD_ARR.push(data.REGION_CD);
            if(nm.length > 5) {
                makeHtml += '<th id="R'+data.REGION_CD+'"><a class="f2 tmsPop" href="#" data-region="'+data.REGION_CD+'">'+nm.substring(0, 3) + '<br/>' + nm.substring(3, 7)+'</a></th>';
            } else {
                makeHtml += '<th id="R'+data.REGION_CD+'"><a class="f2 tmsPop" href="#" data-region="'+data.REGION_CD+'">'+nm+'</a></th>';
            }
        });
        
        $('#regionCnt').text(REGION_ARR.length - 1);
        $('table thead tr').html(makeHtml);
    });
}



//측정항목 정보 가져오기
function getItemLevelInfo() {
    let elem = $('option:selected', 'select[name=searchItemCode]');
    $.ajax({
            url : '/cni/comm/getCommLevelInfo.ax',
            data : {
                'searchItemCode' : elem.val(),
                'searchLevelType' : 'BASE'
            },
            type : 'GET',
            dataType : 'json',
    }).done(function(res) {
        let val = elem.val();
        let name = elem.text();
        let unit = elem.data('unit');
        let fullName = name + '(' + unit + ')';
        
        if(res.data.length > 0) {
            ITEM_LEVEL = res.data.L_VL;
        }
        
        $('.unit').text(unit);
        //$('.itemSelName').text(fullName);
        //$('#itemLvl').text(setBaseline(ITEM_LEVEL) + unit);
        
    });
}


// 화변 기본 정보들 표시
function setScreen(searchDataType) {
    let item = $('option:selected', 'select[name=searchItemCode]').val();
    
    
    if(searchDataType == 'day') {
        //$('#regionName').text($('option:selected', 'select[name=searchRegionCode]').text());
        $('#chart1').css({'height' : '250px'});
        //$('#stationDataArea').show();
        $('#subTitle01').text('시간자료(수치)');
        $('#sub01List').show();
        $('sub02List').show();
    } else if(searchDataType == '7days') {
        $('#chart1').css({'height' : '400px'});
        $('#stationDataArea').hide();
        $('#subTitle01').text('당일평균');
        $('#sub01List').hide();
        $('#sub02List').hide();
    } else if(searchDataType == 'month') {
        $('#chart1').css({'height' : '400px'});
        $('#stationDataArea').hide();
        $('#subTitle01').text('당일평균');
        $('#sub01List').hide();
        $('#sub02List').hide();
    }
    
    if(item == 'PM2') {
        $('#onlyPm25').show();
    } else {
        $('#onlyPm25').hide();
    }
}


// 현재 측정 데이터 날짜 표시
function setDateTime() {
    // 측정시간 세팅
    let dt = moment(new Date(), "YYYYMMDDHH").subtract(1, 'hours').toDate(); // 2시간 전
    let y = dt.getFullYear() < 10 ? '0' + dt.getFullYear() : dt.getFullYear();
    let m = dt.getMonth() + 1;
        m = m < 10 ? '0' + m : m;
    let d = dt.getDate() < 10 ? '0' + dt.getDate() : dt.getDate();
    let h = dt.getHours() < 10 ? '0' + dt.getHours() : dt.getHours();
    $('#dateTime').text(y + '-' + m + '-' + d + ' ' + h + '시');
    
    // 월별 콤보박스
    let curDate = moment().toDate();
    let minDate = moment('20200101').toDate();
    let endDate = y + '' + m;
    for(i=0; i<15; i++) {
        if(curDate < minDate) {
            return false;
        } else {
            y = curDate.getFullYear() < 10 ? '0' + curDate.getFullYear() : curDate.getFullYear();
            m = curDate.getMonth() + 1;
            m = m < 10 ? '0' + m : m;
            curDate = moment(curDate).subtract(1, 'month').toDate(); // 한달 빼기
            $('select[name=searchMonthDate]').append('<option value="'+(y+ '' + m)+'">'+y+'년 ' + m + '월</option>');
        }
    }
}


// 테이블 데이터 가져오기
function getTabelData() {
    $('input[name=searchRegionMulti]').val(REGION_CD_ARR.toString());
    
    let param = {
        'searchItemCode' : $('select[name=searchItemCode]').val(),
        'searchDataType' : $('input[name=searchDataType]:checked').val(),
        'searchMonthDate' : $('select[name=searchMonthDate]').val(),
        'searchRegionMulti' : REGION_CD_ARR.toString(),
        'searchUnit' : $('select[name=searchItemCode] option:selected').data('unit'),
        'searchValidChiper' : $('select[name=searchItemCode] option:selected').data('valid'),
    };
    $.get(
            '/cni/real/getRealCitiesTableData.ax',
            param
    ).done(function(res) {
        console.log(res);
        let searchDataType = $('input[name=searchDataType]:checked').val();
        
        if(searchDataType == 'day') {
            setDayData(res);
        } else if(searchDataType == '7days') {
            set7DaysData(res);
        } else if(searchDataType == 'month') {
            setMonthData(res);
        }
        
        // 팝업 시 사용할 파라메터 정보
        popupParam = '?searchItemCode='+param.searchItemCode+'&searchMonthDate='+param.searchMonthDate+'&searchDataType='+param.searchDataType+'&searchValidChiper='+param.searchValidChiper+'&searchUnit='+param.searchUnit;
    })
}

// 당일 데이터 세팅(테이블과 시군별만)
function setDayData(res) {
    let makeHtml = '';
    let index = 0;
    let flag = false;
    
    CHART_DATA = [['시군구', '수치', '']];
    
    $.each(res.data, function(i, data) {
        if(i == 0) {
            makeHtml += '<tr><th>시간평균</th>';
        } else if(i == 1) {
            makeHtml += '<tr><th>일평균</th>';
        } else if(i == 2) {
            makeHtml += '<tr><th>최고값</th>';
        } else if(i == 3) {
            makeHtml += '<tr><th>최저값</th>';
        }
        
        $.each(REGION_ARR, function(j, region) {
            let val = data['R'+region.REGION_CD];
            makeHtml += '<td>';
            makeHtml += val || '-';
            makeHtml += '</td>';
            
            // 일 평균 값 일때 차트 값 구성하기
            if(i == 0) {
                let arr = [];
                arr.push(region.REGION_NM);
                arr.push(val || 0);
                arr.push(setBaseline(ITEM_LEVEL));
                CHART_DATA.push(arr);
                
                if(val){
                    flag = true;
                }
            }
        });
        
        makeHtml += '</tr>';
    });
    
    if(!flag) {
        options1.vAxis.viewWindow.max = 10;
        options1.vAxis.viewWindow.min = 0;
    } else {
        options1.vAxis.viewWindow = {min:0};
    }
    
    $('#citiesDataTable tbody').html(makeHtml);
    google.charts.setOnLoadCallback(drawColumn1); // 차트
}

var options1 = {
        legend: 'none', // { position: 'bottom' },
        series: {1: {
            type: "steppedArea", 
            color: '#AA0000', 
            visibleInLegend: false, 
            areaOpacity: 0}
        },
        chartArea: {'width': '90%', 'height': '70%'},
        vAxis: {
            title: $('option:selected', 'select[name=searchItemCode]').data('unit'),
            minValue: 0,
            viewWindow: {min:0},
        },
        hAxis: {
            textStyle: {fontSize:8},
            //showTextEvery : 1,
            slantedTextAngle : 45
        },
        animation:{
            duration: 1000,
            easing: 'out',
            startup: true
        },
};

// 디바이스 형식에 따라 fontSize 재설정
if(isDesktopOS() && !isMobile) {
    options1.hAxis.textStyle.fontSize = 10;
}

function drawColumn1() {
    var data = google.visualization.arrayToDataTable(CHART_DATA);
    CHART = new google.visualization.ColumnChart(document.getElementById('chart1'));
    CHART.draw(data, options1);
}


function getStationData() {
    let flag = false;
    CHART_DATA2 = [['측정소', '수치', '']];
    
    $.get(
            '/cni/real/getRealCitiesChartData.ax',
            {
                'searchItemCode' : $('select[name=searchItemCode]').val(),
                'searchDataType' : $('input[name=searchDataType]').val(),
                'searchMonthDate' : $('select[name=searchMonthDate]').val(),
                'searchRegionCode' : $('select[name=searchRegionCode]').val(),
            }
    ).done(function(res) {
        $.each(res.data, function(i, data) {
            let arr = [];
            arr.push(data.TMS_NM);
            arr.push(parseFloat(data.MSR_VL || 0));
            arr.push(setBaseline(ITEM_LEVEL));
            CHART_DATA2.push(arr);
            
            if(data.MSR_VL){
                flag = true;
            }
        })
        
        if(!flag) {
            options2.vAxis.viewWindow.max = 10;
            options2.vAxis.viewWindow.min = 0;
        } else {
            options2.vAxis.viewWindow = {min:0};
        }
        
        google.charts.setOnLoadCallback(drawColumn2); // 차트
    })
}


var options2 = {
        legend: 'none', // { position: 'bottom' },
        series: {1: {
            type: "steppedArea", 
            color: '#AA0000', 
            visibleInLegend: false, 
            areaOpacity: 0}
        },
        chartArea: {'width': '90%', 'height': '70%'},
        vAxis: {
            title: $('option:selected', 'select[name=searchItemCode]').data('unit'),
            minValue: 0,
            viewWindow: {min:0},
        },
        hAxis: {textStyle: {fontSize:10},
        },
        animation:{
            duration: 1000,
            easing: 'out',
            startup: true
        },
};
function drawColumn2() {
    var data = google.visualization.arrayToDataTable(CHART_DATA2);
    var chart = new google.visualization.ColumnChart(document.getElementById('chart2'));
    chart.draw(data, options2);
}


// 7일간 자료구분 데이터 세팅
function set7DaysData(res) {
    let makeHtml = '';
    let index = 0;
    let flag = false;
    let headerArr = ['날짜'];
    $.each(REGION_ARR, function(j, region) {
        headerArr.push(region.REGION_NM);
    });
    headerArr.push('');
    
    CHART_DATA3 = [headerArr];
    
    $.each(res.data, function(i, data) {
        makeHtml += '<tr>';
        makeHtml += '<td>'+data.DSP_DT+'</td>';
        
        let arr = [];
        arr.push(data.DSP_DT);
        
        $.each(REGION_ARR, function(j, region) {
            let val = data['R'+region.REGION_CD];
            makeHtml += '<td>';
            makeHtml += val || '-';
            makeHtml += '</td>';
            
            arr.push(val || 0);
            
            if(val){
                flag = true;
            }
        });
        makeHtml += '</tr>';
        
        if(!flag) {
            options3.vAxis.viewWindow.max = 10;
            options3.vAxis.viewWindow.min = 0;
        } else {
            options3.vAxis.viewWindow = {min:0};
        }
        
        console.log(ITEM_LEVEL);
        arr.push(setBaseline(ITEM_LEVEL));
        CHART_DATA3.push(arr);
    });
    
    $('#citiesDataTable tbody').html(makeHtml);
    google.charts.setOnLoadCallback(drawColumn3); // 차트
}


var options3 = {
        legend: {
            position: 'top',
            maxLines : 4,
            textStyle : {
                fontSize : 12
            }
        },
        chartArea: {'width': '90%', 'height': '60%', 'top': '25%'},
        vAxis: {
            title: $('option:selected', 'select[name=searchItemCode]').data('unit'),
            minValue: 0,
            viewWindow: {min:0}
        },
        hAxis: {textStyle: {fontSize:12},
        }
};
function drawColumn3() {
    options3.series = {
        [REGION_ARR.length]: {
            type: "steppedArea", 
            color: '#AA0000', 
            visibleInLegend: false, 
            areaOpacity: 0
        }
    };
    var data = google.visualization.arrayToDataTable(CHART_DATA3);
    var chart = new google.visualization.LineChart(document.getElementById('chart1'));
    chart.draw(data, options3);
    visibleDataColumns(chart, data, options3) // 차트 범예 이벤트
}



//7일간 자료구분 데이터 세팅
function setMonthData(res) {
    let makeHtml = '';
    let index = 0;
    let headerArr = ['날짜'];
    $.each(REGION_ARR, function(j, region) {
        headerArr.push(region.REGION_NM);
    });
    headerArr.push('');
    
    CHART_DATA3 = [headerArr];
    
    $.each(res.data, function(i, data) {
        makeHtml += '<tr>';
        makeHtml += '<td>'+data.DSP_DAY+'</td>';
        
        let arr = [];
        arr.push(data.DSP_DAY);
        
        $.each(REGION_ARR, function(j, region) {
            let val = data['R'+region.REGION_CD];
            makeHtml += '<td>';
            makeHtml += val || '-';
            makeHtml += '</td>';
            
            arr.push(val || 0);
        });
        
        makeHtml += '</tr>';
        
        arr.push(setBaseline(ITEM_LEVEL));
        CHART_DATA3.push(arr);
    });
    
    $('#citiesDataTable tbody').html(makeHtml);
    google.charts.setOnLoadCallback(drawColumn3); // 차트
}