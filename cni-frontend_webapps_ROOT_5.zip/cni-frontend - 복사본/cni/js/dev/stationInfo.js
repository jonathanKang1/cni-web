const DEFAULT_REGION = 44200;
const DEFAULT_TMS = 20038000;

$(function() {
    init();
    
    // 조회 버튼 이벤트
    $('#searchBtn').click(function() {
        getStationList();
    });
    
    // 측정망 변경 이벤트
    $('#netSel').change(function() {
        getSelTmsList();
    });
    
    // 측정소 클릭 시
    $(document).on('click', '#stationTable tbody tr', function() {
        let tmsCd = $(this).data('cd');
        $('.map_marker.on img').attr('src', '/cni/image/map_markerX.png');
        $('.map_marker').removeClass('on');
        $('#' + tmsCd).find('img').attr('src', '/cni/image/map_markerA.png');
        $('#' + tmsCd).addClass('on');
    });
    
});


// 기본 세팅
function init() {
    //getSelNetList();
    getSelTmsList();
    getStationList();
}

// 시,군 정보 가져오기
function getSelNetList() {
    $.get(
            '/cni/comm/getCommCodeList.ax'
            ,{'parent_id':'NET_CD'}
    ).done(function(res) {
        console.log(res);
        let makeHtml = '<option value="">전체</option>';
        $.each(res.data, function(i, data) {
            makeHtml += '<option value="'+data.CODE_ID+'">' + data.CODE_NM + '</option>' ;
        });
        
        $('#netSel').html(makeHtml);
    });
}

// 측정소 리스트 가져오기
function getSelTmsList(p_region) {
    console.log({'searchNetCode':$('#netSel').val()});
    $.get(
            '/cni/comm/getCommUseTmsList.ax'
            ,{'searchNetCode':$('#netSel').val()}
    ).done(function(res) {
        console.log(res);
        let makeHtml = '<option value="">측정소 전체</option>';
        $.each(res.data, function(i, data) {
            makeHtml += '<option value="'+data.TMS_CD+'">' + data.TMS_NM + '</option>' ;
        });
        
        $('#tmsSel').html(makeHtml);
    });
}

// 측정소 리스트 가져오기
function getStationList() {
    console.log({
        'searchNetCode':$('#netSel').val(),
        'searchTmsCode':$('#tmsSel').val()
    });
    $.get(
            '/cni/comm/getCommUseTmsList.ax'
            ,{
                'searchNetCode':$('#netSel').val(),
                'searchTmsCode':$('#tmsSel').val()
            }
    ).done(function(res) {
        console.log(res);
        let makeHtml1 = '';
        let makeHtml2 = '';
        $('#map span').remove();
        
        $.each(res.data, function(i, data) {
            let tmsNm = data.TMS_NM;
            let tmsCd = data.TMS_CD;
            let xPos = data.XPOS;
            let yPos = data.YPOS;
            
            // 마커
            makeHtml1 += '<span class="map_marker marker" id="station'+tmsCd+'" style="top:'+yPos+'px;left: '+xPos+'px;position:absolute;"><img src="/cni/image/map_markerX.png"></span>';
            
            // 테이블 리스트
            makeHtml2 += '<tr data-cd="station'+tmsCd+'">' ;
            makeHtml2 += '    <th>'+data.CODE_NM+'</th>' ;
            makeHtml2 += '    <th>'+tmsNm+'</th>' ;
            makeHtml2 += '    <td>'+data.ADDR+'</td>' ;
            makeHtml2 += '</tr>' ;
        });
        
        $('#map').prepend(makeHtml1);
        $('#stationTable tbody').html(makeHtml2);
    });
}
