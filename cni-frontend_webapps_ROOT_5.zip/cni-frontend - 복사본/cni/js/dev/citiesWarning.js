let SEARCH_FROM_DATE, SEARCH_TO_DATE;
$(function() {
    init();
    
    // 탭 이벤트
    $('input[name=tabs]').click(function() {
        let val = $(this).attr('id');
        if(val == 'tab1') {
            getTab1TabelData();
        } else if(val == 'tab2') {
            getTab2TabelData()
        } else if(val == 'tab3') {
            //getTab3TabelData()
        }
    });
    
    // 검색버튼 이벤트
    $('.searchBtn').click(function() {
        let val = $(this).data('tab');
        if(val == 'tab1') {
            getTab1TabelData();
        } else if(val == 'tab2') {
            getTab2TabelData();
        } else if(val == 'tab3') {
            getTab3TabelData();
        }
    });
    
    // 검색영역 변경 이벤트
    $('select[name=searchTmsCode]').change(function() {
        //$('select[name=searchTmsCode]').val($('option:selected', this).val());
    });
    $('input[name=searchDataType]').change(function() {
        let val = $(this).val();
        
        if(val == 'hour') {
            $('select[name=searchFromTime]').show();
            $('select[name=searchToTime]').show();
        } else {
            $('select[name=searchFromTime]').hide();
            $('select[name=searchToTime]').hide();
        }
        
        $('input[name=searchDataType][value='+val+']').prop('checked', true);
    });
});


function init() {
    // 달력 세팅
    SEARCH_FROM_DATE = $('input[name=searchFromDate]').datepicker({autoClose: true}).data('datepicker');
    SEARCH_TO_DATE = $('input[name=searchToDate]').datepicker({autoClose: true}).data('datepicker');
    let dt = new Date();
    SEARCH_TO_DATE.selectDate(dt);
    dt.setMonth(dt.getMonth() - 2);
    SEARCH_FROM_DATE.selectDate(dt);
    getStationList();
    //getRegionList();
    getTab1TabelData()
}

//측정소 리스트 가져오기
function getStationList() {
    $.ajax({
            url : '/cni/comm/getCommUseTmsList.ax',
            type : 'GET',
            dataType : 'json',
            async : false
    }).done(function(res) {
        let makeHtml = '<option value="">전체</option>';
        $.each(res.data, function(i, data) {
            makeHtml += '<option value="'+data.TMS_CD+'">'+data.TMS_NM+'</option>'; 
        });
        $('.searchTmsCode').html(makeHtml);
    });
}


//시군 리스트 가져오기
function getRegionList() {
    $.ajax({
        url : '/cni/comm/getCommUseRegionList.ax',
        type : 'GET',
        dataType : 'json',
        async : false
    }).done(function(res) {
        let makeHtml = '<option value="">전체</option>';
        $.each(res.data, function(i, data) {
            makeHtml += '<option value="'+data.TMS_CD+'">'+data.TMS_NM+'</option>'; 
        });
        $('select[name=searchRegionCode]').html(makeHtml);
    });
}

function getTab1TabelData(p_pageNum) {
    let pageNum = p_pageNum || 1;
    let elem = $('#content1');
    $.get(
            '/cni/air/getCitiesWarningData.ax',
            {
                'searchTmsCode' : elem.find('select[name=searchTmsCode]').val(),
                'searchItemCode' : elem.find('select[name=searchItemCode]').val(),
                'searchFromDate' : elem.find('input[name=searchFromDate]').val(),
                'searchToDate' : elem.find('input[name=searchToDate]').val(),
                'pageNum' : pageNum
            }
    ).done(function(res) {
        console.log(res);
        let makeHtml = '';
        let totalCount = res.totalCount.CNT;
        let no = totalCount - (pageNum - 1) * PAGE_SIZE;
        
        if(res.data.length == 0) {
            makeHtml += '<tr><td colspan="8">검색된 조건값이 존재하지 않습니다.</td></tr>';
        }
        
        $.each(res.data, function(i, data) {
            makeHtml += '<tr>';
            makeHtml += '   <th>'+no+'</th>';
            makeHtml += '   <td>'+(data.REGION_NM || '-')+'</td>';
            makeHtml += '   <td>'+(data.TMS_NM || '-')+'</td>';
            makeHtml += '   <td>'+(data.ITEM_NM || '-')+'</td>';
            makeHtml += '   <td>'+(data.WARNING_NM || '-')+'</td>';
            makeHtml += '   <td>'+(data.WARNING_DT || '-')+'</td>';
            makeHtml += '   <td>'+(data.RESET_NM || '-')+'</td>';
            if(data.RESET_CD == '-') {
                makeHtml += '   <td></td>';
            } else {
                makeHtml += '   <td>'+(data.RESET_DT || '-')+'</td>';
            }
            makeHtml += '</tr>';
            
            no--;
        });
        
        let opt = {
                frm : "searchForm1",
                attrId : 'divPageNavigator1',
                pageNum : pageNum,
                pageSize : PAGE_SIZE,
                totalCount : totalCount,
        };
        setPagingNavigator(opt);
        
        elem.find('table tbody').html(makeHtml);
    });
}


function getTab2TabelData() {
    let elem = $('#content2');
    $.get(
            '/cni/air/getCitiesWarningYearData.ax',
            {
                'searchYear' : elem.find('select[name=searchYear]').val(),
                'searchItemCode' : elem.find('select[name=searchItemCode]').val(),
            }
    ).done(function(res) {
        console.log(res);
        let makeHtml = '';
        let no = 0;
        let beforeRegionCd;
        $.each(res.data, function(i, data) {
            
            if(beforeRegionCd !=null && data.REGION_CD != beforeRegionCd) {
                no = 1;
                makeHtml += '<tr class="bold">';
            } else {
                no++;
                makeHtml += '<tr>';
            }
            
            makeHtml += '   <th>'+no+'</th>';
            makeHtml += '   <td>'+(data.REGION_NM || '-')+'</td>';
            makeHtml += '   <td>'+(data.TMS_NM || '-')+'</td>';
            makeHtml += '   <td>'+(data.ITEM_NM || '-')+'</td>';
            makeHtml += '   <td>'+(data.WARNING_NM || '-')+'</td>';
            makeHtml += '   <td>'+(data.WARNING_DT || '-')+'</td>';
            makeHtml += '   <td>'+(data.RESET_DT || '-')+'</td>';
            makeHtml += '</tr>';
            
            beforeRegionCd = data.REGION_CD;
        });
        
        elem.find('table tbody').html(makeHtml);
    });
}

let DATA = [['Year', 'Sales', '']];
function getTab3TabelData() {
    let elem = $('#content3');
    $.get(
            '/cni/air/getCitiesWarningRegData.ax',
            {
                'searchRegionCode' : elem.find('select[name=searchRegionCode]').val(),
                'searchItemCode' : elem.find('select[name=searchItemCode]').val()
            }
    ).done(function(res) {
        console.log(res);
        let makeHtml = '';
        
        google.charts.load('current', {packages: ['corechart', 'bar']});
        google.charts.setOnLoadCallback(drawColumn);
    });
}


function drawColumn() {
    var redCross = '#ff0000';
    var blueCross = '#0000ff';
    var data = new google.visualization.arrayToDataTable([
        ['측정소', '수치',  {'role': 'style'}, ''],
        ['서울', 12, redCross, 10],
        ['인천', 11, null, 10],
        ['경기', 10, null, 10],
        ['경기2', 10, null, 10],
        ['경기3', 10, null, 10],
        ['경기4', 10, null, 10],
    ]);

    var options = {
      colors : ['#33bb33'],
      legend : 'none', // { position: 'bottom' }
      series: {1: {
          type: "steppedArea", 
          color: '#AA0000', 
          visibleInLegend: false, 
          areaOpacity: 0}
      },
      vAxis: {
        title: 'cm',
        minValue: 0,
        viewWindow: {min:0},
      },
      animation:{
          duration: 1000,
          easing: 'out',
          startup: true
      },
    };

    var chart = new google.visualization.ColumnChart(document.getElementById('chart1'));
    chart.draw(data, options);
    
}


/**
 * 리스트 페이징 생성
 * @param option {frm, attrId, pageNum, totalCount, pageSize, visible}
 */
function setPagingNavigator(p_opt) {
    let opt = p_opt || {};
    var frm = opt.frm || 'searchForm',
        attrId = opt.attrId || 'divPageNavigator', 
        pageNum = opt.pageNum || 1, 
        pageSize = opt.pageSize || 10, 
        totalCount = opt.totalCount || 0, 
        visible = opt.visible || false;
    
    // 페이징 생성
    var oPageNavigator = new PageNavigator(
            document.getElementById(attrId), 
            function(pageNum) {
                if(frm == 'searchForm1') {
                    getTab1TabelData(pageNum);
                } else if(frm == 'searchForm2') {
                    getTab2TabelData(pageNum);
                } else if(frm == 'searchForm3') {
                    //getTab3TabelData(pageNum);
                }
            },
            { 
                firstVisible:visible
                , lastVisible:visible
                , prevClassName : 'prev'
                , nextClassName : 'next' 
                //, firstClassName : 'first'
                //, lastClassName : 'end'
                , currentClassName: "on"
                , currentNodeType:"A"
                , prevTags:"&lt;&lt;"
                , nextTags:"&gt;&gt;"
            }
    );
    
    oPageNavigator.show(pageNum, Math.ceil(totalCount/pageSize), 5);
}