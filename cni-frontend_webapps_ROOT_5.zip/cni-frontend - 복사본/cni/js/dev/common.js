const RS_IMG_PATH = '/cni/image/';
const PAGE_SIZE = 10;

$(document).ready(function () {

    $(".more-btn").mouseover(function() {
    	$(this).attr("src", $(this).attr("src").replace("out","over"));
    });

    $(".more-btn").mouseleave(function() {
    	$(this).attr("src", $(this).attr("src").replace("over","out"));
    });
    
    /*family*/
    var sw=true;
    $('.family button').click(function(){
	    sw = !sw;
	    if(sw==true){
	    	$('.family .family_list').hide();
	    } else {
	    	$('.family .family_list').show();
	    }
    });
    
    // 인쇄 버튼
    $('.btn_print').click(function() {
        window.print();
    });
    
    // 엑셀버튼 이벤트
    $('.btn_excel').click(function() {
        let frm = $(this).parents('form');
        frm.attr('method', 'POST');
        frm.attr('action', '/cni/comm/excelFile.do');
        frm.submit();
    });
    
    
    // 차트 이미지 다운로드
    $('.downloadChartImg').click(function(e) {
        e.preventDefault();
        let id = $(this).data('id');
        let frm = $('#chartImgForm');
        let img;
        
        if(id == 'chart1') {
            img = CHART1.getImageURI();
        } else if(id == 'chart2'){
            img = CHART2.getImageURI();
        } else if(id == 'chart3'){
            img = CHART3.getImageURI();
        } else if(id == 'chart4'){
            img = CHART4.getImageURI();
        } else if(id == 'chart5'){
            img = CHART5.getImageURI();
        } else if(id == 'chart6'){
            img = CHART6.getImageURI();
        } else if(id == 'chart7'){
            img = CHART7.getImageURI();
        } else {
            img = CHART.getImageURI();
        }
        
        $('#imgSrc').val(img);
        frm.attr('method', 'post');
        frm.attr('action', '/cni/comm/chartDownloadImg.do');
        frm.submit();
    });
});


// 등급 색코드
function getGradeColorCode(p_lvl) {
    if(p_lvl == 'A') {
        return '#006cb1';
    } else if(p_lvl == 'B') {
        return '#65b24b';
    } else if(p_lvl == 'C') {
        return '#d5b60e';
    } else if(p_lvl == 'D') {
        return '#e94045';
    } else {
        return '#626262';
    }
}

//등급 텍스트
function getGradeColorTxt(p_level) {
    if(p_level == 'A') {
        return 'blue';
    } else if(p_level == 'B') {
        return 'green';
    } else if(p_level == 'C') {
        return 'yellow';
    } else if(p_level == 'D') {
        return 'red';
    } else {
        return '';
    }
}

// 빈값 체크
function isEmpty(str) {
    return str == null || $.trim(str).length == 0;
}


// 빈값 체크 후 치환
function isNull(p_val, p_repl) {
    if(p_val == null) {
        return p_repl;
    } else {
        return p_val;
    }
}

// 기준값 -1 또는 소수 한자리 삭제
function setBaseline(p_val) {
    if(p_val == null) {
        return 0;
    }
    
    p_val = p_val.toString();
    let len = p_val.indexOf('.');
    
    if(len == -1) {
        return parseInt(p_val)-1;
    } else {
        let v = p_val.substring(len + 1, p_val.length - 1);
        let r = p_val.substring(0, len);
        return parseFloat(r + "." + v);
    }
}

// 문자를 숫자로
function convertNumber(p_val) {
    if(p_val == null || !p_val) {
        return 0;
    }
    
    p_val = p_val.toString();
    let len = p_val.indexOf('.');
    
    if(len == -1) {
        return parseInt(p_val);
    } else {
        return parseFloat(p_val);
    }
}


// 차트 범례(legend) 클릭 시 show/hide 처리
function visibleDataColumns(p_chart, p_data, p_options) {
    var columns = [];
    var series = {};
    
    for (var i = 0; i < p_data.getNumberOfColumns(); i++) {
      columns.push(i);
      if (i > 0) {
        series[i - 1] = {};
      }
    }
    
    google.visualization.events.addListener(p_chart, 'select', function() {
        var sel = p_chart.getSelection();
        if (sel.length > 0) {
          if (sel[0].row === null) {
            var col = sel[0].column;
            if (columns[col] == col) {
              columns[col] = {
                label: p_data.getColumnLabel(col),
                type: p_data.getColumnType(col),
                calc: function() {
                  return null;
                }
              };
              series[col - 1].color = '#CCCCCC';
              
            } else {
              columns[col] = col;
              series[col - 1].color = null;
            }
            
            var view = new google.visualization.DataView(p_data);
            view.setColumns(columns);
            p_chart.draw(view, p_options);
          }
        }
      });
}


// 반응형 웹 디바이스 체크
function isDesktopOS(){
    return ( 'win16|win32|win64|windows|mac|macintel|linux|freebsd|openbsd|sunos'.indexOf(navigator.platform.toLowerCase()) >= 0 );
}
var isMobile = /Mobi/i.test(window.navigator.userAgent);

/**
 * contextpath 생성
 * @returns
 */
function getContextPath() {
    var hostIndex = location.href.indexOf(location.host) + location.host.length;
    var contextPath= location.href.substring(hostIndex, location.href.indexOf('/', hostIndex + 1));
    return contextPath; 
}