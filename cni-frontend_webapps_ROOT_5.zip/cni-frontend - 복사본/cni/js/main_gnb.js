// JavaScript Document


 $(function () {
             $("#main_gnb > div > ul > li").hover(
                  function () {
                       $("#main_gnb").addClass("active");
                  },
                  function () {
                       $("#main_gnb").removeClass("active");
                  }
             );
 
             $("#main_gnb > div > ul > li:first-child > a").focusin(function () {
                 $("#main_gnb").addClass("active");
             });
             $("#main_gnb li:last-child li:last-child a").focusout(function () {
                 $("#main_gnb").removeClass("active");
             });
             $("#main_gnb > div > ul > li > a").focusin(function () {
                  $(this).parent().addClass("active");
             });
             $("#main_gnb li li:last-child a").focusout(function () {
                $("#main_gnb > div > ul > li").removeClass("active");
             });

        });