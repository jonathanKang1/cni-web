function setCookie( name, value, expiredays ) {
    var todayDate = new Date();
        todayDate.setDate( todayDate.getDate() + expiredays );
        document.cookie = name + "=" + escape( value ) + "; path=/; expires=" + todayDate.toGMTString() + ";"
}

function closeWin(div, chk, cookname) {
    if ( document.getElementById(chk).checked ){
        setCookie(cookname, "done", 1);
    }
    document.getElementById(div).style.visibility = "hidden";
}

window.onload = function() {
   cookiedata = document.cookie; 
   /* popup1 메인 고정 공지팝업 비활성화 > kang*/
   /*if ( cookiedata.indexOf("maindiv=done") < 0 ){   
     document.getElementById('divpop').style.visibility = "visible";
   } else {
     document.getElementById('divpop').style.visibility = "hidden";
   }*/

   /* popup2 */
//   if ( cookiedata.indexOf("maindiv2=done") < 0 ){   
//     document.getElementById('divpop2').style.visibility = "visible";
//   } else {
//     document.getElementById('divpop2').style.visibility = "hidden";
//   }
}