$(document).ready(function(){

    uiDom();
      //화면 확대 축소
       $zoom_small.on('click',function(){ zoomSmall();});
       $zoom_big.on('click',function(){ zoomBig(); });
       $zoom_defalut.on('click',function(){ zoomDefault(); });
    });
    
    
    var $zoom_defalut,$zoom_big,$zoom_small,nowZoom,maxZoom,minZoom;
    function uiDom(){
       $zoom_defalut = $('.zoom_default');
       $zoom_big = $('.zoom_big');
       $zoom_small = $('.zoom_small');
       nowZoom = 100;
       maxZoom = 200;
       minZoom = 80;
    }
    
    /*화면 확대 축소(s)*/
    function zoomSmall(){ 
       if (nowZoom > minZoom){ 
           nowZoom -= 10; //10%씩 작아진다. 
       }else{ 
           return; 
       } 
    document.getElementById("map_zoom").style.zoom = nowZoom + "%"; 
    }
    
    function zoomBig(){ 
           if (nowZoom < maxZoom){ 
               nowZoom += 10; //10%씩 커진다. 
           }else{ 
               return; 
           }   
        document.getElementById("map_zoom").style.zoom = nowZoom + "%"; 
    } 
    function zoomDefault(){ 
       nowZoom = 100; 
       document.getElementById("map_zoom").style.zoom = nowZoom + "%"; 
    }